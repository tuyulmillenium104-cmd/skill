# FINAL AUDIT - The Apology / mission-0 "The Apology"

Campaign: 0x5ee21727Adf112b090Df09B1dA54d9CE381785E5 | Mission: mission-0 | Data: 110 mission-0 submissions, 10 winners.

## Content
- Opener: "This apology belongs to the woman who cleaned the office I worked in at nineteen." (1047 chars)
- Lane: an apology to an invisible service worker (office cleaner). UNSATURATED standout lane: the stranger/service-worker target that produced several winners (bus driver, baggage handler, blood volunteer, swim coach). Avoids the saturated younger-self (47), mother (29), lost-touch friend (16) lanes.
- Mention: omitted by design. No @RallyOnChain mention is required for this campaign; 5 of 10 winners used none. Forcing a brand tag would break the honest, non-performing style.

## Gate status
| Gate | Result | Note |
|---|---|---|
| Compliance | PASS | no em dash; does not start with mention/hashtag; honest/vulnerable |
| Loser-DNA scan | PASS (clean) | rewrote saturated 5-gram opener "I owe an apology to" |
| Originality saturation | PASS | nearest lexical sim 0.13, below the 0.14 review line |
| OAA structure | PASS | 0 errors, 1 warning |
| TQ format | PASS | 0 errors |
| IA claim boundary | PASS | 0 errors |
| EP compactness | FAIL (>850) | GENRE ARTIFACT: winners changzhcrypto (1332), somonia14 (1317), kalvinkai08 (1191) all FAIL and exceed the hard 1050 cap; this content (1047) stays under it |
| RQ prompt-answer | PASS 20/20 | |
| RQ mechanics calibration | PASS | mechanics 11/20, skeptic 6/20, 4 categories |
| Final integrity | PASS | content 1047, Q=20, A=20, no em dash, sections present |

## Honest status
- RQ5-READY, not guaranteed RQ 5/5. RQ is author-portable and depends on real external replies, sub-30-minute reply speed, the judge, and the posting account.
- Compactness FAIL is a DOCUMENTED confessional-genre artifact (proven by running the same tool on winning entries). The real gates for this campaign (Compliance, Loser-DNA, Originality, OAA, TQ, IA, length under the hard cap) all PASS.
