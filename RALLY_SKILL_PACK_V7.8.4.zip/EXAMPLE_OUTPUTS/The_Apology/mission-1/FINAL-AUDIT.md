# FINAL AUDIT - The Apology / mission-1 "Why You Never Said It"

Campaign: 0x5ee21727Adf112b090Df09B1dA54d9CE381785E5 | Mission: mission-1 | Data: 64 mission-1 submissions, 2 winners (small winner pool; supplemented with top OAA-max non-winners as DNA signal).

## Content
- Opener: "For years I told people the moment for that apology was simply gone. That was the clean version." (1038 chars)
- Lane: the real reason for silence = protecting a flattering self-story (the apology would force admitting a permanent flaw). UNSATURATED self-image-protection lane (only 2 entries), where both winners landed. Avoids the saturated surface reasons stated AS the answer: younger-self (38), pride (27), fear-of-rejection (24), timing/too-late (21).
- Mention: omitted by design (not required; neither winner used one).

## Gate status
| Gate | Result | Note |
|---|---|---|
| Compliance | PASS | no em dash; does not start with mention/hashtag; honest/vulnerable |
| Loser-DNA scan | PASS (clean) | rewrote saturated 5-grams ("as long as I stayed silent", "too much time had passed", "to face the version of") |
| Originality saturation | REVIEW (0.15) | GENRE ARTIFACT: OAA-max-vs-OAA-max lexical similarity reaches 0.586 in this dataset; brief mandates shared vocab. This content sits far below that floor. |
| OAA structure | PASS | 0 errors, 1 warning |
| TQ format | PASS | 0 errors |
| IA claim boundary | PASS | 0 errors |
| EP compactness | FAIL (>850) | GENRE ARTIFACT: winner maimelee (1324) and top scorers changzhcrypto (1344), cl_samm (1692) all FAIL and exceed the hard 1050 cap; this content (1038) stays under it. |
| RQ prompt-answer | PASS 20/20 | |
| RQ mechanics calibration | PASS | mechanics 9/20, skeptic 6/20, 4 categories; 0 tier-A failures |
| Final integrity | PASS | content 1038, Q=20, A=20, no em dash, sections present |

## Honest status
- RQ5-READY, not guaranteed RQ 5/5. RQ is author-portable and depends on real external replies, sub-30-minute reply speed, the judge, and the posting account.
- ORIGINALITY REVIEW and Compactness FAIL are DOCUMENTED confessional-genre artifacts (proven by running the same tools on winning/OAA-max entries). The real gates (Compliance, Loser-DNA, OAA, TQ, IA, length under the hard cap) all PASS.
- Winner pool here is only 2 (campaign period may be incomplete), so Winner DNA was supplemented with the top OAA-max non-winners. Treat the DNA as strong-signal but thinner than a fully-settled campaign.
