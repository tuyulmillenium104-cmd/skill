# RALLY ENGINE - SKILL PACK (V7.8.4, real-judge URL+length guard)

Ready-to-use Rally campaign toolkit. Drop this folder into a new chat/workspace and go.

## What is inside
- `RALLY_ENGINE/skills/` - all rally-*.py gate tools + engine docs (.md).
  - NEW in V7.8.4: `rally-preflight-url-length.py` (catches the URL/length bugs real
    judges punished). `rally-tq-format-audit.py`, `rally-compliance-gate.py`,
    `rally-final-integrity-check.py` now also block malformed URLs.
  - `RALLY-QNA-ENGINE-V2.md` - the 20-pair reply-pack methodology (Q-COPY/A-COPY,
    gate-pass format, strongest->weakest ranking rubric).
  - `RQ5-FIELD-LESSONS-ADDENDUM.md` - real judge calibration (see LJ1-LJ4).
- `RALLY_ENGINE/rally-data/learn/` - empty; fetch fills it.
- `EXAMPLE_OUTPUTS/` - six finished, gate-passing combined.md + FINAL-AUDIT.md to copy the format.

## Quickstart for one campaign + mission
```bash
cd RALLY_ENGINE
# 1) fetch REAL data (Meta-Rule #0B: never assume)
python3 skills/rally-dna-fetcher.py --address 0xADDRESS --mission mission-0
#    big campaigns time out on content: add --no-fetch-content, then pull tweets via syndication.

# 2) read brief + winner DNA from rally-data/learn/<short-addr>-mission-0/
#    decide GENRE: tactical/product vs confessional/narrative (this changes which gates are real)

# 3) write content.txt + contract.json, then run gates:
python3 skills/rally-compliance-gate.py content.txt contract.json
python3 skills/rally-preflight-url-length.py --content content.txt --genre tactical   # or confessional
python3 skills/rally-cta-quality-check.py --content content.txt --out-json cta.json --out-md CTA.md
python3 skills/rally-tactical-value-check.py --content content.txt --out-json t.json --out-md T.md      # tactical genre
python3 skills/rally-ep-compactness-check.py --content content.txt --out-json c.json --out-md C.md
python3 skills/rally-loser-dna-scan.py --content content.txt --submissions loser_corpus.json --out-json l.json --out-md L.md --whitelist "@RallyOnChain"
python3 skills/rally-originality-saturation-check.py --content content.txt --submissions loser_corpus.json --out-json o.json --out-md O.md
python3 skills/rally-oaa-structure-audit.py --content content.txt --submissions loser_corpus.json --out-json oaa.json --out-md OAA.md
python3 skills/rally-tq-format-audit.py --content content.txt --out-json tq.json --out-md TQ.md --genre tactical
python3 skills/rally-ia-claim-boundary.py --content content.txt --campaign campaign.json --out-json ia.json --out-md IA.md

# 4) build 20 Q&A pairs into combined.md (see RALLY-QNA-ENGINE-V2.md), then:
python3 skills/rally-rq-prompt-answer-check.py --combined combined.md --out-json rq.json --out-md RQ.md --min-pairs 20
python3 skills/rally-rq-mechanics-calibration-check.py --combined combined.md --content content.txt --out-json rqm.json --out-md RQM.md --min-mechanics-pct 0.70 --min-skeptic-pct 0.25
python3 skills/rally-final-integrity-check.py --content content.txt --combined combined.md --min-qna 20 --rq-report rq.json --rq-mechanics-report rqm.json
```

## Non-negotiable rules (learned from real verdicts)
1. URL must NEVER have punctuation touching it. `grep -nE "rally\.fun[,.;:/]" content.txt` must be empty.
2. No em dashes. Do not start with a mention/hashtag.
3. GENRE CALIBRATION: for confessional/memoir, CTA/Compactness/Originality-REVIEW FAILs
   are documented artifacts (winners fail them too - prove it by running tools on winners).
   For tactical/product, those tools are calibrated and must PASS for real; aim ~600-850 chars.
4. Never claim "guaranteed RQ 5/5". Say RQ5-ready. RQ depends on real replies, <30 min reply
   speed, the judge, and the posting account.
5. Work from REAL fetched data, never assumptions.
