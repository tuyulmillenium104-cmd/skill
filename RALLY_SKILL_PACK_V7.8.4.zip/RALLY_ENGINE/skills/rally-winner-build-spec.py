#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Winner DNA Build Spec generator.

Purpose: force a pre-draft construction brief from mission-scoped winner DNA.
This is not a validator after writing; it creates the blueprint before writing.
"""
import argparse, json, re, statistics, time
from pathlib import Path
from collections import Counter

STOP=set('the a an and or but to of in on for with is are was were be been being it this that as at by from you your i my me we they them if not just more most no one do does did into about how why what when where who'.split())

def paras(t):
    return [p.strip() for p in re.split(r"\n\s*\n+", t or "") if p.strip()]

def toks(t):
    return [x for x in re.findall(r"[a-z0-9@']+", (t or '').lower()) if x not in STOP and len(x)>2]

def tail(text):
    ps=paras(text)
    return ps[-1] if ps else (text or '')[-280:]

def opener_type(text):
    first=(paras(text)[0] if paras(text) else text or '').lower()
    if re.search(r"\b(i|i'm|i've|my|last year|last month|three years|for years)\b", first): return 'personal_confession'
    if re.search(r"\bthere is|there's|the number|refusing|someone|a fund|a story\b", first): return 'tension_declarative'
    if '?' in first: return 'question_hook'
    return 'declarative'

def has_tactical_payload(text):
    tl=(text or '').lower()
    markers=['rule','test','method','process','step','checklist','scoreboard','proof trail','receipt','dashboard','if ','when ','before you','ask yourself']
    actions=['write','post','publish','share','test','track','measure','choose','decide','name','protect','stop','start','ship','draft']
    return any(m in tl for m in markers) and any(re.search(r"\b"+re.escape(a)+r"\b",tl) for a in actions)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--submissions', required=True)
    ap.add_argument('--campaign', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    subs=json.load(open(args.submissions, encoding='utf-8'))
    winners=[s for s in subs if s.get('winner') or (s.get('allMax'))]
    if not winners:
        winners=sorted(subs, key=lambda s:s.get('normTotal',0), reverse=True)[:10]
    contents=[s.get('content') or '' for s in winners]
    lens=[len(c) for c in contents if c]
    pcounts=[len(paras(c)) for c in contents if c]
    openers=Counter(opener_type(c) for c in contents)
    tails=[{'author':s.get('xUsername'),'tail':tail(s.get('content') or '')[:300]} for s in winners]
    firsts=[{'author':s.get('xUsername'),'first':(paras(s.get('content') or '')[0] if paras(s.get('content') or '') else '')[:300]} for s in winners]
    all_tokens=[]
    for c in contents: all_tokens += toks(c)
    terms=Counter(all_tokens)
    # value style heuristics from content + judge praise
    value_styles=Counter()
    for s,c in zip(winners,contents):
        cl=c.lower()
        if any(x in cl for x in ['rule','test','process','dashboard','proof trail','scoreboard','receipt','draft','posts']): value_styles['tactical_proof_or_process']+=1
        if any(x in cl for x in ['because','that means','i realized','i understood','the answer','not because']): value_styles['reflective_reasoning']+=1
        if any(x in cl for x in ['salary','money','fund','paid','financial','pay']): value_styles['money_or_work_trade']+=1
        if any(x in cl for x in ['relationship','family','person','myself','values','integrity']): value_styles['identity_or_boundary_trade']+=1
        if '?' in tail(c): value_styles['reflective_question_close']+=1
    # loser/crowd warning tokens are not computed here; downstream loser scan still required.
    spec={
        'tool':'rally-winner-build-spec.py',
        'generated':time.strftime('%Y-%m-%d %H:%M:%S'),
        'winnerCount':len(winners),
        'medianChars':statistics.median(lens) if lens else 0,
        'medianParagraphs':statistics.median(pcounts) if pcounts else 0,
        'openerTypes':dict(openers),
        'valueStyles':dict(value_styles),
        'topTerms':terms.most_common(30),
        'openerSamples':firsts[:10],
        'ctaTailSamples':tails[:10],
        'mandatoryBuildSpec':{
            'hook':'Use dominant winner opener family, but with a concrete scene or tension in first 2 lines.',
            'trade':'Name the tempting gain and the refused cost explicitly.',
            'whyRefuse':'Explain why the winning version would not feel worth owning.',
            'valuePayload':'Include a tactical rule/test/method, not only philosophy.',
            'brandBridge':'Mention @RallyOnChain as prompt/context, not as product pitch.',
            'cta':'Use winner-style reflective question with easy self-disclosure path.'
        }
    }
    Path(args.out_json).write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding='utf-8')
    md=[]
    md.append('# WINNER DNA BUILD SPEC\n\n')
    md.append(f"Winner samples: **{len(winners)}**\n\n")
    md.append(f"Median chars: **{spec['medianChars']}**  \nMedian paragraphs: **{spec['medianParagraphs']}**\n\n")
    md.append('## Opener Types\n\n')
    for k,v in openers.most_common(): md.append(f'- {k}: {v}\n')
    md.append('\n## Value Delivery Styles Detected\n\n')
    for k,v in value_styles.most_common(): md.append(f'- {k}: {v}\n')
    md.append('\n## Opener Samples\n\n')
    for r in firsts[:8]: md.append(f"- @{r['author']}: `{r['first']}`\n")
    md.append('\n## CTA / Tail Samples\n\n')
    for r in tails[:8]: md.append(f"- @{r['author']}: `{r['tail']}`\n")
    md.append('\n## Mandatory Build Spec Before Drafting\n\n')
    for k,v in spec['mandatoryBuildSpec'].items(): md.append(f'- **{k}:** {v}\n')
    md.append('\n## Hard Rule\n\nDo not draft until this build spec is converted into the actual content plan. Winner DNA is the blueprint; tools are validators only.\n')
    Path(args.out_md).write_text(''.join(md), encoding='utf-8')
    print(f"WINNER BUILD SPEC: wrote {args.out_md} from {len(winners)} winners")

if __name__=='__main__': main()
