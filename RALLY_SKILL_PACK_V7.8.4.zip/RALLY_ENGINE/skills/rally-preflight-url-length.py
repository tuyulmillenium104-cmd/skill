#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rally-preflight-url-length.py  (REAL-JUDGE GUARD, added 2026-06-30)

Catches the two field bugs that real Rally judges punished but the older tools
missed:
  LJ1  a URL with attached trailing punctuation -> Twitter linkifies it as a
       malformed link (e.g. "app.rally.fun," -> "app.rally.fun,/"). Real TQ 2/5.
  LJ2  a TACTICAL/PRODUCT post over ~850 chars -> real TQ+EP penalize length
       ("1047-character length exceeds standard Twitter constraints").

Usage:
  python3 skills/rally-preflight-url-length.py --content content.txt [--genre tactical|confessional]

Exit 0 = clean. Exit 1 = a hard problem (LJ1, or tactical over 1050 hard cap).
Confessional longform and tactical 850-1050 are reported as WARN (exit 0).
"""
import argparse, re, sys
from pathlib import Path

ATTACHED = set([',', '.', ';', ':', '/', '!', '?', ')', ']', '}', '>', '"', "'"])
URL = re.compile(r"(?:https?://)?(?:[a-z0-9-]+\.)+(?:fun|com|io|xyz|app|gg|org|net|co|me|dev|ai)(?:/[^\s]*)?", re.I)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--content', required=True)
    ap.add_argument('--genre', default='auto', choices=['auto', 'tactical', 'confessional'])
    args = ap.parse_args()
    text = Path(args.content).read_text(encoding='utf-8').strip()
    errors, warnings = [], []

    # LJ1
    for m in URL.finditer(text):
        nxt = text[m.end():m.end()+1]
        if nxt in ATTACHED:
            errors.append("LJ1 URL has attached trailing punctuation: %r followed by %r. "
                          "Put the URL at the end of the line/sentence with a SPACE or newline "
                          "after it, or move the punctuation before the URL." % (m.group(0), nxt))

    # LJ2
    n = len(text)
    if args.genre == 'tactical':
        if n > 1050:
            errors.append("LJ2 tactical post is %d chars (>1050 hard cap). Shorten." % n)
        elif n > 850:
            warnings.append("LJ2 tactical post is %d chars. Real TQ/EP judge wants ~600-850. Consider shortening." % n)
    elif n > 1050:
        warnings.append("post is %d chars (>1050). Confessional longform tolerates this, "
                        "but verify it stays under any campaign hard cap." % n)

    print("RALLY PREFLIGHT (URL+LENGTH): %s [%d errors, %d warnings, %d chars]"
          % ('FAIL' if errors else 'PASS', len(errors), len(warnings), n))
    for e in errors:   print("  ERROR: " + e)
    for w in warnings: print("  WARN:  " + w)
    sys.exit(1 if errors else 0)

if __name__ == '__main__':
    main()
