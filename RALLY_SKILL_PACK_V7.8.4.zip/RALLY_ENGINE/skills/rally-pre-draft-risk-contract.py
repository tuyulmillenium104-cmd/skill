#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pre-Draft Risk Contract generator.

Purpose: convert fresh mission-scoped Rally data into hard pre-draft constraints.
This is the missing preventive layer: do not wait until after drafting to discover
saturated motifs, loser phrases, weak CTA patterns, or value-ceiling risks.

Output is a contract the agent must follow before writing content.
"""
import argparse, json, re, statistics, time
from pathlib import Path
from collections import Counter, defaultdict

STOP=set('the a an and or but to of in on for with is are was were be been being it this that as at by from you your i my me we they them if not just more most no one do does did into about how why what when where who'.split())

DEDuction_CLASSES = {
    'cta_weak': ['cta','call-to-action','direct question','direct prompt','reply','prompt','invitation','conversation'],
    'conversation_limited': ['conversation','replies','reply','discussion','engagement','spark','audience'],
    'value_not_exceptional': ['value delivery','solid','not exceptional','bookmark','surface-level','not transformative','reflective','philosophical','actionable'],
    'specificity_missing': ['specific','concrete','detail','personal','example','vague','abstract'],
    'hook_weak': ['hook','opening','curiosity','first line','opener'],
    'structure_density': ['dense','length','longform','readability','scannable','structure','formatting','too long'],
    'brand_bridge_promotional': ['promotional','brand','mention','forced','tacked','plug','campaign-like'],
    'generic_or_formulaic': ['generic','formulaic','common','standard','familiar','templated','predictable','ai-generated'],
    'authenticity_polish_tax': ['polished','overly polished','crafted','scripted','performative','manufactured'],
}

MOTIF_LEXICON = {
    'private_to_public_proof': ['private','hidden','unseen','public','proof','evidence','visible','score','group chat'],
    'comfort_to_growth': ['comfort','safe','safety','stagnant','growth','momentum','discipline'],
    'generic_drink_water_coffee': ['water','tap water','coffee','espresso','black coffee','glass of water','sparkling water'],
    'generic_drink_alcohol': ['beer','champagne','martini','cocktail','sambuca','wine'],
    'expectation_reality_template': ['thought 2026 would','january','ordered','reality','instead','not what i ordered'],
    'creator_public_work': ['content','creator','audience','post','publish','work','proof trail'],
    'money_career_trade': ['salary','money','pay','career','job','client','access'],
    'relationship_boundary': ['relationship','family','love','boundary','self','values','integrity'],
}

CTA_TYPES = {
    'drink_decision': ['drink','january','holding','ordered','order','glass','cup'],
    'trade_refusal': ['trade','give up','gain','refuse','protect','exchange'],
    'work_proof': ['work','proof','public','private','share','test'],
}

def toks(text):
    return [x for x in re.findall(r"[a-z0-9@']+", (text or '').lower()) if len(x)>2 and x not in STOP]

def ngrams(tokens,n):
    return [' '.join(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

def paras(text):
    return [p.strip() for p in re.split(r"\n\s*\n+", text or '') if p.strip()]

def tail(text):
    ps=paras(text)
    return ps[-1] if ps else (text or '')[-240:]

def opener_type(text):
    first=(paras(text)[0] if paras(text) else text or '').lower()
    if re.search(r"\b(i|i'm|i've|my|january|back in january|last year|last month|for years)\b", first): return 'personal_confession'
    if re.search(r"\bthere is|there's|everyone|nobody|the number|refusing\b", first): return 'tension_declarative'
    if '?' in first: return 'question_hook'
    return 'declarative'

def motif_hits(text):
    tl=(text or '').lower(); hits=[]; evidence={}
    for m,words in MOTIF_LEXICON.items():
        h=[w for w in words if w in tl]
        if len(h)>=2 or any(' ' in x for x in h):
            hits.append(m); evidence[m]=h
    return hits,evidence

def gate_text(sub, gate_name):
    return ' '.join(a.get('analysis','') for a in (sub.get('analysis') or []) if gate_name.lower() in (a.get('category') or '').lower())

def classify_deductions(subs):
    counts=Counter(); examples=defaultdict(list)
    for s in subs:
        ep=(s.get('gates') or {}).get('EP',[None])[0]
        oaa=(s.get('gates') or {}).get('OAA',[None])[0]
        rq=(s.get('gates') or {}).get('RQ',[None])[0]
        texts=[]
        if ep is not None and ep<5: texts.append(gate_text(s,'Engagement Potential'))
        if oaa is not None and oaa<2: texts.append(gate_text(s,'Originality'))
        if rq is not None and rq<5: texts.append(gate_text(s,'Reply Quality'))
        alltxt=' '.join(texts).lower()
        for cls, words in DEDuction_CLASSES.items():
            if any(w in alltxt for w in words):
                counts[cls]+=1
                if len(examples[cls])<5:
                    # find a short sentence with word
                    sent=next((x.strip() for x in re.split(r'(?<=[.!?])\s+|\n+', ' '.join(texts)) if any(w in x.lower() for w in words)), '')
                    examples[cls].append({'author':s.get('xUsername'),'ep':ep,'oaa':oaa,'rq':rq,'sentence':sent[:260]})
    return counts, examples

def infer_cta_answer_format(campaign, mission, winner_tails):
    text=((mission.get('title','')+' '+mission.get('description','')+' '+mission.get('rules','')).lower()) if mission else ''
    tails=' '.join(winner_tails).lower()
    combined=text+' '+tails
    if any(w in combined for w in CTA_TYPES['drink_decision']):
        return 'drink + situation/story + decision/change forced by the year'
    if any(w in combined for w in CTA_TYPES['trade_refusal']):
        return 'trade/refusal + personal stake + decision or boundary'
    if any(w in combined for w in CTA_TYPES['work_proof']):
        return 'private work/proof + situation + decision to share/test/protect'
    return 'direct answer to CTA + personal story + decision/consequence'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--submissions', required=True)
    ap.add_argument('--campaign', required=True)
    ap.add_argument('--mission', required=True)
    ap.add_argument('--winner-build-spec', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    subs=json.load(open(args.submissions, encoding='utf-8'))
    campaign=json.load(open(args.campaign, encoding='utf-8'))
    mission=next((m for m in campaign.get('missions',[]) if m.get('id')==args.mission), {})
    winners=[s for s in subs if s.get('winner')]
    nonw=[s for s in subs if not s.get('winner')]
    if not winners:
        winners=sorted(subs,key=lambda s:s.get('normTotal',0),reverse=True)[:10]

    # Crowded phrase map from all submissions and non-winners.
    big=Counter(); tri=Counter(); four=Counter(); non_big=Counter(); non_tri=Counter(); non_four=Counter()
    for s in subs:
        ts=toks(s.get('content') or '')
        big.update(ngrams(ts,2)); tri.update(ngrams(ts,3)); four.update(ngrams(ts,4))
    for s in nonw:
        ts=toks(s.get('content') or '')
        non_big.update(ngrams(ts,2)); non_tri.update(ngrams(ts,3)); non_four.update(ngrams(ts,4))

    banned_phrases=[]
    for phrase,count in (non_tri+non_four).most_common(80):
        if count>=3 and not any(x in phrase for x in ['@rallyonchain','app rally fun','rally fun']):
            banned_phrases.append({'phrase':phrase,'count':count})
        if len(banned_phrases)>=30: break

    # Motif saturation.
    motif_counts=Counter(); motif_samples=defaultdict(list); motif_evidence=defaultdict(list)
    for s in subs:
        ms,ev=motif_hits(s.get('content') or '')
        for m in ms:
            motif_counts[m]+=1
            if len(motif_samples[m])<5:
                motif_samples[m].append({'author':s.get('xUsername'),'winner':bool(s.get('winner')),'text':(s.get('content') or '')[:220]})
            motif_evidence[m]+=ev.get(m,[])[:3]
    saturated=[]
    for m,c in motif_counts.most_common():
        pct=c/max(1,len(subs))
        if c>=8 or pct>=0.08:
            saturated.append({'motif':m,'count':c,'pct':round(pct,3),'sampleEvidence':Counter(motif_evidence[m]).most_common(8),'samples':motif_samples[m]})

    # Winner mechanisms.
    opener_counts=Counter(opener_type(s.get('content') or '') for s in winners)
    lens=[len(s.get('content') or '') for s in winners]
    pcounts=[len(paras(s.get('content') or '')) for s in winners]
    winner_tails=[tail(s.get('content') or '') for s in winners]
    cta_format=infer_cta_answer_format(campaign, mission, winner_tails)

    deduction_counts, deduction_examples=classify_deductions(subs)
    top_deductions=[{'class':k,'count':v,'examples':deduction_examples[k]} for k,v in deduction_counts.most_common(10)]

    # Required mechanisms from deductions.
    required=[]
    if deduction_counts['value_not_exceptional'] or deduction_counts['conversation_limited']:
        required.append('Include operational/tactical payload, not only reflection.')
    if deduction_counts['cta_weak'] or deduction_counts['conversation_limited']:
        required.append('CTA must be a low-friction self-disclosure prompt matching campaign action format.')
    if deduction_counts['specificity_missing'] or deduction_counts['hook_weak']:
        required.append('Use concrete receipt details in first 2-3 paragraphs.')
    if deduction_counts['structure_density']:
        required.append('Keep length compact or earned; avoid dense paragraphs and literary fog.')
    if deduction_counts['brand_bridge_promotional']:
        required.append('Use @RallyOnChain as prompt/context, not product pitch.')
    if deduction_counts['generic_or_formulaic'] or saturated:
        required.append('Choose semantic angle outside saturated motifs; if using crowded motif, add major twist.')

    likely_deductions=[]
    for d in top_deductions[:6]:
        if d['class']=='value_not_exceptional': likely_deductions.append('Strong, but value delivery is more reflective than actionable.')
        if d['class']=='generic_or_formulaic': likely_deductions.append('Authentic, but the structure/angle feels familiar or templated.')
        if d['class']=='conversation_limited': likely_deductions.append('Good story, but conversation potential is limited without an answerable prompt.')
        if d['class']=='cta_weak': likely_deductions.append('CTA is present but not direct enough to drive replies.')
        if d['class']=='structure_density': likely_deductions.append('Readable, but slightly long/dense for casual scrollers.')
        if d['class']=='specificity_missing': likely_deductions.append('Aligned, but needs more concrete personal detail.')
        if d['class']=='brand_bridge_promotional': likely_deductions.append('@RallyOnChain mention may feel tacked on or promotional.')
        if d['class']=='authenticity_polish_tax': likely_deductions.append('Well-written, but slightly polished/crafted rather than raw.')

    contract={
        'tool':'rally-pre-draft-risk-contract.py',
        'generated':time.strftime('%Y-%m-%d %H:%M:%S'),
        'campaign':campaign.get('title'),
        'mission':args.mission,
        'missionTitle':mission.get('title'),
        'winnerCount':len(winners),
        'nonWinnerCount':len(nonw),
        'winnerMechanisms':{
            'openerTypes':dict(opener_counts),
            'medianChars':statistics.median(lens) if lens else 0,
            'medianParagraphs':statistics.median(pcounts) if pcounts else 0,
            'ctaTails':winner_tails[:10],
            'requiredCTAAnswerFormat':cta_format,
        },
        'bannedPhrases':banned_phrases,
        'saturatedMotifs':saturated,
        'topDeductionClasses':top_deductions,
        'requiredMechanisms':required,
        'likelyJudgeDeductionSentencesToAvoid':list(dict.fromkeys(likely_deductions)),
        'rebuildTriggers':[
            'draft uses saturated motif without major twist',
            'draft lacks operational/tactical payload',
            'CTA cannot be answered with concrete personal story/decision',
            'brand mention reads like product pitch',
            'Q&A replies validate post instead of answering actual CTA',
            'worst positive verdict can still write EP4/OAA1/RQ3 sentence'
        ],
        'decision':'CONTRACT_READY'
    }
    Path(args.out_json).write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')

    md=[]
    md.append('# PRE-DRAFT RISK CONTRACT\n\n')
    md.append(f"Campaign: **{campaign.get('title')}**  \nMission: **{args.mission} - {mission.get('title')}**\n\n")
    md.append('## Winner-DNA mechanisms to build from\n\n')
    md.append(f"- Winner count: {len(winners)}\n- Median chars: {contract['winnerMechanisms']['medianChars']}\n- Median paragraphs: {contract['winnerMechanisms']['medianParagraphs']}\n- Opener types: {dict(opener_counts)}\n- Required CTA answer format: **{cta_format}**\n\n")
    md.append('### Winner CTA tails\n')
    for t in winner_tails[:8]: md.append(f'- `{t[:240]}`\n')
    md.append('\n## Banned / crowded phrases from non-winners\n')
    for b in banned_phrases[:25]: md.append(f"- `{b['phrase']}` ({b['count']})\n")
    md.append('\n## Saturated semantic motifs\n')
    if saturated:
        for s in saturated[:10]: md.append(f"- **{s['motif']}**: {s['count']} submissions ({s['pct']*100:.1f}%) evidence={s['sampleEvidence']}\n")
    else: md.append('- none detected above threshold\n')
    md.append('\n## Top judge deduction classes in pool\n')
    for d in top_deductions[:10]: md.append(f"- **{d['class']}**: {d['count']}\n")
    md.append('\n## Required mechanisms for draft\n')
    for r in required: md.append(f'- {r}\n')
    md.append('\n## Likely judge deduction sentences to avoid\n')
    for s in contract['likelyJudgeDeductionSentencesToAvoid']: md.append(f'- "{s}"\n')
    md.append('\n## Rebuild triggers\n')
    for r in contract['rebuildTriggers']: md.append(f'- {r}\n')
    md.append('\n## Operating rule\n\nDo not draft until this contract is converted into the WINNER-DNA BUILD PLAN. If draft violates this contract, rebuild instead of patching.\n')
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f"PRE-DRAFT RISK CONTRACT: CONTRACT_READY [{campaign.get('title')} {args.mission}]")

if __name__=='__main__': main()
