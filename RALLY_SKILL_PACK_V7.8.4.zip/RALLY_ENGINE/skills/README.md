# /skills/ — RALLY ENGINE TOOLKIT LENGKAP (V7.7.1 + DNA FETCHER + MISSION-SOUL PROTOCOL)

> ⚠️ PERBAIKAN UTAMA (2026-06-24): Masalah "skill tidak bisa mengambil data konten
> asli dari DNA winner & non-winner" kini TERATASI via `rally-dna-fetcher.py`.
> Lihat bagian "PERBAIKAN DNA" di bawah.

Folder ini = SEMUA yang dibutuhkan untuk menjalankan Rally Content Engine.
Portabel: salin folder ini utuh ke workspace baru dan seluruh sistem hidup.

## ISI & PERAN (9 file)

| File | Peran | Kapan dipakai |
|---|---|---|
| `rally-content-engine-V7.7-SKILL.md` | SKILL UTAMA — protokol penuh produksi konten (V7.7 + STEP 0 PREFLIGHT) | Setiap `/rally <address>` |
| `STEP0-PREFLIGHT-RULES.md` | Preflight protocol detail v1.0 (WAJIB sebelum Step 1) | Setiap `/rally` |
| `rally-qna-engine.md` | Skill Q&A terpisah — reply-pack untuk RQ 5/5 (V1.0) | Setelah konten final + ledger |
| `BLIND-JUDGE-PROMPT.md` | Prompt blind-judge portabel (#0M) | Step 6/7.x, sebelum scanner |
| `INTERNAL_DECISION_SUMMARY_TEMPLATE.md` | Template resmi internal decision summary | Setelah konten final |
| `rally-rules.py` | **SATU FILE semua rule-100%** (EP/OAA/TQ/IA/CA) + scanner CLI; input JSON vonis simulasi → PASS/FAIL per gate; exit 0 = layak submit | FINAL-CHECK setiap konten |
| `rally-compliance-gate.py` | Binary gate CC — scan KONTEN terhadap aturan mekanis mission (#0J-1); exit 1 = dilarang output | Sebelum & sesudah final |
| `MISSION-SOUL-PROTOCOL.md` | **[v1.4 NEW]** Mission-Soul Protocol: 6 formalisasi dari post-mortem sesi GenLayer (#0B2 Mission-Scoped DNA, Step 0.5 Mission-Soul Decode, Mission-Type Playbook, Template Duplication Ban, Scanner Self-Validation Disclosure, Rebuild-vs-Patch) | Setiap `/rally` multi-misi, sebelum Step 1 |
| `rally-dna-fetcher.py` | **[BARU] PERBAIKAN DNA** — ambil konten tweet ASLI winner & non-winner via multi-source (syndication/fxtwitter/oembed + fallback fragmen-vonis-juri); output dna.json + DNA-WINNER.md + DNA-NONWINNER.md | Step 1/2: load Winner/Loser DNA dari data nyata |
| `README.md` | File ini | — |

## ⚠️ PERBAIKAN DNA — AKAR MASALAH YANG DIATASI

**MASALAH:** Skill butuh "Winner DNA" & "Non-Winner DNA" (konten tweet ASLI pemenang
& yang kalah) untuk Step 2 (angle-fit, structure-gap-scan, motif-overlap, kompetitor-
failure-audit). NAMUN Rally submissions API HANYA mengembalikan `tweetId`,
`xUsername`, skor, dan `analysis` (vonis juri yang hanya mengutip FRAGMEN konten).
**Field tweetText/content TIDAK ADA.** Akibatnya DNA selama ini dibangun dari
asumsi, bukan data nyata = pelanggaran berat Meta-Rule #0B.

**SOLUSI:** `rally-dna-fetcher.py` mengambil konten ASLI per submission via:

| Prioritas | Sumber | Status |
|---|---|---|
| PRIMER | `cdn.syndication.twimg.com/tweet-result` | ✅ teks lengkap + media |
| Fallback #1 | `api.fxtwitter.com` | ✅ jika syndication gagal |
| Fallback #2 | `publish.x.com/oembed` | ⚠️ sering mati (HTML error) |
| TERAKHIR | ekstraksi kutipan dari `analysis` juri | ✅ tweet dihapus (fragmen) |

**Tes real (campaign "Invent the future", 274 submission):**
- 234 konten-penuh berhasil diambil (86%)
- 40 tweet dihapus → fragmen vonis juri (14%)
- 0 gagal total — DNA kini 100% dari data nyata

### CARA PAKAI
```bash
# Ambil DNA lengkap untuk campaign (jalankan SEBELUM /rally content generation)
python3 skills/rally-dna-fetcher.py --address 0xCONTRACT_ADDRESS

# Output:
#   rally-data/learn/<addr>/campaign.json
#   rally-data/learn/<addr>/submissions_enriched.json   (cache lengkap)
#   rally-data/learn/<addr>/dna.json                    (mesin: ringkas untuk skill)
#   rally-data/learn/<addr>/DNA-WINNER.md               (dibaca skill: Step 2 Winner DNA)
#   rally-data/learn/<addr>/DNA-NONWINNER.md            (dibaca skill: Step 7 Kompetitor-Failure)
```

Skill membaca `DNA-WINNER.md` untuk Winner DNA markers dan `DNA-NONWINNER.md`
untuk kompetitor failure pattern audit — keduanya berisi KONTEN ASLI + vonis juri,
bukan asumsi.

## ⚠️ MISSION-SOUL PROTOCOL — ADDENDUM v1.4 (2026-06-24)

**MASALAH YANG DIATASI:** Post-mortem sesi GenLayer mengungkap 8 kegagalan sistematik. Akar masalahnya: agent tidak paham jiwa misi sebelum menulis + DNA tidak di-scope per-misi + template duplikasi lintas misi.

**6 FORMALISASI:**

| # | Aturan | Kapan |
|---|---|---|
| A | **#0B2 Mission-Scoped DNA** — DNA WAJIB filter by missionId untuk campaign multi-misi | Sebelum load DNA |
| B | **Step 0.5 Mission-Soul Decode** — bedah brief, identifikasi jiwa misi, tentukan struktur | Sebelum Step 1 |
| C | **Mission-Type Playbook** — EXPLAIN=teach, IDENTIFY=named project (struktur berbeda per tipe) | Step 0.5 |
| D | **Template Duplication Ban** — multi-mission: struktur WAJIB beda | Sebelum output |
| E | **Scanner Self-Validation Disclosure** — scanner PASS pada self-vonis = "self-validated, NOT proof" | Step 7 |
| F | **Rebuild vs Patch** — struktur salah = rebuild, bukan patch | Step 4/7 |

File detail: `skills/MISSION-SOUL-PROTOCOL.md`

## ALUR EKSEKUSI RESMI (V7.7 + DNA)

```
/rally <address>
  └─ python3 skills/rally-dna-fetcher.py --address <addr>   ← [BARU] ambil DNA nyata
       └─ rally-content-engine (STEP 0 PREFLIGHT → funnel → angle-fit → ...)
            └─ BLIND-JUDGE-PROMPT → vonis simulasi → vonis.json
                 └─ python3 skills/rally-rules.py vonis.json            (exit 0 WAJIB)
                 └─ python3 skills/rally-compliance-gate.py ...         (exit 0 WAJIB)
                      └─ SUBMIT → rally-qna-engine.md → balas <30 menit
```

## BASIS DATA RULE (7.400+ vonis, 13 pool)

| Gate | Sel-100% | Out-of-sample |
|---|---|---|
| EP | 58/58 | 18/18 |
| OAA | 192/192 | 86/86 |
| TQ | 246/246 | 109/109 |
| CA | 299/299 | 122/122 |
| IA | 229/229 | — |
| CC | mekanis (rally-compliance-gate.py) | — |
| RQ | qna-engine (trait kumulatif) | — |

## ⚠️ HUKUM EDIT rally-rules.py

1. **Lexicon per-gate TIDAK BOLEH di-share/dinormalisasi** (bukti regresi: OAA 192→184,
   TQ 246→192).
2. Setiap edit lexicon = per-gate + komentar tanggal + sumber vonis.
3. WAJIB regresi setelah edit vs `/rally-data/mining/{ep,oaa,tq,ia,ca}_dataset.json`.

## ACTIVE ADDENDUM v1.5 — JUDGE-VARIANCE HARDENING

New file: `JUDGE-VARIANCE-HARDENING-PROTOCOL.md`.

Purpose: reduce LLM judge non-determinism risk by requiring 5 persona judge simulations, worst-credible verdict, recurrence tracking, and deduction-surface mapping before final output.

Integration: Step 7.7 → Step 7.8 Judge-Variance Hardening (#0R) → scanner/final audit.

## ACTIVE ADDENDUM v1.6 — LOSER-DNA STERILIZATION

New file: `LOSER-DNA-STERILIZATION-PROTOCOL.md`.

Purpose: prevent drafts from passing winner-DNA/scanner/judge-variance checks while still carrying non-winner phrase, motif, structure, or failure-pattern contamination.

Integration: Step 7.7 → Step 7.8 Judge-Variance Hardening (#0R) → Step 7.9 Loser-DNA Sterilization (#0S2) → final audit.

## ACTIVE ADDENDUM v1.7 — CTA QUALITY SEPARATION

New file: `CTA-QUALITY-SEPARATION-PROTOCOL.md`.

Purpose: prevent future EP5 misses where a rhetorical question creates conversation potential but does not satisfy CTA Quality. Every run must separate Conversation Potential from CTA Quality and require a direct behavioral CTA unless campaign format explicitly forbids it.

## ACTIVE ADDENDUM v1.8 — TOOL-BACKED EXECUTION CORE

New active operating file:
- `RALLY-EXECUTION-CORE.md`

New enforcement tools:
- `rally-loser-dna-scan.py` — official #0S2 scan, exit 1 on unwhitelisted 5-gram+ or fatal loser pattern.
- `rally-final-integrity-check.py` — detects stale combined files, stale compliance/scanner outputs, QnA count issues, bad punctuation.
- `rally-dna-confidence.py` — reports confidence level from winner count, non-winner count, and content retrieval coverage.

Future `/rally` runs must use the core flow and these tools before final output.

## ACTIVE ADDENDUM v1.7.1 — CTA QUALITY MAX FORMULA

New file: `CTA-QUALITY-MAX-FORMULA.md`.
New tool: `rally-cta-quality-check.py`.

Purpose: enforce the CTA pattern found in real Rally EP5 verdicts: behavioral verb + concrete object + campaign-native choice + low-friction reply path. Future final audits must include CTA Formula Score.

## ACTIVE ADDENDUM v1.9 — ADAPTIVE SKILL RATCHET

New files:
- `ADAPTIVE-SKILL-RATCHET-PROTOCOL.md`
- `ADAPTIVE-RATCHET-LESSONS.md`
- `rally-ep-deduction-map.py`
- `rally-winner-dna-map.py`

Purpose: make the skill evolve directly from real verdicts and mission-scoped pools. New EP deduction classes and winner mechanisms are written into active skill lessons, not only memory.

## ACTIVE ADDENDUM v2.0 — ADAPTIVE GATE EXPANSION

New files/tools:
- `ADAPTIVE-GATE-EXPANSION-PROTOCOL.md`
- `rally-tq-format-audit.py`
- `rally-oaa-structure-audit.py`
- `rally-ia-claim-boundary.py`

Purpose: expand adaptivity into TQ media/readability, OAA semantic structure/trope, and IA campaign-specific claim boundaries. Final integrity can now require these adaptive reports.

## ACTIVE ADDENDUM v2.2 — EP SEMANTIC DEDUCTION REVIEW

New files:
- `EP-SEMANTIC-DEDUCTION-REVIEW-PROTOCOL.md`
- `rally-ep-semantic-review.py`

Purpose: final semantic EP red-team after deduction map. Final output is invalid if a credible unresolved EP4 sentence remains.

## ACTIVE ADDENDUM v2.3 — CAMPAIGN CARTOGRAPHY FIRST

New tool: `rally-campaign-cartographer.py`.

Purpose: map the mission before writing. It orchestrates DNA fetch/cache, DNA confidence, winner DNA map, EP deduction map, OAA/TQ/IA/RQ pattern maps, topic saturation, and strategy recommendation.

## ACTIVE ADDENDUM v2.4 — GLOBAL EP4 PLAYBOOK MINING

New tool: `rally-global-ep4-playbook.py`.

Purpose: mine all active campaigns for EP<5 subtype patterns and generate a global EP4 playbook used as prior after mission-specific maps.

## ACTIVE ADDENDUM - EP5 TACTICAL VALUE PAYLOAD

New tool:
- `rally-tactical-value-check.py`

Purpose: prevents EP4 misses where content is praised for hook, CTA, structure, and brand bridge but judged "more philosophical than tactical." Future `/rally` runs must include a practical reader payload: rule, test, method, checklist, or action that can be applied today.

Required command:

```bash
python3 skills/rally-tactical-value-check.py --content content.txt --out-json tactical-value.json --out-md TACTICAL-VALUE.md
```

## ACTIVE ADDENDUM - WINNER DNA BUILD SPEC

New tool:
- `rally-winner-build-spec.py`

Purpose: prevents shallow use of Winner DNA. Future runs must convert winner samples into a pre-draft build plan before writing. This includes hook mechanism, trade/refusal mechanism, value delivery style, tactical payload, brand bridge style, CTA style, and loser-DNA exclusions.

## ACTIVE ADDENDUM - ORIGINALITY SATURATION CHECK

New tool:
- `rally-originality-saturation-check.py`

Purpose: catches OAA misses where wording is clean but the core semantic motif and progression overlap with many other submissions. Future final audits must treat saturated motif + common progression as a rebuild trigger.

## ACTIVE ADDENDUM - EP COMPACTNESS / REPLY CONVERSION

New tool:
- `rally-ep-compactness-check.py`

Purpose: catches EP4 risk where content is strong but too long/dense/literary, causing users to admire rather than reply.

## ACTIVE ADDENDUM - RQ PROMPT-ANSWER COMPLIANCE

New tool:
- `rally-rq-prompt-answer-check.py`

Purpose: catches RQ3 risk where replies are relevant and authentic but fail to answer the actual CTA or add substantial personal story/decision.

## ACTIVE ADDENDUM - WORST POSITIVE VERDICT CHECK

New tool:
- `rally-worst-positive-verdict-check.py`

Purpose: catches all-max misses where the judge praises the content but caps a gate with "strong, but..." language. It combines tactical, originality, compactness, CTA, and RQ reports to detect credible EP4/OAA1/RQ3 sentences before submit.

## ACTIVE ADDENDUM - PRE-DRAFT RISK CONTRACT

New tool:
- `rally-pre-draft-risk-contract.py`

Purpose: converts fresh mission-scoped Winner/Loser/Judge data into hard pre-draft constraints. This prevents known problems before content is written instead of catching them only after drafting.

Required command:

```bash
python3 skills/rally-pre-draft-risk-contract.py --submissions submissions_enriched.json --campaign campaign.json --mission mission-0 --winner-build-spec winner-build-spec.json --out-json pre-draft-risk-contract.json --out-md PRE-DRAFT-RISK-CONTRACT.md
```

## ACTIVE ADDENDUM - RQ CAMPAIGN MECHANICS CALIBRATION

New tool:
- `rally-rq-mechanics-calibration-check.py`

Purpose: ensures Q&A packs for product/protocol campaigns match real RQ5 verdict patterns by including campaign mechanics, constructive skepticism, and subject-matter engagement in every Q-COPY.
