#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RQ Campaign Mechanics Calibration checker.

Purpose: ensure Q&A packs are not only prompt-answer compliant, but calibrated to
campaign-specific RQ5 patterns. For product/protocol campaigns, every Q-COPY should
carry a decision plus a concrete campaign mechanic, personal/skeptical angle, or
subject-matter insight.

Real verdict lesson: RQ5 for Wingston praised protocol mechanics, constructive
skepticism, Top 425/whitelist/RLP/Rally Score specificity. Generic relevance is not enough.
"""
import argparse, json, re, sys, time
from pathlib import Path
from collections import Counter

GENERIC_MECH_CATEGORIES = {
    'protocol_utility': ['utility','staking','stake','rlp','reward','rewards','score','boost','protocol','dashboard','holder-only','holder only','exclusive campaign','exclusive campaigns'],
    'access_mechanics': ['whitelist','wl','top 425','leaderboard','rank','ranking','campaign','campaigns','follow','eligible','eligibility','earn','earned'],
    'mint_details': ['free mint','mint','supply','3,000','3000','ethereum','july 7','july 7th','0 eth'],
    'market_contrast': ['floor','hype','flip','flipper','speculation','capital','wallet','gas','time','cost','buy','buying'],
    'product_model': ['product','loop','post-mint','after mint','holders','holder','community','contribution','creator','work'],
}

SKEPTIC_MARKERS = ['but','only if','depends','watch','verify','question','concern','risk','what happens','still a cost','not just','whether','if ']
DECISION_MARKERS = ['i would','my decision','i choose','i would choose','i would rather','i trust','i would pick','i like','my concern','my answer']
LOW_EFFORT = ['great post','nice post','good take','love this','agree','bullish','lfg','gm','well said','spot on']


def pairs(text):
    return re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```", text, flags=re.S)


def campaign_text(path):
    if not path: return ''
    try:
        c=json.load(open(path,encoding='utf-8'))
        parts=[c.get('title',''),c.get('goal','') or '',c.get('rules','') or '']
        for m in c.get('missions',[]): parts += [m.get('title',''),m.get('description',''),m.get('rules','')]
        return ' '.join(x or '' for x in parts).lower()
    except Exception:
        return ''


def is_protocol_campaign(text):
    proto=['nft','mint','whitelist','leaderboard','staking','rlp','score','ethereum','campaign','protocol','holder']
    return sum(1 for p in proto if p in text)>=3


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--combined', required=True)
    ap.add_argument('--content', required=True)
    ap.add_argument('--campaign', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    ap.add_argument('--min-mechanics-pct', type=float, default=0.70)
    ap.add_argument('--min-skeptic-pct', type=float, default=0.25)
    args=ap.parse_args()
    combined=Path(args.combined).read_text(encoding='utf-8')
    content=Path(args.content).read_text(encoding='utf-8').lower()
    camp=campaign_text(args.campaign)
    proto=is_protocol_campaign(camp+' '+content)
    ps=pairs(combined)
    rows=[]; cat_counts=Counter(); failures=[]
    for idx,(q,a) in enumerate(ps,1):
        ql=q.lower(); al=a.lower(); both=ql+' '+al
        cats=[]
        for cat,terms in GENERIC_MECH_CATEGORIES.items():
            if any(t in both for t in terms):
                cats.append(cat); cat_counts[cat]+=1
        has_mech=bool(cats)
        has_decision=any(m in ql for m in DECISION_MARKERS)
        has_skeptic=any(m in ql for m in SKEPTIC_MARKERS)
        low=any(x in ql.strip() for x in LOW_EFFORT)
        open_loop='?' in a
        # For protocol/product campaigns, tier-A means decision + mechanic + open loop; skeptic or personal is a plus.
        ok=(has_decision and has_mech and open_loop and not low) if proto else (has_decision and open_loop and not low)
        row={'idx':idx,'qChars':len(q),'aChars':len(a),'categories':cats,'hasMechanic':has_mech,'hasDecision':has_decision,'hasSkeptic':has_skeptic,'openLoop':open_loop,'lowEffort':low,'decision':'PASS' if ok else 'FAIL','q':q[:220]}
        rows.append(row)
        if not ok:
            reasons=[]
            if not has_decision: reasons.append('missing explicit decision/stake')
            if proto and not has_mech: reasons.append('missing campaign-specific mechanic')
            if not open_loop: reasons.append('A-COPY lacks open-loop')
            if low: reasons.append('low-effort/generic phrasing')
            failures.append({'idx':idx,'reasons':reasons,'q':q})
    pair_count=len(ps)
    mech_count=sum(1 for r in rows if r['hasMechanic'])
    skeptic_count=sum(1 for r in rows if r['hasSkeptic'])
    decision_count=sum(1 for r in rows if r['hasDecision'])
    mech_pct=mech_count/max(1,pair_count)
    skeptic_pct=skeptic_count/max(1,pair_count)
    category_coverage=sum(1 for c in cat_counts if cat_counts[c]>0)
    reasons=[]
    if failures: reasons.append(f'{len(failures)} pairs fail tier-A mechanics/decision/open-loop standard')
    if proto and mech_pct < args.min_mechanics_pct: reasons.append(f'mechanics coverage {mech_pct:.0%} < {args.min_mechanics_pct:.0%}')
    if proto and category_coverage < 4: reasons.append(f'category coverage {category_coverage} < 4')
    if proto and skeptic_pct < args.min_skeptic_pct: reasons.append(f'skeptic/constructive coverage {skeptic_pct:.0%} < {args.min_skeptic_pct:.0%}')
    decision='PASS' if not reasons else 'FAIL'
    result={'tool':'rally-rq-mechanics-calibration-check.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'protocolCampaign':proto,'pairCount':pair_count,'mechanicsPairCount':mech_count,'mechanicsPct':round(mech_pct,3),'decisionPairCount':decision_count,'skepticPairCount':skeptic_count,'skepticPct':round(skeptic_pct,3),'categoryCounts':dict(cat_counts),'categoryCoverage':category_coverage,'rows':rows,'failures':failures,'decision':decision,'reasons':reasons}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append('# RQ CAMPAIGN MECHANICS CALIBRATION CHECK\n\n')
    md.append(f'Decision: **{decision}**\n\n')
    md.append(f'- Protocol/product campaign: {proto}\n- Pairs: {pair_count}\n- Mechanics pairs: {mech_count}/{pair_count} ({mech_pct:.0%})\n- Decision pairs: {decision_count}/{pair_count}\n- Skeptic/constructive pairs: {skeptic_count}/{pair_count} ({skeptic_pct:.0%})\n- Category coverage: {category_coverage}\n\n')
    md.append('## Category counts\n')
    for k,v in cat_counts.most_common(): md.append(f'- {k}: {v}\n')
    md.append('\n## Reasons\n')
    md += [f'- {r}\n' for r in reasons] or ['- clear\n']
    md.append('\n## Failed pairs\n')
    if failures:
        for f in failures: md.append(f"- Pair {f['idx']}: {', '.join(f['reasons'])}\n")
    else: md.append('- none\n')
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f"RQ MECHANICS CALIBRATION CHECK: {decision} [mechanics={mech_count}/{pair_count}, categories={category_coverage}, skeptic={skeptic_count}/{pair_count}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
