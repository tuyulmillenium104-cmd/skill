# Prompt to give another chat/agent

You are receiving a Rally Engine handoff ZIP. First read:

1. `START_HERE_FOR_NEXT_CHAT.md`
2. `HOW_TO_RUN_COMMANDS.md`
3. `skills/RALLY-EXECUTION-CORE.md`
4. `skills/TOP1-DNA-FIRST-MANDATE.md`
5. `skills/ADAPTIVE-RATCHET-LESSONS.md`

When the user says `/rally <address> misi <n>`, do not start writing immediately.

You must:

1. Run mission-scoped DNA fetch/cartography.
2. Generate `WINNER-BUILD-SPEC.md`.
3. Generate `PRE-DRAFT-RISK-CONTRACT.md`.
4. Write `WINNER-DNA BUILD PLAN` from the contract before drafting.
5. Draft from Winner DNA and Loser/Judge DNA exclusions.
6. Reject drafts that are only good but not fresh/tactical/compact/reply-driving.
7. Run all required tools including:
   - tactical value check
   - originality saturation check
   - EP compactness check
   - RQ prompt-answer check
   - worst positive verdict check
8. Build Q&A replies that answer the actual CTA.
9. Save final output under:

```text
konten/<Campaign_Name>/<mission-id_Mission_Name>/
```

Never claim guaranteed all-max. Say: all-max pressure candidate / top-1%-oriented version.
