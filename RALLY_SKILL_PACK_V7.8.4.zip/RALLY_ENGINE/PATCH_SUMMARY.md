# Patch Summary

This bundle includes latest post-verdict fixes.

## New/important tools

- `rally-winner-build-spec.py`
- `rally-pre-draft-risk-contract.py`
- `rally-tactical-value-check.py`
- `rally-originality-saturation-check.py`
- `rally-ep-compactness-check.py`
- `rally-rq-prompt-answer-check.py`
- `rally-rq-mechanics-calibration-check.py`
- `rally-worst-positive-verdict-check.py`

## Real verdict misses fixed

1. EP4 because content was more philosophical than tactical.
2. OAA1 because wording was unique but core motif was saturated.
3. EP4 because long/literary content made users admire more than reply.
4. RQ3 because replies validated the post but did not answer the actual CTA.
5. Consistency issue: Winner DNA and Judge/Loser DNA must become hard blockers, not loose references.
6. Preventive issue: fresh campaign data must become a pre-draft risk contract before writing.

## New blockers

- No Winner Build Spec = no draft.
- No Pre-Draft Risk Contract = no draft.
- Tactical Value not PASS = no EP5 claim.
- Originality Saturation not PASS = rebuild angle.
- EP Compactness not PASS = compress/rebuild.
- RQ Prompt-Answer not PASS = rewrite Q&A pack.
- Worst Positive Verdict not PASS = fix or rebuild.

## Core rule

```text
Fresh data -> Pre-draft contract -> Build plan -> Draft -> Stress test.
Do not submit strong content. Submit hard-to-deduct content.
```

## Latest RQ update

Protocol/product campaign Q&A must now pass RQ mechanics calibration: every Q-COPY should include explicit decision + campaign mechanic + personal/skeptical angle.

## V7.8.4 patch (2026-06-30) - REAL-JUDGE URL + LENGTH GUARD

Three real Rally judge verdicts landed on our own posted content. One was a hard
miss the OLD tools did NOT catch:

- A tactical post scored **TQ 2/5** because the URL `app.rally.fun,` (comma touching
  the domain) was linkified as a malformed link `app.rally.fun,/`. CTA (5/5),
  Compliance, and the old TQ audit all PASSED it, because the old URL regex only
  matched `http(s)://` links and bare domains were never inspected; trailing
  punctuation was only a warning.
- The same verdict penalized length ("1047-character length exceeds standard
  Twitter constraints") on a TACTICAL post, even though our compactness cap (1050)
  passed it.

### Structural fixes (so it cannot recur)
1. `rally-tq-format-audit.py`: URL regex now matches BARE domains (app.rally.fun)
   too; trailing punctuation TOUCHING a URL is now a HARD ERROR (FAIL), not a
   warning. New `--genre tactical` flag: >1050 = error, >850 = warning (real judge
   wants tactical ~600-850).
2. `rally-compliance-gate.py`: added a hard FAIL for any URL followed by attached
   punctuation (LJ1) - blocks it at the earliest gate.
3. `rally-final-integrity-check.py`: added the same URL check at the final gate.
4. NEW `rally-preflight-url-length.py`: one-shot guard for LJ1 + LJ2, run before
   posting: `python3 skills/rally-preflight-url-length.py --content content.txt --genre tactical`.

### Validated in the field (keep doing)
- Confessional no-CTA + closing rhetorical question is CORRECT (judge praised it).
- Skeptic-first ranked Q&A replies work (one scored RQ 4/5, "authentic, not templated").

See `skills/RQ5-FIELD-LESSONS-ADDENDUM.md` -> "REAL-JUDGE CALIBRATION 2026-06-30"
for the full lessons (LJ1-LJ4).

### Hard rule added
```text
A campaign URL must end its line/sentence with NO punctuation touching it.
Preflight grep that must return nothing:  grep -nE "rally\.fun[,.;:/]" content.txt
```
