# 🔒 SKILL 25: FINAL INTEGRITY CHECK

**Phase:** 3 (Q&A)
**Source:** RESTORED from v2.3 rally-final-integrity-check.py logic
**Purpose:** Pastikan semua artifacts CURRENT dan CONSISTENT sebelum submit. Jangan ship stale pass.

---

## CORE CHECKS

### 1. Content = Content
- [ ] `content.txt` berisi EXACT content yang akan di-submit
- [ ] Tidak ada perubahan yang belum terdokumentasi
- [ ] Content tidak berubah SETELAH reports di-run

### 2. combined.md = Content + Q&A
- [ ] `combined.md` berisi exact current `content.txt` sebagai bagian pertama
- [ ] Q&A pairs di combined.md match Q&A pack terbaru
- [ ] Tidak ada stale Q&A dari versi sebelumnya

### 3. Reports are Current
- [ ] EP Gate report merefleksikan content saat ini
- [ ] Taste Director report merefleksikan content saat ini
- [ ] Q&A AI Review merefleksikan Q&A pack saat ini
- [ ] Tidak ada report dari versi sebelumnya yang masih di-reference

### 4. All Gates PASS
- [ ] EP Gate: PASS
- [ ] Rigid Gates: ALL PASS
- [ ] Taste Director: PASS (all 7 personas)
- [ ] Hostile Judge Attack: reviewed
- [ ] Q&A AI Review: PASS
- [ ] Human Typed Copy: PASS

### 5. No Forbidden Claims
- [ ] Tidak ada "guaranteed winner"
- [ ] Tidak ada "guaranteed EP5"
- [ ] Tidak ada "guaranteed RQ5"
- [ ] Hanya allowed claims: "local strict PASS", "RQ5-ready"

### 6. Compliance Final Check
- [ ] No em dashes
- [ ] @RallyOnChain mention present
- [ ] Single post (no thread)
- [ ] URLs clickable (no punctuation after)
- [ ] Length within campaign limits
- [ ] All required missions elements present

---

## CONFLICT RESOLUTION

Kalau ada inconsistency:

| Issue | Action |
|---|---|
| Content changed after report | Rerun ALL affected reports |
| Q&A refers to old content | Rebuild Q&A pack |
| Report says PASS tapi content berubah | Report = STALE. Rerun. |
| Two reports contradict | Trust yang lebih recent. Rerun kalau perlu. |

**JANGAN ship stale pass.** Satu stale report = seluruh submission questionable.

---

## OUTPUT

```
FINAL_INTEGRITY_REPORT.md
```

Isi:
- Checklist results (all 6 sections)
- Any conflicts found + resolution
- Final status: INTEGRITY PASS / INTEGRITY FAIL
- If PASS: "SUBMIT READY"
- If FAIL: list specific fixes needed

---

## RELATIONSHIP KE SKILL LAIN

- **Step Conflict Check (Skill 17)**: Skill 17 cek per-step. Skill 25 cek cross-artifact consistency.
- **The Oath (Skill 20)**: Skill 20 enforce rules. Skill 25 verify compliance.
- **Submit Checklist (Skill 26)**: Skill 25 = integrity check. Skill 26 = final go/no-go.
