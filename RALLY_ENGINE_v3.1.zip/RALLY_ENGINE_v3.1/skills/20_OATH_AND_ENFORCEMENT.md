# ⚖️ SKILL 20: THE OATH + ZERO TOLERANCE

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 RALLY-FUNDAMENTAL-LAW.md (The Oath + Zero Tolerance)
**Purpose:** Enforcement mechanism. Law tanpa enforcement = saran, bukan aturan.

---

## THE OATH

**Ketika `/rally` dipanggil, AI WAJIB:**

1. ✅ **MEMBACA LAW INI DULU** sebelum melakukan apapun
2. ✅ **MEMBACA SKILL FILE YANG RELEVAN** sebelum menjalankan setiap phase
3. ✅ **TIDAK BOLEH JALANKAN DARI MEMORY** — baca skill file setiap kali
4. ✅ **TIDAK BOLEH SKIP** satupun step atau sub-step
5. ✅ **TIDAK BOLEH ASSUME** data yang tidak di-fetch
6. ✅ **TIDAK BOLEH BOHONG** tentang status completion
7. ✅ **TIDAK BOLEH LANJUT** ke Phase berikutnya sebelum Phase ini PASS
8. ✅ **TIDAK BOLEH COMPROMISE** pada kualitas output
9. ✅ **MEMBACA PROVEN EXAMPLES** sebelum menjalankan phase yang ada contohnya
10. ✅ **AI MANUAL REVIEW** — baca konten langsung, bukan JSON data saja

---

## ZERO TOLERANCE VIOLATIONS

Pelanggaran berikut = **IMMEDIATE STOP & RESTART**:

| # | Violation | Consequence |
|---|-----------|-------------|
| 1 | Skip data fetch | ❌ RESTART dari Phase 1 |
| 2 | Skip artifact generation | ❌ RESTART dari step yang di-skip |
| 3 | Generate Q&A sebelum konten PASS stress test | ❌ RESTART dari Phase 2 |
| 4 | Assume data instead of fetch | ❌ RESTART dari Phase 1 |
| 5 | Claim PASS tanpa run gate | ❌ RESTART dari gate yang di-skip |
| 6 | Skip stress test | ❌ RESTART dari Phase 2 |
| 7 | Skip Taste Director | ❌ RESTART dari Skill 13 |
| 8 | Lanjut ke Q&A saat konten FAIL | ❌ STOP, regenerate konten |
| 9 | Tidak dokumentasi keputusan | ❌ RESTART dari step yang tidak terdokumentasi |
| 10 | Run dari memory tanpa baca skill file | ❌ RESTART dari phase yang bersangkutan |
| 11 | Copy winner surface tanpa transform | ❌ RESTART dari Phase 1 (Original Thesis) |
| 12 | Declare "guaranteed winner/EP5/RQ5" | ❌ RESTART, review allowed claims |

---

## PHASE GATES

**Phase 1 → Phase 2:**
- ✅ Konten generated (min 1 candidate)
- ✅ Skill files dibaca sebelum generate
- ✅ Content Thinking Framework dijalankan
- ❌ TIDAK perlu PASS — Phase 2 yang akan test

**Phase 2 → Phase 3:**
- ✅ EP Gate PASS
- ✅ Rigid Gates ALL PASS
- ✅ Taste Director PASS
- ✅ Hostile Judge Attack reviewed
- ✅ Hidden Gate + Winner Pull considered
- ✅ Feedback iteration completed (max 3)
- ✅ Safe flags fixed (if any)
- ❌ JANGAN lanjut kalau konten masih FAIL

**Phase 3 → SUBMIT:**
- ✅ Q&A pack 20 pairs generated
- ✅ Q&A AI Review PASS
- ✅ Q&A format matches proven example
- ✅ Human Typed Copy check PASS
- ✅ Final Integrity check PASS
- ✅ User APPROVE

---

## ALLOWED VS FORBIDDEN CLAIMS

### Allowed:
- "local strict PASS"
- "Irreducible Apex local PASS" (PRODUCT/DEBAT only)
- "RQ5-ready"
- "Gold V3 PASS"
- "proven workflow"

### Forbidden:
- "guaranteed all-max"
- "guaranteed winner"
- "guaranteed top 1%"
- "guaranteed RQ5"
- "guaranteed EP5"

---

## RELATIONSHIP KE SKILL LAIN

This skill is the ENFORCEMENT LAYER untuk semua skill lain.
- Kalau skill bilang "baca skill dulu" → The Oath enforce itu
- Kalau skill bilang "jangan skip" → Zero Tolerance enforce itu
- Kalau skill bilang "jangan dari memory" → The Oath enforce itu

**This skill has HIGHEST AUTHORITY after the campaign brief itself.**
