# 🔨 SKILL 11: AMPLIFY TECHNIQUES

**Tujuan:** Buat insight terasa nyata, konkret, dan visceral.

**Prinsip:** Detail harus spesifik sampai hanya KAMU yang bisa menulisnya.

---

## 7 TEKNIK (BERURUT DARI YANG PALING PENTING)

### 1. Detail Spesifik — FONDASI, harus ada di setiap konten

Bukan "kopi" → tapi "Kopi Keladi."
Bukan "dia bilang sesuatu" → tapi "dia bilang the rice pot at the end of the day."

Detail spesifik = tanda tangan. Kalau orang lain bisa tulis hal yang sama dengan detail yang sama, belum cukup spesifik.

**Contoh dari data:**
- @uso411247: "rented suit, coupon, 40-minute drive" (bukan "a nice outfit")
- @str_kerx: "almost broke down my own door at 4:30am" (bukan "was worried")
- @_iamdotun_: "born at 6'7\", which turned out to be his least useful specification" (bukan "tall")

---

### 2. Angka — Senjata paling kuat setelah detail

Angka tidak bisa diperdebatkan. Angka bikin klaim jadi fakta.

**Contoh dari data:**
- @ahonjumaidil: "200K followers, 11 likes" → kontras langsung, tidak perlu penjelasan
- @_iamdotun_: "6'7\"" → spesifisitas yang absurd
- @str_kerx: "4:30am" → taruh reader di momen spesifik
- @uso411247: "40-minute drive" → effort yang terukur

**Tip:** Angka yang kuat = angka yang kontras dengan ekspektasi. "200K" besar, "11" kecil. Bersama-sama = ledakan.

---

### 3. Dialog Kutipan — Bikin reader DENGAR, bukan baca

Dialog mengubah tulisan menjadi percakapan. Reader tidak cuma membaca — mereka mendengar suara.

**Contoh dari data:**
- @alver1301: "'I deleted my comment. That wasn't an apology.'" → pembaca DENGAR nada datar yang powerful
- @chainops1_: "'I make this every day. It's terrible. But I'm still here.'" → pembaca DENGAR kejujuran Marco
- @str_kerx: "like this was just another shift and I was the useless intern" → pembaca DENGAR frustasi yang lucu

**Tip:** Dialog terbaik = singkat, tidak perlu kata pengantar, biar konteks yang menjelaskan siapa yang bicara.

---

### 4. Kontras — Dua hal berdampingan yang saling memperkuat

Kontras tidak perlu penjelasan. Reader langsung merasakan ketegangan.

**Contoh dari data:**
- @ahonjumaidil: "200K followers, 11 likes" → besar vs kecil
- @svictorayomi: "venture-backed APIs with token wrappers" → lama vs baru tapi sama saja
- @uso411247: "rented suit" vs "toast" → keseriusan acara vs kesederhanaan diri

**Tip:** Kontras terkuat = antara ekspektasi dan kenyataan. "Supposed to be X, actually Y."

---

### 5. Nama Spesifik — Hanya kamu yang bisa tulis ini

Nama = keputusan editorial paling sederhana dan paling kuat.

**Contoh dari data:**
- @str_kerx: "Hallie" (kucing, bukan "my cat") → karakter jadi hidup
- @chainops1_: "Marco" (tetangga, bukan "my neighbor") → relationship jadi nyata
- @sameddy01: "Maya" (teman, bukan "my friend") → invest reader di orang

**Tip:** Nama tidak harus nama orang. "Kopi Keladi", "Kendari", "warung dekat pelabuhan" = nama tempat yang sama kuatnya.

---

### 6. Adegan/Momen — Taruh reader di satu detik spesifik

Adegan = detail yang bisa difilmkan. Kamera bisa tangkap apa yang kamu tulis?

**Contoh dari data:**
- @str_kerx: "almost broke down my own door at 4:30am" → kamera bisa tangkap: orang, pintu, jam, kepanikan
- @chainops1_: "terrible paella, wet socks and sadness" → kamera bisa tangkap: piring, kaki basah, ekspresi
- @uso411247: "rented suit, coupon, 40-minute drive" → kamera bisa tangkap: jas rental, kupon, jalan malam

**Tip:** Kalau kamera tidak bisa tangkap, terlalu abstrak. Turunkan ke level fisik.

---

### 7. Metafora — Hanya kalau ditempel pada detail konkret

Metafora sendiri tanpa detail = generic. Metafora + detail = mematikan.

**Contoh dari data:**
- @ahonjumaidil: "peacock tail" → BEKERJA karena ada "200K followers, 11 likes" di sebelahnya. Tanpa angka, cuma metafora biasa.
- @navtq0808: wallet sebagai metaphor → BEKERJA karena dia benar-benar menulis TOAST ke wallet, bukan sekadar bilang "wallet is like a friend"

**Tip:** Kalau metafora bisa berdiri sendiri tanpa detail pendukung → kemungkinan terlalu generic.

---

## ⚠️ YANG BUKAN TEKNIK

### Emosi = EFEK SAMPING, bukan teknik

Data: 0/8 winner menggunakan emosi sebagai teknik.

| Menambahkan emosi langsung | Emosi muncul dari detail |
|---|---|
| "I feel sad" → performing | "rented suit, coupon, 40-minute drive" → reader MERASAKAN |
| "This is heartbreaking" → telling | "'I deleted my comment. That wasn't an apology.'" → reader MERASAKAN |
| "I believe in this" → red flag (DEBAT) | "200K followers, 11 likes" → reader MERASAKAN absurdity |

Emosi yang ditambahkan langsung = performing. Juri di DEBAT bilang: "I believe" = red flag, performing anger = most dangerous.

### Vivid = HASIL, bukan teknik

"Make it vivid" = "buat bagus." Tidak actionable.

7 teknik di atas, kalau dijalankan dengan benar, MENGHASILKAN vividness. Jangan target vividness. Target detail spesifik, angka, dialog — vividness datang dengan sendirinya.

---

## SELF-CHECK

Setelah amplify, tanya:

1. **"Bisakah pembaca MELIHAT apa yang saya maksud?"** → Kalau tidak, tambah adegan atau detail spesifik.
2. **"Bisakah pembaca MERASAKAN apa yang saya maksud?"** → Kalau tidak, tambah dialog atau kontras.
3. **"Apakah detail ini spesifik sampai hanya SAYA yang bisa menulisnya?"** → Kalau tidak, turunkan ke level yang lebih spesifik.
4. **"Apakah setiap detail MEMBUKTIKAN insight, atau sekadar mendekorasi?"** → Kalau mendekorasi, hapus atau hubungkan ke insight.
