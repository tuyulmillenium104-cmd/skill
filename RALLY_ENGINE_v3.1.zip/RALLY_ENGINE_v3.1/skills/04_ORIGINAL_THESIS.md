# 💡 SKILL 04: ORIGINAL THESIS ENGINE

**Tujuan:** Generate thesis yang clear, specific, fresh, dan campaign-native.

---

## FRAMEWORK

### 1. Wrong Assumption
Apa yang semua orang pikir tapi salah?
- "Wikipedia page should present the truth" → SALAH, Wikipedia pages are battlegrounds of editing wars
- "You should toast people who helped you succeed" → SALAH, real backbone is people who stay when you fumble

### 2. Human Problem
Apa masalah manusia yang relate?
- "Nobody's bio is clean" → everyone has parts someone would dispute
- "We all fumble" → everyone has embarrassing moments

### 3. Contradiction = REFRAME
Apa yang berlawanan dari ekspektasi?

**Ini adalah REFRAME.** Contradiction yang mengubah cara pandang = philosophical flip.

| Genre | Default reframe | Contoh |
|---|---|---|
| KREATIF | Flip asumsi tentang format/topik | "Your real Wikipedia page is the Talk page, not the article" |
| DEBAT | Flip asumsi tentang argumen | "We didn't remove middlemen, we renamed them" |
| PRODUCT | Flip asumsi tentang mekanisme | "The slowest step is actually the security feature" |
| KONFESIONAL | Flip asumsi tentang makna (BUKAN emosi) | "Loss deserves a toast more than winning" |

**⚠️ Jika reframe terasa dipaksakan atau mengurangi keaslian:**
→ Gunakan story, observation, analogy, atau first-principles sebagai gantinya.
→ Di KONFESIONAL murni, story/observation bisa lebih kuat dari reframe.

### 4. Thesis = INSIGHT
Statement yang clear, specific, fresh. Ini adalah one memorable insight.

**Pertanyaan test:** "Jika pembaca hanya mengingat satu kalimat, kalimat apa?"
- Kalau tidak bisa dijawab → thesis belum cukup tajam
- Kalau jawabannya bisa ditulis orang lain → thesis belum cukup spesifik

### 5. Concrete Object = AMPLIFIER
Detail yang vivid dan memorable. Ini adalah amplifier.

**Amplifier harus MEMBUKTIKAN thesis, bukan mendekorasi.**

| Thesis (insight) | Amplifier (bukti) | ❌ Dekorasi |
|---|---|---|
| "Slow internet = best audit" | "Never read whitepaper, never rug pulled" | "WiFi is really slow here" |
| "Follower count = nothing" | "200K followers, 11 likes" | "Views can be bought" |
| "Your page is the Talk page" | "Flagged for deletion by editors who never been to a warung" | "Wikipedia has debates" |

### 6. CTA
Pertanyaan yang mengundang personal response.

**CTA terbaik = ties back ke reframe/thesis.**

| Thesis | CTA yang ties back | CTA generik |
|---|---|---|
| "Your page is the Talk page" | "What would your Talk page say that the article never would?" | "What's your Wikipedia page?" |
| "Slow internet = best audit" | "What's the one thing your hometown knows that Wikipedia still doesn't?" | "What do you think?" |
| "Follower count = nothing" | "What metric do you trust that nobody else measures?" | "Do you agree?" |

---

## THESIS QUALITY CHECK

- [ ] Is it CLEAR? (bisa dijelarkan dalam 1 kalimat)
- [ ] Is it SPECIFIC? (bukan generic wisdom — hanya kamu yang bisa tulis ini)
- [ ] Is it FRESH? (belum dipakai di pool — cek "apa yang sudah sering ditulis?")
- [ ] Is it CAMPAIGN-NATIVE? (bisa dieksekusi dalam format campaign)
- [ ] Is it a REFRAME or genuine insight? (bukan sekadar observasi)
- [ ] Does it have AMPLIFIERS that PROVE the thesis? (bukan dekorasi)
- [ ] Does it have a CTA that FOLLOWS from the thesis? (bukan generik)

---

## OUTPUT

1. ✅ Wrong Assumption stated
2. ✅ Human Problem stated
3. ✅ Contradiction/REFRAME stated
4. ✅ Thesis/INSIGHT stated
5. ✅ Concrete Object/AMPLIFIER identified (proves thesis)
6. ✅ CTA proposed (ties back to thesis)
7. ✅ Quality check passed
