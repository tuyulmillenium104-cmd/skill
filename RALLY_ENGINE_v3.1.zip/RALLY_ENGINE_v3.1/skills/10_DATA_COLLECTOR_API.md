# 🔌 SKILL 10: DATA COLLECTOR — API Reference

**Tujuan:** Referensi lengkap untuk fetch data dari Rally dan fxtwitter API.

---

## RALLY API

### Campaign List
```bash
curl "https://app.rally.fun/api/campaigns?limit=10&offset=0"
```
Returns: array of campaigns with id, title, intelligentContractAddress, etc.

### Campaign Detail
```bash
curl "https://app.rally.fun/api/campaigns/{intelligentContractAddress}"
```
Returns: full campaign object

**Key fields:**
- `id`, `intelligentContractAddress`, `title`, `goal`, `knowledgeBase`
- `rules`, `style`, `missions[]`, `gateWeights`, `metricWeights`
- `token`, `campaignRewards`, `startDate`, `endDate`, `maxWinners`

### Submissions Pool
```bash
curl "https://app.rally.fun/api/submissions?campaignAddress={addr}&limit=100&offset=0"
```
Returns: array of submissions

**Key fields per submission:**
- `id`, `campaignAddress`, `xUsername`, `tweetId`
- `atemporalPoints`, `attoRawScore`, `temporalPoints`
- `analysis[]` — array of judge verdicts per category
- `syncStatus`, `timestamp`

**Analysis structure per category:**
```json
{
  "category": "Engagement Potential",
  "atto_score": "5000000000000000000",
  "atto_max_score": "5000000000000000000",
  "analysis": "Full verdict text..."
}
```

Score conversion: `atto_score / 1e18` = actual score

---

## FXTWITTER API

### Tweet Content
```bash
curl "https://api.fxtwitter.com/status/{tweetId}"
```
Returns: full tweet object with text, media, author info, engagement metrics

**Key fields:**
- `tweet.text` — full tweet text
- `tweet.raw_text.text` — text with display range
- `tweet.author.screen_name` — username
- `tweet.likes`, `tweet.retweets`, `tweet.replies`, `tweet.views` — metrics
- `tweet.media.photos[]` — images if any

---

## HELPER COMMANDS

### Get top submissions sorted by score
```python
import json
data = json.load(open('submissions_raw.json'))
data.sort(key=lambda x: int(x.get('atemporalPoints','0')), reverse=True)
```

### Extract score per category
```python
for a in submission['analysis']:
    cat = a['category']
    score = int(a['atto_score']) / 1e18
    max_score = int(a['atto_max_score']) / 1e18
    print(f"{cat}: {score:.0f}/{max_score:.0f}")
```

### Get EP 4/5 verdicts
```python
for s in data:
    for a in s['analysis']:
        if a['category'] == 'Engagement Potential':
            score = int(a['atto_score']) / 1e18
            if score == 4:
                print(a['analysis'][:500])
```

---

## RATE LIMITS

- Rally API: No known rate limits, but be respectful
- fxtwitter: No known rate limits
- Recommendation: Add 1-second delay between requests if fetching many

---

## COMMON ISSUES

1. **Some submissions have no analysis** — submission might be too new or not yet synced
2. **atto_score is in wei format** — divide by 1e18 to get human-readable score
3. **Some tweets deleted** — fxtwitter will return error for deleted tweets
4. **Campaign address is case-sensitive** — use exact address from campaign list
