# ✅ SKILL 26: SUBMIT CHECKLIST

**Phase:** 3 (Q&A)
**Purpose:** Final go/no-go sebelum submit. Semua phase harus complete.

---

## PREREQUISITES

### Phase 1: GENERATE — Complete?
- [ ] Campaign brief understood
- [ ] Data fetched (submissions, winners, scores)
- [ ] Genre detected
- [ ] Source truth extracted (what judges want/don't want)
- [ ] Fresh surface selected (unique angle)
- [ ] Content Thinking Framework executed (READ→INSIGHT→AMPLIFY→POLISH→PUBLISH)
- [ ] Original thesis with REFRAME + AMPLIFIER
- [ ] Content generated (1-3 candidates, 1 selected)
- [ ] Skill files were READ before execution (The Oath)

### Phase 2: STRESS TEST — Complete?
- [ ] EP Gate Review: PASS
- [ ] Rigid Gates: ALL PASS
- [ ] Taste Director (7 personas): PASS
- [ ] Hostile Judge Attack: reviewed, ≤6 fair deductions
- [ ] Hidden Gate Mining: considered
- [ ] Winner Pull Mining: considered
- [ ] Step Conflict Check: no unresolved conflicts
- [ ] Feedback + Iteration: completed (max 3)
- [ ] Flag Paradox: RISKY+ flags documented but NOT fixed

### Phase 3: Q&A — Complete?
- [ ] Q&A pack: 20 pairs generated
- [ ] Type distribution: 4SP/5CH/5TD/4HT/2RE
- [ ] Q&A AI Review: PASS
- [ ] Gold RQ Standard: thresholds met
- [ ] Human Typed Copy: PASS
- [ ] Final Integrity: PASS
- [ ] User APPROVE

---

## FINAL COMPLIANCE

- [ ] No em dashes
- [ ] @RallyOnChain mention present and natural
- [ ] Single post (no thread)
- [ ] URLs clickable (no punctuation after URL)
- [ ] Length within campaign limits
- [ ] All mission required elements present
- [ ] No forbidden claims
- [ ] Content reads human, not AI-engineered

---

## GO / NO-GO

### ✅ GO — Submit when ALL checkboxes above are checked

Allowed claims:
- "local strict PASS"
- "RQ5-ready"
- "SUBMIT READY"

### ❌ NO-GO — Do NOT submit if ANY checkbox unchecked

Action: Go back to the failing phase and resolve.

---

## SUBMISSION DATA NEEDED

- Campaign address
- Content (exact text to post)
- Screenshot of post
- Q&A pack ready for replies
- Run log documented

---

## AFTER SUBMIT

1. Monitor for replies
2. Deploy A-COPY matching real organic replies
3. Prioritize: real confession > serious skepticism > technical questions
4. Do NOT deploy simulated experiences as fake organic engagement
5. Document real judge verdict when available
6. Feed verdict back into engine (lessons learned)
