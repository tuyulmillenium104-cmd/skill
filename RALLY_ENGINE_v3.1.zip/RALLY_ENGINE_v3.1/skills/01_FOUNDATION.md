# 📡 SKILL 01: FOUNDATION — Data Collection

**Tujuan:** Fetch semua data yang dibutuhkan sebelum generate konten.

---

## API ENDPOINTS

```bash
# Campaign list
curl "https://app.rally.fun/api/campaigns?limit=10&offset=0"

# Campaign detail
curl "https://app.rally.fun/api/campaigns/{intelligentContractAddress}"

# Submissions pool
curl "https://app.rally.fun/api/submissions?campaignAddress={addr}&limit=100&offset=0"

# Tweet content (for reading winner tweets)
curl "https://api.fxtwitter.com/status/{tweetId}"
```

---

## DATA YANG HARUS DI-COLLECT

### 1. Campaign Brief
- Title, goal, knowledgeBase, rules, style
- Missions[] (required elements)
- gateWeights (which categories matter)
- metricWeights (scoring weights)
- Campaign rewards & dates

### 2. Pool Submissions (min 100)
- Sort by atemporalPoints (highest = best performers)
- Extract per submission:
  - xUsername, tweetId
  - All analysis scores (EP, Orig, CA, CC, TQ, RQ)
  - Analysis text (judge verdict)
  - atemporalPoints (ranking)

### 3. Top 3-5 Winner Content
- Fetch via fxtwitter to get FULL tweet text
- Read content directly
- Extract what judge PRAISED specifically

### 4. Score Distribution
```
EP 5/5: X/100 (X%)  ← How hard is this campaign?
EP 4/5: X/100 (X%)
Orig 2/2: X/100 (X%)
Orig 1/2: X/100 (X%)
```

### 5. EP 4 Causes
- From EP 4 verdicts, extract: why did judge give 4 instead of 5?
- Common patterns: weak hook, too long, soft CTA, generic

### 6. EP 5 Praise Patterns
- From EP 5 verdicts, extract: what did judge specifically praise?
- Common patterns: specific details, authentic voice, strong hook

---

## OUTPUT

Setelah Foundation, kamu harus punya:
1. ✅ Campaign brief understood
2. ✅ Score distributions known
3. ✅ Top 3 winner content read
4. ✅ EP 4 causes identified
5. ✅ EP 5 praise patterns identified
6. ✅ Genre detected (see GENRE_DETECTION_GUIDE.md)
