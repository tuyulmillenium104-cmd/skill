# 🔐 SKILL 27: PUBLIC COPY LEAKAGE POLICY

**Phase:** 3 (Q&A)
**Source:** RESTORED from v2.3 PUBLIC_COPY_LEAKAGE_POLICY.md
**Purpose:** Prevent private skill/checker/audit language from leaking into public copy.

---

## One Prompt Rule

```
PUBLIC-COPY PRIVACY RULE:
Q-COPY and A-COPY must read as public replies from real people.
Do not include language that reveals our private skill files, checker workflow, audit process, internal metadata, or generation scaffolding.
Official Rally/campaign/community terms are allowed when they are natural in context.
If unsure, ask: would a normal Rally participant write this publicly without seeing our skill files? If no, rewrite it into plain public language.
```

---

## Hard Leakage Ban List

These terms must NEVER appear in Q-COPY or A-COPY:

| Category | Banned Terms |
|---|---|
| Checker names | `rally-rq-prompt-answer`, `rally-rq-mechanics`, `rally-naturalness`, `rally-qna-gold`, `rally-rq-v3-policy` |
| Audit labels | `decision-marker`, `coefficient of variation`, `5-gram shell`, `naturalness review` |
| Metadata labels | `qa_ranking`, `voicePersona`, `voiceMode`, `SIMULATED_ARCHETYPE`, `CONDITIONAL_ORGANIC_MATCH_ONLY` |
| Skill terms | `loser DNA`, `self-judge`, `hidden gate`, `winner pull`, `exponential content`, `irreducible apex` |
| Generation scaffolding | `EVIDENCE_PERSONA_`, `EVIDENCE_VOICE_`, `scaffold` |

---

## Operating Note

Do not maintain a broad forbidden vocabulary for normal Rally, campaign, marketing, or creator language. Keep leakage control **lightweight**.

A tiny exact-match guardrail may catch obvious private scaffolding examples, but the real rule is the prompt above, not a long blacklist.

Everything else is a writing/naturalness decision, not a hard leakage ban.

---

## What IS Allowed in Public Copy

- Official Rally terms: `@RallyOnChain`, `Rally`, campaign names
- Campaign-specific terms from the brief
- Normal crypto/marketing/creator language
- Product/protocol names that are public knowledge

---

## Relationship to Skill 24 (Human Typed Copy)

- **Skill 27 (this)**: Prevents INTERNAL terms from leaking (privacy)
- **Skill 24**: Ensures public copy sounds naturally HUMAN (naturalness)
- Both must pass. A line can be leak-free but still sound robotic, or human but leak internal terms.

---

## Enforcement

If leakage is found in final Q&A pack:
1. Identify the leaked term
2. Rewrite the affected Q-COPY or A-COPY into plain public language
3. Re-run Q&A AI Review (Skill 23)
4. Re-run Human Typed Copy check (Skill 24)
