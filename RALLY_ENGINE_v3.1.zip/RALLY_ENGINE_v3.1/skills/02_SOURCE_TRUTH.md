# 🔍 SKILL 02: SOURCE TRUTH — Hidden Gates & Winner DNA

**Tujuan:** Identifikasi apa yang juri AKTUAL pedulikan, dari data bukan teori.

---

## WINNER DNA EXTRACTION

Untuk setiap top winner, extract:

### Pattern Analysis:
1. **Apa yang MEMBEDAKAN winner dari loser?** (specific details, structure, voice)
2. **Apa yang winner PUNYA tapi loser TIDAK?** (nama? twist? reframe? humor?)
3. **Apa yang winner TIDAK PUNYA tapi loser PUNYA?** (generic content? forced brand? long paragraphs?)

### Per Winner Detail:
- Opening line (hook type: tension? curiosity? humor? contradiction?)
- Structure (linear? non-linear? twist?)
- Specificity level (hyper-specific vs generic)
- @RallyOnChain placement (beginning? middle? end? how integrated?)
- CTA type (naming? conceptual? emotional? humorous?)
- Name present? (Y/N)
- Twist/subversion present? (Y/N)
- Reframe present? (Y/N)

---

## HIDDEN GATES

### What judges PRAISE (from data):
1. Specificity (nama, angka, detail konkret)
2. Authenticity (human voice, admission of weakness)
3. Hook effectiveness (baris pertama)
4. @RallyOnChain natural
5. CTA yang mengundang reply
6. Conversation potential
7. Value delivery

### What judges PENALIZE (from data):
1. Formula risk (recognizable structure)
2. Polish risk (slogan-like, optimized)
3. Weak hook
4. Generic content
5. @RallyOnChain forced
6. Missing CTA
7. Too long

### Genre-specific hidden gates:
- KONFESIONAL: "told not shown" = OK, linear = OK, emotional beats = essential
- KREATIF: format execution = essential, humor > emotion, hook must be format-native
- PRODUK: mechanism clarity = essential, tactical value = important
- DEBAT: stance strength = essential, contrarian angle = fresh

---

## OUTPUT

1. ✅ Winner DNA mapped
2. ✅ Hidden gates identified (praise + penalize)
3. ✅ Genre-specific rules understood
4. ✅ What NOT to do (from loser patterns)
