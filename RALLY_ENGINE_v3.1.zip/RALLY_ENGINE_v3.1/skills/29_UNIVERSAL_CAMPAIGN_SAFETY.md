# 🛡️ SKILL 29: UNIVERSAL CAMPAIGN SAFETY PROTOCOL

**Phase:** 2 (STRESS TEST) — run before submit
**Source:** RESTORED from v2.3 UNIVERSAL-RALLY-CAMPAIGN-SAFETY-PROTOCOL.md
**Purpose:** Make the Rally workflow safer across ALL campaigns. Campaign-agnostic safety checks.

---

## Core Principle

```
Same safety discipline. Campaign-specific creative output.
```

This protocol must run before packaging the final deliverable.

---

## 1. Mission Isolation Lock

Every mission is a separate product.

Rules:
- Do not reuse the same content for multiple missions
- Mission 0 and mission 1 must have different strategic intent
- Before finalization, compare content across missions
- If two mission contents are near-identical (similarity > 0.82), rebuild at least one

---

## 2. Canonical Handle and URL Lock

Each campaign has canonical public entities:

- Required handles: verify exact count matches brief
- Forbidden/old handles: verify zero occurrences
- Quote/reply URL: verify correct URL
- Campaign title: matches API title
- Prohibited formatting: verify none present

If the user corrects a handle, treat it as canonical override. Replace all public occurrences.

---

## 3. Public vs Internal Deliverable Separation

Public folder may contain:
```
README.md
mission-x/content.txt
mission-x/content_and_qna_final.md
```

Public folder must NOT contain:
- Q-COPY, A-COPY labels (in public-facing files)
- Tier labels
- Gold V3 metadata
- qa_ranking references
- voicePersona, voiceMode
- SIMULATED_ARCHETYPE labels
- Internal metadata / checker names / private audit workflow

---

## 4. Semantic Process Order Audit

For campaigns explaining a process, pipeline, protocol, workflow, or stack — check temporal/causal order.

Safe order for commerce/contract pipelines:
```
agreement → escrow/payment hold → work/execution → verification → dispute → release/settlement
```

Danger patterns to catch:
- Settlement before work/execution
- Verdict before evidence
- Release before proof
- Dispute before agreement
- Verification before delivery
- Appeal before initial decision
- Final settlement before contested work assessed

---

## 5. Q&A Public Naturalness Lock

Q&A must read as public replies from humans, not as generated labels.

Risk patterns (must NOT appear in public Q/A):
```
Small doubt:
Real issue:
Hot take:
Wrong lesson:
Challenge:
Technical deep-dive:
Specific probe:
```

These are acceptable in private ranking metadata only.

Universal Q&A rules:
- No public parser labels
- No private skill metadata
- No repetitive opening shell
- No colon-label opening unless genuinely human
- No semicolon-heavy artificial style
- Q&A must match final content, final CTA, and final handle

---

## 6. Final Synchronization Gate

After every content, handle, CTA, or Q&A change, update ALL final surfaces:

```
1. content.txt
2. content_and_qna_final.md
3. combined/internal file if used
4. contract/report if used
5. zip package
6. grep/sanity checks
7. present final file
```

Never say "updated" until the zip and public folder are actually rebuilt.

---

## 7. Controllable Truth Boundary

Universal claim allowed:
```
No known controllable non-max reason remains in the local audit set.
```

Universal claims forbidden:
```
Guaranteed all-max
Guaranteed EP 5/5
Guaranteed RQ 5/5
Guaranteed top 1%
Guaranteed winner
Guaranteed rewards
```

Always separate:
- controllable local gates
- subjective local judgment
- external Rally judge variance
- real replies and engagement

---

## 8. Universal Final Checklist

Before final delivery, answer all:

- [ ] Mission folders are isolated and not duplicated
- [ ] Required handle count is correct
- [ ] Forbidden/old handle count is zero
- [ ] Required URL is present where required
- [ ] Main content in content.txt equals main content in public MD
- [ ] Q&A count is correct
- [ ] Q&A aligns with final content and CTA
- [ ] Public folder has no internal metadata labels
- [ ] Semantic process order has no causal contradiction
- [ ] Zip was rebuilt after last edit
- [ ] External score guarantees are not claimed

---

## Relationship to Skill Lain

- **Final Integrity (Skill 25)**: Cross-artifact consistency. This skill = universal safety across campaigns.
- **Step Conflict Check (Skill 17)**: Per-step conflicts. This skill = universal cross-campaign safety.
- **The Oath (Skill 20)**: Enforcement mechanism. This skill = specific safety rules to enforce.
