# 🏆 SKILL 16: WINNER-PULL MINING

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 WINNER-PULL-MINING-PROTOCOL.md
**Purpose:** Extract APA yang juri PRAISE dari winners, supaya konten dibangun untuk menang, bukan hanya menghindari kekalahan.

---

## CORE IDEA

Hidden-Gate Mining = **DEFENSE** (apa yang bisa bikin deduction?)
Winner-Pull Mining = **OFFENSE** (apa yang bikin judge mau kasih max?)

Draft harus punya keduanya:
1. Hidden gates closed (tidak ada deduction yang jelas)
2. Winner-pull mechanisms present (ada alasan kuat untuk praise)

---

## DATA DOES NOT WRITE

Winner-pull mining TIDAK boleh membuat first draft.

Urutan yang benar:
1. Buat original thesis dulu
2. Buat fresh concrete object
3. Buat mechanism bridge
4. Buat CTA idea
5. **BARU** gunakan winner-pull data untuk JUDGE apakah draft punya cukup positive force

Kalau draft dimulai sebagai variant dari winner example → REJECT atau transform via ANTI_COPY rule.

---

## WHAT TO MINE FROM WINNERS

Jangan copy text winner. Extract MECHANISMS:

- Hook mechanism (bagaimana hook-nya kerja?)
- Concrete scenario type (tipe contoh apa yang dipakai?)
- Mechanism explanation style (gaya penjelasan mekanisme?)
- Value payload / mental model (apa value yang diberikan?)
- CTA pattern (pola CTA?)
- Voice / persona (persona apa yang dipakai?)
- Brand bridge style (gaya integrasi brand?)
- Structure / pacing (pola struktur/ritme?)
- Shareable/quotable line pattern (baris yang bisa di-quote?)

---

## CLASSIFICATION

Untuk setiap candidate pull:

| Verdict | Arti |
|---|---|
| **USE_NOW** | Harus shape current draft |
| **WATCH** | Berguna tapi tidak required |
| **DO_NOT_COPY** | Kuat di winner, tapi terlalu spesifik/crowded untuk reuse |

Setiap accepted pull harus di-express sebagai MECHANISM, bukan copied phrase.

❌ Bad: "Pakai frase 'claim number' karena winner pakai"
✅ Good: "Pakai administrative object yang bikin workflow concrete, seperti claim number, lab order, receipt, itinerary"

---

## WINNER-PULL CONTRACT

Sebelum drafting, isi:

```md
# WINNER-PULL CONTRACT

## Expected positive verdict lines
1. Judge should praise hook karena...
2. Judge should praise concrete scenario karena...
3. Judge should praise mechanism clarity karena...
4. Judge should praise value/CTA karena...
5. Judge should praise originality/human voice karena...

## Evidence lines planned
- Hook line:
- Scenario line:
- Mechanism line:
- Value rule line:
- CTA line:
```

Kalau tidak bisa tulis expected positive verdict lines → **jangan draft dulu.**

---

## OUTPUT

```
WINNER_PULL_MAP.md
```

Isi:
- Tabel: | Pull Mechanism | Evidence (winner example) | Verdict | Fresh Expression |
- Winner-pull contract

---

## RELATIONSHIP KE SKILL LAIN

- **Hidden-Gate Mining (Skill 15)**: Defense + Offense. Gunakan kedua reports.
- **Reframe+Amplifier (Skill 12)**: Winner-pull dari Orig 2/2 winners = reframe spesifik + amplifier spesifik. Ini mechanism-nya.
- **Anti-Copy Rule**: Winner surface → underlying mechanism → fresh expression. Jangan copy surface.
