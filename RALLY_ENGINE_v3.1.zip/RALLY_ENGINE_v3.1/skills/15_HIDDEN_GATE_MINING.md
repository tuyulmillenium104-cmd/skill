# 🔍 SKILL 15: HIDDEN-GATE MINING

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 HIDDEN-GATE-MINING-PROTOCOL.md
**Purpose:** Temukan pola deduction judge dari data submissions SEBELUM dan SESUDAH drafting.

---

## CORE PRINCIPLE

Hidden gates = pola judge yang IMPLISIT. Tidak ditulis di brief, tapi konsisten muncul di verdicts.

Contoh:
- Judge selalu penalize "generic CTA" → hidden gate: CTA harus concrete
- Judge praise "specific detail" → hidden gate: detail spesifik = positive signal
- Judge penalize "template smell" → hidden gate: konten harus terasa original

---

## SCOPE CLASSIFICATION

Setiap hidden gate harus di-scope sebelum jadi drafting rule:

| Scope | Kapan | Contoh |
|---|---|---|
| **GLOBAL** | Pola muncul di banyak campaign unrelated | "CTA harus concrete dan answerable" |
| **CAMPAIGN_FAMILY** | Pola berlaku untuk tipe mission | "Quote/reply launch harus terasa seperti response" |
| **CAMPAIGN_ONLY** | Pola berlaku untuk satu campaign | "Internet Court tidak boleh hanya dispute resolution" |
| **MISSION_ONLY** | Pola berlaku hanya mission ini | "Gunakan quote thread sebagai launch context" |
| **WATCH** | Evidence suggestif tapi belum kuat | Catat, jangan jadikan rule |
| **REJECT** | Noise, variance, atau akan overfit | Buang |

**Default: MISSION_ONLY** kecuali evidence membuktikan broader.

---

## HOW TO MINE

### Dari Submission Data:

1. **Baca EP 4 verdicts** — kenapa judge kasih 4 bukan 5?
2. **Baca EP 5 verdicts** — apa yang judge spesifik praise?
3. **Baca Orig 1/2 verdicts** — kenapa tidak 2/2?
4. **Baca Orig 2/2 verdicts** — apa yang beda?

### Per Verdict, Extract:
- Pola deduction yang muncul berulang
- Pola praise yang muncul berulang
- Pattern yang HANYA muncul di high-scorers vs low-scorers

### Classification:
- Setiap candidate gate: ACCEPT / WATCH / REJECT
- Setiap accepted gate: assign scope
- Jangan promote ke GLOBAL tanpa multi-campaign evidence

---

## NON-OVERFIT RULE

Prefer principle rules over vocabulary bans.

❌ Bad: "Ban the phrase 'missing layer'"
✅ Good: "Kalau pakai 'missing layer', hubungkan ke concrete scenario dalam 2 baris"

---

## PROMOTION RULE

Hidden gate hanya bisa naik level setelah evidence cukup:

```
MISSION_ONLY → CAMPAIGN_ONLY → CAMPAIGN_FAMILY → GLOBAL
```

Jangan skip langsung ke GLOBAL dari satu mission.

---

## OUTPUT

```
HIDDEN_GATE_CANDIDATES.md
```

Isi:
- Tabel: | Candidate Gate | Evidence | Scope | Verdict (ACCEPT/WATCH/REJECT) |
- Pre-draft contract (rules yang harus diikuti saat drafting)

---

## RELATIONSHIP KE SKILL LAIN

- **Source Truth (Skill 02)**: Source Truth = apa yang JURI MAU. Hidden Gate = apa yang JURI IMPLISIT EVALUATE. Keduanya complementary.
- **Winner-Pull Mining (Skill 16)**: Hidden Gate = defense (hindari deduction). Winner-Pull = offense (targetkan praise). Gunakan keduanya.
- **AI Manual Review**: SELALU baca verdict langsung, bukan JSON data saja.
