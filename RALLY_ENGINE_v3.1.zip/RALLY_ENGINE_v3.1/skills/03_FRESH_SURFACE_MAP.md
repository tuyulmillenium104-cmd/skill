# 🗺️ SKILL 03: FRESH SURFACE MAP

**Tujuan:** Identifikasi angle yang belum dipakai di pool. Fresh ≠ weird. Fresh = non-crowded + campaign-native + inevitable.

---

## PROCESS

### Step 1: Map Crowded Surfaces
Dari 100 submissions, identifikasi angle yang BANYAK orang pakai:
- Di "The Toast": everyone toasts a mentor → CROWDED
- Di "Wikipedia": everyone does Known for / Early life / Career → CROWDED (tapi expected)

**Pertanyaan kunci:** "Apa yang sudah sering ditulis orang lain?" → Ini supaya kita TIDAK ikut template.

### Step 2: Identify Fresh Surfaces
Cari angle yang NOBODY atau VERY FEW di pool yang pakai:
- Fresh = nobody doing this
- Semi-fresh = few doing this, tapi bisa dibedakan

### Step 3: Evaluate Fresh Surfaces
Untuk setiap fresh surface, tanya:
1. Apakah ini FORMAT-NATIVE? (bisa dieksekusi dalam format campaign?)
2. Apakah ini STILL ALIGNS dengan campaign ask?
3. Apakah ini memungkinkan specificity dan authenticity?
4. Apakah @RallyOnChain bisa diintegrasikan natural?
5. Apakah ada CTA yang bisa dimasukkan?

### Step 4: Apply Fresh-But-Inevitable Test

```
Fresh is useful only when it feels inevitable after reading.
```

Target:
```
non-crowded core surface + clear campaign mechanism + human object + fast payoff + CTA-integrated reply path
```

NOT target:
```
literal 0% lexical overlap
```

Mandatory campaign terms, handles, URLs, product nouns, and knowledge-base facts may overlap. What must be fresh is the **public surface, hook, progression, mental model, and CTA framing**.

#### Good Fresh:
- campaign-native
- concrete
- easy to retell
- supported by screenshot/media/source truth
- not copied from winners
- not the crowded pool phrase as the main hook
- clear enough for target audience
- tied to a practical CTA

#### Bad Fresh:
- weird but unclear
- too distant from product truth
- clever but not useful
- too metaphor-heavy
- impossible for target audience to retell
- fresh only because it avoids campaign language too much

### Step 5: Choose Surface
Pilih surface yang:
- Paling unik vs corpus
- Paling executable dalam format
- Paling memungkinkan specificity
- Paling natural untuk @RallyOnChain
- **Fresh but inevitable** — bukan fresh tapi weird

**Do not select the most unique surface if it weakens product clarity.**

---

## CANDIDATE TOURNAMENT RULE

Generate at least three candidate surfaces unless the user explicitly asks for speed:

1. safest campaign-native surface
2. freshest non-crowded surface
3. broadest/most accessible surface

Select the surface that best balances:
```
freshness × campaign fit × clarity × human voice × CTA potential
```

---

## EXAMPLE (from The Toast)

### Crowded:
- ❌ Toast to mentor/parent who helped
- ❌ "Thank you for believing in me"
- ❌ "You were there when nobody else was"

### Fresh:
- ✅ The Unreliable Narrator (meta-approach) — CHOSEN for Wikipedia
- ✅ Toast to person who stayed when you fumbled — CHOSEN for Toast

### Fresh-But-Inevitable Check:
- Toast campaign: "toast to person who fumbled" → fresh (nobody doing it) + inevitable (it's literally a toast format) ✅
- Wikipedia campaign: "Talk Page format" → fresh (14/188 doing format subversion) + inevitable (it's a real Wikipedia page type) ✅

---

## FAILURE HANDLING

If a draft fails because the surface is crowded or too weird, **do not patch one line**. Reject the candidate and generate a new surface.

```
CANDIDATE_REJECTED
REGENERATE_WITH_NEW_SURFACE
```

Surgical rewrite is allowed only if the surface is strong and the issue is a small wording, CTA, or proof mismatch.

---

## OUTPUT

1. ✅ Crowded surfaces listed (AVOID)
2. ✅ Fresh surfaces listed (3-4 options)
3. ✅ Fresh-but-inevitable check per surface
4. ✅ Chosen surface + justification
5. ✅ Why fresh: ...
6. ✅ Why inevitable/campaign-native: ...
7. ✅ Why not too weird: ...
