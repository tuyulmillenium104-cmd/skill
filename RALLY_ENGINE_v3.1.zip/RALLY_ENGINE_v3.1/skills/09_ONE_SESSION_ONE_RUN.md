# 🔄 SKILL 09: ONE-SESSION / ONE-RUN PROTOCOL

**Tujuan:** Ensure efficiency dan avoid over-engineering.

---

## RULES

1. **Max 3 candidates** per campaign
2. **Fail-fast:** if first 2 are clearly bad, generate a completely new one for #3
3. **No patching:** if a candidate fails EP Gate, REGENERATE, don't fix piece-by-piece
4. **Max 1 iteration:** if candidate passes EP Gate with flags, fix ONLY safe flags, then submit
5. **One session:** entire workflow in one session, no saving state for later

---

## WHY?

### Max 3 candidates:
- Diminishing returns after 3
- More candidates = more confusion
- Better to have 1 good candidate than 3 mediocre ones

### Fail-fast:
- If direction is wrong, change direction immediately
- Don't try to fix a fundamentally flawed approach

### No patching:
- Patching = fixing individual words/lines
- This leads to Frankenstein content (optimized but soulless)
- v2 of Toast was a PATCH — result: less authentic than v1
- REGENERATE = start fresh with lessons learned

### Max 1 iteration:
- If EP Gate PASS with flags → fix safe flags → submit
- Don't iterate endlessly trying to fix every flag
- Paradoks flag: more fixes = more risk of killing EP

### One session:
- Context is lost between sessions
- Fresh eyes = different judgment = inconsistency
- Complete the workflow while all data is in context

---

## EXCEPTION

If candidate FAILS EP Gate entirely (EP predicted 3-4/5):
- REGENERATE with different angle
- Use different fresh surface
- Max 1 regeneration before switching to different campaign
