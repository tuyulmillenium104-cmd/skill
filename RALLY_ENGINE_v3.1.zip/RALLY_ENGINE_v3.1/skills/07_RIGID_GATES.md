# ✅ SKILL 07: RIGID GATES — Compliance Check

**Tujuan:** Pastikan konten memenuhi semua campaign requirements.

---

## UNIVERSAL RIGID GATES (setiap campaign)

| Gate | Check |
|---|---|
| @RallyOnChain mention | ✅ Present (minimal 1x) |
| No em dashes | ✅ No "—" in content |
| No start with mention/hashtag | ✅ First character bukan @ atau # |
| Authentic voice | ✅ Tidak terasa AI-generated |
| No generic AI text | ✅ No "In conclusion", "Let me tell you", dll |

---

## CAMPAIGN-SPECIFIC RIGID GATES

Setiap campaign punya rules tambahan. Cek dari campaign brief:

- Apakah ada required hashtag?
- Apakah ada required mention lain?
- Apakah ada banned words/phrases?
- Apakah ada max length?
- Apakah ada min follower requirement?
- Apakah ada format requirement?

---

## CHECKLIST

```
@RallyOnChain mention:     ✅ / ❌
No em dashes:              ✅ / ❌
No start with mention:     ✅ / ❌
Authentic voice:           ✅ / ❌
No generic AI text:        ✅ / ❌
Campaign-specific rule 1:  ✅ / ❌
Campaign-specific rule 2:  ✅ / ❌
...

ALL PASS → SUBMIT READY
ANY FAIL → FIX dan re-check
```

---

## IMPORTANT

Rigid Gates itu binary. PASS atau FAIL. Tidak ada "mostly pass."
Kalau ada satu gate yang fail, konten TIDAK bisa di-submit sampai di-fix.

Rigid Gates juga TIDAK ada paradoks. Fix rigid gate violation selalu aman.
(Tambah @RallyOnChain atau hapus em dash tidak akan menurunkan EP.)
