# ✍️ SKILL 24: HUMAN-TYPED PUBLIC COPY STANDARD

**Phase:** 3 (Q&A)
**Source:** RESTORED from v2.3 HUMAN-TYPED-PUBLIC-COPY-STANDARD.md (FULL)
**Purpose:** Ensure final content, Q-COPY, and A-COPY read like public posts/replies written by real people, not like audit output, generated templates, or skill-compliance prose.

---

## Core Law

Public copy must sound like something a real participant could type without seeing our skill files.

```
Human public copy > perfect rubric prose
```

This applies to:
- main content
- Q-COPY
- A-COPY
- public-only exports

It does not apply to internal reports, headings, ranking metadata, or audit files.

---

## Hard Distinction

### Internal Language

Belongs **only** in skill/checker/audit files:

- checker names
- audit labels
- metadata labels
- scoring workflow
- `qa_ranking`
- `voicePersona`
- `SIMULATED_ARCHETYPE`
- `CONDITIONAL_ORGANIC_MATCH_ONLY`
- private skill terms

### Public Language

Must sound like a normal public post or reply:

- direct observation
- personal reaction
- concrete example
- natural doubt
- practical question
- lived experience
- plain-language mechanism

**Rule:** If a word/phrase only makes sense to someone who read our skill files, it does not belong in public copy.

---

## Style Rules

### 1. Avoid Repeated Labels

Label-colon shells such as `My concern:`, `My answer:`, `Hot take:`, and `Wrong lesson:` are especially likely to sound generated. Prefer natural sentence forms.

Do not overuse label-like openings:

```
My concern is...
My answer is...
My decision is...
Hot take:
Wrong lesson:
The risk is...
```

These are allowed occasionally, but repeated use makes copy feel generated.

Rule of thumb:
- In a 20-Q pack, no single label shell should dominate
- If 3 adjacent Qs or As feel like the same skeleton, rewrite

### 2. Prefer Natural Reply Shapes

Human replies often sound like:

```
This is the part I don't buy yet...
Wait, who owns the updated note?
The analogy works, but...
Feels like the case file has to exist before the dispute.
I keep coming back to the same thing...
That line is doing more work than the product pitch.
```

Use these kinds of shapes instead of always using rubric language.

### 3. Keep One Human Intent Per Reply

Every Q-COPY should clearly be one of these:
- a real doubt
- a specific question
- a personal example
- a challenge
- a technical concern
- a concrete extension
- a useful alternative framing

If the Q only exists to satisfy a category, rewrite.

### 4. Avoid Audit Voice in Public Copy

Public copy should not sound like:

```
mechanism clarity is insufficient
CTA alignment is weak
this row needs stronger decision-marker coverage
semantic saturation risk
```

Translate to public language:

```
I still don't see who owns the updated pickup note.
The question is easy to admire but hard to answer.
This sounds like a support ticket unless the case starts before the dispute.
```

### 5. Imperfect Rhythm Is OK

- Do not make every sentence the same length
- Do not make every Q the same shape
- Do not over-polish every line
- Human copy can be: short, blunt, slightly conversational, specific, uneven in rhythm
- But it must remain clear and campaign-safe

### 6. Preserve Truth and Precision

Human style does not mean sloppy claims.

Never trade accuracy for casual voice.
If a casual phrase overclaims, rewrite it.

---

## Manual Human-Typed Test

Before finalizing, ask:

1. Would a real person write this publicly without knowing our skill?
2. Can I imagine a specific person typing this?
3. Does it sound like a comment, not a rubric?
4. Does it add a real thought, not just satisfy a category?

If any answer is no, rewrite.

---

## Q&A Pack Additional Checks

For 20-pair Q&A packs:
- Avoid repeated Q shells
- Avoid repeated A openings
- Use direct questions, statements, mini-stories, and concise challenges
- Keep metadata out of Q/A bodies
- Keep simulated Real Experience labels outside public copy
- Let some answers close as statements if natural

---

## Relationship to Gold V3

This standard complements Gold V3. If a line passes mechanical gates but fails human-typed review, rewrite it.

## Relationship to Irreducible Apex / Hostile Judge Attack

Irreducible Apex content must also pass this human-typed standard. A line can be functional and still too engineered. If it feels engineered, rewrite without losing function.

## Relationship to Public Copy Leakage Policy (Skill 27)

Skill 27 prevents private metadata from leaking into public copy. This skill ensures public copy sounds naturally human. They are complementary:
- Skill 27: "Don't leak internal terms" (privacy)
- Skill 24: "Don't sound like a robot" (naturalness)
