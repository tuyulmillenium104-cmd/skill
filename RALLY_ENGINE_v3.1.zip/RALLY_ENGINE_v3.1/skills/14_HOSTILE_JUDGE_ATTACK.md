# ⚔️ SKILL 14: HOSTILE JUDGE ATTACK TEST

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 IRREDUCIBLE-APEX-STANDARD (10-attack test)
**Purpose:** Attack konten sendiri seperti hostile judge. Temukan deduction sebelum judge menemukannya.

---

## CORE PRINCIPLE

Kalau kamu tidak bisa menemukan kelemahan kontenmu sendiri, kamu tidak cukup kritis.

Judge Rally itu adversarial. Mereka dicari untuk menemukan "strong, but...". Kalau kita tidak menemukan "but" sendiri dulu, judge yang akan menemukannya.

---

## 10-ATTACK TEST

Tulis 10 attempted deductions terhadap kontenmu sendiri:

```
1. Strong, but... (hook bisa lebih sharp)
2. Clear, but... (clarity ada tapi ...)
3. Aligned, but... (alignment ada tapi ...)
4. Useful, but... (value ada tapi ...)
5. Original, but... (originality ada tapi ...)
6. Human, but... (voice ada tapi ...)
7. Technically accurate, but... (accuracy ada tapi ...)
8. CTA is present, but... (CTA ada tapi ...)
9. Concrete, but... (detail ada tapi ...)
10. Memorable, but... (kesan ada tapi ...)
```

Setiap deduction harus:
- Spesifik (bukan "could be better")
- Fair (bukan straw-man)
- Di-jawab: "Kalau deduction ini fair, apa yang harus di-fix?"

---

## SCORING

| Attack Result | Score |
|---|---|
| Tidak bisa ditemukan deduction yang fair | Konten mungkin terlalu safe/boring |
| 1-3 fair deductions, semua bisa di-fix dengan safe fix | ✅ STRONG |
| 4-6 fair deductions, beberapa risky fix | ⚠️ NEEDS REVIEW |
| 7+ fair deductions | ❌ REBUILD |

---

## ANTI-BIAS RULES

1. **Jangan bilang "none credible"** — selalu ada sesuatu yang bisa diserang
2. **Minimal 3 fair deductions** — kalau tidak bisa temukan 3, kamu tidak cukup kritis
3. **Jangan hanya attack area yang sudah kamu fix** — cari area yang BELUM kamu perhatikan
4. **Attack dari perspective genre yang berbeda** — kalau KREATIF, coba attack sebagai DEBAT judge
5. **Check register shift** — apakah ada bagian yang tiba-tiba ganti tone?
6. **Check specificity inconsistency** — apakah ada detail yang spesifik di satu bagian tapi generic di bagian lain?

---

## RELATIONSHIP KE SKILL LAIN

- **EP Gate Review**: EP Gate itu structured review. Attack Test itu adversarial. Keduanya wajib.
- **Taste Director**: Taste Director cek "terasa gimana?". Attack Test cek "bisa diserang dimana?".
- **Flag Paradox**: Kalau attack test menemukan issue tapi fix-nya RISKY → ikuti Flag Paradox (FLAG, don't FIX).
- **Genre**: Di KONFESIONAL, jangan attack "told not shown" karena itu bisa jadi kekuatan. Attack "tidak authentic" sebagai gantinya.

---

## DANGEROUS: JANGAN GUNAKAN EXPONENTIAL/APAX SCORING DI KONFESIONAL

Scoring 1-5 per axis (dari v2.3 Irreducible Apex) itu DANGEROUS untuk KONFESIONAL karena:
- "Emotional compression" bisa bunuh authentic emotion
- "Product inevitability" tidak relevan untuk confession
- "Line necessity test" bisa potong emotional beats yang penting

**Gunakan 10-attack test SAJA.** Jangan tambah scoring axes.

---

## OUTPUT

```
HOSTILE_JUDGE_ATTACK.md
```

Isi:
- 10 attacks + fairness assessment
- Per attack: fix suggestion + fix risk level (SAFE/RISKY/HIGH RISK)
- Summary: total fair deductions, recommended action
