# 🔄 SKILL 18: FEEDBACK + ITERATION

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 Phase 4+5 (Feedback + Iteration)
**Purpose:** Cycle feedback→fix→re-test sampai konten siap. Max 3 iteration. Fail-fast.

---

## CORE FLOW

```
STRESS TEST → FEEDBACK → FIX (safe only) → RE-TEST → PASS or REGENERATE
```

Ini BUKAN "patch konten sampai perfect". Ini "fix yang aman, kalau masih jelek regenerate".

---

## STEP 1: COLLECT FEEDBACK

Kumpulkan feedback dari SEMUA stress test yang sudah dijalankan:

| Source | Apa yang diberikan |
|---|---|
| EP Gate Review (Skill 06) | PASS/FAIL + flags + suggestions |
| Rigid Gates (Skill 07) | Binary PASS/FAIL per gate |
| Taste Director (Skill 13) | 7 persona verdicts + issues |
| Hostile Judge Attack (Skill 14) | 10 attacks + fairness + fix suggestions |
| Hidden Gate Mining (Skill 15) | Candidate gates + accepted rules |
| Winner Pull Mining (Skill 16) | Pull mechanisms + expected praise |

---

## STEP 2: PRIORITIZE FIXES

Kategorikan setiap issue:

| Category | Arti | Contoh |
|---|---|---|
| **SAFE** | Fix tidak akan kill EP/Orig | Typo, missing mention, CTA tweak |
| **RISKY** | Fix bisa improve ATAU kill | Rewrite hook, add detail, change structure |
| **HIGH RISK** | Fix kemungkinan besar kill | Change format, remove section, change tone |

### Genre-specific rules:

| Genre | Fix yang boleh | Fix yang dilarang |
|---|---|---|
| **KONFESIONAL** | SAFE saja | RISKY+ dilarang (8/9 flag fixes = risky) |
| **KREATIF** | SAFE + some RISKY | HIGH RISK dilarang |
| **PRODUCT** | SAFE + RISKY | HIGH RISK hati-hati |
| **DEBAT** | Logic fixes OK, tone fixes RISKY | Jangan fix tone kalau itu stance |

---

## STEP 3: APPLY FIXES

- Fix ONE at a time
- Re-test setelah setiap fix
- Kalau EP drop → REVERT fix, submit as-is
- Ingat: **EP 5 + Orig 1 > EP 4 + Orig 2**

---

## STEP 4: DECISION

| Result | Action |
|---|---|
| All gates PASS + no issues | ✅ SUBMIT READY |
| PASS with SAFE fixes | ✅ Apply fixes, re-test, submit |
| PASS but RISKY issues remain | ⚠️ Consider submitting as-is (Flag Paradox) |
| FAIL after max 3 iterations | ❌ REGENERATE with different angle (max 1x) |
| FAIL again after regenerate | ❌ SWITCH CAMPAIGN |

---

## MAX ITERATIONS: 3

| Iteration | Action |
|---|---|
| 1 | Fix safe issues, re-test |
| 2 | Fix remaining safe + consider risky, re-test |
| 3 | Final decision: submit as-is or regenerate |

Setelah 3 iteration → keputusan final. Jangan iterate tanpa henti.

---

## ANTI-PATTERNS

- ❌ Patch konten piece-by-piece sampai jadi Frankenstein
- ❌ Fix semua flags sekaligus tanpa re-test
- ❌ Iterate lebih dari 3x
- ❌ Regenerate dengan angle yang sama
- ❌ Lanjut ke Q&A sebelum konten PASS stress test

---

## RELATIONSHIP KE SKILL LAIN

- **Flag Paradox (Skill 20)**: Detail kategorisasi SAFE/RISKY/HIGH RISK ada di sana.
- **One-Session/One-Run (Skill 09)**: Max 3 candidates, fail-fast. Iteration ini sejalan.
- **Taste Director (Skill 13)**: Feedback dari Taste Director masuk ke sini.
- **Hostile Judge (Skill 14)**: Attack results masuk ke sini sebagai feedback.
