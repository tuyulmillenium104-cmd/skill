# 🔗 SKILL 17: STEP CONFLICT CHECK

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 STEP-CONFLICT-CHECK-PROTOCOL.md
**Purpose:** Pastikan setiap step tidak menciptakan kontradiksi dengan step sebelumnya.

---

## CORE PRINCIPLE

Setiap major step harus ditanya:

```
Apakah step ini menciptakan konflik dengan brief, source truth, data scope, human voice, atau output quality?
```

Kalau ya → STOP dan resolve SEBELUM lanjut.

---

## CONFLICT CHECKS PER STEP

### 1. Foundation Lock
- Mission ID benar?
- UI title match API title?
- Required quote/reply links benar?
- Required handles benar?
- Forbidden formats clear?
- **Konflik**: Kalau ambiguous, fetch ulang. Jangan draft.

### 2. Source Truth Snapshot
- Source post text match campaign rules?
- Quote/reply requirement clear?
- Campaign facts dari KB, bukan memory?
- **Konflik**: Kalau source tidak bisa di-fetch, mark confidence dan pakai campaign rule sebagai authority.

### 3. Data Sufficiency
- Cukup submissions/winners?
- Content retrieval coverage tinggi?
- Data mission-scoped?
- **Konflik**: Kalau data rendah, jangan buat hard mission-specific rules. Pakai brief-first dan family priors.

### 4. Hidden-Gate Mining
- Candidate gate benar-benar rule atau noise?
- Scope set ke MISSION_ONLY by default?
- Kalau di-promote globally, akan merusak campaign lain?
- **Konflik**: Keep as WATCH kecuali manual evidence mendukung ACCEPT.

### 5. Winner-Pull Mining
- Apakah kita copy winner surface atau extract mechanism?
- Apakah draft pakai fresh expression?
- **Konflik**: Kalau copy-risk tinggi, rebuild konsep.

### 6. Original Thesis
- Thesis datang dari brief dan human problem, BUKAN dari copy winner examples?
- Thesis true dan specific?
- **Konflik**: Kalau generic atau derivative, generate thesis baru.

### 7. Content Thinking Framework
- Insight muncul dari DALAM (personal), bukan dari LUAR (observational)?
- Insight memimpin struktur, bukan sebaliknya?
- **Konflik**: Kalau struktur memaksa insight, rebuild.

### 8. Generate
- Konten jalan dari insight, bukan dari teknik?
- Kill criterion: kalau dihapus tidak jadi lebih lemah → hapus
- **Konflik**: Kalau konten terasa engineered/rubric-like, rewrite.

### 9. EP Gate + Stress Test
- Semua gate di-run, tidak ada yang di-skip?
- Fail di-handle dengan regenerate, bukan patch?
- **Konflik**: Kalau ada gate yang di-skip, RESTART dari gate itu.

### 10. Q&A Generation
- Q&A reflect final content, bukan old content?
- Q/A sound human-typed?
- Simulated experiences ditandai?
- **Konflik**: Rebuild Q&A kalau formulaic atau stale.

### 11. Final Integrity
- combined.md berisi exact current content?
- Reports current, bukan stale?
- Content tidak berubah setelah reports di-run?
- **Konflik**: Rerun reports. Jangan ship stale pass.

---

## OUTPUT

Untuk run serius, produce:

```
STEP_CONFLICT_CHECK_REPORT.md
```

Isi per step:
- Step name
- Conflict found: YES/NO
- Action taken
- Final decision

---

## RELATIONSHIP KE SKILL LAIN

- **The Oath (LAW 10)**: Step Conflict Check adalah mekanisme untuk enforce The Oath.
- **Flag Paradox (Skill 20)**: Kalau step conflict discovery butuh fix → ikuti Flag Paradox rule.
- **Taste Director (Skill 13)**: Kalau konflik antara "pass gate" vs "terasa engineered" → Taste Director menang.
