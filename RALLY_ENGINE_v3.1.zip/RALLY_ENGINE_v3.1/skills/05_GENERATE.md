# ✍️ SKILL 05: GENERATE — Content Generation

**Tujuan:** Generate 3 candidates, pilih terbaik.

---

## RULES

1. **Max 3 candidates** (One-Session/One-Run)
2. **Fail-fast:** kalau candidate 1 dan 2 jelas kurang, jangan buat 3
3. **No patching:** kalau candidate gagal EP Gate, REGENERATE, jangan fix
4. **Genre-aware:** generate sesuai genre expectations
5. **Insight memimpin, teknik mengikuti:** jangan mulai dari teknik, mulai dari insight

---

## GENERATION SEQUENCE

### Step A: Temukan INSIGHT dulu
Sebelum tulis satu kata konten, jawab:
- "Jika pembaca hanya mengingat satu kalimat, kalimat apa?"
- "Apa asumsi yang bisa dibalik?"
- "Apa yang sudah sering ditulis orang lain (supaya aku TIDAK ikut)?"

**Kalau tidak bisa menjawab → jangan generate. Kembali ke INSIGHT.**

### Step B: AMPLIFY insight
Tambahkan detail spesifik yang MEMBUKTIKAN insight:
- Angka, dialog, kontras, nama, adegan
- Detail harus spesifik sampai hanya KAMU yang bisa menulisnya
- Setiap detail harus PROVE insight, bukan decorate

**Kalau detail hanya dekorasi → hubungkan ke insight atau hapus.**

### Step C: TULIS konten
Biarkan insight memimpin struktur. Pilih teknik yang paling mendukung penyampaian insight.

**Kill criterion:** "Kalau kalimat ini dihapus, apakah tulisan jadi lebih lemah?" Jika tidak → hapus.

---

## GENRE GUIDELINES

### Untuk KONFESIONAL:
- Emotion FIRST, cleverness second
- Specific details over elegant phrasing
- "Told not shown" is OK (admissions, direct statements)
- Linear structure is OK
- Let voice be RAW, don't polish
- Add NAME if possible
- **Insight default:** Story / Observation (reframe hanya pada makna)

### Untuk KREATIF/FORMAT:
- Format execution FIRST
- Humor over emotion
- Hook must MAXIMIZE the format
- Structure twist expected
- Every section must earn its place
- Self-aware/mock-serious tone
- **Insight default:** Reframe / Counterintuitive truth
- **12/16 Orig 2/2 Wiki winners SUBVERT the format** → insight menentukan format, bukan sebaliknya

### Untuk PRODUK:
- Mechanism clarity FIRST
- Specific examples over vague claims
- Tactical value important
- Logic-driven structure
- Don't over-explain, but don't under-explain either
- **Insight default:** First-principles / Counterintuitive truth on user experience

### Untuk DEBAT:
- Stance FIRST (bold, clear, specific)
- Contrarian angle preferred
- Argument structure (claim → evidence → reasoning)
- Intellectual value > emotional
- Don't hedge — take a position
- **Insight default:** Reframe pada perspektif argumen

---

## CANDIDATE SELECTION

Setelah generate 3 candidates, quick review:

1. **Mana yang INSIGHT-nya paling kuat?** (reframe spesifik, bukan observasi)
2. **Mana yang AMPLIFIER-nya paling spesifik?** (hanya kamu yang bisa tulis)
3. **Mana yang hook-nya paling kuat?** (insight muncul sejak awal)
4. **Mana yang @RallyOnChain-nya paling natural?**
5. **Mana yang CTA-nya ties back ke insight?**

Pilih 1 terbaik → lanjut ke EP Gate Review

---

## LENGTH GUIDANCE

- Target: 600-1000 chars untuk tweet longform
- KONFESIONAL: bisa lebih panjang (emotional beats need space)
- KREATIF: bisa lebih panjang (sections need space)
- PRODUK: lebih pendek lebih baik (mechanism clarity > length)
- DEBAT: medium (argument needs space, tapi jangan drag)

**Jangan optimasi length sebelum EP Gate.** EP Gate akan assess apakah length justified.
