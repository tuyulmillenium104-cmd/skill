# 🎯 EP GATE REVIEW — AI Manual Review

**★ CORE SKILL dari RALLY ENGINE v2.6**
**TERBUKTI menghasilkan EP 5/5 (The Toast, verified by real judge)**

---

## OVERVIEW

3 check × 7 step = EP Gate

Setiap check memiliki 7 step yang HARUS diikuti SEMUA.
Skip step = review tidak valid.

---

## CHECK 1: EP COMPACTNESS

### What to Check:
- ✅ Length optimization (not just char count, tapi readability)
- ✅ Paragraph density (not just metrics, tapi flow)
- ✅ CTA friction (not just formula, tapi ease of reply)
- ✅ Operational value (not just keywords, tapi actual value)

### 7 Steps:

**Step 1: Read content carefully**
Baca konten dari awal sampai akhir. Jangan skimming.

**Step 2: Assess length — Is it optimal for engagement?**
- Berapa karakter? Apakah di range optimal untuk campaign ini?
- Apakah panjangnya justified oleh value yang delivered?
- Jangan cuma bilang "sweet spot" — JELASKAN kenapa.

**Step 3: Assess density — Are paragraphs scannable?**
- Apakah setiap paragraph pendek dan punchy?
- Apakah ada visual rhythm?
- Apakah flow antar paragraph natural?

**Step 4: Assess CTA — Is it easy to reply?**
- Apakah CTA bisa dijawab dalam 5 detik?
- Apakah CTA itu naming-type ("Who's your X?") atau conceptual ("Who stayed?")?
- Naming-type = lower friction, higher conversation potential
- Conceptual = higher friction, tapi bisa lebih emotionally resonant

**Step 5: Assess value — Is there value for the reader?**
- Emotional value? (reader merasa sesuatu)
- Intellectual value? (reader berpikir sesuatu baru)
- Tactical value? (reader bisa melakukan sesuatu)
- Minimal 1 dari 3 harus ada. Ideal: 2 dari 3.

**Step 6: Provide nuanced judgment (not just pass/fail)**
- Jangan cuma kasih skor. Jelaskan STRENGTHS dan WEAKNESSES.
- Contoh benar: "Good compactness. CTA is low-friction but abstract. Length justified by value. Minor concern: 2 lines could be trimmed."
- Contoh salah: "5/5. Sweet spot. No dead lines."

**Step 7: Suggest improvements (context-aware)**
- Minimal 1 suggestion, maksimal 3.
- Setiap suggestion harus explain: kenapa, apa impact-nya, apa risikonya.
- Contoh: "Suggestion: Add name to toast target. Why: Every Orig 2/2 winner has a name. Risk: None — adding name doesn't change voice or structure."

---

## CHECK 2: EP SEMANTIC REVIEW

### What to Check:
- ✅ Clear semantic stance (not just keywords, tapi position)
- ✅ Deduce-ability (not just structure, tapi clarity)
- ✅ Judge perspective (not just metrics, tapi viewpoint)
- ✅ Contextual understanding (not just rules, tapi nuance)

### 7 Steps:

**Step 1: Read content thoroughly**
Baca ulang. Perhatikan SETIAP kalimat, bukan cuma keseluruhan.

**Step 2: Identify stance — What position does content take?**
- Apa thesis utama konten ini?
- Di baris ke berapa stance muncul?
- Apakah stance muncul terlalu lambat? (judge harus baca 80% konten dulu)
- Apakah stance bisa dideduct dari baris pertama?

**Step 3: Assess clarity — Can judges easily deduce quality?**
- Judge membaca 100 submission. Mereka capek.
- Apakah kualitas konten ini langsung visible? Atau perlu baca sampai akhir?
- Apakah judge juga bisa deduce FORMULA? (ini negative — linear structure = formula visible)

**Step 4: Consider context — Campaign-specific factors?**
- Genre campaign apa? (lihat GENRE_DETECTION_GUIDE.md)
- Apa yang juri praise di genre ini? (dari data pool)
- Apa yang juri penalize di genre ini?
- Apakah konten ini align dengan genre expectations?

**Step 5: Evaluate nuance — Subtle quality issues?** ★ PALING PENTING
- Register shift? (raw → ceremonial, personal → universal)
- Specificity inconsistency? (detail semua spesifik kecuali satu hal penting)
- Formula risk? (linear structure, recognizable arc)
- Polish signal? (ending terasa optimized, slogan-like)
- Missing element? (nama, twist, reframe)

**INI STEP YANG MEMBEDAKAN EP 5/Orig1 vs EP 5/Orig2.**
Jika kamu skip step ini, kamu akan miss hal yang juri kritik.

**Step 6: Provide insight (not just pass/fail)**
- Insight = "ini yang MUNGKIN juri pikirkan" + "ini yang MUNGKIN juri kritik"
- Jangan cuma bilang "stance clear." Bilang: "Stance clear, tapi register shift di ending bisa membuat juri bilang 'slogan-like'."
- Jangan cuma bilang "authentic." Bilang: "Authentic di 80% pertama, tapi universal ending kurangi authenticity feel."

**Step 7: Suggest improvements (context-aware)**
- Minimal 1 suggestion, maksimal 3.
- **PERHATIKAN FLAG PARADOX:** Di genre konfesional, suggestion harus minimal. Di genre produk, suggestion bisa lebih agresif.
- Setiap suggestion: kenapa, impact, risiko.

---

## CHECK 3: EP DEDUCTION MAP

### What to Check:
- ✅ Deduction patterns (not just categories, tapi insights)
- ✅ Judge sentences (not just templates, tapi authentic)
- ✅ Quality signals (not just metrics, tapi substance)
- ✅ Evidence-based (not just assumptions, tapi proof)

### 7 Steps:

**Step 1: Think like a judge** ★ PALING PENTING
- Kamu adalah AI judge yang sudah baca 100 submission. Capek. Cari yang BEDA.
- JANGAN think like a fan. Fan bilang "ini bagus!" Judge bilang "ini bagus TAPI..."
- SELALU cari negativenya. Setiap konten punya kelemahan. Kalau kamu bilang "none credible," kamu tidak think like a judge.

**Step 2: Predict — What sentences will judges write?**
Predict MINIMAL 5 positive + MINIMAL 3 negative sentences.

Positive examples:
- "The hook is highly effective — [specific reason]"
- "Specific vivid details like [specific detail] make this memorable"
- "The admission of [specific thing] creates believable human voice"
- "@RallyOnChain is integrated organically — [specific how]"
- "Value delivery is strong through [specific value type]"

Negative examples:
- "The overall arc overlaps with similar entries — [specific overlap]"
- "The ending shifts into [specific tone] that feels [specific assessment]"
- "The [specific element] is [specific weakness] compared to [specific comparison]"

**Step 3: Identify — What deduction patterns emerge?**
Pattern = across multiple signals, bukan isolated observation.

Example patterns:
- "Strong on ALL positive engagement signals, weak on structural originality" → predicts EP 5/5 + Orig 1/2
- "Strong hook + specific details, but formula risk + no name" → predicts EP 5/5 but ranking risk
- "Weak hook + generic content" → predicts EP 4/5

**Step 4: Assess — What quality signals are present?**

Check setiap signal dan rate: STRONG / MODERATE / WEAK / ABSENT

| Signal | Rating |
|---|---|
| Hook creates tension | ? |
| Specific vivid details | ? |
| Authentic human voice | ? |
| CTA invites reply | ? |
| Conversation potential | ? |
| Structure is novel | ? |
| Ending is raw/authentic | ? |
| @RallyOnChain natural | ? |
| Value delivered | ? |

**Step 5: Evaluate — Is there evidence for claims?**
- "Hook is strong" → evidence: "I sent the wrong link" creates immediate question
- "Formula risk" → evidence: linear A→B→C seen in many pool entries
- "Slogan-like ending" → evidence: "We toast the visionaries. The founders. The Architects." uses ceremonial parallel structure

Setiap claim HARUS punya evidence. Tanpa evidence = assumption, bukan evaluation.

**Step 6: Provide insight (not just categories)**
- Apa overall prediction? (EP X/5, Orig X/2)
- Apa RISIKO terbesar?
- Apa IMPROVEMENT terbesar yang bisa dilakukan?
- Apa yang TIDAK BOLEH di-fix? (karena juri praise)

**Step 7: Suggest improvements (evidence-based)**
- Minimal 1 suggestion, maksimal 3.
- Setiap suggestion: evidence dari data + expected impact + risk assessment
- SELALU sebut: "Fix ini AMAN / RISKY / HIGH RISK untuk EP"

---

## SYNTHESIS (setelah 3 check selesai)

Setelah 3 check, combine findings:

```
EP COMPACTNESS:
- Verdict: PASS / PASS WITH FLAGS / FAIL
- Score: X/5
- Key flags: [list]
- Key suggestions: [list]

EP SEMANTIC:
- Verdict: PASS / PASS WITH FLAGS / FAIL
- Score: X/5
- Key flags: [list]
- Key suggestions: [list]

EP DEDUCTION MAP:
- Verdict: PASS / PASS WITH WARNING / FAIL
- Predicted scores: EP X/5, Orig X/2
- Key negative predictions: [list]
- Key suggestions: [list]

OVERALL:
- EP Gate: PASS / CONDITIONAL PASS / FAIL
- Total flags: X
- Flags per category: EP-related X, Orig-related X
- Safe fixes available: X
- Risky fixes: X
- SUBMIT RECOMMENDATION: SUBMIT READY / FIX BEFORE SUBMIT / REGENERATE
```

---

## FLAG THRESHOLDS

| Total Orig-related Flags | Recommendation |
|---|---|
| 0-1 | SUBMIT READY |
| 2-3 | FIX SAFE FLAGS ONLY, then submit |
| 4+ | CONSIDER FIX or REGENERATE |

| Total EP Critical Flags | Recommendation |
|---|---|
| 0 | SUBMIT READY |
| 1 | REVIEW — is it fixable without risk? |
| 2+ | REGENERATE — EP risk too high |

---

## ANTI-BIAS RULES

1. **NEVER declare "none credible" for negatives.** Every content has weaknesses. If you can't find any, you're not looking hard enough.

2. **ALWAYS predict negative judge sentences.** Minimum 3. If you can't think of 3, re-read the content from a tired, skeptical judge's perspective.

3. **ALWAYS suggest improvements.** Minimum 1 per check. No suggestions = you're not evaluating, you're confirming.

4. **NEVER score without explanation.** "5/5" without "why" is not a review, it's a rubber stamp.

5. **ALWAYS check for register shift.** This is the #1 subtle issue that judges catch but reviewers miss.

6. **ALWAYS check for specificity inconsistency.** If everything is specific except one important thing, that's a flag.

7. **ALWAYS consider genre before suggesting fixes.** Konfesional = minimal fix. Produk = more fix ok. Wrong genre assumption = wrong fix = kill EP.
