# 🚩 SKILL 19: FLAG PARADOX

**Phase:** 2 (STRESS TEST)
**Source:** v3.0 original (LAW 3), enhanced with data
**Purpose:** Flags show real problems. But fixing them can kill what's working.

---

## THE PARADOX

```
Flags = masalah nyata yang perlu diperhatikan
Tapi: fix flag = bisa bunuh yang sudah beres
```

Contoh:
- Judge kasih Orig 1/2 karena "arc still clear" → fix = buat arc lebih subtle → EP drop
- Taste Director bilang "CTA terasa soft" → fix = bikin CTA lebih aggressive → voice jadi tidak authentic
- Hostile attack bilang "detail kurang" → fix = tambah detail → konten jadi terlalu panjang

---

## FIX CATEGORIES

### SAFE (hampir selalu aman)
- Typo fix
- Missing @RallyOnChain mention
- CTA tweak yang tidak mengubah stance
- Format compliance (em dash removal, URL fix)
- **KONFESIONAL**: Add nama spesifik (satu-satunya universal safe fix)

### RISKY (bisa improve ATAU kill)
- Rewrite hook
- Add/remove detail
- Change structure
- Change tone/register
- **KONFESIONAL**: Semua fix selain "add nama" = RISKY

### HIGH RISK (kemungkinan besar kill)
- Change format entirely
- Remove entire section
- Change reframe/insight
- Change voice/persona
- **KONFESIONAL**: Remove emotional beats, add cleverness

---

## RULES PER GENRE

| Genre | SAFE fixes | RISKY fixes | HIGH RISK fixes |
|---|---|---|---|
| **KONFESIONAL** | Typo, mention, add nama | ❌ Jangan | ❌ Jangan sama sekali |
| **KREATIF** | Typo, mention, CTA tweak | Hook rewrite, add detail | Change format |
| **PRODUCT** | Typo, mention, mechanism clarity | Restructure, add example | Change angle |
| **DEBAT** | Typo, mention, logic fix | Tone adjustment | Change stance |

---

## DECISION MATRIX

| Situation | Decision |
|---|---|
| EP 5 + Orig 1, ada flags | Fix SAFE saja. Submit as-is. EP 5 + Orig 1 > EP 4 + Orig 2 |
| EP 4 + Orig 2, ada flags | Fix SAFE + consider RISKY. EP perlu naik. |
| EP 5 + Orig 2, ada flags | Fix SAFE saja. Jangan rusak. |
| Semua RISKY/HIGH RISK | FLAG, don't FIX. Document untuk pembelajaran. |

---

## THE "FLAG, DON'T FIX" RULE

Kalau semua fix yang tersedia = RISKY atau HIGH RISK:

1. **Document flag** (tuliskan masalahnya apa)
2. **Jangan fix** (biarkan konten apa adanya)
3. **Submit** (dengan penuh awareness)
4. **Pelajari** (setelah real judge verdict, lihat apakah flag itu benar-benar masalah)

Ini karena: konten yang sudah bagus + fix yang kill = konten yang rusak.
Konten yang sudah bagus + flag yang tidak di-fix = konten yang mungkin masih menang.

---

## RELATIONSHIP KE SKILL LAIN

- **Feedback+Iteration (Skill 18)**: Flag Paradox menentukan kategori fix yang dipakai di iteration.
- **Taste Director (Skill 13)**: Taste Director bisa flag "engineered smell" → cek dulu kategorinya SAFE/RISKY.
- **One-Session/One-Run (Skill 09)**: Jangan iterate tanpa henti untuk fix RISKY flags.
