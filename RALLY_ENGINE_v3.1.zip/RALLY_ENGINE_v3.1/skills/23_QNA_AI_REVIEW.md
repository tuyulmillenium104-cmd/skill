# 📋 SKILL 23: Q&A AI REVIEW

**Phase:** 3 (Q&A)
**Source:** Proven from The Toast campaign run
**Purpose:** AI manual review untuk Q&A pack. Pastikan format, distribution, voice, dan quality sesuai standard.

---

## REVIEW CHECKLIST

### 1. Type Distribution Check

| Type | Required | Actual | Pass? |
|---|---|---|---|
| Specific Probe | 4 | ? | ? |
| Challenge | 5 | ? | ? |
| Technical Deep-Dive | 5 | ? | ? |
| Hot Take | 4 | ? | ? |
| Real Experience | 2 | ? | ? |
| **Total** | **20** | ? | ? |

### 2. Voice Diversity Check

- [ ] Distinct first-two-word Q openers: ≥15
- [ ] Same first Q word: ≤25%
- [ ] At least 10 distinct personas
- [ ] At least 5 distinct voice modes
- [ ] No adjacent rows same persona

### 3. Formula Shell Check

- [ ] Hit same first word frequency
- [ ] Same first word ≤25% of pairs (max 5 dari 20)
- [ ] Kalau >25% → rewrite pairs yang berlebihan

### 4. Per-Pair Quality Review

Untuk setiap pair, review:
- **Q Quality** (1-5): persona-driven, specific, references post?
- **A Insight** (1-5): concise, adds perspective, not KB documentation?
- **Conversational Feel** (1-5): reads like real X/Twitter exchange?
- **Minimum: Q/A/Feel ≥4 untuk setiap pair**

### 5. Q-Length Check

- [ ] Semua Q: 160-260 characters
- [ ] Flag yang di luar range

### 6. A-Length Check

- [ ] Semua A: ≤280 characters
- [ ] Flag yang melebihi

### 7. Coverage Checks

- [ ] Decision-marker coverage: 75-80%
- [ ] CTA-aligned Q: ≥40%
- [ ] Question-ending coverage: 50-75%

### 8. Format Compliance

- [ ] Each pair has: `## R## [Tier X=Y] (Type)`
- [ ] Q-COPY in code block
- [ ] A-COPY in code block
- [ ] No metadata inside Q-COPY
- [ ] R20 marked SIMULATED_ARCHETYPE jika AI-generated

---

## OUTPUT

```
QNA_AI_REVIEW.md
```

Isi:
1. Type distribution table
2. Voice diversity results
3. Formula shell check results
4. Per-pair quality scores (Q/A/Feel)
5. Length check results
6. Coverage check results
7. Final verdict: PASS / PASS WITH FLAGS / FAIL
8. If PASS: "RQ5-ready"
9. If FAIL: list specific fixes needed

---

## ANTI-PATTERN

- ❌ Review hanya surface level ("looks good")
- ❌ Skip per-pair quality review
- ❌ Ignore formula shell check
- ❌ Claim PASS tanpa check semua item
- ❌ Review dari JSON data saja — BACA konten langsung
