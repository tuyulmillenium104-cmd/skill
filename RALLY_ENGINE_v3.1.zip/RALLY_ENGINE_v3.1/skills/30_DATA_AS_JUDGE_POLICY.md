# 📊 SKILL 30: DATA AS JUDGE, NOT WRITER — DETAILED POLICY

**Phase:** 1 (GENERATE) — applies to all phases
**Source:** RESTORED from v2.3 DATA_AS_JUDGE_NOT_WRITER_POLICY.md
**Purpose:** Prevent the system from becoming a winner-example copier. LAW 1 in detail.

---

## Core Law

Real Rally data is used to **judge and stress-test** content, not to write the content by copying winner examples.

```
Data does not write.
Data judges.
```

---

## What Data Is Allowed To Do

Data may:
- reveal hidden deduction risks
- reveal winner-pull mechanisms
- benchmark hook strength, CTA strength, specificity, and mechanism clarity
- show crowded motifs and loser patterns
- challenge whether a draft is distinctive enough
- provide evidence for manual no-cut review

---

## What Data Must NOT Do

Data must not:
- become a template
- dictate a copied analogy
- force reuse of winner phrasing
- globally hard-code mission-specific tricks
- make every campaign sound like the previous winning campaign
- replace original thesis creation

---

## Correct Use of Winner Data

❌ Bad:
```
Winner used claim number, so use claim number.
```

✅ Good:
```
Winner used a mundane administrative object to explain shared context.
Find a fresh object for this mission.
```

❌ Bad:
```
Winner used itinerary, so use itinerary.
```

✅ Good:
```
Winner made the workflow concrete through a familiar coordination object.
Create a new object if the campaign allows it.
```

---

## Drafting Order

Correct order:
1. Literal brief
2. Human problem
3. Original thesis
4. Fresh concrete object
5. Mechanism bridge
6. CTA engine
7. **Winner/loser data as judge**
8. Python/AI gates as safety net

Wrong order:
1. Read winner
2. Copy winner's surface pattern
3. Patch until checker passes

---

## Anti-Copy Test

Before drafting, answer:

- What winner expression are we **avoiding** copying?
- What **underlying mechanism** did that winner use?
- What **fresh expression** are we using instead?
- Why is our expression **mission-true** and not derivative?

If this cannot be answered, **do not draft.**

---

## Copy-Risk Levels

| Level | Description | Action |
|---|---|---|
| **High risk** | Same object, same opening, same CTA, same metaphor with synonym swap | ❌ Do not use |
| **Medium risk** | Same mechanism but new object, similar progression but different example | ⚠️ Add major twist |
| **Low risk** | Same judge-positive mechanism through new object, new scenario, new CTA | ✅ Proceed |

---

## Transform Rule

Every winner-inspired idea must pass through three layers:

```
Winner surface expression → Underlying mechanism → Our fresh expression
```

Required fields:
```md
Winner surface expression:
Underlying winner mechanism:
Why it worked:
Our fresh expression:
Why ours is not a copy:
Mission fit:
```

---

## Relationship to LAW 1 (Fundamental Law)

LAW 1 = "Data as Judge, Not Writer" in one line.
This skill = the detailed policy with examples and tests.

---

## Relationship to Skill Lain

- **Winner Pull Mining (Skill 16)**: Uses data to find positive mechanisms. This skill prevents those mechanisms from becoming copy.
- **Hidden Gate Mining (Skill 15)**: Uses data to find deduction risks. No conflict — both use data as judge.
- **Original Thesis (Skill 04)**: Thesis must come BEFORE data judgment. This skill enforces the order.
- **Reframe+Amplifier (Skill 12)**: Pattern from 17 winners. Use mechanism (reframe+amplifier), don't copy specific reframes.
