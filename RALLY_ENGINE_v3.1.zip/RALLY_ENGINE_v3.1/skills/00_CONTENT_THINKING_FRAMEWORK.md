# 🧠 SKILL 00: CONTENT THINKING FRAMEWORK

**★ PALING FUNDAMENTAL — Ini SEBELUM semua skill lain**
**TERBUKTI dari 195+ scored submissions, 3 campaign, 2 genre, 1 real judge verdict, 17 Orig 2/2 winners**

---

## PRINSIP UTAMA

**Insight memimpin. Teknik mengikuti.**

Jangan mulai dengan: "Hari ini saya mau pakai reframe."
Mulailah dengan: "Apa ide paling menarik yang layak diingat?"

Setelah insight ditemukan, pilih teknik yang paling efektif untuk menyampaikannya.

---

## 5 LANGKAH

### LANGKAH 1: READ — Pahami sebelum menulis

Baca campaign brief. Tapi bukan cuma "apa topiknya." Pahami **4 hal:**

**Pertanyaan:**
1. Apa tujuan campaign?
2. Apa yang ingin juri lihat?
3. Apa aksi yang diharapkan dari pembaca?
4. Apa yang sudah sering ditulis orang lain?

| Campaign | Tujuan | Juri mau lihat | Aksi pembaca | Yang sudah sering ditulis |
|---|---|---|---|---|
| The Toast | Angkat gelas ke seseorang | Emosi genuine, bukan gratitude generik | Ikut toast | "Thank you for everything" |
| Wikipedia | Halaman Wikipedia tentang diri | Humor self-aware, format subversion | Share own page | "Known for / Early life / Career / Legacy" |
| Mic is Yours | Pendapat berani | Quiet conviction, bukan shouting | Debate | "Trust matters / Quality > quantity" |
| GenLayer | Jelaskan mekanisme | Aha moment personal | Learn + share | "GenLayer uses X mechanism → revolutionary" |

**⚠️ Di PRODUK:** READ juga berarti PAHAMI MEKANISME sampai benar-benar mengerti. Accuracy gate akan GAGAL kalau tidak paham.

**Output:**
→ Masalah yang harus diselesaikan.

---

### LANGKAH 2: INSIGHT — Temukan satu ide yang paling layak diingat

**Pertanyaan utama:**
> "Jika pembaca hanya mengingat satu kalimat dari tulisan ini, kalimat apa yang harus mereka ingat?"

**Default:** Cari REFRAME yang mengubah cara pandang pembaca.

Reframe = philosophical flip. Membalik asumsi. Bukan cuma ganti POV atau ganti format.

**Contoh reframe dari data (17/17 Orig 2/2 punya reframe):**

| Winner | Asumsi yang dibalik | Reframe |
|---|---|---|
| @alver1301 (Toast) | "Orang yang kamu salahkan itu jahat" | "The person you accused was actually protecting you" |
| @str_kerx (Toast) | "Penolongmu harus manusia" | "Your savior doesn't have to be human" |
| @uso411247 (Toast) | "Menang layak di-toast" | "Loss deserves a toast more than winning" |
| @_iamdotun_ (Wiki) | "Wikipedia tentang apa yang kamu miliki" | "Your useless traits are actually your Wikipedia entry" |
| @alver1301 (Wiki) | "Wikipedia tentang apa yang ditambahkan" | "Wikipedia should be about what to DELETE" |
| @svictorayomi (Mic) | "Crypto menghapus middleman" | "We didn't remove middlemen, we renamed them" |
| @ahonjumaidil (Mic) | "Follower count = pengaruh" | "Follower count is proof of nothing" |

**Hierarki berdasarkan genre:**

| Genre | Default insight | Alternatif |
|---|---|---|
| KREATIF | Reframe / Counterintuitive truth | Hanya jika reframe merusak keaslian |
| DEBAT | Reframe pada perspektif argumen | First-principles jika reframe terasa forced |
| PRODUCT | First-principles / Counterintuitive truth | Reframe pada pengalaman user (bukan fakta produk) |
| KONFESIONAL | Story / Observation | Reframe hanya pada makna (bukan emosi) |

**⚠️ Jika reframe terasa dipaksakan atau mengurangi keaslian:**
→ Gunakan story, observation, analogy, atau first-principles.

**Data proof:**
- 17/17 Orig 2/2 di KREATIF punya reframe spesifik
- Reframe umum + amplifier umum → Orig 1/2 (bukti: @muktaryaks "creators are free labor")
- Tanpa reframe → Orig 1/2 (bukti: v1 Toast, observasi saja tanpa flip)

**Output:**
→ One memorable insight.

---

### LANGKAH 3: AMPLIFY — Buat insight menjadi konkret dan terasa nyata

**Pertanyaan utama:**
> "Bisakah pembaca melihat dan merasakan apa yang saya maksud?"

Jika belum → Tambahkan detail, bukan penjelasan.

**Gunakan seperlunya:**

| Teknik | Kekuatan | Contoh dari data |
|---|---|---|
| Detail spesifik | Fondasi, harus ada | "rented suit, coupon, 40-minute drive" |
| Angka | Senjata terkuat setelah detail | "200K followers, 11 likes", "6'7\"", "4:30am" |
| Dialog kutipan | Bikin reader DENGAR | "'I deleted my comment. That wasn't an apology.'" |
| Kontras | Dua hal berdampingan saling memperkuat | "200K vs 11", "venture-backed vs token wrappers" |
| Nama spesifik | Hanya kamu yang bisa tulis ini | "Hallie", "Kopi Keladi", "Marco" |
| Adegan/momen | Taruh reader di satu detik spesifik | "4:30am, almost broke down my own door" |
| Metafora | Hanya kalau ditempel pada detail konkret | "peacock tail" (berhasil karena 200K vs 11 di sebelahnya) |

**⚠️ Peringatan:**
- Emosi BUKAN teknik. Emosi muncul sebagai efek samping dari detail spesifik. Menambahkan emosi langsung = performing.
- Vivid = hasil, bukan teknik. 7 teknik di atas menghasilkan vividness.
- Amplifier tanpa insight = dekorasi. Insight tanpa amplifier = konsep. Keduanya = konten yang menang.

**Data proof:**

| Kombinasi | Hasil |
|---|---|
| Reframe spesifik + Amplifier spesifik | Orig 2/2 (17/17 winners) |
| Reframe umum + Amplifier umum | Orig 1/2 (@muktaryaks) |
| Tanpa reframe + Amplifier | Orig 1/2 (v1 Toast) |

**Output:**
→ Insight yang hidup.

---

### LANGKAH 4: POLISH — Baru sekarang fokus pada cara menulis

**Periksa:**
- Hook — apakah insight muncul sejak awal?
- Flow — apakah setiap kalimat mengalir ke berikutnya?
- Rhythm — apakah ada variasi panjang kalimat?
- Pacing — apakah momentum terjaga?
- Clarity — apakah satu bacaan cukup?
- Ending — apakah meninggalkan kesan atau mengundang respons?

**Hilangkan:**
- Kalimat berulang
- Kata sifat berlebihan
- Penjelasan yang tidak menambah nilai

**Pertanyaan utama:**
> "Kalau kalimat ini dihapus, apakah tulisan menjadi lebih lemah?"

Jika tidak → Hapus.

**Output:**
→ Tulisan yang padat dan tajam.

---

### LANGKAH 5: PUBLISH — Checklist final

- [ ] Hook menghentikan scroll.
- [ ] Ada satu insight yang jelas.
- [ ] Insight diperkuat dengan detail konkret.
- [ ] Tidak ada bagian yang mubazir.
- [ ] Ending meninggalkan kesan atau mengundang respons.

Jika semua ✔ → Publish.

---

## CHECKLIST SEBELUM TULIS

Sebelum mulai menulis, jawab:

1. **READ:** Apa tujuan campaign? Apa yang juri mau lihat?
2. **READ:** Apa yang sudah sering ditulis? (supaya tidak ikut template)
3. **READ (PRODUK):** Apakah saya sudah BENAR-BENAR PAHAM mekanismenya?
4. **INSIGHT:** Jika pembaca hanya mengingat satu kalimat, kalimat apa?
5. **INSIGHT:** Apakah ini reframe, atau sekadar observasi? (reframe = flip asumsi)
6. **AMPLIFY:** Bisakah pembaca MELIHAT dan MERASAKAN insight ini?
7. **AMPLIFY:** Apakah detail saya spesifik sampai hanya SAYA yang bisa menulisnya?
8. **POLISH:** Kalau kalimat ini dihapus, apakah tulisan jadi lebih lemah?
9. **PUBLISH:** Semua checklist terpenuhi?

---

## ANTI-PATTERN

### ❌ Mulai dari teknik, bukan dari insight
"Hari ini saya mau pakai format deletion dispute."
→ Ini yang bikin v3 jadi peniru. Teknik mengikuti insight, bukan sebaliknya.

### ❌ Observasi tanpa reframe (di KREATIF)
"WiFi in Kendari has three speeds: slow, slower, maybe tomorrow."
→ Menarik, tapi ini observasi. Flip-nya: "The best audit in crypto isn't CertiK. It's rainy season WiFi."

### ❌ Amplifier tanpa insight
Detail spesifik, angka, dialog — tapi tidak ada ide yang layak diingat.
→ Dekorasi tanpa fondasi. Juri bilang "menarik tapi Sudut pandang apa?" → Orig 1/2.

### ❌ Insight tanpa amplifier
Punya reframe bagus tapi tidak ada detail spesifik yang membuktikan.
→ Konsep tanpa bukti. Reader bilang "setuju tapi tidak terasa."

### ❌ Optimisasi menggantikan kejujuran
"Apa yang bikin orang klik?" bukan "Apa yang genuinely layak diingat?"
→ EP 5/5 + Orig 1/2. Clickbaity, slogan-like. Juri detect ini.

### ❌ Emosi sebagai teknik
Menambahkan "I feel sad" atau "this is heartbreaking" langsung.
→ Performing. Data: 0/8 winner menggunakan emosi sebagai teknik. Emosi muncul dari detail, bukan dipasang.

---

## RULE

**Kalau konten terasa "writerly", "optimized", "textbook", "marketing copy", atau "performed" — kembali ke INSIGHT. Cari ide yang layak diingat, bukan teknik yang terlihat pintar.**

**Kalau konten punya detail spesifik tapi tidak ada ide yang layak diingat — kembali ke INSIGHT. Amplifier tanpa insight = dekorasi.**

**Kalau konten punya insight tapi tidak terasa nyata — kembali ke AMPLIFY. Tambah detail, bukan penjelasan.**

**Kalau kamu tidak bisa menjawab "satu kalimat apa yang pembaca harus ingat?" — kamu belum punya insight. Berhenti. Cari dulu.**
