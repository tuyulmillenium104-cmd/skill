# 💬 SKILL 21: Q&A ENGINE V3.1.3 GOLD

**Phase:** 3 (Q&A)
**Source:** RESTORED from v2.3 RALLY-QNA-ENGINE-V3.1.3.md (FULL)
**Purpose:** Generate reply pack RQ5-ready dengan format proven dan quality gates.
**Authority:** This file replaces older V1/V2 Q&A rules. If any older file, memory, or instruction conflicts with this file, follow this V3.1.3 Gold engine, the literal campaign brief, and fresh mission evidence.

---

## 0. Truth Law

- A pack may be called `RQ5-ready` only after every required gate passes.
- Never call a pack `guaranteed RQ5` or guaranteed RQ 5/5.
- `PASS` means the controllable side is strong and evidence-calibrated. It is not a score prediction, probability, winner promise, or external verdict.

---

## 1. Evidence Hierarchy

Use evidence in this order:

1. **Literal campaign and mission brief** — highest authority
2. **Current mission-scoped real RQ5 replies and judge verdicts**
3. **User-supplied Gold Standard** when compatible with real evidence
4. **Global RQ verdict corpus and field lessons**
5. **Automated gates and heuristics** — lowest authority

Fresh real evidence outranks a generic template or old threshold. Any conflict must be written in the calibration report and resolved evidence-first.

---

## 2. Required Pack

Default English pack:

- **20 Q-COPY/A-COPY pairs**
- Specific Probe: **4**
- Challenge: **5**
- Technical Deep-Dive: **5**
- Hot Take: **4**
- Real Experience: **2**
- Ranked strongest to weakest
- Tier score convention: Tier S=9, Tier A=7, Tier B=4, Tier C=0
- `qa_ranking.json` is mandatory and must contain `voicePersona` and `voiceMode` for every row

AI-generated Real Experience rows:
- must be marked `SIMULATED_ARCHETYPE` in heading/type metadata
- must be marked `CONDITIONAL_ORGANIC_MATCH_ONLY` in ranking/deployment metadata
- must be ranked last unless real mission evidence justifies otherwise
- are not deployable as fake testimony
- must not put warning labels inside Q-COPY

---

## 3. Q-COPY Construction

Every Q must:
- read like a real public X/Twitter reply, not an interview question
- carry a personal opinion, stake, decision, objection, or experience
- reference the final post, CTA, mechanism, timing, number, or exact phrase
- add a new angle instead of paraphrasing the post
- be **160-260 characters**
- avoid generic praise, FAQ language, and writing-craft commentary
- stay within factual boundaries; hypothetical scenarios must read as hypothetical
- contain **no internal metadata, warning label, persona label, tier label, type label, deployment label, audit note, or scaffold placeholder**

Q-COPY is public copy only. Metadata belongs in the heading, audit table, or `qa_ranking.json`, never inside the Q body.

### Type Rules

**Specific Probe**
- Quote an exact phrase from the final post
- Probe a new consequence, edge case, or domain
- Generic `What is X?` questions fail

**Challenge**
- Include a claim + mechanism/evidence/scenario + a precise doubt
- Flat disagreement fails
- Unsupported market facts fail; phrase uncertainty as a hypothesis

**Technical Deep-Dive**
- Reference a specific post mechanism
- Ask a bounded technical question or state a concrete technical concern
- Generic `How does X work?` fails

**Hot Take**
- Make a bold claim and provide an alternative thesis
- Generic opposition fails

**Real Experience**
- Use a mini-story from the replier's perspective
- AI-generated examples must carry metadata outside the Q body only
- Never seed simulated testimony as fake organic engagement

---

## Public-Copy Privacy Rule

Apply `skills/27_PUBLIC_COPY_LEAKAGE_POLICY.md` in prompt mode:

> Q-COPY and A-COPY must read as public replies from real people. Do not include language that reveals private skill files, checker workflow, audit process, internal metadata, or generation scaffolding. Official Rally/campaign/community terms are allowed when they are natural in context. If unsure, ask whether a normal Rally participant would write it publicly without seeing the skill files. If not, rewrite into plain public language.

Do not create broad hard-ban vocabulary for normal Rally/campaign terms. Leakage control is lightweight; everything else is a naturalness/style decision.

---

## 4. Pack-Level Q Controls

Default V3 thresholds:

| Metric | Threshold |
|---|---|
| Decision-marker coverage | 75-80% |
| Decision-word coverage | ≥50% |
| CTA-aligned Q | ≥40% |
| Specific Probe exact-source quote | 100% |
| Q using "because" | ≤35% |
| Q using "I would" | ≤25% |
| Q using "my decision" | ≤20% |
| Q-length coefficient of variation | ≥9% |
| Sentence-count structures | ≥3 across pack |
| Journalist framing | 0 |
| Generic FAQ | 0 |
| Exact duplicate Q | 0 |

Coverage targets prevent rigid per-pair formula. Distinct voices outrank cosmetic uniformity.

---

## 5. Voice-Diversity Controls

Across the 20 pairs:

| Metric | Threshold |
|---|---|
| Explicit first-person Q | ≤75% |
| Decision-marker Q | ≤80% and ≥75% |
| Casual/contraction voice | ≥35% |
| Anecdotal or applied-experience surface | ≥35% |
| Distinct first-two-word Q openers | ≥15 |
| Same first Q word | ≤25% |
| Same first-two-word Q shell | ≤15% |
| First-person Q openings | ≤40% |
| Direct-question Q | 20-35% |
| Two-sentence shell | ≤50% |
| Semicolon usage | ≤15% |
| Formal/abstract register | ≤40% |
| Distinct personas | ≥10 |
| Distinct voice modes | ≥5 |
| No adjacent rows same persona | Required |

Scaffold `EVIDENCE_PERSONA_*` / `EVIDENCE_VOICE_*` placeholders are planning markers only and are rejected in final ranking.

Lexical uniqueness alone is insufficient. A pack fails if different words still carry the same polished analytical voice.

---

## 6. A-COPY Construction

For an English pack:
- **40-45 words** when possible
- **Hard maximum 280 characters**
- One line per answer
- Direct response + a new insight, implication, or honest boundary
- Writer presence consistent with the main post
- Include a decision/action word
- Weave facts naturally; do not recite the knowledge base
- Zero fabricated facts or fake experience
- Vary openings and closings
- Question-ending coverage: **50-75%**, not a per-pair law
- Statement closes are valid when they sound natural and evidence supports them

Follow the FEEL, not a formula. If three adjacent answers start or end with the same pattern, rewrite.

---

## 7. Quality Gate Per Pair

Every pair must be reviewed on three 1-5 dimensions:

| Dimension | What it checks |
|---|---|
| **Q Quality** | Persona-driven, specific, references the post |
| **A Insight** | Concise, adds perspective, not KB documentation |
| **Conversational Feel** | Reads like a real X/Twitter exchange |

Required: **every pair Q/A/Feel ≥4**

---

## 8. Ranking Protocol

Rank strongest to weakest for response speed:

1. Honest, specific objections
2. Deep mechanism questions tied to the post
3. Concrete domain probes answering the CTA
4. Alternative theses and controlled humor
5. Simulated archetypes last and non-deployable

Internal ranking scores are prioritization indices only. Never label them Rally scores or RQ probabilities.

---

## 9. Required Output Format

```md
## R01 [Tier S=9] (Challenge)
**Q-COPY**
```text
<public reply only, 160-260 chars, no metadata>
```
**A-COPY**
```text
<one-line answer, ≤280 chars>
```

## R02 [Tier A=7] (Specific Probe)
**Q-COPY**
```text
<public reply only, 160-260 chars, no metadata>
```
**A-COPY**
```text
<one-line answer, ≤280 chars>
```
...

## R20 [Tier C=0] (Real Experience | SIMULATED_ARCHETYPE)
**Q-COPY**
```text
<public reply only, 160-260 chars, no metadata>
```
**A-COPY**
```text
<one-line answer, ≤280 chars>
```
```

Also write `qa_ranking.json` next to combined.md:

```json
{
  "rows": [
    {
      "idx": 1,
      "type": "Challenge",
      "tier": "S",
      "tierScore": 9,
      "voicePersona": "skeptical protocol user",
      "voiceMode": "constructive skeptical",
      "deployment": "DEPLOYABLE"
    }
  ]
}
```

---

## MANDATORY: BACA PROVEN EXAMPLE SEBELUM GENERATE

**Sebelum generate Q&A pack:**
1. Baca `/skills/proven_examples/toast_qna_proven_format.md`
2. Ikuti format yang SAMA PERSIS
3. Jangan generate dari memory — baca proven example dulu

Ini adalah LAW. Bukan saran. Pelanggaran = RESTART dari Phase 3.

---

## 10. Deployment Law

- Q-COPY models likely incoming replies — JANGAN post semua Q sendiri
- Select only A-COPY matching a real organic reply
- Prioritize: real confession > serious skepticism > technical questions
- Reply quickly when possible, but never sacrifice substance for speed
- Do not post fake experiences, fake community conversation, or synthetic testimony
- Re-audit any edited answer before deployment

---

## 11. Final Status Language

Allowed:
- `RQ5-ready`
- `Gold V3 PASS`
- `mission-calibrated RQ5 pressure`

Forbidden:
- `guaranteed RQ5`
- `guaranteed RQ 5/5`
- `certain winner`
- `external judge proof`

---

## RELATIONSHIP KE SKILL LAIN

- **Gold RQ Standard (Skill 22)**: Quality criteria and evidence hierarchy
- **Q&A AI Review (Skill 23)**: Review mechanism after pack generated
- **Human Typed Copy (Skill 24)**: Anti-engineered text check
- **Public Copy Leakage (Skill 27)**: Privacy rule for public copy
- **The Oath (Skill 20)**: BACA skill file dan proven example DULU sebelum generate
