# 💬 SKILL 08: Q&A ENGINE — Reply Pack Generator

**Tujuan:** Generate Q&A reply pack untuk maximize Reply Quality (RQ).

---

## WHY Q&A MATTERS

Dari data The Toast:
- RQ is the REAL ranking differentiator among EP 5/5 holders
- Top 10 avg RQ: 4.6
- Bottom 20 avg RQ: 3.4
- RQ 5/5 vs 3/5 = massive ranking difference

---

## PROCESS

### Step 1: Understand your content's conversation entry points
- What will people reply about?
- What questions might they ask?
- What personal stories might they share?

### Step 2: Generate 15-20 Q&A pairs
For each pair:
- **Q (anticipated reply/question):** What someone might say
- **A (your reply):** Genuine, specific, adds value, not generic

### Step 3: Quality Check each reply
- ✅ Is it GENUINE? (not generic "thanks!")
- ✅ Is it SPECIFIC? (references their specific point)
- ✅ Does it ADD VALUE? (new insight, follow-up question, shared experience)
- ✅ Is it CONVERSATIONAL? (not formal, not AI-sounding)
- ✅ Does it ENCOURAGE more replies? (ends with question or invitation)

---

## REPLY TYPES

| Type | When to Use | Example |
|---|---|---|
| **Personal Story** | When they share their experience | "That's exactly it. I had a similar moment when..." |
| **Specific Validation** | When they make a good point | "You nailed the part about X. That's what I was trying to capture." |
| **Follow-up Question** | When you want to keep conversation going | "What was the moment that changed your mind?" |
| **Shared Experience** | When they relate to your story | "The screen time thing is real. Mine was even worse..." |
| **Gratitude + Specific** | When they praise your content | "Thank you. The [specific part] was the hardest to write honestly." |

---

## ANTI-PATTERNS (AVOID)

- ❌ Generic "Thanks!" or "Appreciate it!" = RQ killer
- ❌ "Great point!" without adding anything = zero value
- ❌ Sales pitch or promotion = instant turn-off
- ❌ AI-sounding formal language = inauthentic
- ❌ Too long replies = conversation killer

---

## OUTPUT

15-20 Q&A pairs, ready to use as reply templates when people respond to your tweet.
