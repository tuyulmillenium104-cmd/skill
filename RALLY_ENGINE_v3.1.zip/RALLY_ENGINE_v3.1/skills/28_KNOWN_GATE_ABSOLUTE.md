# 🔒 SKILL 28: KNOWN-GATE ABSOLUTE STANDARD

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 KNOWN-GATE-ABSOLUTE-STANDARD.md
**Purpose:** Define the strongest honest claim we can make before submitting. Highest honest certainty standard.

---

## Core Truth

External absolute guarantee is impossible from outside Rally.

Forbidden claims:
```
guaranteed EP5
guaranteed all-max
guaranteed winner
guaranteed top 1%
```

Allowed highest claim:
```
Known-Gate Absolute PASS
```

---

## Definition

Known-Gate Absolute means:

```
All known controllable cut surfaces found in current evidence are closed.
```

It is absolute ONLY with respect to:
- literal campaign/mission brief
- source post / KB truth
- current mission-scoped Rally verdict data
- hidden-gate mining output
- winner-pull mining output
- manual no-cut review
- hostile judge attack review
- human-typed public copy review
- local gate checks
- final integrity

It is NOT absolute with respect to:
- unknown future hidden gates
- Rally internal prompt changes
- LLM judge variance
- competitor pool
- account behavior
- timing
- engagement metrics
- organic replies

---

## Required Closure Map

A final content package cannot be called Known-Gate Absolute unless every category is explicitly closed.

### 1. Campaign Ask Closure
- mission ID correct
- required quote/reply/link correct
- required handles correct
- forbidden formats avoided
- campaign ask answered directly
- no wrong-mission contamination

### 2. Source Truth Closure
- source post/brief/KB truth loaded
- no fabricated claims
- no unsupported guarantee
- product mechanism stated accurately
- relationship between brands/protocols accurate

### 3. EP Known Deduction Closure

Must close current known EP cut surfaces:
- `cta_weak`
- `conversation_limited`
- `value_not_exceptional`
- `structure_density`
- `hook_weak`
- `specificity_missing`
- `generic_formulaic`
- `brand_promotional`
- `too_niche_or_abstract`
- `mechanism_unclear`
- `media_format_issue`
- `authenticity_polish_tax`

### 4. Winner-Pull Closure

Must show evidence for likely judge praise:
- hook
- concrete scenario
- mechanism clarity
- value payload
- CTA/conversation
- human voice
- structure/read-through
- brand/source integration
- distinctiveness

### 5. Human-Typed Closure
- no public skill leakage
- no label-like shells that sound generated
- no audit voice
- main content feels human
- Q/A feel like real public replies

### 6. Hostile Judge Closure
- every line has a function
- no obvious stronger substitution remains
- compression/expansion checked
- hostile judge 10-attack has no credible unresolved cuts
- non-expert retell passes
- expert respect passes

### 7. Local Gate Closure

Required PASS:
- compliance
- CTA quality
- compactness
- originality
- EP semantic
- Q&A gates (if Q&A included)
- final integrity

---

## Unknown-Risk Statement

Every Known-Gate Absolute report must include:

```
Remaining risk is limited to unknown/future judge gates, judge variance, external engagement, account/timing behavior, and organic reply quality.
```

---

## Decision Rule

| Status | Meaning |
|---|---|
| **NOT ABSOLUTE - REBUILD / REPAIR REQUIRED** | Any known cut surface remains open |
| **KNOWN-GATE ABSOLUTE PASS** | All known cut surfaces closed |

---

## Relationship to Allowed Claims

"Known-Gate Absolute PASS" is equivalent to "local strict PASS" — both mean all controllable surfaces are closed.

Both are honest local claims. Neither is an external guarantee.
