# 🔄 SKILL 12: REFRAME + AMPLIFIER PATTERN

**Tujuan:** Memahami pola yang membedakan Orig 2/2 dari Orig 1/2

**Sumber:** 17 Orig 2/2 winners dari 3 campaign (Toast, Wikipedia, Mic), dianalisis satu per satu

---

## POLA UTAMA

```
REFRAME SPESIFIK + AMPLIFIER SPESIFIK = Orig 2/2
REFRAME UMUM + AMPLIFIER UMUM = Orig 1/2
TANPA REFRAME + AMPLIFIER = Orig 1/2
```

---

## BUKTI: 17 ORIG 2/2 WINNERS

### THE TOAST CAMPAIGN

| Winner | Reframe (philosophical flip) | Amplifier (detail spesifik) |
|---|---|---|
| @alver1301 | "The person you accused was actually protecting you" | "'I deleted my comment. That wasn't an apology.'" |
| @str_kerx | "Your savior doesn't have to be human" | "Cat named Hallie, 4:30am, 'useless intern'" |
| @uso411247 | "Loss deserves a toast more than winning" | "Rented suit, coupon, 40-minute drive" |
| @spacejunnk | "A lie can be an act of compassion" | "'Raising a glass to the stranger who lied to me'" |
| @chainops1_ | "Losing was just showing up to work the next day" | "Marco, terrible paella, wet socks and sadness" |
| @sameddy01 | "Doubt can become something you hold" | "Maya, 200 followers, zero budget, still only sold 40 copies" |
| @navtq0808 | "Your ugly first version is proof, not failure" | "Wallet as toast target, 'You were wrong'" |

### WIKIPEDIA CAMPAIGN

| Winner | Reframe (philosophical flip) | Amplifier (detail spesifik) |
|---|---|---|
| @_iamdotun_ | "Your useless traits are actually your Wikipedia entry" | "6'7\" least useful specification, tile gaps, meme coin" |
| @alver1301 | "Wikipedia should be about what to DELETE, not what to add" | "'had potential' is not a career" |
| @jeff__dan | "The edit button deserves as much credit as the post button" | "Draft became older than the trend" |
| @kaybee1899 | "Growth leaves evidence" | "Old wallet filled with failed transactions" |
| @tm_dynamics | "Absurdity is more honest than achievement" | "Cheddar Incident, digital soups, lunar-cycle smart contract" |
| @miftahudinsd9 | "Your real page is the unpublished drafts" | "47 unpublished sources" |

### MIC (DEBAT) CAMPAIGN

| Winner | Reframe (philosophical flip) | Amplifier (detail spesifik) |
|---|---|---|
| @svictorayomi | "We didn't remove middlemen, we renamed them" | "Venture-backed APIs with token wrappers" |
| @ahonjumaidil | "Follower count is proof of nothing" | "200K followers, 11 likes, peacock tail" |

---

## BUKTI: ORIG 1/2 PATTERN

| Konten | Reframe? | Amplifier? | Hasil |
|---|---|---|---|
| v1 Toast (kita) | TIDAK ADA — "person helped → gratitude" | Detail spesifik (screen time) | Orig 1/2 |
| @muktaryaks (Toast) | UMUM — "creators are free labor" | GENERIK — tidak ada detail personal | Orig 1/2 |
| v4 Wikipedia (kita) | TIDAK ADA — observasi saja | Detail spesifik (warung, ojol) | Diprediksi Orig 1/2 |
| @jokerverse01 (Wiki) | TIDAK ADA — mengikuti template | Beberapa detail bagus | Orig 1/2 |
| @dynamicscomics (Wiki) | TIDAK ADA — mengikuti template | Detail personal kuat | Orig 1/2 |

---

## CARA MEMBEDAKAN REFRAME UMUM vs SPESIFIK

| Reframe UMUM (Orig 1/2) | Reframe SPESIFIK (Orig 2/2) |
|---|---|
| "Creators are undervalued" | "The edit button deserves as much credit as the post button" |
| "Small towns have wisdom" | "Slow internet is the only unriggable audit in crypto" |
| "Follower count doesn't matter" | "Follower count is proof of nothing — 200K followers, 11 likes" |
| "Crypto has middlemen" | "We didn't remove middlemen, we renamed them — venture-backed APIs with token wrappers" |

**Perbedaan:** Reframe spesifik bisa langsung ditulis sebagai kalimat pembuka. Reframe umum butuh penjelasan tambahan.

---

## CARA MENEMUKAN REFRAME

### Metode 1: Balik Asumsi
1. Tulis asumsi yang semua orang pegang tentang topik ini
2. Balik asumsi itu
3. Cari detail spesifik yang MEMBUKTIKAN pembalikan itu

**Contoh:**
- Asumsi: "Internet lambat = disadvantage di crypto"
- Balik: "Internet lambat = the only unriggable audit"
- Bukti: "You literally cannot FOMO into anything. The transaction will not confirm before you've walked to the warung and had the uncle explain why you shouldn't send."

### Metode 2: Cari Kontradiksi
1. Cari dua hal yang seharusnya berlawanan tapi di pengalamanmu tidak
2. Jelaskan kenapa mereka konsisten

**Contoh:**
- "Never read a whitepaper" dan "Never been rug pulled" seharusnya berlawanan (tidak baca = tidak tahu = kena scam)
- Tapi di kenyataan: warung uncle paham dari analogi nasi, bukan dari whitepaper → konsisten

### Metode 3: Subvert Format
1. Ambil format campaign (Wikipedia page, toast, debate)
2. Tanya: "Apa bagian dari format ini yang tidak pernah ditulis orang?"
3. Tulis dari bagian itu

**Contoh:**
- Semua orang nulis Wikipedia article → @alver1301 nulis Wikipedia deletion page
- Semua orang nulis article → v6 nulis Talk Page (bagian yang berdebat di balik layar)

---

## RULE

**REFRAME = DRIVER. AMPLIFIER = PROOF.**

Reframe tanpa amplifier = klaim tanpa bukti.
Amplifier tanpa reframe = bukti tanpa klaim.
Keduanya = konten yang menang.

**Setiap amplifier harus MEMBUKTIKAN reframe. Kalau amplifier hanya mendekorasi → hubungkan ke reframe atau hapus.**
