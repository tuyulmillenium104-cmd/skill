# 🎯 SKILL 13: AI HUMAN TASTE DIRECTOR

**Phase:** 2 (STRESS TEST)
**Source:** RESTORED from v2.3 AI-HUMAN-TASTE-DIRECTOR.md
**Purpose:** Review konten dari 7 persona sebelum finalize. Mencegah konten yang lolos gate tapi terasa engineered.

---

## CORE LAW

Public copy harus terasa seperti orang asli ngetik, bukan rubrik yang didisguise jadi tweet.

```
Agent drafts → Agent attacks own draft → Agent edits for human taste → Then run final gates
```

Python gates bisa bilang PASS tapi konten masih terasa engineered, over-polished, template-like, atau terlalu obvious ditulis untuk rubrik.

---

## 7 PERSONA REVIEW

Sebelum konten difinalize, review sebagai setiap persona:

### 1. Normal Reader
- Apakah aku ngerti postingan ini setelah baca sekali?
- Apakah aku mau lanjut baca setelah 2 baris pertama?
- Apakah contohnya gampang dibayangkan?

### 2. Skeptical Rally Judge
- Apa deduction paling fair "strong, but..." yang bisa dikasih?
- Apakah CTA cukup kuat?
- Apakah mekanisme produk jelas?

### 3. Non-Expert Reader
- Apakah perlu insider knowledge untuk ngerti?
- Apakah analogi menjelaskan tanpa jargon?

### 4. Crypto/Agent-Native Reader
- Apakah technically respectful?
- Apakah terlalu normie, terlalu shallow, atau oversimplified?

### 5. Human Voice Editor
- Apakah kedengeran seperti orang ngetik secara publik?
- Apakah ada label-shell seperti "My concern:", "My answer:", "Hot take:", "Reply:"?
- Apakah kedengeran seperti rubrik yang didisguise jadi postingan?

### 6. Brand/Accuracy Editor
- Apakah brand mention terasa natural?
- Apakah ada claim yang terlalu broad?
- Apakah tetap dalam batas campaign knowledge?

### 7. Competitor Comparison Judge
- Apakah ini standout di antara 50 submissions?
- Apakah hook top-tier?
- Apakah concrete object cukup distinctive?

---

## DECISION RULE

Draft TIDAK boleh final jika ADA satu persona yang menemukan credible issue.

Status yang diperbolehkan:
- `PASS` → lanjut
- `REWRITE NEEDED` → edit bagian yang bermasalah, rerun taste review
- `REBUILD NEEDED` → buat konsep baru

---

## OUTPUT

Untuk run serius, produce:

```
TASTE_DIRECTOR_REPORT.md
```

Isi:
- Persona verdicts (7 persona, masing-masing PASS/REWRITE/REBUILD + alasan)
- Issues found
- Edits made
- Final taste decision

---

## RELATIONSHIP KE SKILL LAIN

- **Irreducible Apex**: Konten Apex harus lulus Taste Director. Line bisa functional tapi masih terasa engineered.
- **EP Gate Review**: EP Gate itu review teknis. Taste Director itu review manusia. Keduanya wajib.
- **Flag Paradox**: Kalau Taste Director bilang REWRITE tapi itu bisa kill EP → pakai Flag Paradox rule (SAFE fix only).
- **KONFESIONAL genre**: Human Voice Editor persona PALING penting di genre ini. Jangan polish sampai hilang keaslian.

---

## ANTI-PATTERN

- ❌ Skip persona karena "sudah yakin bagus"
- ❌ Hanya jalankan persona yang kemungkinan besar PASS
- ❌ Run semua persona tapi ignore hasil yang jelek
- ❌ Rebuild tanpa insight baru (cuma ganti kata-kata)
