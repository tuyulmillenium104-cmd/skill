# 🏎️ RALLY ENGINE v3.1

**AI-powered content creation engine for Rally campaigns**

---

## Core Formula

**Campaign Ask × Rally Judge Desire**

**Content Thinking Framework:** READ → INSIGHT → AMPLIFY → POLISH → PUBLISH

**Proven pattern:** Reframe + Amplifier = Orig 2/2 (17/17 Orig 2/2 winners)

---

## 3-Phase Architecture

```
PHASE 1: GENERATE (Skill 00-12, 30)   → Bikin konten terbaik
PHASE 2: STRESS TEST (Skill 13-20, 28-29) → Uji konten sampai tahan
PHASE 3: Q&A (Skill 21-27)          → Reply pack RQ5-ready
```

---

## Quick Start

See `RALLY_QUICK_START_v3.1.md` for 55-minute workflow.

See `RALLY_EFFECTIVE_WORKFLOW_v3.1.md` for full detail.

---

## Skill Files

### PHASE 1: GENERATE (Skill 00-12, 30)

| # | File | Purpose |
|---|------|---------|
| 00 | CONTENT_THINKING_FRAMEWORK.md | ★ PALING FUNDAMENTAL — 5 langkah |
| 01 | FOUNDATION.md | Setup dan data collection |
| 02 | SOURCE_TRUTH.md | Extract judge preferences |
| 03 | FRESH_SURFACE_MAP.md | Find unique angles (with Fresh-but-Inevitable) |
| 04 | ORIGINAL_THESIS.md | Generate thesis with reframe + amplifier |
| 05 | GENERATE.md | Generate 3 candidates, pick best |
| 06 | EP_GATE_REVIEW.md | 3 check × 7 step review |
| 07 | RIGID_GATES.md | Binary compliance check |
| 08 | QNA_ENGINE.md | Basic Q&A awareness |
| 09 | ONE_SESSION_ONE_RUN.md | Fail-fast protocol |
| 10 | DATA_COLLECTOR_API.md | Rally API reference |
| 11 | AMPLIFY_TECHNIQUES.md | 7 data-driven amplify techniques |
| 12 | REFRAME_AMPLIFIER_PATTERN.md | 17 Orig 2/2 winner patterns |
| 30 | DATA_AS_JUDGE_POLICY.md | LAW 1 detailed policy + anti-copy rules |

### PHASE 2: STRESS TEST (Skill 13-20, 28-29)

| # | File | Purpose |
|---|------|---------|
| 13 | TASTE_DIRECTOR.md | ★ 7 persona review (RESTORED v2.3) |
| 14 | HOSTILE_JUDGE_ATTACK.md | ★ 10-attack adversarial test (RESTORED v2.3) |
| 15 | HIDDEN_GATE_MINING.md | Mine implicit judge patterns (RESTORED v2.3) |
| 16 | WINNER_PULL_MINING.md | Extract what judges praise (RESTORED v2.3) |
| 17 | STEP_CONFLICT_CHECK.md | Cross-step conflict detection (RESTORED v2.3) |
| 18 | FEEDBACK_ITERATION.md | Fix cycle, max 3x (RESTORED v2.3) |
| 19 | FLAG_PARADOX.md | Safe/Risky/High Risk categorization |
| 20 | OATH_AND_ENFORCEMENT.md | ★ THE OATH + Zero Tolerance (RESTORED v2.3) |
| 28 | KNOWN_GATE_ABSOLUTE.md | Highest honest certainty standard (RESTORED v2.3) |
| 29 | UNIVERSAL_CAMPAIGN_SAFETY.md | Campaign-agnostic safety checks (RESTORED v2.3) |

### PHASE 3: Q&A (Skill 21-27)

| # | File | Purpose |
|---|------|---------|
| 21 | QNA_ENGINE.md | ★ V3.1.3 Gold engine FULL (RESTORED v2.3) |
| 22 | GOLD_RQ_STANDARD.md | ★ Evidence-calibrated RQ standard FULL (RESTORED v2.3) |
| 23 | QNA_AI_REVIEW.md | Q&A quality review (proven format) |
| 24 | HUMAN_TYPED_COPY.md | Anti-engineered text FULL (RESTORED v2.3) |
| 25 | FINAL_INTEGRITY.md | Cross-artifact consistency (RESTORED v2.3) |
| 26 | SUBMIT_CHECKLIST.md | Final go/no-go |
| 27 | PUBLIC_COPY_LEAKAGE_POLICY.md | Prevent metadata leakage (RESTORED v2.3) |

---

## Root Files

| File | Purpose |
|------|---------|
| RALLY_FUNDAMENTAL_LAW_v3.1.md | 10 laws + The Oath |
| RALLY_EFFECTIVE_WORKFLOW_v3.1.md | Full 3-phase workflow |
| RALLY_QUICK_START_v3.1.md | 55-minute quick start |
| GENRE_DETECTION_GUIDE.md | 4 genres + insight hierarchy |
| PROOF_AND_LESSONS.md | Data from real judge + discoveries |
| VERSION.txt | Version number |

---

## What Changed from v3.0

1. **3-Phase Architecture**: GENERATE → STRESS TEST → Q&A (was 11 bloated phases)
2. **STRESS TEST RESTORED**: Taste Director, Hostile Judge Attack, Hidden Gate Mining, Winner Pull Mining, Step Conflict Check, Feedback+Iteration
3. **THE OATH RESTORED**: LAW 10 "Read skill before execute" + Zero Tolerance enforcement
4. **Q&A ENGINE FULL**: V3.1.3 Gold with pack-level controls, voice diversity, quality gates (was truncated)
5. **GOLD RQ STANDARD FULL**: Evidence hierarchy, type rules, anti-dilution law (was truncated)
6. **HUMAN TYPED COPY FULL**: Hard distinction internal vs public, leakage prevention (was truncated)
7. **PUBLIC COPY LEAKAGE POLICY**: NEW — prevent metadata leaking into public copy
8. **KNOWN-GATE ABSOLUTE**: NEW — 7-closure honest certainty standard
9. **UNIVERSAL CAMPAIGN SAFETY**: NEW — mission isolation, handle lock, semantic process order
10. **DATA AS JUDGE POLICY**: NEW — LAW 1 detailed with anti-copy rules, drafting order
11. **FRESH-BUT-INEVITABLE**: Added to Skill 03 — fresh ≠ weird
12. **Final Integrity RESTORED**: Cross-artifact consistency check

---

## What Changed from v2.3

1. **Content Thinking Framework**: READ→INSIGHT→AMPLIFY→POLISH→PUBLISH
2. **REFRAME+AMPLIFIER pattern**: 17/17 Orig 2/2 proof
3. **Genre awareness**: Different insight defaults per genre
4. **Flag Paradox**: SAFE/RISKY/HIGH RISK categorization
5. **Simplified**: 31 skills vs 80+ files (v2.3 terlalu banyak, banyak archived)
6. **No Python dependency**: All checks AI-driven
7. **"Insight memimpin, teknik mengikuti"**: Core principle

---

## NOT Restored (dangerous for KONFESIONAL)

- Exponential Content Standard scoring (use 10-attack test instead)
- Irreducible Apex scoring axes (use 10-attack test instead)
- 39 Python scripts (not executable in current context)
