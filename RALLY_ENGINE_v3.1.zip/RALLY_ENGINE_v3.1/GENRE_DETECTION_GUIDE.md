# 🎭 GENRE DETECTION GUIDE

**Kenapa penting:** Genre menentukan apa yang juri praise, apa yang berisihnya fix, dan prioritas EP sub-kriteria.

---

## 4 GENRE UTAMA

### 1. KONFESIONAL
**Ciri:** Emotional, personal story, gratitude, admission, vulnerability

**Contoh campaign:**
- The Toast (angkat gelas ke seseorang)
- The Origin Story (asal-usul kamu di crypto)
- Confess Your Sins (pengakuan)

**Apa yang juri PRAISE:**
- Authenticity #1 (human voice, admission of weakness)
- Emotional beats ("I was embarrassed" = PRAISED)
- Specificity (vivid details, nama, angka)
- Raw honesty > polished cleverness
- "Told not shown" itu OK di genre ini

**Apa yang juri PENALIZE:**
- Generic gratitude ("thank you for everything")
- AI-sounding optimization
- Forced @RallyOnChain placement

**Fix flag risk: 🔴 TINGGI**
- Emotional authenticity itu FRAGILE
- Sentuh dikikit, hancur
- JANGAN fix: register shift (ceremonial ending itu OK di toast), "told not shown" language, emotional repetition
- AMAN fix: tambah nama

**EP sub-kriteria prioritas:**
1. Authenticity / Feel
2. Hook effectiveness
3. Value delivery (emotional)
4. Conversation potential
5. Content structure
6. CTA quality
7. @RallyOnChain integration

---

### 2. KREATIF / FORMAT-DRIVEN
**Ciri:** Format spesifik, humor, structure execution, cleverness

**Contoh campaign:**
- Your Wikipedia Page (mock encyclopedia)
- Fake News (satirical news)
- The Twist Ending (story with twist)

**Apa yang juri PRAISE:**
- Format execution #1 (Wikipedia harus FEEL like Wikipedia)
- Self-aware humor (mock-serious tone)
- Hyper-specific details (6'7", 312 points, cold tea)
- Irony/contradiction ("architecture student" → "hasn't built a building")
- @RallyOnChain sebagai natural part of format

**Apa yang juri PENALIZE:**
- Missing format execution (just a bio with headers = boring)
- No humor (earnest Wikipedia page = AI-sounding)
- Weak hook (opening line must maximize format)
- Generic sections

**Fix flag risk: ⚠️ MODERATE**
- Hook fix biasanya AMAN (bahkan recommended)
- Humor fix tricky (comedy timing hard to engineer)
- Structure fix boleh lebih agresif

**EP sub-kriteria prioritas:**
1. Hook effectiveness (format-native)
2. Content structure (format execution)
3. Authenticity / Feel (humor, not earnest)
4. Conversation potential
5. Value delivery (entertainment)
6. CTA quality
7. @RallyOnChain integration

---

### 3. PRODUK / MECHANISM
**Ciri:** Explanation, how-it-works, product narrative, mechanism

**Contoh campaign:**
- "How GenLayer Reaches a Verdict"
- FUD-type campaigns
- Protocol explanation campaigns

**Apa yang juri PRAISE:**
- Mechanism clarity #1 (jelaskan cara kerja dengan jelas)
- Tactical value (reader belajar sesuatu yang actionable)
- Specific examples (bukan vague claims)
- Logic-driven structure

**Apa yang juri PENALIZE:**
- Vague claims ("revolutionary", "game-changing")
- No concrete example
- Missing mechanism explanation
- Pure hype without substance

**Fix flag risk: ✅ RENDAH**
- Fix flag relatif AMAN di genre ini
- Mechanism explanation itu robust — sentuh, masih jalan
- Tambah tactical value = help, bukan hurt

**EP sub-kriteria prioritas:**
1. Value delivery (tactical + intellectual)
2. Content structure (logic-driven)
3. Hook effectiveness (curiosity about mechanism)
4. @RallyOnChain integration
5. Authenticity / Feel
6. Conversation potential
7. CTA quality

---

### 4. DEBAT / OPINI
**Ciri:** Stance, argument, contrarian position, hot take

**Contoh campaign:**
- The Mic is Yours (pendapat)
- Controversial take campaigns

**Apa yang juri PRAISE:**
- Stance strength #1 (position yang clear dan bold)
- Contrarian angle (fresh, not mainstream)
- Argument structure (logis, bukan emotional)
- Intellectual value (makes reader think differently)

**Apa yang juri PENALIZE:**
- Weak/vague stance
- Following consensus (bukan debat, cuma agree)
- Logical fallacies
- Emotional without intellectual backing

**Fix flag risk: ⚠️ MODERATE**
- Logic fixes = AMAN
- Tone fixes = RISKY (stance tone itu delicate)
- Adding contrarian angle = usually helpful

**EP sub-kriteria prioritas:**
1. Hook effectiveness (contrarian/curiosity)
2. Value delivery (intellectual)
3. Content structure (argument-driven)
4. Conversation potential (high for controversial takes)
5. Authenticity / Feel (genuine conviction)
6. CTA quality
7. @RallyOnChain integration

---

## CARA MENDETEKSI GENRE

1. Baca campaign title + goal + style
2. Tanya: "Apa yang campaign ini minta? Emotional story, format execution, mechanism explanation, atau argument?"
3. Tanya: "Apa yang juri praise di pool? Cari pattern dari verdicts."
4. Kalau ambiguous, pilih genre DOMINAN. Bisa hybrid (Kreatif + Produk, dll).

**Insight default per genre:**

| Genre | Insight default | Kenapa |
|---|---|---|
| KREATIF | Reframe / Counterintuitive truth | 17/17 Orig 2/2 punya reframe spesifik. Format subversion (12/16) juga kuat. |
| DEBAT | Reframe pada perspektif argumen | Quiet conviction + philosophical flip = Orig 2/2 proven |
| PRODUCT | First-principles / Counterintuitive truth on user experience | IA gate aktif → reframe pada fakta produk berisiko. Reframe pada pengalaman user lebih aman. |
| KONFESIONAL | Story / Observation | 8/9 flag fixes berisiko. Reframe hanya pada makna pengalaman, bukan emosi itu sendiri. |

**⚠️ Kalau reframe bisa dilakukan, REFRAME. Kalau reframe merusak keaslian, gunakan bentuk lain.**

## HYBRID GENRE

Beberapa campaign hybrid:
- "The Twist Ending" = KREATIF + KONFESIONAL (story with twist + emotional payoff)
- "Fake News" = KREATIF + DEBAT (satire + commentary)

Untuk hybrid, prioritaskan genre PERTAMA (format/structure), lalu tambahkan elemen genre kedua.
