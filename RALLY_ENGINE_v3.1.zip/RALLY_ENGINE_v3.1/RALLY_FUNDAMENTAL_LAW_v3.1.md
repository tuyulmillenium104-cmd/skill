# ⚖️ RALLY FUNDAMENTAL LAW v3.1

**Core formula:** Campaign Ask × Rally Judge Desire

---

## STRUKTUR ENGINE

```
PHASE 1: GENERATE (Skill 00-12, 30)  → Bikin konten terbaik
PHASE 2: STRESS TEST (Skill 13-20, 28-29) → Uji konten sampai tahan
PHASE 3: Q&A (Skill 21-27)          → Reply pack RQ5-ready
```

---

## LAW 0: READ → INSIGHT → AMPLIFY → POLISH → PUBLISH

**The most fundamental law. All other laws assume this one is followed.**

1. **READ** — Pahami tujuan campaign, apa yang juri mau lihat, dan apa yang sudah sering ditulis orang lain.
2. **INSIGHT** — Temukan satu ide yang paling layak diingat. Default: cari REFRAME. Jika reframe merusak keaslian: gunakan story, observation, analogy, atau first-principles.
3. **AMPLIFY** — Buat insight terasa nyata dengan detail spesifik, angka, dialog, kontras, nama, adegan.
4. **POLISH** — Perkuat hook, flow, rhythm, pacing. Hilangkan yang mubazir.
5. **PUBLISH** — Checklist final.

**Prinsip:** Insight memimpin. Teknik mengikuti.

---

## LAW 1: DATA AS JUDGE, NOT WRITER

Winner data JUDGES content. It does NOT write content. (See Skill 30 for full policy)
- Use pool data to understand what judges want
- Do NOT use pool data to copy or template content
- Generate from insight, evaluate from data
- Drafting order: brief → thesis → fresh object → mechanism → CTA → THEN data judges
- Anti-copy test required before drafting

---

## LAW 2: GENRE AWARENESS

Different genres = different insight defaults.
- KONFESIONAL: Story/observation > reframe (reframe hanya pada makna)
- KREATIF: Reframe/counterintuitive truth > story
- PRODUCT: First-principles/counterintuitive truth > reframe pada pengalaman user
- DEBAT: Reframe pada perspektif argumen > agreeable take

---

## LAW 3: FLAG PARADOX

Flags show real problems. But fixing them can kill what's working.
- Minimal fix > comprehensive optimization
- One safe fix > five risky fixes
- EP 5 + Orig 1 > EP 4 + Orig 2
- In KONFESIONAL: 8/9 flag fixes are RISKY. Add name = only universal safe fix.

---

## LAW 4: THINK LIKE A JUDGE, NOT A FAN

Fans say "this is great!" Judges say "this is great, BUT..."
- Always find negatives (minimum 3 in Deduction Map)
- Always suggest improvements (minimum 1 per check)
- Never declare "none credible"

---

## LAW 5: ONE-SESSION / ONE-RUN

Max 3 candidates. Fail-fast. No patching. One iteration for flag fixes.

---

## LAW 6: LUCK IS REAL

12% of outcome is luck. Never claim "guaranteed." Always say "proven workflow" or "local strict PASS."

---

## LAW 7: WHAT JUDGES ACTUALLY EVALUATE (EP)

7 sub-kriteria EP:
1. Hook Effectiveness
2. Content Structure / Digestibility
3. CTA Quality
4. Conversation Potential
5. Value Delivery
6. @RallyOnChain Integration
7. Authenticity / Feel

---

## LAW 8: PROVEN OVER THEORETICAL

If data contradicts theory, trust data.
- Exponential/Apex theory: "I was embarrassed" = told not shown = cut
- Real judge data: "I was embarrassed" = creates believable human voice = praised
- Data wins. Always.

---

## LAW 9: REFRAME + AMPLIFIER = ORIG 2/2 (KREATIF)

In KREATIF genre:
- Reframe spesifik + Amplifier spesifik → Orig 2/2 (proven 17/17)
- Reframe = philosophical flip
- Amplifier = detail spesifik yang hanya kamu punya
- Each amplifier must PROVE the reframe

---

## LAW 10: THE OATH — READ SKILL BEFORE EXECUTE

**Setiap phase, AI WAJIB membaca skill file yang relevan SEBELU eksekusi.**

1. ✅ MEMBACA LAW ini dulu sebelum melakukan apapun
2. ✅ MEMBACA skill file sebelum menjalankan setiap phase
3. ✅ TIDAK BOLEH JALANKAN DARI MEMORY — baca skill file setiap kali
4. ✅ MEMBACA proven examples sebelum phase yang ada contohnya
5. ✅ AI MANUAL REVIEW — baca konten langsung, bukan JSON data saja
6. ✅ MEMBACA leakage policy sebelum generate Q&A
7. ✅ MEMBACA data-as-judge policy sebelum menggunakan winner data

**Pelanggaran = IMMEDIATE STOP & RESTART.** Lihat Skill 20 untuk enforcement detail.

---

## PHASE GATES

**Phase 1 → Phase 2:** Konten generated, skill files dibaca, data-as-judge policy followed
**Phase 2 → Phase 3:** ALL stress test gates PASS, known-gate absolute closure map complete
**Phase 3 → SUBMIT:** Q&A pack ready, final integrity PASS, leakage check PASS, user approve

---

## FORBIDDEN CLAIMS

- ❌ "guaranteed all-max"
- ❌ "guaranteed winner"
- ❌ "guaranteed top 1%"
- ❌ "guaranteed RQ5"
- ❌ "guaranteed EP5"

## ALLOWED CLAIMS

- ✅ "local strict PASS"
- ✅ "RQ5-ready"
- ✅ "Gold V3 PASS"
- ✅ "Known-Gate Absolute PASS"
- ✅ "proven workflow"
