# ⚠️ FLAG PARADOX RULES

**PARADOKS:** Flag menunjukkan masalah REAL (terbukti oleh Orig 1/2). Tapi fix flag BISA membunuh EP 5/5.

---

## DATA DARI TOAST (BUKTI NYATA)

### Juri PRAISE hal ini:
- "I was embarrassed" → **"admission of embarrassment creates believable human voice"**
- "Not a scam link. Not a phishing link." → **"specific, vivid mistake... fresh, funny, memorable"**
- "We toast the visionaries. The founders. The Architects." → **"emotionally effective"**
- "here's to the ones who stay" → **"near-perfect for engagement"**

### Protocol/Flag mau FIX hal ini:
- "I was embarrassed" → "told not shown, CUT" → ❌ KILL AUTHENTICITY
- "Not a scam link. Not a phishing link." → "dead line, CUT" → ❌ KILL VIVIDNESS
- "We toast the visionaries..." → "slogan-like, SIMPLIFY" → ❌ KILL CEREMONIAL BEAT
- "here's to the ones who stay" → "no mechanism bridge, REPLACE" → ❌ KILL TOAST VOICE

**SETIAP HAL YANG JURI PRAISE, FIX MAU HAPUS.**
**Ini terbukti: v2 (optimized by protocol) lebih datar dan kurang authentic.**

---

## RULES

### Rule 1: FLAG = INFORMASI, BUKAN PERINTAH
- Flag mengatakan "ada risk area di sini"
- Flag TIDAK mengatakan "fix ini sekarang"
- Kamu DECIDE berdasarkan genre + risk level

### Rule 2: GENRE DETERMINE FIX RISK

| Genre | Fix Risk | Strategy |
|---|---|---|
| **KONFESIONAL** | 🔴 TINGGI | Minimal fix. Hanya safe fixes. Jangan touch emotional beats. |
| **KREATIF/FORMAT** | ⚠️ MODERATE | Hook fix OK. Structure fix dengan hati-hati. Jangan kill humor. |
| **PRODUK** | ✅ RENDAH | Fix lebih agresif OK. Mechanism fixes aman. |
| **DEBAT/OPINI** | ⚠️ MODERATE | Logic fixes OK. Tone fixes risky. Jangan kill conviction. |

### Rule 3: SAFE vs RISKY vs HIGH RISK FIXES

**SAFE FIXES (hampir tidak pernah menurunkan EP):**
- ✅ Tambah nama — tidak mengubah voice, structure, atau emotion
- ✅ Fix typo/grammar — technical fix, tidak affect content
- ✅ Tambah @RallyOnChain kalau belum ada — compliance fix

**RISKY FIXES (BISA menurunkan EP):**
- ⚠️ Ubah CTA — emotional echo bisa hilang
- ⚠️ Simplify ending — ceremonial beat bisa hilang
- ⚠️ Tambah tactical value — bisa jadi preachy
- ⚠️ Break linear structure — bisa hurt digestibility
- ⚠️ Ganti "told not shown" ke "show" — bisa kill authenticity

**HIGH RISK FIXES (SERING menurunkan EP di genre konfesional):**
- 🔴 Hapus emotional beat karena "told not shown"
- 🔴 Hapus vivid clarification karena "dead line"
- 🔴 Simplify ceremonial ending karena "slogan-like"
- 🔴 Replace toast voice karena "no mechanism bridge"
- 🔴 Tambah mechanism bridge ke emotional piece

### Rule 4: SATU FIX PER TIME
Kalau kamu fix 1 hal, RE-REVIEW sebelum fix hal lain.
Jangan batch fix. Setiap fix bisa ada side effect.

### Rule 5: KALAU RAGU, JANGAN FIX
"Should I fix this?" → Kalau jawabannya bukan 100% yaman, jangan fix.
EP 5/5 dengan Orig 1/2 lebih baik daripada EP 4/5 dengan Orig 2/2.
EP menang. Orig nice-to-have.

---

## DECISION FRAMEWORK

```
Flag ditemukan
    ↓
Genre apa? → KONFESIONAL? → HATI-HATI. Minimal fix.
           → KREATIF?      → Hook fix OK, lainnya hati-hati.
           → PRODUK?        → Fix lebih agresif OK.
           → DEBAT?         → Logic fix OK, tone hati-hati.
    ↓
Fix termasuk kategori apa? → SAFE?  → Lakukan.
                            → RISKY? → Pertimbangkan. Re-review setelah.
                            → HIGH RISK? → JANGAN lakukan di konfesional.
    ↓
Setelah fix → Re-run EP Gate Review
            → EP masih PASS? → OK, fix berhasil.
            → EP turun? → REVERT fix.
```

---

## LESSON FROM v2 (THE TOAST)

v2 memperbaiki SEMUA flag:
- ✅ Tambah nama (Rizal) — AMAN
- ❌ Hapus "Not a scam link. Not a phishing link." — KILL VIVIDNESS
- ❌ Hapus "I was embarrassed" — KILL AUTHENTICITY
- ❌ Simplify "We toast the visionaries..." — KILL CEREMONIAL BEAT
- ❌ Replace "here's to the ones who stay" — KILL TOAST VOICE

1 dari 5 fix yang AMAN. 4 dari 5 fix yang KILL hal yang juri praise.

**Hasil: v2 lebih "optimized" tapi kurang authentic. Juri praise hal yang v2 hapus.**

**Jika v1 hanya ditambah nama (Rizal) tanpa fix lain:**
- EP tetap 5/5 (nama tidak mengubah engagement)
- Orig kemungkinan 2/2 (setiap Orig 2/2 winner punya nama)
- CA, CC tetap 2/2

**Ini kemungkinan OUTCOME TERBAIK dengan RISIKO TERENDAH.**
