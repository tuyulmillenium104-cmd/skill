# ⚡ RALLY QUICK START v3.1

**3 Phase, 55 menit dari nol ke submit**

---

## PHASE 1: GENERATE (~25 min)

### 1. READ (1 min)
Baca campaign brief. Jawab:
- Apa tujuan campaign?
- Apa yang juri mau lihat?
- Genre apa? (KREATIF/DEBAT/PRODUCT/KONFESIONAL)

### 2. INSIGHT (5 min)
Tanya: **"Jika pembaca hanya mengingat satu kalimat, kalimat apa?"**

| Genre | Insight default |
|---|---|
| KREATIF | Reframe / Counterintuitive truth |
| DEBAT | Reframe pada perspektif argumen |
| PRODUCT | First-principles / Counterintuitive truth |
| KONFESIONAL | Story / Observation |

### 3. AMPLIFY (3 min)
Tambahkan detail spesifik yang MEMBUKTIKAN insight:
- Angka, dialog, kontras, nama, adegan
- Setiap detail harus PROVE insight

### 4. POLISH (2 min)
- Hook = insight muncul sejak awal?
- Kill criterion: "Kalau dihapus tidak lebih lemah → hapus"
- CTA ties back ke insight

### 5. GENERATE (14 min)
- Max 3 candidates, fail-fast
- Data fetch (Skill 01, 10)
- Source truth (Skill 02)
- Fresh surface (Skill 03)
- Thesis (Skill 04, 12)
- Write (Skill 05, 11)
- EP Gate quick check (Skill 06, 07)

---

## PHASE 2: STRESS TEST (~20 min)

### 6. TASTE DIRECTOR (5 min) ★
Review dari 7 persona:
- Normal Reader
- Skeptical Judge
- Non-Expert
- Crypto-Native
- Human Voice Editor
- Brand/Accuracy Editor
- Competitor Comparison

**Ada persona yang menemukan credible issue? → Fix dulu.**

### 7. HOSTILE ATTACK (5 min) ★
Tulis 10 "strong, but..." attacks:
- Minimal 3 fair deductions
- Per deduction: fix suggestion + risk level

### 8. DATA MINING (5 min)
- Hidden gates (Skill 15) — what can deduct?
- Winner pulls (Skill 16) — what gets praised?

### 9. FIX + ITERATE (5 min)
- Fix SAFE issues only
- Re-test after each fix
- Max 3 iterations
- FLAG RISKY issues, don't fix

---

## PHASE 3: Q&A (~10 min)

### 10. GENERATE PACK (5 min)
- 20 pairs: 4SP/5CH/5TD/4HT/2RE
- Q-COPY 160-260 chars, A-COPY ≤280 chars
- **BACA PROVEN EXAMPLE DULU**

### 11. REVIEW (3 min)
- Type distribution check
- Voice diversity check
- Formula shell check
- Per-pair quality (Q/A/Feel ≥4)

### 12. FINAL INTEGRITY (2 min)
- Content = content
- Reports current
- All gates PASS
- **SUBMIT**

---

## PRINSIP

**Insight memimpin. Teknik mengikuti.**

Jangan mulai: "Hari ini mau pakai reframe."
Mulailah: "Apa ide paling menarik yang layak diingat?"

---

## THE OATH

**Baca skill file DULU sebelum execute. Jangan jalan dari memory.**
