# 📋 PROOF AND LESSONS — Data dari Juri Asli

**Sumber:** Verdict juri Rally sungguhan untuk The Toast campaign
**Tanggal:** 2026-07-19

---

## SKOR KONTEN v1 (JURI ASLI)

| Kategori | Skor |
|---|---|
| Engagement Potential | **5/5** |
| Originality & Authenticity | **1/2** |
| Content Alignment | **2/2** |
| Campaign Compliance | **2/2** |

---

## APA YANG JURI PRAISE (KUTIPAN LANGSUNG)

1. "The specific, vivid mistake of accidentally sending a screen time report instead of project docs"
2. "That concrete setup feels fresh, funny, and memorable"
3. "The self-incriminating detail about spending six hours on X, the quoted response, and the admission of embarrassment"
4. "Creates a believable, human voice"
5. "Reads like an actual lived moment"
6. "The opening lines are especially strong and believable"
7. "Provides emotional value"
8. "The mention of @RallyOnChain is organic and fits the mission"

## APA YANG JURI KRITIK (KUTIPAN LANGSUNG)

1. "Overall arc overlaps with several similar campaign entries"
2. "The final paragraph shifts into a more universal, slogan-like register that feels slightly optimized"
3. "Follows a recognizable campaign-friendly formula: anecdote, lesson, broadened reflection, brand mention, engagement question"
4. "Not so structurally or conceptually novel that it reaches the highest tier"

---

## APA YANG JURI PRAISE DI WINNER LAIN (Orig 2/2)

### @chainops1_ — Orig 2/2:
- NAMA: "Marco" (neighbor)
- OBJEK UNEXPECTED: "terrible paella", "wet socks and sadness"
- DIALOG WISDOM: "I make this every day. It's terrible. But I'm still here."
- REFRAME: "losing was just showing up to work the next day"
- NON-CRYPTO setting

### @alver1301 — Orig 2/2:
- TWIST: enemy → protector
- CONFLICT → resolution (accusation → gratitude)
- PUNCH LINES: "I deleted my comment. That wasn't an apology."
- NON-LINEAR structure (start from accusation)

### @str_kerx — Orig 2/2:
- HERO UNEXPECTED: a CAT (Hallie)
- VISCERAL SCENE: "almost broke down my own door at 4:30am"
- HUMOR: "like this was just another shift and I was the useless intern"
- PUNCH LINE: "I didn't need a locksmith. I needed my cat."

### @sameddy01 — Orig 2/2:
- NAMA: "Maya"
- DETAIL TENTANG ORANG: "200 followers", "zero budget", "three nights"
- HONEST FAILURE: "broke", "comic no one wanted", "only sold 40 copies"
- REFRAME: "She turned doubt into something you could hold"
- SUCCESS TIDAK DATANG: "still only sold 40 copies" = meaning changed, not outcome

### @navtq0808 — Orig 2/2:
- TOAST ke BENDA (wallet), bukan orang
- TANGIBLE OBJECT sebagai metaphor
- CONFRONTATION: "You were wrong" (to self)
- REFRAME: "ugly first version" = proof, not failure

---

## PATTERN DARI WINNER YANG DAPAT ORIG 2/2

Setiap Orig 2/2 winner punya MINIMAL SATU dari:
1. ✅ NAMA spesifik (Marco, 1By1, Hallie, Maya)
2. ✅ TWIST/SUBVERSION (enemy→protector, cat→hero, wallet→toast)
3. ✅ REFRAME (losing = showing up, doubt = something to hold, ugly = proof)
4. ✅ NON-LINEAR structure
5. ✅ NON-CRYPTO setting / unexpected context

Konten v1 kita punya 0 dari 5.

---

## JURI EP SUB-KRITERIA (DIEKSTRAK DARI 8 VERDICTS)

Juri konsisten evaluasi 7 sub-kriteria di setiap EP verdict:

| # | Sub-kriteria | Frekuensi |
|---|---|---|
| 1 | Hook Effectiveness | 8/8 |
| 2 | Content Structure / Digestibility | 8/8 |
| 3 | CTA Quality | 8/8 |
| 4 | Conversation Potential | 8/8 |
| 5 | Value Delivery | 8/8 |
| 6 | @RallyOnChain Integration | 8/8 |
| 7 | Authenticity / Feel | 7/8 |

---

## EP 4/5 CAUSES (DARI DATA)

1. CTA weak/soft/implicit (bukan direct invitation)
2. Too long (completion risk)
3. Hook could be stronger
4. Generic content

---

## PARADOKS FLAG: DATA DARI TOAST

| Flag | Fix | Hasil Fix | Juri Praise Yang Hilang |
|---|---|---|---|
| "I was embarrassed" = told not shown | CUT | v2 hilang | "admission of embarrassment creates believable human voice" |
| "Not a scam link. Not a phishing link." = dead line | CUT | v2 hilang | "specific, vivid mistake... fresh, funny, memorable" |
| "We toast the visionaries..." = slogan-like | SIMPLIFY | v2 datar | "emotionally effective" |
| "here's to the ones who stay" = no mechanism | REPLACE | v2 jadi argument | "near-perfect for engagement" |

**Setiap fix menghilangkan hal yang juri praise. Hanya 1 fix yang aman: tambah nama.**

---

## LUCK vs PROCESS

| Stage | Luck | Process |
|---|---|---|
| Before data | 60% | 40% |
| After pool analysis | 32% | 68% |
| After luck→process conversion | 12% | 88% |

Remaining 12% luck factors:
- Submissions after ours
- Other people's reply quality
- AI judge randomness
- Creative spark variance

---

## FORMULA EVOLUTION

1. **v2.6:** BACA → HAYATI → TULIS — vague, tidak bisa explain Orig 1/2
2. **v2.7a:** BACA → HAYATI → RESAPI → TULIS — mistis, susah dioperasionalkan
3. **v2.7:** BACA → JADI PEMBACA → TULIS — lebih baik, "jadi pembaca" = desire + avoidance
4. **v2.8:** BACA → TEMUKAN REFRAME → AMPLIFY → TULIS — data-driven, explains all Orig 2/2 cases
5. **v3.0:** READ → INSIGHT → AMPLIFY → POLISH → PUBLISH — final, each step has input→process→output + self-check question

**Kenapa v3.0 lebih baik:**
- Setiap step punya OUTPUT yang jelas (masalah → insight → insight yang hidup → tulisan yang tajam → published)
- Setiap step punya SELF-CHECK question
- "Jadi pembaca" diserap ke dalam READ (pahami apa yang juri mau + apa yang sudah sering ditulis)
- "Kenali jalan / cari jalan" diserap ke dalam INSIGHT (cari reframe = cari jalan sendiri)
- AMPLIFY jadi step eksplisit, bukan bagian dari tulis
- POLISH terpisah — baru fokus cara menulis SETELAH insight dan amplifier jelas
- Prinsip "insight memimpin, teknik mengikuti" mencegah copycat trap

---

## CONFIRMATION BIAS CONFESSION

Saya (AI) bilang "v1 lebih disukai juri" SEBELUM ada evidence. 
Ketika data datang dan mendukung, saya pakai sebagai "bukti."
Itu konfirmasi bias. Kebetulan benar ≠ analisis benar.

**Lesson:** Selalu distinguish OPINI dari FAKTA. "Saya lebih suka v1" = opini. "Juri kasih EP 5/5" = fakta.

---

## REFRAME + AMPLIFIER DISCOVERY

**Ditemukan:** 2026-07-20, dari analisis 17 Orig 2/2 winners

**Pola:** Setiap Orig 2/2 winner punya REFRAME spesifik + AMPLIFIER spesifik.
- Reframe = philosophical flip (membalik asumsi, bukan sekadar ganti POV)
- Amplifier = detail spesifik yang hanya mereka punya (angka, dialog, nama, adegan, kontras)

**3 level:**
1. Reframe spesifik + Amplifier spesifik → Orig 2/2 (17/17 winners)
2. Reframe umum + Amplifier umum → Orig 1/2 (@muktaryaks "creators are free labor")
3. Tanpa reframe → Orig 1/2 (v1 Toast: observasi saja, v4 Wikipedia: detail tanpa flip)

**Bukti langsung:**
- v1 Toast: NO reframe ("person helped → gratitude") → Orig 1/2
- v5 Wikipedia: REFRAME ("slow internet = best audit") → prediksi Orig 2/2
- v6 Wikipedia: REFRAME ("your real page is the Talk page") + FORMAT SUBVERSION → prediksi Orig 2/2 lebih kuat

**Filosofi:** "Philosophical Reframe = DRIVER, Metaphor/Detail = AMPLIFIER" — insight dari user

---

## FORMAT SUBVERSION DATA

**Dari Wikipedia campaign:** 12/16 Orig 2/2 winners SUBVERT the format.
- Bukan sekadar mengisi template Wikipedia — mereka membalik atau menghindari template
- Contoh: @alver1301 → deletion page, @miftahudinsd9 → unpublished drafts, v6 → Talk Page
- Tapi: standard format + highly specific content MASIH bisa Orig 2/2 (@paul_0x1, @jeff__dan)
- Artinya: format subversion membantu tapi BUKAN syarat. REFRAME + AMPLIFIER = syarat.

---

## COPYCAT TRAP LESSON

**v3 Wikipedia = PENIRU @alver1301**

v3 menggunakan format "deletion dispute" yang SAMA dengan @alver1301.
User menangkap: "kamu peniru."

**Kenapa ini terjadi:** Mulai dari TEKNIK ("saya mau pakai format deletion"), bukan dari INSIGHT ("apa ide yang layak diingat?").

**v6 berhasil karena:** Insight dulu ("your real page is the Talk page") → format mengikuti (Talk Page format muncul secara natural dari insight itu sendiri).

**Prinsip:** Insight memimpin. Teknik mengikuti. Jangan mulai dari teknik.
