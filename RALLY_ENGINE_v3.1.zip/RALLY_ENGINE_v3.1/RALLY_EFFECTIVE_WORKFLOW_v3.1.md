# 🔄 RALLY EFFECTIVE WORKFLOW v3.1

**3 Phase, 26 Skills**
**Proven:** The Toast EP 5/5 (verified by real judge), 17 Orig 2/2 winners analyzed

---

## WORKFLOW OVERVIEW

```
PHASE 1: GENERATE (Skill 00-11)   ~25 min
  → Konten jadi

PHASE 2: STRESS TEST (Skill 12-20) ~20 min
  → Konten tahan uji

PHASE 3: Q&A (Skill 21-26)         ~10 min
  → Reply pack RQ5-ready
```

---

## PHASE 1: GENERATE

### Skill 00: Content Thinking Framework ★ PALING FUNDAMENTAL
READ → INSIGHT → AMPLIFY → POLISH → PUBLISH
- Insight memimpin. Teknik mengikuti.
- Kalau tidak bisa jawab "kalimat apa yang layak diingat?" → jangan lanjut

### Skill 01: Foundation
- Fetch campaign data, submissions, winner content
- Extract score distributions
- Detect genre

### Skill 02: Source Truth
- Extract what judges PRAISE
- Extract what judges PENALIZE
- Identify hidden patterns

### Skill 03: Fresh Surface Map
- List crowded surfaces (AVOID)
- List fresh surfaces (3-4 options)
- Choose best surface

### Skill 04: Original Thesis
- Wrong Assumption → Human Problem → REFRAME → Thesis → AMPLIFIER → CTA
- Thesis dari DALAM insight, bukan dari LUAR

### Skill 05: Generate
- Max 3 candidates, fail-fast
- Insight first, then amplify
- Kill criterion: "Kalau dihapus tidak lebih lemah → hapus"

### Skill 06: EP Gate Review
- 3 checks × 7 steps
- Compactness, Semantic, Deduction Map

### Skill 07: Rigid Gates
- Binary compliance: all pass or fix required

### Skill 08: Q&A Engine (placeholder — actual Q&A di Phase 3)
- Basic Q&A awareness

### Skill 09: One-Session/One-Run
- Max 3 candidates, fail-fast, no patching

### Skill 10: Data Collector API
- Rally API reference

### Skill 11: Amplify Techniques
- 7 data-driven techniques (detail, angka, dialog, kontras, nama, adegan, metafora)

### Skill 12: Reframe+Amplifier Pattern
- 17 Orig 2/2 winner patterns
- REFRAME = DRIVER, AMPLIFIER = AMPLIFIER

**Output Phase 1:** 1 candidate konten ready untuk stress test

---

## PHASE 2: STRESS TEST

### Skill 13: Taste Director ★ CRITICAL
- 7 persona review (Normal Reader, Skeptical Judge, Non-Expert, Crypto-Native, Human Voice Editor, Brand/Accuracy Editor, Competitor Comparison)
- Draft TIDAK boleh final jika ADA persona yang menemukan credible issue

### Skill 14: Hostile Judge Attack ★ CRITICAL
- 10-attack test (Strong but..., Clear but..., dll)
- Minimal 3 fair deductions
- Jangan bilang "none credible"

### Skill 15: Hidden-Gate Mining
- Mine judge deduction patterns dari verdicts
- Scope: GLOBAL/CAMPAIGN_FAMILY/CAMPAIGN_ONLY/MISSION_ONLY/WATCH/REJECT
- Default: MISSION_ONLY

### Skill 16: Winner-Pull Mining
- Mine what judges PRAISE dari winners
- Extract mechanisms, bukan copy phrases
- Winner-pull contract: expected positive verdict lines

### Skill 17: Step Conflict Check
- Cross-step conflict detection
- Kalau konflik → STOP dan resolve

### Skill 18: Feedback + Iteration
- Collect feedback dari semua stress tests
- Categorize: SAFE / RISKY / HIGH RISK
- Fix ONE at a time, re-test after each
- Max 3 iterations

### Skill 19: Flag Paradox
- Flags = real problems, but fixing can kill
- Genre-specific rules (KONFESIONAL: SAFE only)
- "FLAG, don't FIX" untuk RISKY+

### Skill 20: The Oath + Zero Tolerance ★ ENFORCEMENT
- MEMBACA SKILL DULU sebelum execute
- 12 zero-tolerance violations
- Phase gates: Phase 1→2→3→Submit

**Output Phase 2:** Konten yang lulus semua stress test, SUBMIT READY

---

## PHASE 3: Q&A

### Skill 21: Q&A Engine V3.1.3 Gold ★ CORE
- 20 Q-COPY/A-COPY pairs
- Type: 4SP/5CH/5TD/4HT/2RE
- Tier: S=9, A=7, B=4, C=0
- **BACA PROVEN EXAMPLE DULU sebelum generate**

### Skill 22: Gold RQ Standard
- Evidence hierarchy
- Pack-level Q controls
- Voice diversity controls

### Skill 23: Q&A AI Review
- Type distribution, voice diversity, formula shell
- Per-pair quality (Q/A/Feel ≥4)
- Length checks, coverage checks

### Skill 24: Human Typed Copy
- Anti-engineered text check
- No label shells, no audit voice
- Imperfect rhythm is OK

### Skill 25: Final Integrity
- Content = content
- combined.md = current
- Reports are current, not stale
- No stale pass shipped

### Skill 26: Submit Checklist
- All phases complete
- All gates PASS
- User approve
- GO / NO-GO decision

**Output Phase 3:** Q&A pack RQ5-ready + submission ready

---

## TIMING

| Phase | Time |
|---|---|
| Phase 1: GENERATE | ~25 min |
| Phase 2: STRESS TEST | ~20 min |
| Phase 3: Q&A | ~10 min |
| **Total** | **~55 min** |

---

## DECISION FLOW

```
Phase 1 Generate
  └─ Konten jadi? → Phase 2

Phase 2 Stress Test
  ├─ EP Gate FAIL → REGENERATE (max 1x, different angle)
  ├─ EP Gate FAIL again → SWITCH CAMPAIGN
  ├─ PASS with flags → Fix SAFE only, re-test
  ├─ Taste Director FAIL → REWRITE or REBUILD
  ├─ Hostile Judge >6 fair deductions → NEEDS REVIEW
  └─ ALL PASS → Phase 3

Phase 3 Q&A
  ├─ Q&A AI Review FAIL → Fix specific pairs, re-review
  ├─ Human Typed Copy FAIL → Rewrite engineered pairs
  ├─ Final Integrity FAIL → Rerun stale reports
  └─ ALL PASS + User Approve → SUBMIT
```

---

## FORBIDDEN

- ❌ Skip stress test
- ❌ Skip Taste Director
- ❌ Lanjut ke Q&A sebelum konten PASS stress test
- ❌ Run dari memory tanpa baca skill file
- ❌ Copy winner surface tanpa transform
- ❌ Fix RISKY flags in KONFESIONAL
- ❌ Ship stale pass
- ❌ Claim "guaranteed"
