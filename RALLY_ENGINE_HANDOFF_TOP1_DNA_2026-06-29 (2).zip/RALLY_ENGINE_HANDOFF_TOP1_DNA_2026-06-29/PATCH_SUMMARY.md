# Patch Summary

This bundle includes latest post-verdict fixes.

## New/important tools

- `rally-winner-build-spec.py`
- `rally-pre-draft-risk-contract.py`
- `rally-tactical-value-check.py`
- `rally-originality-saturation-check.py`
- `rally-ep-compactness-check.py`
- `rally-rq-prompt-answer-check.py`
- `rally-rq-mechanics-calibration-check.py`
- `rally-worst-positive-verdict-check.py`

## Real verdict misses fixed

1. EP4 because content was more philosophical than tactical.
2. OAA1 because wording was unique but core motif was saturated.
3. EP4 because long/literary content made users admire more than reply.
4. RQ3 because replies validated the post but did not answer the actual CTA.
5. Consistency issue: Winner DNA and Judge/Loser DNA must become hard blockers, not loose references.
6. Preventive issue: fresh campaign data must become a pre-draft risk contract before writing.

## New blockers

- No Winner Build Spec = no draft.
- No Pre-Draft Risk Contract = no draft.
- Tactical Value not PASS = no EP5 claim.
- Originality Saturation not PASS = rebuild angle.
- EP Compactness not PASS = compress/rebuild.
- RQ Prompt-Answer not PASS = rewrite Q&A pack.
- Worst Positive Verdict not PASS = fix or rebuild.

## Core rule

```text
Fresh data -> Pre-draft contract -> Build plan -> Draft -> Stress test.
Do not submit strong content. Submit hard-to-deduct content.
```

## Latest RQ update

Protocol/product campaign Q&A must now pass RQ mechanics calibration: every Q-COPY should include explicit decision + campaign mechanic + personal/skeptical angle.
