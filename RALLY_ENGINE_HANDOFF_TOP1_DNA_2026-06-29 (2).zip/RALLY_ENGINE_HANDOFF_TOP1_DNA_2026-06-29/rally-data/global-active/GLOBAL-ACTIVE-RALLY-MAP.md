# GLOBAL ACTIVE RALLY MAP

Generated: 2026-06-25 15:47:05

Active campaigns mined: **24**

## Campaigns
- Wingston NFT Utility `0x0c9507E764C4Af84fe292F4034B17FFC363D15D9` end=2026-06-26T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=692
- Get your Wingston WL `0x4a179Ef935B10Fc86177c6D71C7b13F53cf52C2A` end=2026-06-29T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=688
- Stake & Earn RLPs `0x77e0340948D6803DF7c35418f0B713010c2A7b33` end=2026-06-30T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=467
- Who is Wingston? `0x43636110FFd62CB3590C4886b4928EB314D1Cc0e` end=2026-06-30T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=472
- Alpha Stories `0xEA974798b85dCA4b8470a1faEc268e8E31D39238` end=2026-07-01T22:00:00.000Z missions=[] submissions=0
- Break The Silence `0xeFE8b18846dcB48B571aBa394ec2c8082538A080` end=2026-07-01T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=483
- The DM You Never Sent `0x78EbadBB76441D31949A44d15909d5a3ea33e7fA` end=2026-07-01T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=414
- What's GenLayer? `0x797E72FAb8733E8e794cAAae31dC85A39E113B8a` end=2026-07-02T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=900
- Wingston VIP Community `0x2267D442FC1C66532d416f20a4EB863ecE3cB900` end=2026-07-02T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=551
- Why RLPs Matter `0xA668a0306DF96d41e2f5167C23b26E14Ad6B7D98` end=2026-07-03T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=900
- Reputation `0xf2f3438d22283D278bC33EA7959429B877cb808f` end=2026-07-03T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=900
- The Founder Mode `0x7c4045C8E8B2E0B0b417d4f694639c56b4dc3F13` end=2026-07-04T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=186
- The Verdict `0xaEfa48a9eEe30d04630463Cf185A01B0A19b35c1` end=2026-07-04T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=97
- Bring Back NFTs `0x010ec31e5894E65a6f52aE121d57Ff79BAc9FF89` end=2026-07-07T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=264
- The Trade Off `0x2949F1E1029f36dD665A6f4898320407E81CE75e` end=2026-07-07T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=45
- The Glass Half `0xF4b51e0CCfbCf7f7dE65108eceDDa70a087C2655` end=2026-07-07T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=32
- The Translation `0x9dC8829235E37EBcDa58996c891c1Da9C53Feee4` end=2026-07-07T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=27
- The Dead Wallet `0x3f39fddaC3b1b49bdAEe53fef2d1d028c9f4A7B7` end=2026-07-07T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=34
- The Memoir `0xb1AE8ec12aa396807cfC1dED839C52C10089DEb7` end=2026-07-08T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=43
- The Apology `0x5ee21727Adf112b090Df09B1dA54d9CE381785E5` end=2026-07-08T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=17
- The Brand Accelerator `0x75AEe6668669d8adF4016213BD0d514A2d4Efa7D` end=2026-07-09T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=25
- The Accelerator of Creators `0x70DC2884DFF409b70170e31F240D599f871682Db` end=2026-07-09T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=23
- Final Boss `0x15537e782D3eAb0cce2cdf7Bd042DdFefbD483E0` end=2026-07-10T22:00:00.000Z missions=['mission-0', 'mission-1'] submissions=9
- Underrated `0x9D5333C8206FdEc5004D98cFcc26a7360DD5ebd1` end=2026-07-10T22:00:00.000Z missions=['mission-1', 'mission-0'] submissions=6

## Global Gate Class Counts

### EP
- conversation_limited: 15070
- cta_weak: 11681
- compliance_issue: 5484
- value_not_exceptional: 5258
- hook_weak: 4488
- structure_density: 4278
- brand_promotional: 2901
- media_issue: 2766
- unknown_candidate: 2103
- generic_formulaic: 1917
- specificity_missing: 1851
- authenticity_polish: 719
- rq_generic: 158
- claim_accuracy: 36

### OAA
- unknown_candidate: 8314
- generic_formulaic: 7207
- compliance_issue: 4193
- brand_promotional: 2946
- structure_density: 2474
- authenticity_polish: 2331
- specificity_missing: 1974
- conversation_limited: 1771
- rq_generic: 1615
- value_not_exceptional: 1455
- cta_weak: 1420
- hook_weak: 846
- media_issue: 414
- claim_accuracy: 31

### TQ
- compliance_issue: 4632
- media_issue: 4344
- structure_density: 3811
- unknown_candidate: 3356
- brand_promotional: 2534
- value_not_exceptional: 2417
- cta_weak: 1456
- generic_formulaic: 1221
- authenticity_polish: 1026
- conversation_limited: 602
- hook_weak: 515
- specificity_missing: 482
- claim_accuracy: 100
- rq_generic: 46

### IA
- compliance_issue: 1076
- unknown_candidate: 925
- specificity_missing: 644
- brand_promotional: 483
- claim_accuracy: 472
- cta_weak: 431
- generic_formulaic: 175
- media_issue: 170
- value_not_exceptional: 79
- structure_density: 71
- rq_generic: 63
- conversation_limited: 41
- hook_weak: 4
- authenticity_polish: 4

### CA
- compliance_issue: 1972
- brand_promotional: 1083
- cta_weak: 876
- unknown_candidate: 852
- specificity_missing: 827
- generic_formulaic: 432
- media_issue: 283
- value_not_exceptional: 281
- structure_density: 90
- conversation_limited: 69
- claim_accuracy: 60
- authenticity_polish: 45
- rq_generic: 38
- hook_weak: 18

### CC
- compliance_issue: 3796
- brand_promotional: 1625
- cta_weak: 1509
- generic_formulaic: 1177
- unknown_candidate: 1099
- specificity_missing: 838
- media_issue: 691
- structure_density: 465
- conversation_limited: 370
- value_not_exceptional: 291
- authenticity_polish: 149
- rq_generic: 52
- hook_weak: 22
- claim_accuracy: 20

### RQ
- rq_generic: 15478
- conversation_limited: 14248
- cta_weak: 5793
- generic_formulaic: 5494
- specificity_missing: 5273
- unknown_candidate: 4509
- authenticity_polish: 2236
- compliance_issue: 1798
- brand_promotional: 1329
- value_not_exceptional: 826
- media_issue: 276
- structure_density: 260
- claim_accuracy: 70
- hook_weak: 34

## Unknown Candidate Samples

### EP
- Wingston NFT Utility / mission-0: The content aligns perfectly with the campaign goal of explaining utility while maintaining an authentic, enthusiast voice.
- Wingston NFT Utility / mission-0: The call to action is present but soft.
- Wingston NFT Utility / mission-0: The tweet successfully explains Wingston's utilities (daily RLP staking, VIP access, Rally Score boost) while connecting them to a deeper insight about creator psychology.
- Wingston NFT Utility / mission-0: The personal story occasionally risks overshadowing the product message, but the transition back to Wingston is handled well.
- Wingston NFT Utility / mission-0: While it invites interest from current Rally users, it could do more to bridge the gap for new creators to join the platform.
- Wingston NFT Utility / mission-1: The tweet aligns closely with campaign goals by introducing the NFT and encouraging creators to join Rally, while maintaining an authentic tone.
- Wingston NFT Utility / mission-1: It successfully balances the campaign goals by explaining the Wingston NFT utility while providing a clear onboarding path for new users.
- Wingston NFT Utility / mission-1: while it fulfills the mission, it lacks a high-impact narrative or a sense of urgency that could drive viral sharing.
- Wingston NFT Utility / mission-1: The call to action is present but somewhat soft.
- Wingston NFT Utility / mission-1: The tweet is competent and authentic but misses opportunities to drive stronger interaction.

### OAA
- Wingston NFT Utility / mission-0: However, the framing is very close to the campaign brief and overlaps heavily with the provided similar tweets.
- Wingston NFT Utility / mission-0: Unique perspective: moderate at best.
- Wingston NFT Utility / mission-0: Zero excuses not to grab it." is punchy, but it echoes the same core thesis found in the similar tweets: free mint + utility + creator benefit.
- Wingston NFT Utility / mission-0: Content distinctiveness: low to moderate.
- Wingston NFT Utility / mission-0: Let it work for you." are clean and readable, but they feel marketing-friendly rather than spontaneous.
- Wingston NFT Utility / mission-1: The voice is personal but not deeply distinctive.
- Wingston NFT Utility / mission-1: While it has some authentic personal perspective, it doesn't rise to exceptional originality as it shares significant structural and thematic overlap with other campaign participants' content.
- Wingston NFT Utility / mission-1: On unique perspective, it is decent but not especially fresh.
- Wingston NFT Utility / mission-1: Those are clear campaign points, but not creatively reinterpreted.
- Wingston NFT Utility / mission-1: The copy feels like a competent campaign post more than a uniquely authored voice.

### TQ
- Wingston NFT Utility / mission-0: The follow-up tweets are understandable and mostly error-free, but there are some sentence-level mechanical weaknesses.
- Wingston NFT Utility / mission-0: These are meaningful but not severe flaws.
- Wingston NFT Utility / mission-0: Thread composition is adequate but not especially strong.
- Wingston NFT Utility / mission-0: So while the thread is correctly formed, it is not maximally effective as a composed multi-tweet sequence.
- Wingston NFT Utility / mission-0: Thread composition is minimal, so there is no multi-post thread logic to assess, but as a standalone quote tweet it is coherent and the connection to the official Rally post is clear.
- Wingston NFT Utility / mission-1: Thread composition is not really applicable because this is a single-tweet post rather than a multi-tweet thread, but as a standalone quote tweet it is structurally complete and self-contained.
- Wingston NFT Utility / mission-1: The tweet demonstrates strong technical execution with some minor issues.
- Wingston NFT Utility / mission-1: Language mechanics are generally good, but there is a double space error in 'post on X  this one’s' and a grammatical phrasing issue in 'Why right now is the perfect moment to join?' which would better be 'Why is right now...'.
- Wingston NFT Utility / mission-1: The tweet thread demonstrates strong technical execution with some minor issues.
- Wingston NFT Utility / mission-1: Language mechanics are generally correct with minor informal stylization appropriate for the platform.

### IA
- Wingston NFT Utility / mission-0: However, there are minor technical imprecisions: the tweet suggests holding alone earns RLPs when actually active staking is required, and the three utilities are presented somewhat independently when two of them (score boost and VIP access) are both described as features of the NFT rather than sepa
- Wingston NFT Utility / mission-0: Despite these minor framing issues, the core factual claims about the NFT's utilities and functionality are accurate and aligned with official documentation.
- Wingston NFT Utility / mission-0: However, most other claims are well-aligned with the knowledge base.
- Wingston NFT Utility / mission-0: Overall, the content is mostly accurate and campaign-aligned, with a minor concern around the exact mint availability wording.
- Wingston NFT Utility / mission-0: But the omission/simplification of whitelist conditions and the stronger-than-documented implication about RLP covering task costs prevent a perfect score.
- Wingston NFT Utility / mission-1: This matches the knowledge base language: 'Stake your NFT to earn RLPs every day' and 'The NFT automatically boosts your Rally Score.' The statement that this gives users more influence/'话语权' is a mild interpretive framing, but it is directionally aligned with Rally Score influencing rewards and acc
- Wingston NFT Utility / mission-1: This is the main factual issue.
- Wingston NFT Utility / mission-1: The statement that whitelist access is not based on wallet size but on actual participation is consistent with the campaign's emphasis on rewarding engaged community members, though it simplifies the full criteria.
- Wingston NFT Utility / mission-1: However, the tweet includes a personal claim about having already tried staking and receiving daily RLP.
- Wingston NFT Utility / mission-1: While this is plausible and aligned with utility docs, it is not independently verifiable from the provided materials.

### CA
- Wingston NFT Utility / mission-0: Overall acceptable but not fully exceptional due to these gaps.
- Wingston NFT Utility / mission-0: The character count (255) and word count (42) are within acceptable range.
- Wingston NFT Utility / mission-0: Minor misalignment: slightly over-indexed on philosophical reflection vs.
- Wingston NFT Utility / mission-0: The overall messaging is authentic and engaging, but the ROI language is a notable deviation from campaign guidelines that prevents a higher score.
- Wingston NFT Utility / mission-0: Overall alignment is acceptable on core elements but incomplete per strict criteria.
- Wingston NFT Utility / mission-1: The tweet is broadly aligned with the Wingston NFT Utility campaign, but it is not a perfect fit.
- Wingston NFT Utility / mission-1: However, the core campaign framing is only partially complete.
- Wingston NFT Utility / mission-1: The value proposition is present, but not fully centered on Wingston as a product NFT with stake in the Rally ecosystem.
- Wingston NFT Utility / mission-1: The tweet accurately describes Rally's core mechanics (discover missions, share thoughts, verification, onchain rewards) and correctly highlights Wingston NFT benefits including the free mint, VIP Community access, and Rally Score boost.
- Wingston NFT Utility / mission-1: However, there are notable gaps: the tweet omits the staking utility and RLP earnings, which is a key value proposition in the knowledge base.

### CC
- Wingston NFT Utility / mission-0: This makes it acceptable but not fully exceptional.
- Wingston NFT Utility / mission-0: Main issue: the programmatic checks state "Do not make any promises about price, value, or return on investment (ROI): VIOLATED." The tweet says "The utility is what makes it worth keeping" and "higher reward campaigns begin," which could be interpreted as value/return framing, even if not a direct 
- Wingston NFT Utility / mission-0: Overall: partially compliant, but not fully aligned with the campaign mission, so this scores a 1.
- Wingston NFT Utility / mission-0: Given the technical adherence but the borderline language regarding 'real benefits' and 'active assets', it receives a 1.
- Wingston NFT Utility / mission-0: The text says "As announced by Rally:" and includes quoted text, but that is not the same as actually quote-tweeting the official announcement.
- Wingston NFT Utility / mission-1: Additionally, the content touches on 'earning potential' but frames it as 'potential to earn' and 'turning influence into a tangible asset', which avoids prohibited financial guarantees.
- Wingston NFT Utility / mission-1: The character count (842) and word count (118) from 'tweet_subtype' are within acceptable limits for a longform tweet.
- Wingston NFT Utility / mission-1: Timing/day restrictions are not specified beyond reporting the post time, so no timing issue can be established.
- Wingston NFT Utility / mission-1: The post is a longform tweet with 954 characters and 157 words, which is acceptable.
- Wingston NFT Utility / mission-1: Character count (502) and word count (76) are within acceptable limits.

### RQ
- Wingston NFT Utility / mission-0: How do I get on it?' demonstrate a clear understanding of the 'meritocratic' whitelist mechanic and the 'retail vs VC' narrative presented in the tweet.
- Wingston NFT Utility / mission-0: You have to go through the rally campaigns...'), demonstrating genuine community management and subject-matter understanding.
- Wingston NFT Utility / mission-0: Most users focus solely on the 'free' aspect without demonstrating an understanding of the Rally ecosystem.
- Wingston NFT Utility / mission-0: Another user raises a critical point about the marketing tone ('這話怎麼像營銷號文案'), which indicates an authentic human reaction.
- Wingston NFT Utility / mission-0: However, these substantive contributions are vastly outnumbered by shallow, repetitive comments.
- Wingston NFT Utility / mission-1: There is no constructive dialogue, verifiable information, or authentic personal voice.
- Wingston NFT Utility / mission-1: 1.
- Wingston NFT Utility / mission-1: Scores very low.
- Wingston NFT Utility / mission-1: 2.
- Wingston NFT Utility / mission-1: 3.

## Active Skill Update Recommendations
Top active EP deduction pressure points:
- conversation_limited: 15070
- cta_weak: 11681
- compliance_issue: 5484
- value_not_exceptional: 5258
- hook_weak: 4488
- structure_density: 4278
- brand_promotional: 2901
- media_issue: 2766

Recommended enforcement: keep CTA, conversation, value ceiling, hook, structure/media, specificity, and generic/formulaic gates mandatory.
