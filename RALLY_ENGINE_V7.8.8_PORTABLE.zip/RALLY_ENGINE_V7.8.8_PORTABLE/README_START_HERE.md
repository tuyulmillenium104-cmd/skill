# START HERE - RALLY ENGINE V7.8.8 PORTABLE

This is the single entry point for any new chat or AI agent.

## Mandatory read order

1. `SKILL.md`
2. `PATCH_V7.8.8_PORTABLE.md`
3. `PATCH_V7.8.7_EP_MAX.md`
4. `PATCH_V7.8.6_ANTI_RIGIDITY.md`
5. `ANTI_RIGIDITY_PROTOCOL.md`
6. `skills/ACTIVE-PRECEDENCE.md`
7. `HOW_TO_RUN_COMMANDS.md`
8. `skills/RALLY-EXECUTION-CORE.md`
9. `skills/RALLY-QNA-ENGINE-V2.md`

## Verify the bundle first

```bash
python3 skills/rally-handoff-self-check.py --root .
```

Do not start a campaign run if this check fails.

## Trigger

When the user says:

```text
/rally <campaign-address> misi <number>
```

Do not draft immediately.

## Required execution

1. Fetch full current API pagination and lock `SNAPSHOT-MANIFEST.json`.
2. Generate requirement provenance and mission contract.
3. Verify relation/quote/reply/media plan.
4. Decode mission soul from the literal mission verb.
5. Build mission-scoped Winner/Loser/Judge DNA.
6. Separate concise, mid, and long winner lanes.
7. Separate all-max winners from temporal top-1% champions.
8. Generate Winner Build Spec with hard constraints, soft signals, and creative flex zones.
9. Generate Pre-Draft Risk Contract and Build Plan.
10. Draft naturally from winner mechanisms; do not copy winner wording or stack every positive feature.
11. Run deterministic, semantic, originality, naturalness, and RQ gates.
12. Run Worst Positive Verdict.
13. Run EP Max Pressure Audit; `EP5_PRESSURE` requires all five subrubrics PASS.
14. Run hash-backed final integrity with provenance, relation, snapshot, and EP Max reports.
15. Deliver one combined Markdown file plus honest residual-risk disclosure.

## Non-negotiable honesty

Never claim guaranteed external all-max, guaranteed RQ5, or guaranteed leaderboard win. Use:

- `EP5_PRESSURE`
- `all-max-pressure candidate`
- `top-1%-caliber`
- `self-verdict lexicon PASS, not external proof`

## Hard versus soft

Only literal rules, facts, URLs, copying, relation/media, and hash freshness are hard blockers. Length targets, opener prevalence, Portal usage, personal voice, and winner medians are lane-conditional soft evidence unless the campaign explicitly makes them hard.
