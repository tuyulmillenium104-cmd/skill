# Prompt to give another chat/agent

Read first:

1. `PATCH_V7.8.7_EP_MAX.md`
2. `PATCH_V7.8.6_ANTI_RIGIDITY.md`
3. `ANTI_RIGIDITY_PROTOCOL.md`
4. `PATCH_V7.8.5_DEEP_AUDIT.md`
5. `skills/ACTIVE-PRECEDENCE.md`
6. `START_HERE_FOR_NEXT_CHAT.md`
7. `HOW_TO_RUN_COMMANDS.md`
8. `skills/RALLY-EXECUTION-CORE.md`
9. `skills/TOP1-DNA-FIRST-MANDATE.md`

For `/rally <address> misi <n>`:

1. Fetch full mission-scoped data and lock `SNAPSHOT-MANIFEST.json`.
2. Generate requirement provenance.
3. Generate lane-aware Winner DNA and temporal champion map.
4. Generate Winner Build Spec with hard/soft/flex separation.
5. Generate Pre-Draft Risk Contract and build plan.
6. Draft from Winner mechanisms without copying surface.
7. Run compliance, IA, URL, originality, loser, tactical, compactness, semantic, and naturalness gates.
8. Build controlled-variation Q&A: mechanics >=70%, decisions >=75%, skeptic >=25%.
9. Run Worst Positive Verdict.
10. Run the five-subrubric EP Max Pressure Audit.
11. Final integrity must verify report hashes, snapshot identity, provenance, EP5_PRESSURE, Q&A, and exact MAIN block sync.

Never claim guaranteed external all-max. Use `EP5_PRESSURE`, `all-max-pressure candidate`, and disclose external uncertainty.
