import importlib.util,json,os,re,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];SK=ROOT/'skills';sys.path.insert(0,str(SK))
from rally_common import find_url_issues,sha256_text

def load(name,file):
 spec=importlib.util.spec_from_file_location(name,SK/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def run(script,args,cwd=None):
 return subprocess.run([sys.executable,str(SK/script),*map(str,args)],cwd=cwd or ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
class TestPatches(unittest.TestCase):
 def test_url_guard(self):
  self.assertTrue(find_url_issues('go https://site.com/path,')['attachedPunctuation'])
  self.assertTrue(find_url_issues('[site](https://site.com)')['markdownLinks'])
  self.assertFalse(find_url_issues('go https://site.com/path')['attachedPunctuation'])
 def test_mission_type_brief_first(self):
  m=load('cart','rally-campaign-cartographer.py')
  x={'title':'What is GenLayer?','description':'Explain in simple words how validators reach a verdict.','rules':''}
  self.assertEqual(m.infer_mission_type(x),'EXPLAIN')
 def test_fetcher_paginates_past_1200(self):
  m=load('fetch','rally-dna-fetcher.py');rows=[{'id':str(i)} for i in range(1450)]
  old=m.http_get
  def fake(url):
   lim=int(re.search(r'limit=(\d+)',url).group(1));off=int(re.search(r'offset=(\d+)',url).group(1));return json.dumps(rows[off:off+lim])
  m.http_get=fake
  try:self.assertEqual(len(m.fetch_all_submissions('x',page_size=300,max_total=0)),1450)
  finally:m.http_get=old
 def test_cta_semantic_parallelism(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);bad=td/'bad.txt';good=td/'good.txt'
   bad.write_text('Use this test before launch.\n\nReply and choose the decision you would appeal: copyright, credit, health coverage, or hiring?')
   good.write_text("Use this test before launch.\n\nWhich decision would you pick to appeal: copyright ruling, credit denial, claim denial, or job rejection?")
   p=run('rally-cta-quality-check.py',['--content',bad,'--out-json',td/'b.json','--out-md',td/'b.md']);self.assertNotEqual(p.returncode,0,p.stdout)
   p=run('rally-cta-quality-check.py',['--content',good,'--out-json',td/'g.json','--out-md',td/'g.md']);self.assertEqual(p.returncode,0,p.stdout)
 def test_ia_modality_and_truth(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);camp=td/'c.json';camp.write_text(json.dumps({'goal':'AI agents are projected to move nearly $9 trillion by 2030.','knowledgeBase':'Contracts can pull live web inputs.','missions':[]}))
   for text,ok in [('Trillions are entering agent wallets.',False),('Live web sources are neutral truth.',False),('Forecasts put agent transactions in the trillions.',True)]:
    f=td/'x.txt';f.write_text(text);p=run('rally-ia-claim-boundary.py',['--content',f,'--campaign',camp,'--out-json',td/'o.json','--out-md',td/'o.md']);self.assertEqual(p.returncode==0,ok,(text,p.stdout))
 def test_dynamic_build_spec(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);subs=td/'s.json';camp=td/'c.json';out=td/'o.json'
   subs.write_text(json.dumps([{'winner':True,'allMax':True,'content':'A fixed rule cannot interpret context. @GenLayer helps. Which case matters?','contentSource':'fxtwitter','contentComplete':True,'xUsername':'a'}]))
   camp.write_text(json.dumps({'rules':'','missions':[{'id':'mission-0','title':'What is GenLayer?','description':'Explain what GenLayer is in simple words.','rules':'You must mention @GenLayer.'}]}))
   p=run('rally-winner-build-spec.py',['--submissions',subs,'--campaign',camp,'--mission','mission-0','--out-json',out,'--out-md',td/'o.md']);self.assertEqual(p.returncode,0,p.stdout);d=json.loads(out.read_text());self.assertEqual(d['missionType'],'EXPLAIN');self.assertEqual(d['requiredMention'],'@GenLayer');self.assertNotIn('@RallyOnChain',json.dumps(d))
 def test_rq_token_boundaries(self):
  m=load('rqm','rally-rq-mechanics-calibration-check.py');self.assertFalse(m.low_effort('I disagree with the premise.'));self.assertTrue(m.low_effort('gm'))
 def test_exact_main_block_and_hash_staleness(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);content='Alpha beta?';c=td/'content.txt';c.write_text(content)
   comb=td/'combined.md';comb.write_text('## MAIN CONTENT\n\n```text\n'+content+'\n```\n\n## DETAIL KANONIK\n# FINAL AUDIT\n# LOSER-DNA\n# JUDGE-VARIANCE\n')
   co=td/'co.txt';co.write_text(f'COMPLIANCE GATE: ALL BINARY PASS ({len(content)} chars)\nCONTENT SHA256: {sha256_text(content)}\n')
   p=run('rally-final-integrity-check.py',['--content',c,'--combined',comb,'--compliance-output',co]);self.assertEqual(p.returncode,0,p.stdout)
   c.write_text('Omega beta?');comb.write_text(comb.read_text().replace(content,'Omega beta?'))
   p=run('rally-final-integrity-check.py',['--content',c,'--combined',comb,'--compliance-output',co]);self.assertNotEqual(p.returncode,0,p.stdout);self.assertIn('hash is stale',p.stdout)
 def test_ep_praise_not_unknown(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);subs=td/'s.json';content=td/'c.txt';content.write_text('A concrete test. Which decision would you pick?')
   analysis=[{'category':'Engagement Potential','analysis':'The explanation is clear, useful, and highly effective.'}]
   subs.write_text(json.dumps([{'xUsername':'a','gates':{'EP':[4,5]},'analysis':analysis,'content':'x'}]))
   p=run('rally-ep-deduction-map.py',['--submissions',subs,'--content',content,'--out-json',td/'o.json','--out-md',td/'o.md']);self.assertEqual(p.returncode,0,p.stdout);d=json.loads((td/'o.json').read_text());self.assertEqual(d['unknownCorpusClassCount'],0);self.assertEqual(d['decision'],'PASS')
 def test_naturalness_detects_duplicate_pack(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);content=td/'c.txt';content.write_text('A concrete example. Use this test. Which option would you pick?')
   block='''## R1\n\n**Q-COPY**\n```text\nI would choose the same exact mechanic and decision every time.\n```\n**A-COPY**\n```text\nI would choose the same answer every time?\n```\n'''
   combined=td/'m.md';combined.write_text('## MAIN CONTENT\n\n```text\n'+content.read_text()+'\n```\n'+block*20)
   p=run('rally-naturalness-variance-check.py',['--content',content,'--combined',combined,'--out-json',td/'n.json','--out-md',td/'n.md']);self.assertNotEqual(p.returncode,0,p.stdout);self.assertEqual(json.loads((td/'n.json').read_text())['decision'],'FAIL')
 def test_naturalness_review_is_nonfatal(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);content=td/'c.txt';content.write_text('A concrete example. Use this test. Which option would you pick?')
   parts=['## MAIN CONTENT\n\n```text\n'+content.read_text()+'\n```\n'];starts=['My concern','I would','My decision','A skeptic','From experience']
   for i in range(20):
    q=f"{starts[i%5]} number {i} adds a distinct mechanism, personal stake, and concrete decision for this campaign.";a=f"I would answer number {i} with a different example and then ask which path would you choose?";parts.append(f"## R{i+1}\n\n**Q-COPY**\n```text\n{q}\n```\n**A-COPY**\n```text\n{a}\n```\n")
   combined=td/'m.md';combined.write_text(''.join(parts));p=run('rally-naturalness-variance-check.py',['--content',content,'--combined',combined,'--out-json',td/'n.json','--out-md',td/'n.md']);self.assertEqual(p.returncode,0,p.stdout);self.assertIn(json.loads((td/'n.json').read_text())['decision'],['PASS','REVIEW'])
 def test_legacy_max_is_soft_unless_official(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);c=td/'c.txt';c.write_text('A clear sentence with a specific question?');contract=td/'x.json';contract.write_text(json.dumps({'max_chars':10,'require_cta_question':True}))
   p=run('rally-compliance-gate.py',[c,contract]);self.assertEqual(p.returncode,0,p.stdout);self.assertIn('soft target',p.stdout)
   contract.write_text(json.dumps({'official_max_chars':10,'require_cta_question':True}));p=run('rally-compliance-gate.py',[c,contract]);self.assertNotEqual(p.returncode,0,p.stdout)
 def test_requirement_provenance(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);camp=td/'c.json';camp.write_text(json.dumps({'title':'X','goal':'Drive users to Portal.','rules':'','missions':[{'id':'mission-0','title':'What is X?','description':'Explain X.\n\n**Proposed angles:**\nUse a jury analogy.','rules':'You must mention @Brand.\nNo em dash.\nMaximum 280 characters.'}]}));p=run('rally-requirement-provenance.py',['--campaign',camp,'--mission','mission-0','--out-json',td/'o.json','--out-md',td/'o.md']);self.assertEqual(p.returncode,0,p.stdout);d=json.loads((td/'o.json').read_text());src={x['source'] for x in d['requirements']};self.assertIn('MISSION_HARD',src);self.assertIn('OPTIONAL_ANGLE',src);self.assertIn('ENGINE_SOFT_TARGET',src);self.assertEqual(d['officialMaxChars'],280)
 def test_snapshot_lock_rejects_missing_report_hash(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);text='Alpha beta?';c=td/'c.txt';c.write_text(text);m=td/'m.md';m.write_text('## MAIN CONTENT\n\n```text\n'+text+'\n```\n\n## DETAIL KANONIK\n# FINAL AUDIT\n# LOSER-DNA\n# JUDGE-VARIANCE\n');from rally_common import sha256_text;co=td/'co.txt';co.write_text(f'COMPLIANCE GATE: ALL BINARY PASS ({len(text)} chars)\nCONTENT SHA256: {sha256_text(text)}\n');loser=td/'loser.json';loser.write_text(json.dumps({'decision':'PASS','contentSha256':sha256_text(text)}));winner=td/'winner.json';winner.write_text('{}');man=td/'manifest.json';man.write_text(json.dumps({'submissionsEnrichedSha256':'a'*64}));p=run('rally-final-integrity-check.py',['--content',c,'--combined',m,'--compliance-output',co,'--loser-report',loser,'--winner-map',winner,'--snapshot-manifest',man]);self.assertNotEqual(p.returncode,0,p.stdout);self.assertIn('lacks submissionsSha256',p.stdout)
 def test_relation_compliance(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);prov=td/'p.json';plan=td/'plan.json';prov.write_text(json.dumps({'requiredRelation':{'required':True,'allowedTypes':['quote','reply'],'sourceUrls':['https://x.com/Brand/status/123']},'mediaRequired':False,'requirements':[{'source':'MISSION_HARD','text':'quote or reply'}]}));plan.write_text(json.dumps({'relationType':'original','sourceUrl':None,'mediaUsed':False}));p=run('rally-relation-compliance.py',['--provenance',prov,'--plan',plan,'--out-json',td/'o.json','--out-md',td/'o.md']);self.assertNotEqual(p.returncode,0,p.stdout);plan.write_text(json.dumps({'relationType':'quote','sourceUrl':'https://x.com/Brand/status/123','mediaUsed':False}));p=run('rally-relation-compliance.py',['--provenance',prov,'--plan',plan,'--out-json',td/'o.json','--out-md',td/'o.md']);self.assertEqual(p.returncode,0,p.stdout)
 def test_ep_max_aggregator(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);content=td/'c.txt';text='A concrete conflict exposes a missing appeal.\n\nUse this test before launch.\n\nWhich decision would you pick to appeal?';content.write_text(text);combined=td/'m.md';combined.write_text('## MAIN CONTENT\n\n```text\n'+text+'\n```\n');from rally_common import report_identity;ident=report_identity(text,combined.read_text())
   def wr(name,data):p=td/name;p.write_text(json.dumps({**ident,**data}));return p
   cta=wr('cta.json',{'decision':'PASS','ctaStrengthRank':1,'ctaFormulaScore':5,'semanticParallelism':{'pass':True},'lowFrictionReplyPath':True,'engagementBaitRisk':False,'prompt':'Which decision?'})
   tac=wr('tac.json',{'decision':'PASS','score':6,'payloadCandidates':['Use this test']});comp=wr('comp.json',{'decision':'PASS'});nat=wr('nat.json',{'decision':'PASS'});eps=wr('eps.json',{'decision':'PASS','risks':[]});ori=wr('ori.json',{'decision':'PASS'});oaa=wr('oaa.json',{'decision':'PASS'});tq=wr('tq.json',{'decision':'PASS'});worst=wr('worst.json',{'decision':'PASS','credibleDeductions':[]});rq=wr('rq.json',{'decision':'PASS'});rqm=wr('rqm.json',{'decision':'PASS','skepticPct':.25});subs=td/'s.json';subs.write_text('[]')
   p=run('rally-ep-max-pressure-audit.py',['--content',content,'--combined',combined,'--submissions',subs,'--cta-report',cta,'--tactical-report',tac,'--compactness-report',comp,'--naturalness-report',nat,'--ep-semantic-report',eps,'--originality-report',ori,'--oaa-report',oaa,'--tq-report',tq,'--worst-verdict-report',worst,'--rq-report',rq,'--rq-mechanics-report',rqm,'--out-json',td/'out.json','--out-md',td/'out.md']);self.assertEqual(p.returncode,0,p.stdout);self.assertEqual(json.loads((td/'out.json').read_text())['epDecision'],'EP5_PRESSURE')
if __name__=='__main__':unittest.main()
