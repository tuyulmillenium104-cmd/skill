# How To Run - Commands

Replace `<address>` and `<mission>` with user input.

## 1. Fetch DNA and cartography

```bash
python3 skills/rally-campaign-cartographer.py \
  --address <address> \
  --mission <mission> \
  --page-size 300 \
  --max-total 0 \
  --out rally-data/learn/<address>-<mission>
```

## 1.5 Provenance, mission contract, and relation plan

Cartographer V7.8.8 creates requirement provenance and mission contract automatically. Before drafting, also create `submission-plan.json` from `submission-plan.example.json`, then run:

```bash
python3 skills/rally-relation-compliance.py \
  --provenance "$BASE/requirement-provenance.json" \
  --plan "$OUT/submission-plan.json" \
  --out-json "$OUT/relation.json" \
  --out-md "$OUT/RELATION.md"
```

## 2. Winner build spec before writing

```bash
BASE=rally-data/learn/<address>-<mission>
python3 skills/rally-winner-build-spec.py \
  --submissions "$BASE/submissions_enriched.json" \
  --campaign "$BASE/campaign.json" \
  --mission <mission> \
  --out-json "$BASE/winner-build-spec.json" \
  --out-md "$BASE/WINNER-BUILD-SPEC.md"
```

## 3. Pre-draft risk contract before writing

```bash
python3 skills/rally-pre-draft-risk-contract.py \
  --submissions "$BASE/submissions_enriched.json" \
  --campaign "$BASE/campaign.json" \
  --mission <mission> \
  --winner-build-spec "$BASE/winner-build-spec.json" \
  --out-json "$BASE/pre-draft-risk-contract.json" \
  --out-md "$BASE/PRE-DRAFT-RISK-CONTRACT.md"
```

Then write a build plan before drafting:

```text
WINNER-DNA BUILD PLAN:
- Hook mechanism selected:
- Trade/refusal/story mechanism selected:
- Value delivery mechanism selected:
- Tactical payload selected:
- Brand bridge style selected:
- CTA style selected:
- Loser-DNA exclusions:
- Contract blockers respected:
```

No pre-draft contract = no draft.

## 4. Required validators after drafting

```bash
OUT=$BASE/final-run
mkdir -p "$OUT"

python3 skills/rally-compliance-gate.py "$OUT/content.txt" "$OUT/contract.json" | tee "$OUT/compliance.txt"
python3 skills/rally-cta-quality-check.py --content "$OUT/content.txt" --campaign "$BASE/campaign.json" --mission <mission> --out-json "$OUT/cta.json" --out-md "$OUT/CTA.md" | tee "$OUT/cta.txt"
python3 skills/rally-loser-dna-scan.py --content "$OUT/content.txt" --submissions "$BASE/submissions_enriched.json" --out-json "$OUT/loser-report.json" --out-md "$OUT/LOSER-DNA.md" | tee "$OUT/loser.txt"
python3 skills/rally-tactical-value-check.py --content "$OUT/content.txt" --out-json "$OUT/tactical-value.json" --out-md "$OUT/TACTICAL-VALUE.md" | tee "$OUT/tactical-value.txt"
python3 skills/rally-originality-saturation-check.py --content "$OUT/content.txt" --submissions "$BASE/submissions_enriched.json" --out-json "$OUT/originality-saturation.json" --out-md "$OUT/ORIGINALITY-SATURATION.md" | tee "$OUT/originality-saturation.txt"
python3 skills/rally-ep-compactness-check.py --content "$OUT/content.txt" --genre tactical --out-json "$OUT/ep-compactness.json" --out-md "$OUT/EP-COMPACTNESS.md" | tee "$OUT/ep-compactness.txt"
python3 skills/rally-tq-format-audit.py --content "$OUT/content.txt" --genre tactical --out-json "$OUT/tq.json" --out-md "$OUT/TQ.md" | tee "$OUT/tq.txt"
python3 skills/rally-oaa-structure-audit.py --content "$OUT/content.txt" --submissions "$BASE/submissions_enriched.json" --out-json "$OUT/oaa.json" --out-md "$OUT/OAA.md" | tee "$OUT/oaa.txt"
python3 skills/rally-ia-claim-boundary.py --content "$OUT/content.txt" --campaign "$BASE/campaign.json" --mission <mission> --out-json "$OUT/ia.json" --out-md "$OUT/IA.md" | tee "$OUT/ia.txt"
```

## 5. EP semantic review

```bash
python3 skills/rally-ep-deduction-map.py --submissions "$BASE/submissions_enriched.json" --content "$OUT/content.txt" --out-json "$OUT/ep-content-map.json" --out-md "$OUT/EP-CONTENT-MAP.md"
```

If unknown corpus classes are irrelevant to current content, write explicit `ep-content-clearance.json`, then run:

```bash
python3 skills/rally-ep-semantic-review.py \
  --content "$OUT/content.txt" \
  --mission-type explain \
  --ep-map "$OUT/ep-content-clearance.json" \
  --cta-report "$OUT/cta.json" \
  --oaa-report "$OUT/oaa.json" \
  --tq-report "$OUT/tq.json" \
  --out-json "$OUT/ep-semantic.json" \
  --out-md "$OUT/EP-SEMANTIC.md" | tee "$OUT/epsemantic.txt"
```

## 6. Q&A pack compliance

After `combined.md` is assembled:

```bash
python3 skills/rally-rq-prompt-answer-check.py \
  --content "$OUT/content.txt" \
  --combined "$OUT/combined.md" \
  --out-json "$OUT/rq-prompt-answer.json" \
  --out-md "$OUT/RQ-PROMPT-ANSWER.md" | tee "$OUT/rq-prompt-answer.txt"
```

## 7. RQ campaign mechanics calibration

For product/protocol campaigns run:

```bash
python3 skills/rally-rq-mechanics-calibration-check.py \
  --content "$OUT/content.txt" \
  --combined "$OUT/combined.md" \
  --campaign "$BASE/campaign.json" \
  --mission <mission> \
  --out-json "$OUT/rq-mechanics.json" \
  --out-md "$OUT/RQ-MECHANICS.md" | tee "$OUT/rq-mechanics.txt"
```

## 7.5 Naturalness and controlled variation

```bash
python3 skills/rally-naturalness-variance-check.py \
  --content "$OUT/content.txt" \
  --combined "$OUT/combined.md" \
  --out-json "$OUT/naturalness.json" \
  --out-md "$OUT/NATURALNESS.md" | tee "$OUT/naturalness.txt"
```

`REVIEW` is allowed with disclosure; `FAIL` blocks final output.

## 8. Worst positive verdict check

```bash
python3 skills/rally-worst-positive-verdict-check.py \
  --content "$OUT/content.txt" \
  --combined "$OUT/combined.md" \
  --tactical-report "$OUT/tactical-value.json" \
  --originality-report "$OUT/originality-saturation.json" \
  --compactness-report "$OUT/ep-compactness.json" \
  --rq-report "$OUT/rq-prompt-answer.json" \
  --cta-report "$OUT/cta.json" \
  --out-json "$OUT/worst-positive-verdict.json" \
  --out-md "$OUT/WORST-POSITIVE-VERDICT.md" | tee "$OUT/worst-positive-verdict.txt"
```

## 8. EP Max Pressure Audit

```bash
python3 skills/rally-ep-max-pressure-audit.py \
  --content "$OUT/content.txt" --combined "$OUT/combined.md" \
  --submissions "$BASE/submissions_enriched.json" \
  --cta-report "$OUT/cta.json" \
  --tactical-report "$OUT/tactical-value.json" \
  --compactness-report "$OUT/ep-compactness.json" \
  --naturalness-report "$OUT/naturalness.json" \
  --ep-semantic-report "$OUT/ep-semantic.json" \
  --originality-report "$OUT/originality-saturation.json" \
  --oaa-report "$OUT/oaa.json" --tq-report "$OUT/tq.json" \
  --worst-verdict-report "$OUT/worst-positive-verdict.json" \
  --rq-report "$OUT/rq-prompt-answer.json" \
  --rq-mechanics-report "$OUT/rq-mechanics.json" \
  --out-json "$OUT/ep-max.json" --out-md "$OUT/EP-MAX.md"
```

## 9. Final integrity

```bash
python3 skills/rally-final-integrity-check.py \
  --content "$OUT/content.txt" \
  --combined "$OUT/combined.md" \
  --compliance-output "$OUT/compliance.txt" \
  --rules-output "$OUT/rules.txt" \
  --loser-report "$OUT/loser-report.json" \
  --min-qna 20 \
  --require-cta-verb \
  --cta-report "$OUT/cta.json" \
  --ep-map "$OUT/ep-content-clearance.json" \
  --winner-map "$BASE/winner-dna-map.json" \
  --tq-report "$OUT/tq.json" \
  --oaa-report "$OUT/oaa.json" \
  --ia-report "$OUT/ia.json" \
  --ep-semantic-report "$OUT/ep-semantic.json" \
  --tactical-report "$OUT/tactical-value.json" \
  --originality-report "$OUT/originality-saturation.json" \
  --compactness-report "$OUT/ep-compactness.json" \
  --rq-report "$OUT/rq-prompt-answer.json" \
  --worst-verdict-report "$OUT/worst-positive-verdict.json" \
  --rq-mechanics-report "$OUT/rq-mechanics.json" \
  --naturalness-report "$OUT/naturalness.json" \
  --ep-max-report "$OUT/ep-max.json" \
  --requirement-provenance "$BASE/requirement-provenance.json" \
  --relation-report "$OUT/relation.json" \
  --snapshot-manifest "$BASE/SNAPSHOT-MANIFEST.json" | tee "$OUT/final-integrity.txt"
```
