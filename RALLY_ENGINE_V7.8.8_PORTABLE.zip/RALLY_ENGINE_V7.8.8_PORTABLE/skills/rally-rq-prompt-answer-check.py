#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RQ Prompt-Answer Compliance checker.

Real verdict lesson: replies can be relevant and authentic but score RQ3 if they mostly
validate the post instead of answering the actual CTA or adding personal story/deeper
reflection. This tool checks Q-COPY/A-COPY blocks in the combined file.
"""
import argparse, json, re, sys, time
from pathlib import Path
from rally_common import report_identity

META_CRAFT = [
    "this works because", "what makes this", "the writing", "the detail", "specificity",
    "authenticity", "narrative", "metaphor", "hook", "line lands", "post is strong",
    "this is stronger than", "great way to", "the best part"
]
VALIDATION_ONLY = [
    "this hits", "so true", "i relate", "i felt this", "this made me think", "i like that",
    "that is accurate", "exactly", "same", "too real"
]
FIRST_PERSON = [" i ", " my ", " me ", " i've ", " i'm ", " mine ", " we ", " our "]
DECISION_WORDS = ["decision", "decide", "forced", "cut", "stop", "start", "choose", "remove", "protect", "rewrite", "change", "cancel", "publish", "share", "make"]
DRINK_WORDS = ["drink", "tea", "coffee", "water", "soda", "soup", "cocoa", "juice", "beer", "wine", "cocktail", "martini", "espresso", "smoothie", "champagne", "mug", "cup", "glass", "bottle"]
TRADE_WORDS = ["trade", "give up", "gain", "refuse", "protect", "access", "truth", "apology", "boundary"]


def pairs(text):
    return re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```", text, flags=re.S)


def has_any(t, words):
    tl=' '+t.lower()+' '
    return any(w in tl for w in words)


def infer_prompt_type(main_content):
    tail='\n\n'.join([p.strip() for p in re.split(r"\n\s*\n+", main_content.strip()) if p.strip()][-2:]).lower()
    if any(w in tail for w in ['drink','january','holding','ordered','order']): return 'drink_decision'
    if any(w in tail for w in ['trade','give up','gain','refuse','protect']): return 'trade_refusal'
    if any(w in tail for w in ['work','proof','public','private']): return 'work_proof'
    return 'general'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--combined', required=True)
    ap.add_argument('--content', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    ap.add_argument('--min-pairs', type=int, default=20)
    ap.add_argument('--min-q-chars', type=int, default=160)
    ap.add_argument('--max-q-chars', type=int, default=260)
    ap.add_argument('--max-a-chars', type=int, default=280)
    ap.add_argument('--min-decision-pct', type=float, default=0.75)
    args=ap.parse_args()
    combined=Path(args.combined).read_text(encoding='utf-8')
    content=Path(args.content).read_text(encoding='utf-8').strip() if args.content else ''
    pr_type=infer_prompt_type(content)
    ps=pairs(combined)
    rows=[]; errs=[]
    for idx,(q,a) in enumerate(ps,1):
        ql=q.lower(); al=a.lower(); both=(q+' '+a).lower()
        first_person=has_any(q, FIRST_PERSON) or has_any(a, FIRST_PERSON)
        open_loop='?' in a
        meta=[m for m in META_CRAFT if m in both]
        validation=[v for v in VALIDATION_ONLY if ql.startswith(v) or al.startswith(v)]
        has_decision=has_any(q+' '+a, DECISION_WORDS)
        has_drink=has_any(q+' '+a, DRINK_WORDS)
        has_trade=has_any(q+' '+a, TRADE_WORDS)
        if pr_type=='drink_decision': answers_prompt=has_drink
        elif pr_type=='trade_refusal': answers_prompt=has_trade
        elif pr_type=='work_proof': answers_prompt=('proof' in both or 'public' in both or 'private' in both)
        else: answers_prompt=first_person
        # Decision is an overall coverage target. A controlled minority may add
        # humor, emotion, or lived context without repeating a decision formula.
        advances=first_person and answers_prompt and open_loop and not (meta and not has_decision)
        row={'idx':idx,'qChars':len(q),'aChars':len(a),'firstPerson':first_person,'openLoop':open_loop,'metaCraftHits':meta,'validationHits':validation,'hasDecision':has_decision,'hasDrink':has_drink,'hasTrade':has_trade,'answersPrompt':answers_prompt,'advancesConversation':advances,'decision':'PASS' if advances and args.min_q_chars<=len(q)<=args.max_q_chars and len(a)<=args.max_a_chars else 'FAIL'}
        rows.append(row)
        if row['decision']!='PASS':
            reasons=[]
            if len(q)<args.min_q_chars: reasons.append(f'Q < {args.min_q_chars}')
            if len(q)>args.max_q_chars: reasons.append(f'Q > {args.max_q_chars}')
            if len(a)>args.max_a_chars: reasons.append(f'A > {args.max_a_chars}')
            if not answers_prompt: reasons.append('does not answer actual CTA/prompt')
            if not first_person: reasons.append('no personal story/confession surface')
            if not open_loop: reasons.append('A lacks open-loop question')
            if meta and not has_decision: reasons.append('meta craft commentary without personal decision')
            errs.append({'idx':idx,'reasons':reasons,'q':q,'a':a})
    pass_count=sum(1 for r in rows if r['decision']=='PASS')
    meta_count=sum(1 for r in rows if r['metaCraftHits']);decision_count=sum(1 for r in rows if r['hasDecision']);decision_pct=decision_count/max(1,len(rows))
    reasons=[]
    if len(ps)<args.min_pairs: reasons.append(f'only {len(ps)} pairs < min {args.min_pairs}')
    if pass_count!=len(ps): reasons.append(f'{len(ps)-pass_count} pairs fail prompt-answer/advancement checks')
    if meta_count>2: reasons.append(f'too many meta/craft-commentary replies: {meta_count}')
    if decision_pct<args.min_decision_pct:reasons.append(f'decision coverage {decision_pct:.0%} < {args.min_decision_pct:.0%}')
    decision='PASS' if not reasons else 'FAIL'
    result={'tool':'rally-rq-prompt-answer-check.py v7.8.5',**report_identity(content,combined),'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'promptType':pr_type,'qCharRange':[args.min_q_chars,args.max_q_chars],'aMaxChars':args.max_a_chars,'minDecisionPct':args.min_decision_pct,'decisionPairCount':decision_count,'decisionPct':round(decision_pct,3),'pairCount':len(ps),'passCount':pass_count,'metaCraftPairCount':meta_count,'rows':rows,'errors':errs,'decision':decision,'reasons':reasons}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append('# RQ PROMPT-ANSWER COMPLIANCE CHECK\n\n')
    md.append(f'Decision: **{decision}**\n\nPrompt type: **{pr_type}**  \nPairs: **{len(ps)}**  \nPass: **{pass_count}/{len(ps)}**  \nDecision coverage: **{decision_count}/{len(ps)} ({decision_pct:.0%})**  \nMeta/craft pairs: **{meta_count}**\n\n')
    md.append('## Reasons\n')
    md += [f'- {r}\n' for r in reasons] or ['- clear\n']
    md.append('\n## Failed pairs\n')
    if errs:
        for e in errs: md.append(f"- Pair {e['idx']}: {', '.join(e['reasons'])}\n")
    else: md.append('- none\n')
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f"RQ PROMPT-ANSWER CHECK: {decision} [pass={pass_count}/{len(ps)}, meta={meta_count}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
