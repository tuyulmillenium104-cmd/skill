#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Campaign-specific IA claim boundary and modality audit (V7.8.5)."""
import argparse,json,re,sys,time
from pathlib import Path
from rally_common import report_identity
RISK=['guaranteed','guarantee','profit','roi','100x','fully transparent','perfectly fair','cannot be biased','will make you','income','assured','automatic win','guaranteed whitelist']
TECH=['validators','nodes','on-chain ai','democratic vote','zk proof','smart contract automatically judges','public model reasoning','cross validation']

def campaign_kb(c,mission_id=None):
    parts=[c.get('goal',''),c.get('knowledgeBase',''),c.get('style',''),c.get('rules','')]
    for m in c.get('missions',[]):
        if mission_id and m.get('id')!=mission_id:continue
        parts += [m.get('title',''),m.get('description',''),m.get('rules','')]
    return ' '.join(str(x or '') for x in parts).lower()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--campaign',required=True);ap.add_argument('--mission',default=None);ap.add_argument('--out-json',required=True);ap.add_argument('--out-md',required=True);args=ap.parse_args()
    text=Path(args.content).read_text(encoding='utf-8').strip();tl=text.lower();c=json.load(open(args.campaign,encoding='utf-8'));kb=campaign_kb(c,args.mission)
    errors=[];warnings=[];evidence=[]
    risk_hits=[r for r in RISK if r in tl and r not in kb]
    if risk_hits:errors.append(f'guarantee/overclaim terms absent from KB: {risk_hits}')
    # Capability expansion: web inputs are evidence/context, not truth.
    truth_hits=[p for p in ['neutral truth','objective truth','web sources as truth','sources as neutral'] if p in tl]
    if truth_hits:errors.append(f'live-source capability expanded into truth claim: {truth_hits}')
    # Forecast modality. If KB says projected/forecast, present-progressive or
    # already/current trillion claims are a hard drift; definite future is a warning.
    kb_projection=('projected' in kb or 'forecast' in kb) and 'trillion' in kb
    present_trillion=bool(re.search(r"\b(trillions?|nine trillion|\$9 trillion)\b.{0,45}\b(are|is) (moving|entering|flowing|being moved)\b|\b(are|is) (moving|entering).{0,45}\btrillions?\b",tl))
    if kb_projection and present_trillion:errors.append('forecast-to-present temporal drift: trillion-scale activity stated as current')
    definite_future=bool(re.search(r"\b(will|is going to)\b.{0,60}\b(trillions?|nine trillion|\$9 trillion)\b|\b(trillions?|nine trillion|\$9 trillion)\b.{0,60}\bwill\b",tl))
    if kb_projection and definite_future and not any(x in tl for x in ['projected','forecast','could','may']):warnings.append('forecast expressed as definite future; preserve projection modality')
    # Unsupported absolutes observed during deep audit.
    absolute_patterns={
      'every/any deal inevitably conflicts':r"\b(any|every) deal (brings|creates|causes|ends in) conflict\b",
      'no infrastructure absolute':r"\bno infrastructure (resolves|can resolve|exists)\b",
      'perfect outcome absolute':r"\b(always fair|perfectly fair|impossible to manipulate|cannot fail|never wrong)\b",
    }
    absolute_hits=[]
    for label,pat in absolute_patterns.items():
        if re.search(pat,tl) and not re.search(pat,kb):absolute_hits.append(label)
    if absolute_hits:errors.append(f'unsupported absolutes: {absolute_hits}')
    tech_hits=[t for t in TECH if t in tl and t not in kb]
    if tech_hits:warnings.append(f'technical terms not evident in KB: {tech_hits}')
    nums=re.findall(r"\b\d+(?:\.\d+)?\s*(?:k|m|%|x)?\b",tl);num_risk=[n for n in nums if n not in kb]
    if num_risk:warnings.append(f'numbers not found in KB text: {num_risk}')
    # Report superlatives only when not directly supported by KB.
    supers=re.findall(r"\b(first|only|best|single most|completely|fully)\b",tl)
    unsupported_supers=[x for x in supers if x not in kb]
    if unsupported_supers:warnings.append(f'absolute/superlative wording requires review: {unsupported_supers}')
    decision='PASS' if not errors else 'FAIL'
    result={'tool':'rally-ia-claim-boundary.py v7.8.5',**report_identity(text),'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'mission':args.mission,'riskHits':risk_hits,'truthExpansionHits':truth_hits,'technicalWarnings':tech_hits,'numbers':nums,'numberWarnings':num_risk,'warnings':warnings,'errors':errors,'decision':decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# IA CLAIM BOUNDARY AUDIT - MODALITY AWARE\n\n',f'- Decision: **{decision}**\n',f'- Content SHA-256: `{result["contentSha256"]}`\n\n','## Errors\n']+([f'- {e}\n' for e in errors] or ['- none\n'])+['\n## Warnings\n']+([f'- {w}\n' for w in warnings] or ['- none\n'])
    Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f'IA CLAIM AUDIT: {decision} [{len(errors)} errors, {len(warnings)} warnings]');sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__':main()
