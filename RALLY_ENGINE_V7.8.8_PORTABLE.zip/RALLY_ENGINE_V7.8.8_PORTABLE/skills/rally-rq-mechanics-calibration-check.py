#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Campaign-derived RQ mechanics calibration (V7.8.5)."""
import argparse,json,re,sys,time
from pathlib import Path
from collections import Counter
from rally_common import report_identity
CATEGORY_LIBRARY={
 'adjudication':['adjudication','dispute','verdict','ruling','fairness'],
 'intelligent_contract':['intelligent contract','natural language','context','terms','live input'],
 'independent_review':['validator','independent review','separate ai','model diversity','reviewer'],
 'appeal_accountability':['appeal','recourse','second round','new round','economic accountability','economic cost','reversal'],
 'semantic_consensus':['semantic','meaning','reading','interpretation','consensus','conclusion','alignment','receipt'], 
 'protocol_utility':['utility','staking','stake','rlp','reward','score','protocol','dashboard','holder-only'],
 'access_mechanics':['whitelist','wl','top 425','leaderboard','rank','eligible','campaign participation'],
 'mint_details':['free mint','mint','supply','ethereum','0 eth'],
 'market_contrast':['floor','hype','flip','flipper','speculation','gas','wallet','cost'],
 'product_model':['product','post-mint','holder','community','contribution','creator'],
 'real_domain_application':['copyright','credit','coverage','hiring','insurance','delivery','license','freelance','payment'],
}
SKEPTIC_MARKERS=['but','only if','depends','verify','question','concern','risk','what happens','still a cost','whether','if ']
DECISION_MARKERS=['i would','my decision','i choose','i would choose','i would rather','i trust','i would pick','i like','my concern','my answer']
LOW_EFFORT_WORDS=['bullish','lfg','gm']
LOW_EFFORT_PHRASES=['great post','nice post','good take','love this','well said','spot on']
def pairs(text):return re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```",text,flags=re.S)
def campaign_text(path,mission=None):
 if not path:return ''
 c=json.load(open(path,encoding='utf-8'));parts=[c.get('title',''),c.get('goal',''),c.get('knowledgeBase',''),c.get('rules','')]
 for m in c.get('missions',[]):
  if mission and m.get('id')!=mission:continue
  parts += [m.get('title',''),m.get('description',''),m.get('rules','')]
 return ' '.join(str(x or '') for x in parts).lower()
def active_categories(camp):
 active={}
 for cat,terms in CATEGORY_LIBRARY.items():
  if any(t in camp for t in terms):active[cat]=terms
 return active or {'campaign_specific':['campaign']}
def low_effort(text):
 tl=text.lower();tokens=set(re.findall(r"\b[a-z0-9']+\b",tl))
 return any(x in tokens for x in LOW_EFFORT_WORDS) or any(x in tl for x in LOW_EFFORT_PHRASES)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--combined',required=True);ap.add_argument('--content',required=True);ap.add_argument('--campaign',default=None);ap.add_argument('--mission',default=None);ap.add_argument('--out-json',required=True);ap.add_argument('--out-md',required=True);ap.add_argument('--min-mechanics-pct',type=float,default=.70);ap.add_argument('--min-decision-pct',type=float,default=.75);ap.add_argument('--min-skeptic-pct',type=float,default=.25);ap.add_argument('--max-consecutive-nonmechanic',type=int,default=2);args=ap.parse_args()
 combined=Path(args.combined).read_text(encoding='utf-8');content=Path(args.content).read_text(encoding='utf-8').strip();camp=campaign_text(args.campaign,args.mission);active=active_categories(camp)
 protocol=sum(1 for p in ['protocol','validator','contract','network','nft','mint','whitelist','staking','consensus','adjudication'] if p in camp)>=2
 ps=pairs(combined);rows=[];counts=Counter();fail=[]
 for idx,(q,a) in enumerate(ps,1):
  ql=q.lower();both=ql+' '+a.lower();cats=[]
  for cat,terms in active.items():
   if any(t in both for t in terms):cats.append(cat);counts[cat]+=1
  mech=bool(cats);dec=any(m in ql for m in DECISION_MARKERS);skeptic=any(m in ql for m in SKEPTIC_MARKERS);low=low_effort(q);open_loop=a.rstrip().endswith('?')
  # Per-pair hard requirements are only conversation safety. Decision and
  # mechanics are coverage targets so a controlled minority can carry humor,
  # emotion, or human texture without becoming formulaic.
  ok=(open_loop and not low)
  row={'idx':idx,'qChars':len(q),'aChars':len(a),'categories':cats,'hasMechanic':mech,'hasDecision':dec,'hasSkeptic':skeptic,'openLoop':open_loop,'lowEffort':low,'decision':'PASS' if ok else 'FAIL','q':q[:260]};rows.append(row)
  if not ok:fail.append({'idx':idx,'reasons':(['A lacks final open-loop question'] if not open_loop else [])+(['token-level low effort'] if low else [])})
 n=len(ps);mc=sum(r['hasMechanic'] for r in rows);dc=sum(r['hasDecision'] for r in rows);sc=sum(r['hasSkeptic'] for r in rows);mp=mc/max(1,n);dp=dc/max(1,n);sp=sc/max(1,n);coverage=sum(v>0 for v in counts.values());required_cov=min(4,len(active));reasons=[]
 if fail:reasons.append(f'{len(fail)} pairs fail hard conversation safety')
 if protocol and mp<args.min_mechanics_pct:reasons.append(f'mechanics {mp:.0%} < {args.min_mechanics_pct:.0%}')
 if dp<args.min_decision_pct:reasons.append(f'decision coverage {dp:.0%} < {args.min_decision_pct:.0%}')
 if protocol and coverage<required_cov:reasons.append(f'category coverage {coverage} < {required_cov}')
 if protocol and sp<args.min_skeptic_pct:reasons.append(f'skeptic {sp:.0%} < {args.min_skeptic_pct:.0%}')
 streak=max_streak=0
 for r in rows:
  streak=0 if r['hasMechanic'] else streak+1;max_streak=max(max_streak,streak)
 if protocol and max_streak>args.max_consecutive_nonmechanic:reasons.append(f'non-mechanic streak {max_streak} > {args.max_consecutive_nonmechanic}')
 decision='PASS' if not reasons else 'FAIL';ident=report_identity(content,combined)
 result={'tool':'rally-rq-mechanics-calibration-check.py v7.8.5',**ident,'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'protocolCampaign':protocol,'activeMechanicCategories':active,'pairCount':n,'mechanicsPairCount':mc,'mechanicsPct':round(mp,3),'decisionPairCount':dc,'decisionPct':round(dp,3),'minDecisionPct':args.min_decision_pct,'skepticPairCount':sc,'skepticPct':round(sp,3),'maxConsecutiveNonMechanic':max_streak,'categoryCounts':dict(counts),'categoryCoverage':coverage,'requiredCategoryCoverage':required_cov,'rows':rows,'failures':fail,'decision':decision,'reasons':reasons}
 Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 md=['# RQ CAMPAIGN-DERIVED MECHANICS CHECK\n\n',f'Decision: **{decision}**\n\n',f'- Protocol: {protocol}\n- Active categories: {list(active)}\n- Mechanics: {mc}/{n} ({mp:.0%})\n- Decision coverage: {dc}/{n} ({dp:.0%})\n- Skeptic: {sc}/{n} ({sp:.0%})\n- Max non-mechanic streak: {max_streak}\n- Coverage: {coverage}/{len(active)}\n\n','## Reasons\n']+([f'- {r}\n' for r in reasons] or ['- clear\n'])
 Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f'RQ MECHANICS: {decision} [mechanics={mc}/{n}, categories={coverage}/{len(active)}, skeptic={sc}/{n}]');sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__':main()
