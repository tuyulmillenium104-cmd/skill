# ACTIVE PRECEDENCE - V7.8.8 PORTABLE

1. Campaign and mission literal brief.
2. `PATCH_V7.8.8_PORTABLE.md` and `README_START_HERE.md`.
3. `PATCH_V7.8.7_EP_MAX.md`.
4. `PATCH_V7.8.6_ANTI_RIGIDITY.md` and `ANTI_RIGIDITY_PROTOCOL.md`.
5. `PATCH_V7.8.5_DEEP_AUDIT.md`.
6. `RALLY-EXECUTION-CORE.md`.
7. `TOP1-DNA-FIRST-MANDATE.md`.
8. `RALLY-QNA-ENGINE-V2.md`.
9. `RQ5-FIELD-LESSONS-ADDENDUM.md`.
10. Older V7.7/V7.8 files as reference only.

## Active replacements

- Literal official limits are extracted into provenance and mission contract.
- Relation/quote/reply/media plan is a first-class compliance artifact.
- Snapshot lock rejects missing as well as mismatched corpus hashes.
- EP Max promotes deterministic and precedented warnings.
- EP Max is five-subrubric evidence aggregation, not length alone.
- Hard constraints remain separate from soft signals and creative flex zones.
- Self-verdict lexicon PASS is not external judge proof.
