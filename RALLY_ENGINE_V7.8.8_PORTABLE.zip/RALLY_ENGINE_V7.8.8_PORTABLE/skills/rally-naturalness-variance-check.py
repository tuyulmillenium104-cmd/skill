#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Naturalness and controlled-variation audit (V7.8.6 anti-rigidity).

This tool does not prescribe a voice. It detects formula repetition, duplicate
reply templates, mechanical CTA commands, and keyword packing. Minor findings are
REVIEW, not hard failure. Only severe duplication/templating is FAIL.
"""
import argparse,json,re,statistics,sys,time
from collections import Counter
from pathlib import Path
from rally_common import report_identity
FORMULAIC=['this is exactly why','the real lesson is','let that sink in','game changer','in today\'s landscape','the point is','it was never about','that changed how i think']
TECH_TERMS=['adjudication','validator','consensus','intelligent contract','optimistic democracy','protocol','semantic','economic accountability','agentic economy','smart contract']
BAIT_STARTS=['reply with','comment below','drop yours','engage below','tag a friend']
def sentences(t):return [x.strip() for x in re.split(r'(?<=[.!?])\s+|\n+',t or '') if x.strip()]
def opener(t,n=2):
 w=re.findall(r"[a-z0-9']+",t.lower());return ' '.join(w[:n])
def pairs(t):return re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```",t,flags=re.S)
def ngrams(t,n=5):
 w=re.findall(r"[a-z0-9']+",t.lower());return {' '.join(w[i:i+n]) for i in range(len(w)-n+1)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--combined',default=None);ap.add_argument('--out-json',required=True);ap.add_argument('--out-md',required=True);args=ap.parse_args()
 text=Path(args.content).read_text(encoding='utf-8').strip();combined=Path(args.combined).read_text(encoding='utf-8') if args.combined else None;reviews=[];fails=[];passes=[]
 ss=sentences(text);lens=[len(re.findall(r"\b\w+\b",s)) for s in ss];starts=Counter(opener(s) for s in ss if opener(s));max_start=max(starts.values(),default=0)/max(1,len(ss))
 formula=[x for x in FORMULAIC if x in text.lower()];semi=max((s.count(';') for s in ss),default=0);tech_hits=sum(text.lower().count(x) for x in TECH_TERMS);tech_per100=tech_hits/max(1,len(re.findall(r"\b\w+\b",text)))*100
 last=[p.strip() for p in re.split(r"\n\s*\n+",text) if p.strip()][-1].lower();bait=next((x for x in BAIT_STARTS if last.startswith(x)),None)
 if formula:reviews.append(f'formulaic phrase hits: {formula}')
 if max_start>.55 and len(ss)>=6:reviews.append(f'main sentence opener concentration {max_start:.0%}')
 if semi>=2:reviews.append(f'semicolon chain in one sentence: {semi}')
 if tech_per100>16:reviews.append(f'technical-term density {tech_per100:.1f}/100 words')
 if bait:reviews.append(f'explicit engagement-command opener: {bait}')
 if lens and len(lens)>=8 and statistics.pstdev(lens)/max(1,statistics.mean(lens))<.18:reviews.append('sentence lengths are unusually uniform')
 if not reviews:passes.append('main-content rhythm and phrasing show no formula concentration')
 qrows=[];qps=pairs(combined or '')
 if combined is not None:
  if not qps:fails.append('combined file contains no parseable Q/A pairs')
  else:
   qopen=[opener(q) for q,a in qps];aopen=[opener(a) for q,a in qps];qc=Counter(qopen);ac=Counter(aopen)
   qratio=max(qc.values())/len(qps);aratio=max(ac.values())/len(qps)
   duplicate_q=len(qps)-len({re.sub(r'\s+',' ',q.lower()).strip() for q,a in qps});duplicate_a=len(qps)-len({re.sub(r'\s+',' ',a.lower()).strip() for q,a in qps})
   if duplicate_q or duplicate_a:fails.append(f'exact duplicate Q/A rows: Q={duplicate_q}, A={duplicate_a}')
   if len(qc)<4 and len(qps)>=12:fails.append(f'too few distinct Q opener families: {len(qc)}')
   if qratio>.40:reviews.append(f'Q opener concentration {qratio:.0%}: {qc.most_common(3)}')
   if aratio>.65:reviews.append(f'A opener concentration {aratio:.0%}: {ac.most_common(3)}')
   adjacent=sum(qopen[i]==qopen[i-1] for i in range(1,len(qopen)))
   if adjacent>3:reviews.append(f'adjacent repeated Q openers: {adjacent}')
   # Repeated 5-grams across many pairs can reveal generated template shells.
   ngc=Counter(x for q,a in qps for x in ngrams(q+' '+a,5));repeated=[(x,c) for x,c in ngc.most_common(20) if c>=4]
   if repeated:reviews.append(f'repeated 5-gram shells across >=4 pairs: {repeated[:6]}')
   qrows={'pairCount':len(qps),'qOpenerCounts':dict(qc),'aOpenerCounts':dict(ac),'qMaxOpenerPct':round(qratio,3),'aMaxOpenerPct':round(aratio,3),'adjacentRepeatedQOpeners':adjacent,'repeated5gramShells':repeated}
   if not any('opener concentration' in x or 'repeated 5-gram' in x for x in reviews):passes.append('Q/A controlled variation clear')
 decision='FAIL' if fails else ('REVIEW' if reviews else 'PASS');ident=report_identity(text,combined)
 result={'tool':'rally-naturalness-variance-check.py v7.8.6',**ident,'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'mainMetrics':{'sentenceCount':len(ss),'openerCounts':dict(starts),'maxOpenerPct':round(max_start,3),'semicolonMax':semi,'technicalTermsPer100Words':round(tech_per100,2),'formulaicHits':formula,'engagementBaitStart':bait},'qnaMetrics':qrows,'passes':passes,'reviews':reviews,'fails':fails,'decision':decision}
 Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 md=['# NATURALNESS / CONTROLLED VARIATION AUDIT\n\n',f'Decision: **{decision}**\n\n','## Passes\n']+([f'- {x}\n' for x in passes] or ['- none\n'])+['\n## Review\n']+([f'- {x}\n' for x in reviews] or ['- none\n'])+['\n## Fail\n']+([f'- {x}\n' for x in fails] or ['- none\n'])
 Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f'NATURALNESS VARIANCE: {decision} [review={len(reviews)}, fail={len(fails)}]');sys.exit(1 if decision=='FAIL' else 0)
if __name__=='__main__':main()
