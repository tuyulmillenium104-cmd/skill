---
name: rally-content-engine
version: 7.8.8-portable
entrypoint: README_START_HERE.md
status: active
---

# Rally Content Engine V7.8.8

Read `README_START_HERE.md` first and follow `skills/ACTIVE-PRECEDENCE.md`.

Core operating law:

```text
Brief defines purpose.
Winner DNA supplies mechanisms.
Writer owns voice.
Tools remove risk.
External outcomes are never guaranteed.
```

A valid full run requires:

- complete mission-scoped snapshot;
- requirement provenance;
- generated mission contract;
- relation/media plan;
- lane-aware Winner DNA;
- Loser/Judge DNA;
- Winner Build Spec;
- Pre-Draft Risk Contract;
- natural main content;
- controlled-variation Q&A;
- EP5_PRESSURE report;
- hash-backed final integrity;
- one final combined Markdown deliverable.
