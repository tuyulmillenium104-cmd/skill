# STRESS HANDOFF PACKET

Send this file to the stress session/agent.

Stress agent must:

- evaluate main content only first,
- stop on hard fail or major credible deduction,
- output a stop report if fail,
- create Q&A only after `MAIN_CONTENT_STRESS_PASS`.
