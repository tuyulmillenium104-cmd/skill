# GENERATE OUTPUT FOR STRESS

## Status

```text
MAIN CONTENT CREATIVE DRAFT
Q&A NOT GENERATED
STRESS TEST PENDING
NOT FINAL
```

## Campaign truth lock

- Campaign:
- Address:
- Mission:
- Required relation:
- Required mention(s):
- Required URL(s):
- Required screenshot/media:
- Forbidden claims:
- Forbidden punctuation:
- Source URL if required:

## Creative intelligence

### Crowded / avoid as main hook

- 

### Promising fresh surfaces

- 

### Judge desire signals

- 

### Judge cut signals

- 

## EP surface selected

```text
[selected surface]
```

## Original thesis

```text
This campaign is not only about ____.
It is really about ____.
The human object is ____.
The reader should leave thinking/feeling/choosing ____.
```

## Candidate angles considered

1. 
2. 
3. 
4. 
5. 

## Chosen main content draft

```text
[paste content]
```

## Screenshot / media plan

```text
[what screenshot/media must show; what mismatch would require rewrite]
```

## What not to change unless stress finds hard fail

- 

## Known watch risks before stress

- 

## Stress instruction

Use the Stress Pack. Run fail-fast main-content stress first. Do not generate Q&A unless main content passes.
