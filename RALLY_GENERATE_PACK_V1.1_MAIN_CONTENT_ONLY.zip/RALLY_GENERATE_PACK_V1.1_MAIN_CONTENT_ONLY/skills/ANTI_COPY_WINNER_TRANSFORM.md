# ANTI-COPY WINNER TRANSFORM

Status: ACTIVE
Purpose: prevent winner-pull mining from becoming disguised copy-paste.

## Transform rule

Every winner pattern must be transformed through three layers:

```text
surface expression -> underlying mechanism -> fresh expression
```

## Required fields

For any winner-inspired idea, write:

```md
Winner surface expression:
Underlying winner mechanism:
Why it worked:
Our fresh expression:
Why ours is not a copy:
Mission fit:
```

## Example

Winner surface expression:

```text
claim number
```

Underlying mechanism:

```text
A mundane administrative object that keeps one case coherent across fragmented service providers.
```

Fresh expressions:

```text
lab order
work order
inspection sheet
release note
chain-of-custody log
handoff receipt
```

## Copy-risk levels

### High risk

- same object;
- same opening structure;
- same CTA choices;
- same progression;
- same metaphor with synonym swap.

### Medium risk

- same mechanism but new object;
- similar progression but different example.

### Low risk

- same judge-positive mechanism expressed through a new object, new scenario, and new CTA.

## Final law

If copy-risk is high, do not use the concept.
If copy-risk is medium, add a major twist.
If copy-risk is low, it can proceed to data-judge review.
