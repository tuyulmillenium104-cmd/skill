# ORIGINAL THESIS ENGINE

Status: ACTIVE
Purpose: create winner-level content from first principles before using data as a judge.

## Goal

A winning draft must start from an original thesis, not from a copied winner example.

An original thesis is a sentence that reframes the campaign in a way that is:

- true to the brief;
- concrete enough to understand;
- distinct from crowded submissions;
- useful for explaining the product/protocol;
- capable of generating a strong CTA.

## Step 1 - Wrong assumption

Ask:

```text
What does everyone assume this campaign is about?
Why is that incomplete?
```

Example:

```text
People think Internet Court is about court after a dispute.
But the deeper issue is whether the promise survives the handoff before the dispute.
```

## Step 2 - Human problem

Translate the campaign into a human problem:

```text
What would a normal person recognize immediately?
```

Examples:

- claim number;
- itinerary;
- lab order;
- work order;
- inspection sheet;
- release rule;
- receipt bundle;
- delivery log.

## Step 3 - Contradiction

Build a tension pair:

```text
A works, but B fails.
```

Examples:

```text
The money moved. The promise did not.
The demo looks complete. The deal changes shape.
The app says delivered. The buyer says useless.
```

## Step 4 - Thesis

Write the core thesis:

```text
This campaign matters because [specific hidden problem] needs [specific mechanism].
```

The thesis must not be generic.

Weak:

```text
AI agents need trust.
```

Strong:

```text
Agent commerce needs a way for the promise to survive when work, proof, release, and objection move through different tools.
```

## Step 5 - Concrete object

Pick one object that proves the thesis.

The object must be fresh for the mission and should not simply copy a winner's surface analogy.

## Step 6 - Mechanism bridge

Connect object to product/protocol:

```text
That is where [product] fits: it does [mechanism] so [consequence].
```

## Step 7 - CTA engine

CTA must ask for a concrete choice tied to the thesis.

Template:

```text
Which [specific object/handoff/rule] would you [choose/test/lock] first? Reply: A, B, C, or D.
```

## Step 8 - Data challenge

Only after thesis/object/CTA exist, use data:

- hidden-gate map asks: what could cut this?
- winner-pull map asks: is this strong enough to be praised?
- loser-DNA asks: is it too similar?

Data judges. Data does not write.


## Avoid literal value labels

The system should create a value payload, not necessarily the literal phrase `My rule` or `My test`. Use natural wording that fits the voice. If several recent drafts use the same label, vary it or remove the label entirely.
