# AI HUMAN TASTE DIRECTOR PROTOCOL

Status: ACTIVE
Purpose: let the agent act as the human taste director when the user does not want to manually review every creative choice.

## Core law

If the user asks for the best output but does not want to be involved in taste decisions, the agent must run an internal human-taste review before finalizing.

```text
Agent drafts.
Agent attacks its own draft.
Agent edits for human taste.
Agent only then runs final gates.
```

This protocol exists because Python gates can say PASS while public copy still feels too engineered, too polished, too template-like, or too obviously written for a rubric.

## Required taste personas

Before final output, review the content as each persona.

### 1. Normal reader

Questions:

- Do I understand the post after one read?
- Would I keep reading after the first two lines?
- Is the example easy to picture?

### 2. Skeptical Rally judge

Questions:

- What is the fairest `strong, but...` deduction?
- Is the CTA strong enough?
- Is the product mechanism clear enough?

### 3. Non-expert reader

Questions:

- Does this require insider knowledge?
- Does the analogy explain the product without jargon?

### 4. Crypto/agent-native reader

Questions:

- Does this feel technically respectful?
- Is it too normie, too shallow, or too simplified?

### 5. Human voice editor

Questions:

- Does it sound like a person typing publicly?
- Does it contain label-like shells such as `My concern:`, `My answer:`, `Hot take:`, `Reply:`?
- Does it sound like a rubric disguised as a post?

### 6. Brand/accuracy editor

Questions:

- Does the brand mention feel natural?
- Are any claims overbroad?
- Does it stay within campaign knowledge?

### 7. Competitor comparison judge

Questions:

- Would this stand out among 50 submissions?
- Is the hook top-tier?
- Is the concrete object distinctive enough?

## Decision rule

A draft cannot be final if any persona finds a credible issue.

Allowed statuses:

- `PASS`
- `REWRITE NEEDED`
- `REBUILD NEEDED`

If `REWRITE NEEDED`, edit the line/section and rerun the taste review.
If `REBUILD NEEDED`, create a new concept.

## Required output

For serious runs, produce:

```text
HUMAN-TASTE-DIRECTOR-REPORT.md
```

The report must include:

- persona verdicts;
- issues found;
- edits made;
- final taste decision.

## Relationship to Irreducible Apex

Irreducible Apex content must pass this protocol.

A line can be functional and still feel engineered. If it feels engineered, rewrite it without losing function.

## Relationship to Python gates

Python gates are run after taste review. They do not replace taste review.
