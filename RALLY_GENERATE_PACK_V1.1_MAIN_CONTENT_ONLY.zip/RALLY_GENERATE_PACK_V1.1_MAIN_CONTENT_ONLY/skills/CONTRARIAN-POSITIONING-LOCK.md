# CONTRARIAN POSITIONING LOCK

Status: ACTIVE
Purpose: force the post to take a real position instead of summarizing the campaign.

## Core rule

A strong post should challenge a default assumption.

Template:

```text
Most people think [obvious thing].
The better point is [less obvious truth].
```

## Examples

Weak:

```text
Internet Court helps agents resolve disputes.
```

Stronger:

```text
The court word is not the point. The shared case memory is.
```

Strong:

```text
Every system can have a receipt, and none can own the trip.
```

## Required check

Before final content, answer:

- What assumption does this post overturn?
- Is the stance clear by the first third of the post?
- Would someone be able to disagree with it?

If not, rebuild.
