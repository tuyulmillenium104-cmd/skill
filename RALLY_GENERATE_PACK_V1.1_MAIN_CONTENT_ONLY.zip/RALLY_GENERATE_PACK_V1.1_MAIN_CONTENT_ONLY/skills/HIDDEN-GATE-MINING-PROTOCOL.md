# RALLY HIDDEN-GATE MINING PROTOCOL

Status: ACTIVE  
Purpose: discover judge deduction patterns from real Rally submissions **before** drafting without overfitting other campaigns.

## Core principle

Hidden gates are not automatically global rules.

Every hidden-gate candidate must be scoped before it becomes drafting law:

- `GLOBAL`
- `CAMPAIGN_FAMILY`
- `CAMPAIGN_ONLY`
- `MISSION_ONLY`
- `WATCH`
- `REJECT`

Default scope is **MISSION_ONLY** unless evidence proves broader applicability.

## Why scope matters

Each campaign and mission can reward different behavior. A hidden gate from one mission can damage another mission if promoted globally too early.

Example:

- `Do not frame Internet Court as only dispute resolution` = campaign/mission-specific.
- `CTA must be concrete and answerable` = global principle.
- `Quote-launch post must feel like a reaction to the quoted thread` = campaign-family rule for quote/reply launch missions.

## Scope classification rules

### GLOBAL

Use only if the pattern appears across multiple unrelated campaigns or is universal quality/safety law.

Examples:

- literal brief compliance
- no fabricated claims
- no private skill/checker/audit leakage
- CTA should be answerable and concrete when engagement matters
- avoid generic hype unless the brief explicitly asks for hype

### CAMPAIGN_FAMILY

Use when the pattern applies to a type of mission, not all missions.

Examples:

- Quote/reply launch missions must feel like a response to the source post.
- Product/protocol campaigns need clear mechanism and concrete use case.
- Personal confession campaigns need authentic stake and lived decision.
- Educational explainers need plain-language mechanism and no jargon wall.

### CAMPAIGN_ONLY

Use when the rule belongs to one campaign across multiple missions.

Example:

- Internet Court content must not frame the product as only dispute resolution.

### MISSION_ONLY

Use when the rule belongs only to the current mission.

Examples:

- Use the required quote thread as launch context.
- Mention the required handle exactly once.
- Avoid a saturated motif found only in this mission pool.

### WATCH

Use when evidence is suggestive but not strong enough to become a rule.

### REJECT

Use when the candidate is noise, variance, or would overfit/harm other campaigns.

## Required workflow

Run after DNA fetch/cartography and before drafting:

```bash
python3 skills/rally-hidden-gate-miner.py \
  --submissions rally-data/learn/<addr>/submissions_enriched.json \
  --mission mission-0 \
  --out <run-folder>/hidden-gates
```

Outputs:

- `hidden-gate-candidates.json`
- `HIDDEN-GATE-CANDIDATES.md`
- `HIDDEN-GATE-MANUAL-REVIEW.md`
- `PRE-DRAFT-HIDDEN-GATE-CONTRACT.stub.md`

## Manual review law

Tool output is **not automatically law**.

For each candidate class, decide:

- `ACCEPT` or `WATCH` or `REJECT`
- scope: `GLOBAL`, `CAMPAIGN_FAMILY`, `CAMPAIGN_ONLY`, `MISSION_ONLY`
- whether it should update global skill, a family playbook, or only this run's pre-draft contract

Do not promote to GLOBAL unless there is multi-campaign evidence.

## Mission-specific contract

After manual review, produce a short pre-draft hidden-gate contract:

```md
# PRE-DRAFT HIDDEN-GATE CONTRACT

Campaign:
Mission:
Evidence base:

## Accepted hidden gates
| Rule | Scope | Evidence | Applies now? |
|---|---|---|---|

## Drafting rules for this mission
- ...

## Rebuild triggers
- ...

## Watch-only risks
- ...
```

Content must be drafted against this contract before Python checker runs.

## Non-overfit rule

Prefer principle rules over vocabulary bans.

Bad:

```text
Ban the phrase "missing layer".
```

Good:

```text
If using "missing layer", attach it to a concrete scenario and mechanism within two lines.
```

## Promotion rule

A hidden gate can be promoted upward only after evidence grows:

```text
MISSION_ONLY -> CAMPAIGN_ONLY -> CAMPAIGN_FAMILY -> GLOBAL
```

Never skip straight to GLOBAL from one mission.
