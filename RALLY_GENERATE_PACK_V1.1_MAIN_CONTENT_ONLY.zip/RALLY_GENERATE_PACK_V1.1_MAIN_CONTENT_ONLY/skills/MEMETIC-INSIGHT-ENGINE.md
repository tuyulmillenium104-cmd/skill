# MEMETIC INSIGHT ENGINE

Status: ACTIVE
Purpose: make content not only safe or irreducible, but socially memorable and repeatable.

## Core idea

A winning post should contain a compact idea that people can remember, quote, argue with, or reuse.

```text
No flaw is defense.
Memetic insight is offense.
```

## Required questions before final content

### 1. Cultural tension

What tension does the post expose that readers already feel but may not have named?

Examples:

- every tool can show success, but the whole deal can still fail;
- agents can act, but the promise can lose context;
- payment can clear while proof remains disputed.

### 2. Contrarian truth

What common assumption does the post challenge?

Template:

```text
People think [X]. The sharper truth is [Y].
```

### 3. Meme unit

What is the 5-12 word line someone could quote?

Examples:

```text
Every system has a receipt. None has the whole trip.
The money moved. The promise did not.
Green checks do not equal a finished deal.
```

### 4. Social repeatability

Can the phrase be reused by others without needing the whole post?

If no, sharpen it.

### 5. Debate handle

What can people disagree with or choose between?

Examples:

- Which handoff breaks first?
- Which proof should count?
- Which condition would you lock first?

### 6. Status identity

What identity does replying let the reader perform?

Examples:

- careful builder;
- skeptical operator;
- protocol architect;
- practical user;
- trust/minimization thinker.

## Memetic pass criteria

A draft passes only if it has:

- one quotable compression line;
- one concrete object;
- one debatable or answerable CTA;
- one recognizable human problem;
- one mechanism bridge to the product.

## Failure modes

Reject if:

- the post is clear but not memorable;
- the post is accurate but not repeatable;
- the CTA invites answers but not identity;
- the core line sounds like a product slogan instead of a human observation;
- the insight depends entirely on brand context.

## Relation to Irreducible Apex

Irreducible Apex removes weakness.
Memetic Insight adds spread.

The highest target is:

```text
Memetic Irreducible Apex
```

meaning:

```text
no obvious cuts + strong repeatable idea + human voice + local gates pass.
```
