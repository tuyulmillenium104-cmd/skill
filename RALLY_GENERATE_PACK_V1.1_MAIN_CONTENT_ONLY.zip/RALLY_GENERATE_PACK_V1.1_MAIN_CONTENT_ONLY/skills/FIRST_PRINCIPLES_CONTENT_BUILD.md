# FIRST PRINCIPLES CONTENT BUILD

Status: ACTIVE
Purpose: force original content construction before winner/loser data benchmarking.

## Required pre-draft artifacts

Before writing the final post, create:

1. `ORIGINAL-THESIS.md`
2. `THESIS-OBJECT-CANDIDATES.md`
3. `DATA-JUDGE-REVIEW.md`

## ORIGINAL-THESIS.md

Must contain:

```md
# Original Thesis

## Literal brief

## Wrong assumption

## Human problem

## Core contradiction

## Original thesis

## Mechanism bridge

## CTA idea
```

## THESIS-OBJECT-CANDIDATES.md

Generate at least 3 fresh object candidates.

Example:

```md
| Object | Why it explains the product | Copy-risk vs winners | Keep? |
|---|---|---|---|
| lab order | carries source, temperature, release rule | low | yes |
| claim number | shared case memory | medium if winner used similar | maybe |
| work order | simple operational frame | low | yes |
```

## DATA-JUDGE-REVIEW.md

After the original thesis exists, use winner/loser data to judge it:

```md
# Data Judge Review

## Hidden-gate pressure
- ...

## Winner-pull pressure
- ...

## Loser similarity risk
- ...

## Anti-copy transform
Winner surface pattern:
Underlying mechanism:
Our fresh expression:
Similarity risk:

## Decision
PASS / REBUILD
```

## Drafting law

Do not write final content until the original thesis and data-judge review both pass.

## Rebuild triggers

Rebuild if:

- the draft is mostly a winner-example variant;
- the concrete object is copied from a winner without transformation;
- the thesis is generic;
- the product mechanism is only implied;
- CTA is not tied to the thesis;
- data review says the frame is saturated.


## Value payload is not a label

A draft does not need to say `My rule` or `My test` to be tactical. It needs to give the reader a usable decision, check, or frame. Prefer natural phrasing over repeated labels.
