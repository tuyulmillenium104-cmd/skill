# COMPRESSION VARIANT TOURNAMENT

Status: ACTIVE
Purpose: find the sharpest version of the core insight before finalizing.

## Required mini-tournament for Apex+ content

Before final, generate at least 5 variants of the core compression line.

Example idea:

```text
fragmented systems each have proof, but no shared context
```

Variants:

1. Every system has a receipt. None has the whole trip.
2. Every app can be right, and the deal can still be wrong.
3. The payment cleared. The promise got lost.
4. Green checks do not equal a finished deal.
5. The receipt exists. The context does not.

## Selection criteria

Pick the line that is:

- most human;
- most memorable;
- most accurate;
- shortest without losing meaning;
- easiest to reuse in a quote.

## Warning

Do not pick the most clever line if it weakens clarity.
