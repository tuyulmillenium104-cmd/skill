# CANDIDATE TOURNAMENT PROTOCOL

Status: ACTIVE for Apex/Irreducible runs
Purpose: avoid settling for the first good draft.

## Rule

For Apex or Irreducible content, generate at least:

- 5 hook candidates;
- 3 concrete object/scenario candidates;
- 3 compression-line candidates;
- 3 CTA candidates;
- 3 final draft candidates.

Then select the best combination by:

1. Campaign Ask fit.
2. Rally Judge Desire fit.
3. Human-typed feel.
4. Memetic strength.
5. Known-gate closure.
6. Local gate safety.

## Required output

```text
CANDIDATE-TOURNAMENT.md
```

It should include rejected candidates and why they lost.

## Warning

Do not create Frankenstein content by combining unrelated best lines. The winning draft must have one coherent voice and one coherent thesis.
