# HUMAN TASTE DIRECTOR REPORT TEMPLATE

Campaign:
Mission:
Draft version:
Date:

## Final draft reviewed

```text
...
```

## 1. Normal reader

Verdict: PASS / REWRITE NEEDED / REBUILD NEEDED

What works:

Issue found:

Edit made:

## 2. Skeptical Rally judge

Verdict: PASS / REWRITE NEEDED / REBUILD NEEDED

Strong-but attempt:

Is it credible?

Edit made:

## 3. Non-expert reader

Verdict: PASS / REWRITE NEEDED / REBUILD NEEDED

Confusion point:

Plain-language retell:

Edit made:

## 4. Crypto/agent-native reader

Verdict: PASS / REWRITE NEEDED / REBUILD NEEDED

Technical respect check:

Oversimplification risk:

Edit made:

## 5. Human voice editor

Verdict: PASS / REWRITE NEEDED / REBUILD NEEDED

Template smell:

Label-like phrases found:

Over-polished lines:

Edit made:

## 6. Brand/accuracy editor

Verdict: PASS / REWRITE NEEDED / REBUILD NEEDED

Claim risk:

Brand mention naturalness:

Edit made:

## 7. Competitor comparison judge

Verdict: PASS / REWRITE NEEDED / REBUILD NEEDED

Would it stand out?

What could beat it?

Edit made:

## 8. Final taste decision

Final verdict:

`PASS / REWRITE NEEDED / REBUILD NEEDED`

Reason:

## 9. Lines changed after taste review

| Before | After | Why |
|---|---|---|
|  |  |  |
