# RALLY WINNER-PULL MINING PROTOCOL

Status: ACTIVE
Purpose: mine what real Rally winners are praised for, so content is built to win, not only to avoid loser patterns.

## Core idea

Loser/hidden-gate mining is defense:

```text
What can cause a deduction?
```

Winner-pull mining is offense:

```text
What makes the judge want to award max?
```

A draft must have both:

1. Hidden gates closed.
2. Winner-pull mechanisms present.


## Data does not write

Winner-pull mining must not create the first draft.

First create:

1. original thesis;
2. fresh concrete object;
3. mechanism bridge;
4. CTA idea.

Then use winner-pull data to judge whether the draft has enough positive force.

If the draft starts as a variant of a winner example, reject it or transform it through `ANTI_COPY_WINNER_TRANSFORM.md`.

## What to mine from winners

Do not copy winner text. Extract mechanisms:

- hook mechanism
- concrete scenario type
- mechanism explanation style
- value payload / mental model
- CTA pattern
- voice / persona
- brand bridge style
- structure / pacing
- shareable or quotable line pattern

## Required command

Run after DNA fetch/cartography and before drafting:

```bash
python3 skills/rally-winner-pull-miner.py \
  --submissions <run>/cartography/submissions_enriched.json \
  --mission <mission-id> \
  --out <run>/winner-pull
```

Outputs:

- `winner-pull-map.json`
- `WINNER-PULL-MAP.md`
- `WINNER-PULL-CONTRACT.stub.md`

## Manual review law

The tool finds positive mechanisms. Manual review decides what belongs in the current draft.

For every candidate pull, classify:

- `USE_NOW`: should shape current draft.
- `WATCH`: useful but not required.
- `DO_NOT_COPY`: strong in winner, but too specific/crowded to reuse.

Every accepted pull must be expressed as a mechanism, not a copied phrase.

Example:

Bad:

```text
Use the phrase "claim number" because winner used it.
```

Good:

```text
Use a plain administrative object that makes the workflow concrete, such as claim number, lab order, receipt, itinerary, or work order.
```

## Winner-pull contract

Before drafting, fill:

```md
# WINNER-PULL CONTRACT

## Expected positive verdict lines
1. The judge should praise the hook because...
2. The judge should praise the concrete scenario because...
3. The judge should praise mechanism clarity because...
4. The judge should praise value/CTA because...
5. The judge should praise originality/human voice because...

## Evidence lines planned
- Hook line:
- Scenario line:
- Mechanism line:
- Value rule line:
- CTA line:
```

If you cannot write expected positive verdict lines, do not draft yet.

## Relation to hidden-gate mining

Use both reports:

- `HIDDEN-GATE-CANDIDATES.md` says what can cut us.
- `WINNER-PULL-MAP.md` says what can lift us.

Drafting rule:

```text
No hidden gate open + enough winner pull present.
```
