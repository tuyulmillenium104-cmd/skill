# REPLY IDENTITY TEST

Status: ACTIVE
Purpose: make CTAs create replies that let readers perform an identity.

## Core rule

A CTA should not only be answerable. It should let the reader show who they are.

Examples of reply identities:

- builder: chooses terms or integration;
- operator: chooses proof or release;
- skeptic: chooses appeal;
- user: chooses the handoff they have personally seen break.

## Required check

For the CTA, answer:

- What identity does replying perform?
- Is the answer easy in under 5 seconds?
- Are the options concrete?
- Does the CTA reopen the same conflict as the post?

If no, rewrite CTA.
