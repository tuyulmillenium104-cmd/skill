# AUDIENCE PSYCHOLOGY MAP

Status: ACTIVE
Purpose: ensure the post is written for real readers, not only for a judge.

## Reader triggers

A strong Rally post should trigger at least two of these:

- recognition: "I have seen this problem";
- fear: "this can break real deals";
- status: "replying makes me look thoughtful";
- utility: "I learned a useful test";
- curiosity: "I want to know how this resolves";
- disagreement: "I have a different answer";
- clarity: "I finally get the product".

## Required map

Before final content, write:

```text
Primary emotion:
Secondary emotion:
Reader identity invited by CTA:
What makes a reader reply:
What makes a reader quote:
What makes a reader trust the post:
```

## Red flags

- The post informs but does not make anyone feel anything.
- The CTA asks a question but does not let the reader perform identity.
- The example is concrete but emotionally flat.
- The post is only for experts when the mission asks broad explanation.
