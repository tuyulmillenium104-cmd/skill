# SCENE VIVIDNESS CHECK

Status: ACTIVE
Purpose: ensure concrete examples feel seen, not merely named.

## Core rule

A scenario must be visual enough that the reader can picture it.

## Scene requirements

A strong scene includes at least three of:

- person/agent role;
- location or context;
- task;
- evidence object;
- system success signal;
- failure signal;
- disputed handoff.

## Questions

- Can the reader picture the scene?
- Does the scene prove the thesis?
- Does the scene make the product feel necessary?
- Is any detail decorative rather than functional?

## Red flags

- Generic "two agents disagree" with no object.
- A list of stack layers without a scene.
- A scenario that could fit any product.
