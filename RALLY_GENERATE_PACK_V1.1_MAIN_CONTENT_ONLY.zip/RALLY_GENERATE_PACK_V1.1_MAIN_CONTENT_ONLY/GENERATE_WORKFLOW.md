# GENERATE WORKFLOW - MAIN CONTENT ONLY

## Purpose

Create the strongest possible main content draft without turning public copy into checker output.

## Correct order

```text
Truth lock -> creative intelligence -> EP surface -> original thesis -> candidate tournament -> main content draft -> stress handoff
```

## What generate must know before writing

- Literal campaign ask.
- Required mention(s).
- Required URL(s).
- Required screenshot/media.
- Relation type: original / quote / reply.
- Forbidden punctuation and claims.
- Crowded angles/language to avoid as main hook.
- Winner/judge desire signals as direction, not wording.
- Screenshot/product surface available.

## What generate must not do

- Do not write Q&A.
- Do not claim final pass.
- Do not run stress gates as writing law.
- Do not copy winner examples.
- Do not force decision-marker or Q&A quota language.

## Required deliverable

One file:

```text
GENERATE_OUTPUT_FOR_STRESS.md
```

Optional clean copy:

```text
content.txt
```

Status must remain:

```text
STRESS TEST PENDING
```
