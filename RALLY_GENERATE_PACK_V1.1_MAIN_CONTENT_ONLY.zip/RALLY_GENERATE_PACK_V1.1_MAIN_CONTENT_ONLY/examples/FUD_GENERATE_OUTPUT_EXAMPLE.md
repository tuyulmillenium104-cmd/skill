# Example - Generate output shape only

Status:

```text
MAIN CONTENT CREATIVE DRAFT
Q&A NOT GENERATED
STRESS TEST PENDING
NOT FINAL
```

EP surface:

```text
messy FUD board as CT before cleanup
```

Draft example:

```text
The FUD homepage is messy in the right way.

Green-candle calls beside panic bait.
24h lines beside is-it-dead boards.
Sports sitting next to meme tickers.

That is not a clean dashboard. It is CT before the cleanup.
```

Do not copy as a template. It is an output-shape example only.
