#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DNA confidence reporter for Rally mission-scoped DNA."""
import argparse, json, sys, time
from pathlib import Path

def level(score):
    if score >= 80: return "HIGH"
    if score >= 50: return "MEDIUM"
    return "LOW"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dna", required=True)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    d = json.load(open(args.dna, encoding="utf-8"))
    winners = int(d.get("winners", len(d.get("winnerDNA", []))))
    nonw = int(d.get("nonWinners", len(d.get("nonWinnerDNA", []))))
    total = int(d.get("totalSubmissions", winners + nonw))
    cr = d.get("contentRetrieval", {})
    full = int(cr.get("fullContent", 0))
    failed = int(cr.get("failed", 0))
    full_cov = (full / total * 100) if total else 0
    score = 0
    score += min(35, winners * 12)          # 3 winners ~= strong anchor
    score += min(25, nonw / 4)              # 100 non-winners ~= 25
    score += min(25, full_cov * 0.25)       # 100% coverage ~= 25
    score += 15 if failed == 0 else max(0, 15 - failed * 3)
    lvl = level(score)
    strategy = {
        "HIGH": "Follow mission-scoped winner DNA strongly, still run loser sterilization.",
        "MEDIUM": "Use winner DNA as anchor, combine near-winners, loser-DNA sterilization, and brief-first reasoning.",
        "LOW": "Do not overfit winner DNA. Use brief-first, projected judge language, and strict #0R/#0S2.",
    }[lvl]
    md = f"""# DNA CONFIDENCE REPORT

Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}

Campaign: {d.get('campaign')}  
Mission: {d.get('mission')}  
Total submissions: {total}  
Winners: {winners}  
Non-winners: {nonw}  
Full content coverage: {full}/{total} ({full_cov:.1f}%)  
Failed content retrieval: {failed}

## Confidence

Score: {score:.1f}/100  
Level: **{lvl}**

## Operating Strategy

{strategy}
"""
    if args.out:
        Path(args.out).write_text(md, encoding="utf-8")
    print(md)
    sys.exit(0)

if __name__ == "__main__":
    main()
