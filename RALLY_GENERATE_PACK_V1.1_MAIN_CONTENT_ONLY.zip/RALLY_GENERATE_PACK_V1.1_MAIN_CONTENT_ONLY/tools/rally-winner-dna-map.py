#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Adaptive winner DNA mapper from mission-scoped winners and near-winners."""
import argparse,json,re,time,statistics
from pathlib import Path

def paras(t): return [p.strip() for p in re.split(r"\n\s*\n", t or "") if p.strip()]
def toks(t): return re.findall(r"[a-z0-9@']+", (t or "").lower())
def opener_type(text):
    first=paras(text)[0] if paras(text) else (text or "")[:120]
    fl=first.lower()
    if "?" in first: return "question"
    if any(x in fl for x in ["hot take", "unpopular", "controversial"]): return "hot_take"
    if any(x in fl for x in ["i ", "my ", "i've", "i’m", "i'm"]): return "personal_confession"
    if any(x in fl for x in ["most ", "the problem", "nobody", "everyone"]): return "general_contrast"
    return "declarative"

def cta_tail(text):
    ps=paras(text)
    return ps[-1] if ps else ""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--submissions",required=True)
    ap.add_argument("--out-json",required=True)
    ap.add_argument("--out-md",required=True)
    args=ap.parse_args()
    subs=json.load(open(args.submissions,encoding="utf-8"))
    winners=[]
    for s in subs:
        gates=s.get("gates") or {}
        ep=gates.get("EP",[0])[0] if "EP" in gates else 0
        oaa=gates.get("OAA",[0])[0] if "OAA" in gates else 0
        tq=gates.get("TQ",[0])[0] if "TQ" in gates else 0
        if s.get("winner") or (ep==5 and oaa==2 and tq>=4): winners.append(s)
    rows=[]
    for s in winners:
        text=s.get("content") or ""
        ps=paras(text)
        mention_pos=((__import__("re").search(r"@[A-Za-z0-9_]+", text).start()/len(text)*100) if (__import__("re").search(r"@[A-Za-z0-9_]+", text) and len(text)>0) else None)
        rows.append({"author":s.get("xUsername"),"chars":len(text),"paragraphs":len(ps),"openerType":opener_type(text),"mentionPosPct":mention_pos,"ctaTail":cta_tail(text),"content":text[:1200],"gates":{k:v[0] for k,v in (s.get("gates") or {}).items()}})
    opener_counts={}
    for r in rows: opener_counts[r["openerType"]]=opener_counts.get(r["openerType"],0)+1
    mention_vals=[r["mentionPosPct"] for r in rows if r["mentionPosPct"] is not None]
    result={"tool":"rally-winner-dna-map.py","generated":time.strftime("%Y-%m-%d %H:%M:%S"),"winnerLikeCount":len(rows),"openerCounts":opener_counts,"charMedian":statistics.median([r['chars'] for r in rows]) if rows else 0,"paragraphMedian":statistics.median([r['paragraphs'] for r in rows]) if rows else 0,"mentionPosMedian":statistics.median(mention_vals) if mention_vals else None,"rows":rows[:100]}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[]
    md.append("# WINNER DNA MAP\n\n")
    md.append(f"Winner-like samples: **{len(rows)}**\n\n")
    md.append(f"Median chars: **{result['charMedian']}**  \nMedian paragraphs: **{result['paragraphMedian']}**  \nMention position median: **{result['mentionPosMedian']}**\n\n")
    md.append("## Opener Types\n\n")
    for k,v in sorted(opener_counts.items(), key=lambda x:x[1], reverse=True): md.append(f"- {k}: {v}\n")
    md.append("\n## Samples\n\n")
    for r in rows[:40]:
        md.append(f"### @{r['author']} — {r['chars']} chars — {r['openerType']}\n")
        md.append(f"CTA tail: `{r['ctaTail'][:240]}`\n\n")
        md.append(f"```text\n{r['content']}\n```\n\n")
    Path(args.out_md).write_text("".join(md),encoding="utf-8")
    print(f"WINNER DNA MAP: {len(rows)} winner-like samples")
if __name__=="__main__": main()
