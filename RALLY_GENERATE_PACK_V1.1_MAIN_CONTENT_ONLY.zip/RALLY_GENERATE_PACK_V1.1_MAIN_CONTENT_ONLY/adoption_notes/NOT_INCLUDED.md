# Not included in Generate Pack

Final stress gates, Q&A scoring, final integrity, one-shot auto-writer, old examples as templates, and guarantee language are intentionally excluded from generate authority.
