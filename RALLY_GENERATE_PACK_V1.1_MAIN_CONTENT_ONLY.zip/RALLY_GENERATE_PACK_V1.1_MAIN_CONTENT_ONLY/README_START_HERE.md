# RALLY GENERATE PACK V1.1 - MAIN CONTENT ONLY

Purpose: generate **main Rally content only** plus one stress-handoff Markdown file.

This pack must not produce final Q&A and must not claim final PASS.

## Role split

```text
Generate pack = Creator / Writer
Stress pack = Rally Stress Judge / Red Team
```

## Output status

Every output from this pack must say:

```text
MAIN CONTENT CREATIVE DRAFT
Q&A NOT GENERATED
STRESS TEST PENDING
NOT FINAL
```

## Core law

```text
Campaign Ask x Rally Judge Desire
Data does not write. Data judges.
```

## Generate workflow

1. Mission truth lock.
2. Requirement provenance.
3. Relation/media plan.
4. Data sufficiency and saturation map as creative compass only.
5. EP surface selection.
6. Original thesis.
7. Candidate angle tournament.
8. AI Human Taste Director selection.
9. Main content draft only.
10. One Markdown handoff file for stress.

## Hard boundary

Do not make Q&A in this pack. Q&A is created only after the stress pack gives `MAIN_CONTENT_STRESS_PASS`.

Do not claim:

```text
guaranteed all-max
guaranteed winner
guaranteed top 1%
guaranteed RQ5
Known-Gate Absolute PASS
```

## Read order

1. `GENERATE_WORKFLOW.md`
2. `templates/GENERATE_OUTPUT_FOR_STRESS_TEMPLATE.md`
3. `templates/STRESS_HANDOFF_PACKET_TEMPLATE.md`
4. `skills/RALLY-FUNDAMENTAL-LAW.md`
5. `skills/EP-SURFACE-SELECTION-PROTOCOL.md`
