# REAL VERDICT LESSON - 2026-07-18 - Internet Court mission-1

Source: user-pasted real Rally judge verdict for content beginning:

```text
I finally understood this launch through a lost-bag tag.
```

## Real scores observed

- Engagement Potential: 4 / 5
- Technical Quality: 5 / 5
- Reply Quality: 3 / 5
- Engagement metrics: Retweets 6, Likes 96, Replies 12, Followers of Repliers 28,361, Impressions 925

## What the judge liked

EP positives:
- strong hook through concrete lost-luggage analogy,
- storytelling made abstract technical concept tangible,
- strong line-break rhythm and visual breathing room,
- analogy mapped cleanly onto fragmented agentic commerce stack,
- CTA was genuinely strong: `Which handoff would you choose to stress test first: terms, proof, release, or appeal?`,
- specific choice-style CTA lowered reply barrier and invited technical opinions,
- avoided generic hype and fulfilled campaign mission.

TQ:
- 5 / 5.

RQ positives:
- replies engaged with lost-bag metaphor,
- several replies raised genuine architectural questions,
- examples: raw records vs agreed fields, booking vs dispute timing, missing evidence, partial truth, local receipts vs live itinerary.

## What the judge cut

EP cut from 5 to 4:
- relatively niche technical audience: agentic commerce / AI agents,
- may limit broad virality,
- moderate impression count 925 suggested limited distribution.

Important scope:
- impression count/distribution is partly external and cannot be fully controlled by content gates.
- niche-audience breadth can be partially controlled by broader analogy/object choice.

RQ cut from potential high score to 3:
- repeated formulaic public reply pattern,
- judge explicitly flagged phrases like `My concern is...` and `My decision is...`,
- many replies started with same mention and similar sentence structures,
- replies had substance, but set-level authenticity felt coordinated/templated.

## Correction to local system

Previous local Gold V3 checks over-rewarded decision-marker coverage and allowed too many repeated decision shells. This was wrong.

New rule:
- Decision-marker presence is not enough.
- Repeated shell phrases are a real Rally RQ risk even when content is substantive.
- Public Q/A must vary natural entry points and cannot repeatedly use:
  - `My concern is...`
  - `My decision is...`
  - `My answer is...`
  - `Hot take, ...`
  - repeated direct @mention starts

## Patch applied

- `skills/rally-human-typed-audit.py` now flags repeated real-judge formula Q shells and repeated mention starts.
- `skills/rally-rq-v3-policy-check.py` now enforces caps for:
  - `myConcernStartPct <= 10%`
  - `myAnswerStartPct <= 10%`
  - `formulaStartPct <= 35%`
  - `mentionStartPct <= 25%`
- `skills/rq-gold-policy-v3.json` version updated to `3.1.4-real-rq-formula-cap`.

## Future workflow consequence

A Q/A set can no longer be called Gold local PASS if it passes substance checks but has repeated formulaic public shells. Substance and naturalness must both pass.

## Honest interpretation

The content itself was strong but not EP5. Local Irreducible Apex / Known-Gate Absolute was too optimistic for external EP because broadness/distribution was not fully closed. RQ local pass was specifically wrong because it missed formulaic reply-set smell.
