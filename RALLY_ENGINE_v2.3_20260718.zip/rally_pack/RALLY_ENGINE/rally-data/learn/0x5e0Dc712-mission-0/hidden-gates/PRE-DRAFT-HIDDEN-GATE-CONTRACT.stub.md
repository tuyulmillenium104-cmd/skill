# PRE-DRAFT HIDDEN-GATE CONTRACT STUB - mission-0

Fill this manually after reviewing `HIDDEN-GATE-CANDIDATES.md`. Do not promote mission rules globally without evidence.

## Accepted hidden gates for this mission

| Rule | Scope | Evidence | Why it applies now |
|---|---|---|---|
|  | MISSION_ONLY |  |  |

## Drafting rules for this mission

- 

## Watch-only risks

- 

## Rebuild triggers

- 
