# Hidden Gate Candidate Map - mission-0

- Submissions: 44
- Winners: 1
- Deduction candidate sentences: 2192

## Top candidate classes

| Class | Total | Non-winner | Winner | EP<5 | EP5 | Manual status |
|---|---:|---:|---:|---:|---:|---|
| brand_bridge_promotional | 561 | 555 | 6 | 124 | 2 | KNOWN |
| cta_reply_engine | 520 | 512 | 8 | 207 | 0 | KNOWN |
| unknown_or_nuance | 481 | 481 | 0 | 73 | 0 | REVIEW/UNKNOWN |
| distinctiveness_saturation | 387 | 382 | 5 | 45 | 2 | KNOWN |
| media_format_technical | 313 | 313 | 0 | 31 | 0 | KNOWN |
| readthrough_density | 287 | 283 | 4 | 90 | 1 | KNOWN |
| hook_stop_power | 191 | 190 | 1 | 87 | 0 | KNOWN |
| concrete_specificity | 188 | 185 | 3 | 53 | 2 | KNOWN |
| rq_reply_quality | 161 | 156 | 5 | 41 | 0 | KNOWN |
| tactical_value_payload | 128 | 127 | 1 | 67 | 2 | KNOWN |
| mechanism_clarity | 118 | 117 | 1 | 24 | 0 | KNOWN |
| accuracy_claim_boundary | 104 | 104 | 0 | 11 | 0 | KNOWN |

## Gate x class counts

- **EP / cta_reply_engine**: 207
- **TQ / media_format_technical**: 166
- **RQ / cta_reply_engine**: 157
- **OAA / distinctiveness_saturation**: 154
- **CC / unknown_or_nuance**: 154
- **EP / brand_bridge_promotional**: 126
- **OAA / brand_bridge_promotional**: 106
- **RQ / rq_reply_quality**: 105
- **TQ / readthrough_density**: 93
- **EP / readthrough_density**: 91
- **TQ / unknown_or_nuance**: 90
- **EP / hook_stop_power**: 87
- **RQ / distinctiveness_saturation**: 82
- **TQ / brand_bridge_promotional**: 82
- **CC / brand_bridge_promotional**: 80
- **OAA / unknown_or_nuance**: 76
- **EP / unknown_or_nuance**: 73
- **CC / media_format_technical**: 71
- **CA / brand_bridge_promotional**: 70
- **EP / tactical_value_payload**: 69
- **IA / accuracy_claim_boundary**: 60
- **CC / cta_reply_engine**: 60
- **TQ / mechanism_clarity**: 57
- **EP / concrete_specificity**: 55
- **IA / brand_bridge_promotional**: 53
- **TQ / cta_reply_engine**: 48
- **EP / distinctiveness_saturation**: 47
- **RQ / brand_bridge_promotional**: 44
- **CC / distinctiveness_saturation**: 43
- **RQ / concrete_specificity**: 43
- **CC / readthrough_density**: 43
- **EP / rq_reply_quality**: 41
- **CA / unknown_or_nuance**: 41
- **OAA / hook_stop_power**: 37
- **OAA / concrete_specificity**: 36
- **CA / distinctiveness_saturation**: 33
- **EP / media_format_technical**: 31
- **OAA / readthrough_density**: 30
- **OAA / cta_reply_engine**: 28
- **CA / readthrough_density**: 24

## Evidence examples by gate/class

### CA / accuracy_claim_boundary
- @bencrypz [NONWIN, gateScore=2.0]: Message accuracy is high: it correctly frames FUD as a place where Crypto Twitter takes become markets and positions, using core campaign language like "the take becomes a market," "LONG or SHORT," and emphasizing real interaction with the product.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Message accuracy is high: it clearly communicates the core FUD thesis that Crypto Twitter takes should become tradable positions, using language like 'turns the take into a market,' 'take a side,' and 'fade it,' which closely matches the campaign goal and knowledge base.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Still, this is a minor issue relative to its strong factual alignment, terminology accuracy, product usage proof, and campaign-fit angle.
- @ahonjumaidil [NONWIN, gateScore=2.0]: Overall this is a very strong campaign fit, with only minor deduction for the slightly link-heavy close and the fact that product interaction is implied rather than deeply described.
- @shuyue_ai [NONWIN, gateScore=2.0]: Message Accuracy: It correctly presents FUD as a place where CT takes become positions, emphasizing accountability, live markets, and real usage rather than vague awareness.

### CA / brand_bridge_promotional
- @0xqingmei [NONWIN, gateScore=2.0]: It avoids obvious corporate ad language and does not rely on generic hype.
- @dennis92z [NONWIN, gateScore=2.0]: It accurately captures the core value proposition by explicitly explaining how FUD transforms fleeting Crypto Twitter predictions into tradable LONG/SHORT positions, directly mirroring the campaign's central thesis.
- @bencrypz [NONWIN, gateScore=2.0]: Message accuracy is high: it correctly frames FUD as a place where Crypto Twitter takes become markets and positions, using core campaign language like "the take becomes a market," "LONG or SHORT," and emphasizing real interaction with the product.
- @bencrypz [NONWIN, gateScore=2.0]: Terminology usage is strong and campaign-consistent: CT, LONG/SHORT, market, product screen, and FUD Points Season 1 are all used naturally and correctly in a crypto-native way.
- @bencrypz [NONWIN, gateScore=2.0]: It also explicitly references the campaign thesis that CT takes should become positions.

### CA / concrete_specificity
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Still, this is a minor issue relative to its strong factual alignment, terminology accuracy, product usage proof, and campaign-fit angle.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: It strongly suggests real product usage, though it does not explicitly describe a specific market the author personally opened or interacted with in detail.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: Minor weaknesses: the copy is somewhat long and more polished than the ideal brief prefers, and it does not explicitly document a specific market interaction beyond the screenshot/activity reference.
- @lovaniceth [NONWIN, gateScore=2.0]: It clearly shows real product usage by citing specific live markets ($ANSEM, $WIF) and their exact odds, moving far beyond generic awareness.
- @shuyue_ai [NONWIN, gateScore=2.0]: Weaknesses: The only minor gap is that while it implies product use and a screenshot is attached, the text does not explicitly describe a specific market the user opened or interacted with, which would have made it even stronger as proof-of-use.

### CA / cta_reply_engine
- @hexzypher [NONWIN, gateScore=2.0]: The tone is punchy, direct, and avoids generic AI-style over-explanation, ending with a strong call to action that encourages community interaction.
- @bencrypz [NONWIN, gateScore=2.0]: Message accuracy is high: it correctly frames FUD as a place where Crypto Twitter takes become markets and positions, using core campaign language like "the take becomes a market," "LONG or SHORT," and emphasizing real interaction with the product.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: Minor weaknesses: the copy is somewhat long and more polished than the ideal brief prefers, and it does not explicitly document a specific market interaction beyond the screenshot/activity reference.
- @mjavad7596 [NONWIN, gateScore=2.0]: While slightly longer than the ideal punchy format, it remains direct, product-driven, and highly effective at driving community growth and engagement.
- @ahonjumaidil [NONWIN, gateScore=2.0]: Overall this is a very strong campaign fit, with only minor deduction for the slightly link-heavy close and the fact that product interaction is implied rather than deeply described.

### CA / distinctiveness_saturation
- @mdmarufgnoma [NONWIN, gateScore=2.0]: It feels authentic and user-driven, not like generic AI copy.
- @0xqingmei [NONWIN, gateScore=2.0]: It avoids obvious corporate ad language and does not rely on generic hype.
- @0xqingmei [NONWIN, gateScore=2.0]: The only minor drawback is that the post is somewhat long and polished for the style guide, but it still reads like an authentic user take rather than a press release.
- @hexzypher [NONWIN, gateScore=2.0]: The tone is punchy, direct, and avoids generic AI-style over-explanation, ending with a strong call to action that encourages community interaction.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: That is a strong campaign-fit angle because it gives a real take rather than generic promotion.

### CA / hook_stop_power
- @0xqingmei [NONWIN, gateScore=2.0]: The tone is crypto-native, sharp, and product-driven rather than corporate, and the opening line creates tension and curiosity as requested.
- @ahonjumaidil [NONWIN, gateScore=2.0]: The opening sentence creates immediate tension and curiosity, and the post feels crypto-native, direct, and trader-oriented rather than corporate or polished.
- @carte_free [NONWIN, gateScore=2.0]: Brand consistency is good overall: the opening creates curiosity and tension, the tone is crypto-native and product-driven, and it feels like a real user testimonial rather than a corporate ad.
- @cryptodragon [NONWIN, gateScore=2.0]: It opens with a compelling hook about discovering FUD's settlement system ('the missing piece of onchain economies being neutral adjudication'), which creates genuine intrigue.
- @janumetax [NONWIN, gateScore=1.0]: The message accurately represents FUD's core value proposition—turning CT takes into tradable positions—and correctly uses terminology like 'open a market, take a side.' The hook 'CT is full of opinions' creates tension effectively.

### CA / mechanism_clarity
- @trita_a [WIN, gateScore=2.0]: The content uses the recommended sharp, crypto-native tone and includes the required hooks like 'CT has been calling tops and bottoms for free for too long.' It correctly integrates key technical updates such as Solana deposits, Season 1 points, and weekly shipping.
- @cryptodragon [NONWIN, gateScore=2.0]: The reference link formatting is slightly off (double slash in one instance), but this is a minor technical issue.
- @cuemnee [NONWIN, gateScore=2.0]: The author correctly explains the core mechanic - CT takes becoming markets rather than disappearing into the timeline.
- @rasdamsama [NONWIN, gateScore=2.0]: It clearly explains why FUD is interesting: not just speculation, but accountability and conviction.
- @akashmintx [NONWIN, gateScore=2.0]: The framing resonates with traders who understand the concept of 'pricing conviction.' The content is not generic AI copy and feels authentic.

### CA / media_format_technical
- @mjavad7596 [NONWIN, gateScore=2.0]: While slightly longer than the ideal punchy format, it remains direct, product-driven, and highly effective at driving community growth and engagement.
- @emef0815 [NONWIN, gateScore=2.0]: The tweet includes the required links and hashtag-free style, and it does not use em dashes or make promises about financial outcomes.
- @ahonjumaidil [NONWIN, gateScore=2.0]: However, it leans somewhat into promotional link listing at the end, and the screenshot requirement cannot be verified from the tweet text alone, though the thread metadata shows a photo is present.
- @ahonjumaidil [NONWIN, gateScore=2.0]: Overall this is a very strong campaign fit, with only minor deduction for the slightly link-heavy close and the fact that product interaction is implied rather than deeply described.
- @kmwscan18970 [NONWIN, gateScore=2.0]: 7. **Minor Issues:** The URL has a formatting artifact (fud.markets,/) but the link is present.

### CA / readthrough_density
- @0xqingmei [NONWIN, gateScore=2.0]: The only minor drawback is that the post is somewhat long and polished for the style guide, but it still reads like an authentic user take rather than a press release.
- @dennis92z [NONWIN, gateScore=2.0]: It accurately captures the core value proposition by explicitly explaining how FUD transforms fleeting Crypto Twitter predictions into tradable LONG/SHORT positions, directly mirroring the campaign's central thesis.
- @trita_a [WIN, gateScore=2.0]: The content uses the recommended sharp, crypto-native tone and includes the required hooks like 'CT has been calling tops and bottoms for free for too long.' It correctly integrates key technical updates such as Solana deposits, Season 1 points, and weekly shipping.
- @bencrypz [NONWIN, gateScore=2.0]: Message accuracy is high: it correctly frames FUD as a place where Crypto Twitter takes become markets and positions, using core campaign language like "the take becomes a market," "LONG or SHORT," and emphasizing real interaction with the product.
- @bencrypz [NONWIN, gateScore=2.0]: Terminology usage is strong and campaign-consistent: CT, LONG/SHORT, market, product screen, and FUD Points Season 1 are all used naturally and correctly in a crypto-native way.

### CA / rq_reply_quality
- @kbgold77 [NONWIN, gateScore=2.0]: While the post is on the longer side (958 characters), it remains substantive and reads as authentic user testimony rather than press-release copy.
- @rasdamsama [NONWIN, gateScore=2.0]: That is a differentiated value proposition and feels like a real user insight rather than generic praise.
- @irzarag [NONWIN, gateScore=1.0]: The biggest issue is target/action alignment: the mission requires real product usage and a screenshot, and while this thread includes an image URL, the tweet itself is more of a commentary post plus referral link spam than a sharp proof-driven submission.

### CA / tactical_value_payload
- @dennis92z [NONWIN, gateScore=2.0]: It accurately captures the core value proposition by explicitly explaining how FUD transforms fleeting Crypto Twitter predictions into tradable LONG/SHORT positions, directly mirroring the campaign's central thesis.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: It also reinforces the product-led value proposition by contrasting FUD with generic consumer crypto apps and copycat prediction markets.
- @rasdamsama [NONWIN, gateScore=2.0]: That is a differentiated value proposition and feels like a real user insight rather than generic praise.
- @_maki29_ [NONWIN, gateScore=2.0]: Value proposition alignment is good but not complete: the post clearly communicates that the product is evolving quickly and encourages users to open the app and explore it themselves, which supports community growth and product discovery.
- @phuthach9837 [NONWIN, gateScore=2.0]: This is a minor but clear rule violation.

### CA / unknown_or_nuance
- @bencrypz [NONWIN, gateScore=2.0]: The tone is sharp, direct, trader-native, and product-led rather than corporate.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: The copy sounds like a real user with an opinion rather than a corporate ad.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: The tweet speaks directly to CT users, references memecoin distraction and narrative markets, and addresses a core audience pain point: consumer crypto often lacks real products with active usage.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: But these are small issues relative to its strong compliance and message fit.
- @yantowid1 [NONWIN, gateScore=2.0]: The content features a real screenshot showing product usage (FUD Points Season 1) and provides a sharp, crypto-native 'take' about the lack of consequences for CT calls.

### CC / accuracy_claim_boundary
- @carte_free [NONWIN, gateScore=1.0]: It also includes media, specifically photos (tweet_subtype.has_media=true, media_types=["photo"]), which supports the required screenshot rule; while the actual image contents are not directly inspectable here, the text references FUD Points, leaderboard ranks, and active usage, making the screenshot claim credible and consistent with the campaign.
- @akashmintx [NONWIN, gateScore=2.0]: But the programmatic check marked SATISFIED, which in this context likely means the check passed (no em dashes found).

### CC / brand_bridge_promotional
- @_dripxel [NONWIN, gateScore=2.0]: Style matches campaign (punchy, trader-native, product-driven, not AI-generic or link-spam).
- @0xqingmei [NONWIN, gateScore=2.0]: However, because has_media=true and the campaign’s required screenshot criterion is supported by the submission structure, I treat this as satisfied.
- @bencrypz [NONWIN, gateScore=2.0]: Minor caveat: while the text says the screenshot is real, the structured data only confirms a photo attachment and not the image contents themselves; however, the campaign explicitly allows any live FUD product screen and the post’s wording strongly indicates compliance.
- @bencrypz [NONWIN, gateScore=2.0]: Overall, this is not just minimally compliant but a strong submission that aligns closely with campaign mission, content angle, required links, mention, and proof-of-use expectations.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: There are no mandatory hashtags specified in the campaign materials, so the absence of hashtags is not a compliance issue.

### CC / concrete_specificity
- @bencrypz [NONWIN, gateScore=2.0]: Overall, this is not just minimally compliant but a strong submission that aligns closely with campaign mission, content angle, required links, mention, and proof-of-use expectations.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: However, the submission violates a specific stylistic prohibition: it uses a long-form post with 'long polished AI-style paragraphs' and 'corporate/press release' tone, which contradicts the 'punchy', 'trader-native', and 'not generic AI copy' requirements.
- @anhtunbi536660 [NONWIN, gateScore=2.0]: The post is clearly not generic AI copy or low-effort engagement farming - it tells a personal story about product usage with authentic insights.
- @carte_free [NONWIN, gateScore=1.0]: No specific day/time restrictions are provided, so timing is compliant by default.
- @lovaniceth [NONWIN, gateScore=2.0]: The content demonstrates genuine product usage by citing specific markets and odds ($ANSEM at 2.8x, $WIF at 1.9x), which aligns with the campaign goal of showing real interaction rather than generic awareness.

### CC / cta_reply_engine
- @dennis92z [NONWIN, gateScore=2.0]: Formatting aligns with X longform standards, and the post demonstrates genuine product engagement while clearly articulating the platform's utility.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Objective engagement metrics are not specified as requirements, though public_metrics are healthy.
- @m_amarudinn2 [NONWIN, gateScore=2.0]: Engagement metrics are low to modest, but there is no minimum engagement requirement in the campaign brief, so that does not affect compliance.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: The post successfully includes all mandatory elements: @FUDmarkets mention, the platform URL, the Discord invite link, and a screenshot (verified via urls_expanded).
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: Engagement metrics are high (74 likes, 6745 impressions).

### CC / distinctiveness_saturation
- @_dripxel [NONWIN, gateScore=2.0]: Style matches campaign (punchy, trader-native, product-driven, not AI-generic or link-spam).
- @0x_4444 [NONWIN, gateScore=2.0]: It avoids prohibited content like em dashes, financial advice, airdrop language, token allocation claims, and generic AI text.
- @0xqingmei [NONWIN, gateScore=2.0]: The tone is sharp and product-aware rather than corporate or generic AI.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Content-wise, it contains a real product take rather than generic promotion: it explains the core thesis that CT takes become markets/positions, references product usage, and mentions recent updates like FUD Points Season 1, badges, creator quests, community XP, Solana USDC deposits, and new markets.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: However, the submission violates a specific stylistic prohibition: it uses a long-form post with 'long polished AI-style paragraphs' and 'corporate/press release' tone, which contradicts the 'punchy', 'trader-native', and 'not generic AI copy' requirements.

### CC / hook_stop_power
- @yantowid1 [NONWIN, gateScore=2.0]: The content follows the 'crypto-native' and 'punchy' style guidelines, using one of the suggested opening hooks ('CT has been calling tops and bottoms for free for too long').
- @kbgold77 [NONWIN, gateScore=1.0]: The tweet meets all mandatory structural and programmatic requirements: it includes @FUDmarkets (mentions_usernames), the https://fud.markets URL, the recommended FUD Discord invite link (https://discord.gg/74hqWD75A), and contains attached media (photos, per media_types and urls_expanded) that contextually align with the required FUD screenshot since the author references opening a real position (Argentina vs.
- @emef0815 [NONWIN, gateScore=2.0]: The first sentence creates curiosity by highlighting FUD Points and 'Week 0', and the entire post avoids prohibited content like generic AI text, financial advice, or airdrop language.
- @ahonjumaidil [NONWIN, gateScore=1.0]: Content is aligned with the campaign goal and style: it gives a real user take about opening FUD and turning opinions into positions, which matches the campaign’s crypto-native, product-driven angle.
- @kmwscan18970 [NONWIN, gateScore=1.0]: - First sentence 'FUD Points Season 1 makes more sense after actually using the product' creates curiosity

### CC / mechanism_clarity
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Content-wise, it contains a real product take rather than generic promotion: it explains the core thesis that CT takes become markets/positions, references product usage, and mentions recent updates like FUD Points Season 1, badges, creator quests, community XP, Solana USDC deposits, and new markets.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: While it meets all technical requirements, the style is slightly too formal/generic for the 'Crypto Twitter' native vibe requested.
- @anhtunbi536660 [NONWIN, gateScore=2.0]: The only technical violation is the Discord invite link discrepancy (used a different Discord link than the recommended https://discord.gg/74hqWD75A), but a FUD-related Discord link is present in the thread.
- @oralyth [NONWIN, gateScore=1.0]: The tweet includes a screenshot from FUD (has_media: true, media_types: ['photo']) and a genuine, thoughtful take about why FUD works as a product.
- @0xehsani [NONWIN, gateScore=1.0]: - The opening line 'Tried @FUDmarkets today and finally understand why it's getting more attention' is decent but not particularly sharp or provocative.

### CC / media_format_technical
- @_dripxel [NONWIN, gateScore=2.0]: Style matches campaign (punchy, trader-native, product-driven, not AI-generic or link-spam).
- @bencrypz [NONWIN, gateScore=2.0]: Minor caveat: while the text says the screenshot is real, the structured data only confirms a photo attachment and not the image contents themselves; however, the campaign explicitly allows any live FUD product screen and the post’s wording strongly indicates compliance.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: The post successfully includes all mandatory elements: @FUDmarkets mention, the platform URL, the Discord invite link, and a screenshot (verified via urls_expanded).
- @kbgold77 [NONWIN, gateScore=1.0]: The tweet meets all mandatory structural and programmatic requirements: it includes @FUDmarkets (mentions_usernames), the https://fud.markets URL, the recommended FUD Discord invite link (https://discord.gg/74hqWD75A), and contains attached media (photos, per media_types and urls_expanded) that contextually align with the required FUD screenshot since the author references opening a real position (Argentina vs.
- @ahonjumaidil [NONWIN, gateScore=1.0]: Required elements are present: @FUDmarkets appears in both the raw text and mentions_usernames/mentions_unique_count=1; https://fud.markets is present in urls_expanded; the FUD Discord invite link is present as https://discord.gg/74hqWD75A in urls_expanded.

### CC / readthrough_density
- @0xqingmei [NONWIN, gateScore=2.0]: However, because has_media=true and the campaign’s required screenshot criterion is supported by the submission structure, I treat this as satisfied.
- @trita_a [WIN, gateScore=2.0]: The content follows the 'crypto-native' and 'punchy' style guidelines, using recommended hooks ('CT has been calling tops and bottoms for free for too long') and avoiding prohibited elements like em dashes, financial advice, or airdrop language.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Potential minor weakness: the style guide says not to use long polished AI-style paragraphs and not to overexplain.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: This post is longer and more polished than ideal, with several dense paragraphs.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: Overall, based on thread_data fields (mentions_usernames, urls_expanded, tweet_subtype, relation_flags, public_metrics, hashtags) and the tweet text, this is a high-quality, compliant submission with only a small stylistic caveat about length/overexplanation.

### CC / rq_reply_quality
- @_dripxel [NONWIN, gateScore=2.0]: Style matches campaign (punchy, trader-native, product-driven, not AI-generic or link-spam).
- @ahonjumaidil [NONWIN, gateScore=1.0]: Engagement metrics exist (likes/retweets/replies), but the brief does not specify thresholds, so they cannot be judged as failing.
- @anhtunbi536660 [NONWIN, gateScore=2.0]: The post is clearly not generic AI copy or low-effort engagement farming - it tells a personal story about product usage with authentic insights.
- @cryptodragon [NONWIN, gateScore=2.0]: Content-wise, this is a strong, authentic crypto-native post with a compelling hook about GenLayer settlement, demonstrates genuine product understanding, discusses FUD Points Season 1, and avoids all prohibited content (no em dashes, no airdrop language, no token allocation claims, no generic AI text, no low-effort farming).
- @cuemnee [NONWIN, gateScore=1.0]: - 61 likes, 12 retweets, 32 replies, 4865 impressions — reasonable engagement.

### CC / tactical_value_payload
- @bencrypz [NONWIN, gateScore=2.0]: Timing compliance cannot be meaningfully restricted here because no prohibited posting window or day restriction is provided; the post was made Tuesday 2026-07-07 22:53:09 UTC per created_at/created_day_of_week, which does not conflict with any stated rule.
- @ahonjumaidil [NONWIN, gateScore=1.0]: Given strong rule coverage with only style-level softness, this is acceptable but not perfect.
- @kmwscan18970 [NONWIN, gateScore=1.0]: The rule says 'Do not use em dashes.' This is a VIOLATION.
- @kmwscan18970 [NONWIN, gateScore=1.0]: The SATISFIED here may mean 'no em dashes found' (i.e., the rule to avoid em dashes is satisfied).
- @kmwscan18970 [NONWIN, gateScore=1.0]: I'll interpret SATISFIED as compliant with the no-em-dash rule.

### CC / unknown_or_nuance
- @0xqingmei [NONWIN, gateScore=2.0]: Disclosure/sponsorship issues do not appear relevant here; none are required by the brief, and none are missing in a way that would affect compliance.
- @0xqingmei [NONWIN, gateScore=2.0]: Minor caveat: while the metadata strongly indicates a photo/screenshot is attached, the exact screenshot content cannot be visually verified from the structured fields alone.
- @bencrypz [NONWIN, gateScore=2.0]: Style adherence is also strong: the tone is crypto-native, direct, product-driven, and not overly corporate.
- @bencrypz [NONWIN, gateScore=2.0]: There are no mandatory hashtags specified in the rules, so the lack of hashtags is not a compliance issue.
- @bencrypz [NONWIN, gateScore=2.0]: Objective metrics like likes/retweets are provided in public_metrics, but no minimum thresholds are specified, so they do not affect compliance.

### EP / accuracy_claim_boundary
- @0xqingmei [NONWIN, gateScore=4.0]: Overall, this is a high-quality campaign submission with real product context, clear positioning, and strong crypto-native tone.
- @bencrypz [NONWIN, gateScore=4.0]: The mention of live points and product screenshots adds practical context.
- @m_amarudinn2 [NONWIN, gateScore=4.0]: Content structure is mixed but mostly solid: the line breaks improve readability, the list of shipped features adds scanability, and the progression from claim to proof to product differentiation is effective.
- @m_amarudinn2 [NONWIN, gateScore=4.0]: Conversation potential is strong: the post makes a debatable claim, contrasts FUD against competitors, and ends with a direct prompt asking what narrative people would turn into a market.
- @ahonjumaidil [NONWIN, gateScore=4.0]: The opening is reasonably strong and immediately relatable to traders: screenshotting calls after the fact is a familiar CT behavior, so the hook creates recognition and a bit of tension.

### EP / brand_bridge_promotional
- @_dripxel [NONWIN, gateScore=5.0]: Value delivery is solid with explanations of product mechanics, recent updates like FUD Points, and proof of authentic usage rather than hype.
- @0x_4444 [NONWIN, gateScore=4.0]: The structure is clear and digestible, using short paragraphs and a direct, authentic tone that aligns perfectly with the campaign's crypto-native and punchy style.
- @0x_4444 [NONWIN, gateScore=4.0]: While the call-to-action is somewhat implicit, the overall execution of the campaign goal—showing real usage and a clear take—is strong, making it highly likely to drive engagement from the target audience.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: However, the length might slightly reduce scannability, but it aligns well with the campaign's crypto-native, product-driven style.
- @0xqingmei [NONWIN, gateScore=4.0]: It fits the campaign well because it positions FUD as the place where disagreement becomes actionable.

### EP / concrete_specificity
- @_dripxel [NONWIN, gateScore=5.0]: Value delivery is solid with explanations of product mechanics, recent updates like FUD Points, and proof of authentic usage rather than hype.
- @0x_4444 [NONWIN, gateScore=4.0]: The inclusion of specific product features like Solana deposits and Season 1 points adds tangible value and credibility.
- @0xqingmei [NONWIN, gateScore=4.0]: The inclusion of a screenshot supports the proof-of-use requirement and increases trust.
- @hexzypher [NONWIN, gateScore=4.0]: The inclusion of a screenshot satisfies the campaign's 'proof of usage' requirement, which builds trust and authenticity.
- @trita_a [WIN, gateScore=5.0]: The inclusion of real product usage (screenshots and specific rank data) adds high value and authenticity, distinguishing it from generic AI-generated hype.

### EP / cta_reply_engine
- @0x_4444 [NONWIN, gateScore=4.0]: It successfully includes all required elements (@FUDmarkets, Discord link, and referral link) while maintaining a conversation-driving question at the end ('你们最近在FUD上玩啥市场？') to encourage replies.
- @0x_4444 [NONWIN, gateScore=4.0]: While the call-to-action is somewhat implicit, the overall execution of the campaign goal—showing real usage and a clear take—is strong, making it highly likely to drive engagement from the target audience.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: The tweet demonstrates strong engagement potential.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: The call-to-action is clear and multi-faceted, inviting users to try, follow, and join the community.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: It has high conversation potential by discussing CT behavior and encouraging market participation.

### EP / distinctiveness_saturation
- @_dripxel [NONWIN, gateScore=5.0]: Value delivery is solid with explanations of product mechanics, recent updates like FUD Points, and proof of authentic usage rather than hype.
- @0x_4444 [NONWIN, gateScore=4.0]: The structure is clear and digestible, using short paragraphs and a direct, authentic tone that aligns perfectly with the campaign's crypto-native and punchy style.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: The hook effectively highlights a common crypto pain point, grabbing attention.
- @0xqingmei [NONWIN, gateScore=4.0]: It explains what FUD does, why it matters, and how it differs from generic crypto products.
- @hexzypher [NONWIN, gateScore=4.0]: The hook effectively addresses a common pain point on Crypto Twitter (CT) by positioning FUD as a utility layer rather than a replacement.

### EP / hook_stop_power
- @0x_4444 [NONWIN, gateScore=4.0]: The tweet effectively utilizes a strong, narrative-driven hook by positioning FUD against the noise of typical Crypto Twitter takes, framing it as a place for real, tradable positions rather than just talk.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: The hook effectively highlights a common crypto pain point, grabbing attention.
- @0xqingmei [NONWIN, gateScore=4.0]: The hook is solid: “The best moment in crypto is before everyone agrees” creates instant tension and frames the post around a contrarian, trader-native idea.
- @0xqingmei [NONWIN, gateScore=4.0]: The opening is attention-grabbing and relevant to the audience.
- @hexzypher [NONWIN, gateScore=4.0]: The hook effectively addresses a common pain point on Crypto Twitter (CT) by positioning FUD as a utility layer rather than a replacement.

### EP / mechanism_clarity
- @0xqingmei [NONWIN, gateScore=4.0]: The numbered-style rhetorical questions around narratives and momentum also help the reader process the product positioning quickly.
- @0xqingmei [NONWIN, gateScore=4.0]: It explains what FUD does, why it matters, and how it differs from generic crypto products.
- @0xqingmei [NONWIN, gateScore=4.0]: The framing around live arguments, market interaction, FUD Points, and shipping updates gives readers a reason to understand the product.
- @hexzypher [NONWIN, gateScore=4.0]: The hook effectively addresses a common pain point on Crypto Twitter (CT) by positioning FUD as a utility layer rather than a replacement.
- @hexzypher [NONWIN, gateScore=4.0]: The value delivery is high as it explains the product's core logic: turning opinions into tradable markets.

### EP / media_format_technical
- @0x_4444 [NONWIN, gateScore=4.0]: It successfully includes all required elements (@FUDmarkets, Discord link, and referral link) while maintaining a conversation-driving question at the end ('你们最近在FUD上玩啥市场？') to encourage replies.
- @0xqingmei [NONWIN, gateScore=4.0]: It could generate replies from traders who agree or disagree with the thesis, but it does not explicitly ask a question to spark a thread.
- @0xqingmei [NONWIN, gateScore=4.0]: It is not the most viral or comment-baiting format, but it is persuasive and aligned with the brief.
- @kbgold77 [NONWIN, gateScore=4.0]: It includes all mandatory campaign elements—screenshots, @FUDmarkets, the product URL, and Discord link—while demonstrating real product usage with specific market examples.
- @anhtunbi536660 [NONWIN, gateScore=4.0]: However, at 855 characters, the longform nature may limit engagement from users who don't read through the entire thread.

### EP / readthrough_density
- @_dripxel [NONWIN, gateScore=5.0]: Content is structured into digestible paragraphs with bullet points and a real usage screenshot, making it scannable despite length.
- @0x_4444 [NONWIN, gateScore=4.0]: The structure is clear and digestible, using short paragraphs and a direct, authentic tone that aligns perfectly with the campaign's crypto-native and punchy style.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: Content structure is well-organized with bullet points and separate sections, making it digestible despite its length.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: However, the length might slightly reduce scannability, but it aligns well with the campaign's crypto-native, product-driven style.
- @0xqingmei [NONWIN, gateScore=4.0]: Content structure is strong.

### EP / rq_reply_quality
- @0x_4444 [NONWIN, gateScore=4.0]: It successfully includes all required elements (@FUDmarkets, Discord link, and referral link) while maintaining a conversation-driving question at the end ('你们最近在FUD上玩啥市场？') to encourage replies.
- @0xqingmei [NONWIN, gateScore=4.0]: It could generate replies from traders who agree or disagree with the thesis, but it does not explicitly ask a question to spark a thread.
- @dennis92z [NONWIN, gateScore=4.0]: The CTA is highly relevant, directly tying into the platform's core mechanic and prompting immediate replies.
- @bencrypz [NONWIN, gateScore=4.0]: It also ends with a direct question asking which market type feels most natural for CT, which helps drive replies.
- @dmlxbt [NONWIN, gateScore=4.0]: While the engagement metrics show decent traction, the specific question at the end ('If you could turn one crypto debate into a market today...') is a high-quality conversation starter that encourages meaningful replies over bot-like interactions.

### EP / tactical_value_payload
- @_dripxel [NONWIN, gateScore=5.0]: Value delivery is solid with explanations of product mechanics, recent updates like FUD Points, and proof of authentic usage rather than hype.
- @0x_4444 [NONWIN, gateScore=4.0]: The inclusion of specific product features like Solana deposits and Season 1 points adds tangible value and credibility.
- @mdmarufgnoma [NONWIN, gateScore=4.0]: Value delivery is robust, explaining the product's features and benefits, which could inspire saves or bookmarks.
- @0xqingmei [NONWIN, gateScore=4.0]: It fits the campaign well because it positions FUD as the place where disagreement becomes actionable.
- @0xqingmei [NONWIN, gateScore=4.0]: Value delivery is good for the intended campaign.

### EP / unknown_or_nuance
- @0xqingmei [NONWIN, gateScore=4.0]: Not recycled sentiment charts.” This gives it rhythm and makes the argument easy to scan.
- @0xqingmei [NONWIN, gateScore=4.0]: The post is built around disagreement, narratives, and mispricing, which are naturally discussion-friendly topics.
- @0xqingmei [NONWIN, gateScore=4.0]: It encourages people to think in terms of positions and market takes.
- @hexzypher [NONWIN, gateScore=4.0]: The tweet successfully aligns with the crypto-native, direct tone requested.
- @bencrypz [NONWIN, gateScore=4.0]: The follow-up framing around CT having endless takes and FUD turning those takes into markets is clear, relevant, and easy for a crypto audience to latch onto.

### IA / accuracy_claim_boundary
- @mdmarufgnoma [NONWIN, gateScore=2.0]: The only minor observation is that it does not explicitly state that FUDP are not redeemable for money, but this is not a factual error since the tweet does not make any such claim.
- @dennis92z [NONWIN, gateScore=2.0]: Technical Accuracy: The tweet correctly describes FUD.markets as a prediction platform where Crypto Twitter predictions become tradable LONG or SHORT positions, accurately reflecting the product's core mechanics and on-chain conviction model.
- @dennis92z [NONWIN, gateScore=2.0]: Context Accuracy: Properly contextualizes FUD as a layer that turns existing CT attention, debates, and hype into tradable markets rather than trying to change user behavior, which matches the official product positioning.
- @bencrypz [NONWIN, gateScore=2.0]: Technical accuracy is strong: it correctly describes FUD as a place where opinions or 'takes' become markets where users can go LONG or SHORT, which matches the platform positioning as a crypto-native prediction market where every take can become a position.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: The claim that the product makes more sense after clicking through it and that the flow involves 'real markets, real positions' is consistent with the platform description, though it is experiential rather than independently verifiable from the provided materials.

### IA / brand_bridge_promotional
- @0xqingmei [NONWIN, gateScore=2.0]: The only minor issue is that the tweet text shown includes a Discord invite, but the campaign rules specify the Discord invite link should be included; since it is present, that requirement is satisfied.
- @dennis92z [NONWIN, gateScore=2.0]: Context Accuracy: Properly contextualizes FUD as a layer that turns existing CT attention, debates, and hype into tradable markets rather than trying to change user behavior, which matches the official product positioning.
- @bencrypz [NONWIN, gateScore=2.0]: The only minor limitation is that some statements are subjective or promotional rather than strictly verifiable, such as 'the product makes more sense when you actually use it' and 'early users are already building activity while the product keeps shipping.' These are plausible and campaign-consistent, but not directly evidenced with hard data in the tweet.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: However, there is no quantitative evidence offered in the tweet itself, so while not misleading, these are broad promotional claims rather than rigorously substantiated metrics.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: It is promotional and opinionated, but the factual components it includes are supported by the provided materials.

### IA / concrete_specificity
- @ahonjumaidil [NONWIN, gateScore=2.0]: However, the tweet is somewhat generic in that it does not explicitly mention a specific market interaction or verify the screenshot content beyond the attached image link.
- @sultannasir51 [NONWIN, gateScore=1.0]: The user followed the mission requirements by including the @FUDmarkets handle, the website URL, and the specific Discord invite link.
- @sultannasir51 [NONWIN, gateScore=1.0]: Additionally, while it mentions '1M FUD Points' and a 'Volume goal', these specific quantitative targets are not explicitly verified in the provided knowledge base, though they align with the general 'Season 1' narrative.
- @lovaniceth [NONWIN, gateScore=2.0]: The only limitation is that the specific market odds cannot be independently verified from the knowledge base, but they are presented as real data from app usage, which is consistent with campaign requirements.
- @longp9981 [NONWIN, gateScore=2.0]: There are no concrete statistics or numerical claims beyond mentioning “Season 1,” so there is little risk on the data front.

### IA / cta_reply_engine
- @0xqingmei [NONWIN, gateScore=2.0]: The only minor issue is that the tweet text shown includes a Discord invite, but the campaign rules specify the Discord invite link should be included; since it is present, that requirement is satisfied.
- @mjavad7596 [NONWIN, gateScore=2.0]: Documentation Alignment: Strictly adheres to campaign guidelines by including mandatory elements (@FUDmarkets, app URL, Discord invite, screenshot/media) while maintaining the required crypto-native, direct tone without corporate language or em dashes.
- @ahonjumaidil [NONWIN, gateScore=2.0]: However, the tweet is somewhat generic in that it does not explicitly mention a specific market interaction or verify the screenshot content beyond the attached image link.
- @sultannasir51 [NONWIN, gateScore=1.0]: The user followed the mission requirements by including the @FUDmarkets handle, the website URL, and the specific Discord invite link.
- @kmwscan18970 [NONWIN, gateScore=2.0]: The tweet includes @FUDmarkets mention, references fud.markets (though the URL has a formatting error with a comma: 'https://fud.markets,/' which is a minor technical issue), and includes the correct Discord invite link (https://discord.gg/74hqWD75A).

### IA / distinctiveness_saturation
- @kbgold77 [NONWIN, gateScore=2.0]: No inaccurate technical terms, no false claims about FUDP converting to tokens, no financial advice, no em dashes, and no generic AI-style language.
- @ahonjumaidil [NONWIN, gateScore=2.0]: However, the tweet is somewhat generic in that it does not explicitly mention a specific market interaction or verify the screenshot content beyond the attached image link.
- @anhtunbi536660 [NONWIN, gateScore=2.0]: The content feels like a genuine user experience rather than generic AI copy, successfully addressing the campaign goal of real product usage and distribution.
- @cuemnee [NONWIN, gateScore=2.0]: Key claims verified: 1) FUD Points Season 1 being live is confirmed in the knowledge base. 2) The description of opening markets and taking sides aligns with the platform's actual functionality. 3) The tweet includes all required elements: @FUDmarkets mention, fud.markets link, Discord invite link, and a real take about the product. 4) The author mentions using a personal referral link (ref=764E87D7) which is acceptable per campaign rules. 5) The screenshot is included (photo media type confirmed). 6) No false claims about FUDP converting to $FUD, no airdrop language, no financial advice. 7) The Discord link used (discord.gg/CXqarkEE47) differs from the recommended one (discord.gg/74hqWD75A) but this is a minor deviation as any valid Discord link is acceptable. 8) The content correctly describes the core value proposition - turning CT takes into markets with longevity. 9) No em dashes used in the post. 10) The tone is relatively authentic and product-focused, though slightly more polished than ideal.
- @shuyue_ai [NONWIN, gateScore=2.0]: On context accuracy, the relationships between concepts are presented properly: FUD is framed as an active product with live markets and community systems rather than a generic app, which matches the campaign’s desired positioning.

### IA / hook_stop_power
- @dennis92z [NONWIN, gateScore=2.0]: Context Accuracy: Properly contextualizes FUD as a layer that turns existing CT attention, debates, and hype into tradable markets rather than trying to change user behavior, which matches the official product positioning.
- @longp9981 [NONWIN, gateScore=2.0]: The statement “open a real market” could be interpreted as claiming the author literally opened a market, but the campaign allows either opening or interacting with one; still, the tweet says “I used FUD” and references a real session, so it remains plausible and not clearly misleading.
- @cuemnee [NONWIN, gateScore=2.0]: Key claims verified: 1) FUD Points Season 1 being live is confirmed in the knowledge base. 2) The description of opening markets and taking sides aligns with the platform's actual functionality. 3) The tweet includes all required elements: @FUDmarkets mention, fud.markets link, Discord invite link, and a real take about the product. 4) The author mentions using a personal referral link (ref=764E87D7) which is acceptable per campaign rules. 5) The screenshot is included (photo media type confirmed). 6) No false claims about FUDP converting to $FUD, no airdrop language, no financial advice. 7) The Discord link used (discord.gg/CXqarkEE47) differs from the recommended one (discord.gg/74hqWD75A) but this is a minor deviation as any valid Discord link is acceptable. 8) The content correctly describes the core value proposition - turning CT takes into markets with longevity. 9) No em dashes used in the post. 10) The tone is relatively authentic and product-focused, though slightly more polished than ideal.
- @chilotete [NONWIN, gateScore=2.0]: One minor caveat is that 'the one thing crypto never really priced was attention' is rhetorical and somewhat overstated, since attention markets and social speculation have existed in various forms, but this is opinionated framing rather than a concrete falsehood.
- @janumetax [NONWIN, gateScore=1.0]: The tweet makes several claims about FUD that are factually accurate according to the knowledge base: 1) 'You can open a market, take a side' - aligns with the KB statement that users can 'open or interact with markets' and the good angle 'open a market, take a side'. 2) 'gives those opinions a place to become something more than just a tweet' - consistent with 'every take can become a position' and 'CT takes are not free anymore'. 3) 'see how your conviction stands against the crowd' - aligns with 'let others follow or fade them'. 4) The @FUDmarkets mention, fud.markets URL, and Discord link (https://discord.gg/74hqWD75A) are all correct per campaign documentation. 5) 'conversations can actually become markets' - consistent with 'FUD is turning crypto attention into markets'.

### IA / mechanism_clarity
- @dennis92z [NONWIN, gateScore=2.0]: Technical Accuracy: The tweet correctly describes FUD.markets as a prediction platform where Crypto Twitter predictions become tradable LONG or SHORT positions, accurately reflecting the product's core mechanics and on-chain conviction model.
- @dennis92z [NONWIN, gateScore=2.0]: Context Accuracy: Properly contextualizes FUD as a layer that turns existing CT attention, debates, and hype into tradable markets rather than trying to change user behavior, which matches the official product positioning.
- @bencrypz [NONWIN, gateScore=2.0]: Technical accuracy is strong: it correctly describes FUD as a place where opinions or 'takes' become markets where users can go LONG or SHORT, which matches the platform positioning as a crypto-native prediction market where every take can become a position.
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: The only mildly subjective elements are qualitative claims such as 'That is why FUD is growing' and 'better social layer for crypto,' which are opinions rather than hard facts.
- @kbgold77 [NONWIN, gateScore=2.0]: No inaccurate technical terms, no false claims about FUDP converting to tokens, no financial advice, no em dashes, and no generic AI-style language.

### IA / media_format_technical
- @0xqingmei [NONWIN, gateScore=2.0]: The only minor issue is that the tweet text shown includes a Discord invite, but the campaign rules specify the Discord invite link should be included; since it is present, that requirement is satisfied.
- @mjavad7596 [NONWIN, gateScore=2.0]: Documentation Alignment: Strictly adheres to campaign guidelines by including mandatory elements (@FUDmarkets, app URL, Discord invite, screenshot/media) while maintaining the required crypto-native, direct tone without corporate language or em dashes.
- @kbgold77 [NONWIN, gateScore=2.0]: Key messaging aligns with campaign goals: 'the team ships every week,' 'turns the opinions CT already shares into something people can act on,' and 'consumer crypto needs apps people actually want to use.' The author references screenshots (implied by media attachments).
- @ahonjumaidil [NONWIN, gateScore=2.0]: However, the tweet is somewhat generic in that it does not explicitly mention a specific market interaction or verify the screenshot content beyond the attached image link.
- @sultannasir51 [NONWIN, gateScore=1.0]: The user followed the mission requirements by including the @FUDmarkets handle, the website URL, and the specific Discord invite link.

### IA / readthrough_density
- @dennis92z [NONWIN, gateScore=2.0]: Technical Accuracy: The tweet correctly describes FUD.markets as a prediction platform where Crypto Twitter predictions become tradable LONG or SHORT positions, accurately reflecting the product's core mechanics and on-chain conviction model.
- @bencrypz [NONWIN, gateScore=2.0]: Technical accuracy is strong: it correctly describes FUD as a place where opinions or 'takes' become markets where users can go LONG or SHORT, which matches the platform positioning as a crypto-native prediction market where every take can become a position.
- @dmlxbt [NONWIN, gateScore=2.0]: The tone is crypto-native and punchy, avoiding prohibited elements like em dashes, AI-style long paragraphs, or financial advice.
- @irzarag [NONWIN, gateScore=1.0]: It correctly presents FUD as a crypto-native prediction market where users can take long or short positions, and it aligns with the campaign’s framing that “CT takes become positions.” It also mentions FUD Points Season 1, which is explicitly allowed and encouraged in the campaign materials.

### IA / tactical_value_payload
- @joshepsmitxu9b [NONWIN, gateScore=2.0]: It does not overstate rewards, token utility, or future value, and it avoids prohibited claims about FUD Points converting into money or tokens.
- @sultannasir51 [NONWIN, gateScore=1.0]: It correctly identifies the core product value proposition ('every take becomes a position'), mentions the current 'FUD Points Season 1', and accurately lists technical features like Solana USDC deposits and the FUD vault.
- @anhtunbi536660 [NONWIN, gateScore=2.0]: Context accuracy is excellent - the tweet correctly portrays FUD's value proposition (takes becoming positions, opinions being challenged through markets rather than just likes), and the claim that FUD is growing aligns with campaign materials.
- @cuemnee [NONWIN, gateScore=2.0]: Key claims verified: 1) FUD Points Season 1 being live is confirmed in the knowledge base. 2) The description of opening markets and taking sides aligns with the platform's actual functionality. 3) The tweet includes all required elements: @FUDmarkets mention, fud.markets link, Discord invite link, and a real take about the product. 4) The author mentions using a personal referral link (ref=764E87D7) which is acceptable per campaign rules. 5) The screenshot is included (photo media type confirmed). 6) No false claims about FUDP converting to $FUD, no airdrop language, no financial advice. 7) The Discord link used (discord.gg/CXqarkEE47) differs from the recommended one (discord.gg/74hqWD75A) but this is a minor deviation as any valid Discord link is acceptable. 8) The content correctly describes the core value proposition - turning CT takes into markets with longevity. 9) No em dashes used in the post. 10) The tone is relatively authentic and product-focused, though slightly more polished than ideal.
- @rasdamsama [NONWIN, gateScore=2.0]: It does not overstate rewards, token value, or unsupported future promises.

### IA / unknown_or_nuance
- @0xqingmei [NONWIN, gateScore=2.0]: The post also matches the required style: crypto-native, direct, product-driven, and not overly corporate.
- @bencrypz [NONWIN, gateScore=2.0]: There are no suspicious statistics or numerical claims to verify, so the Data & Statistics criterion is neutral rather than exceptional.
- @kbgold77 [NONWIN, gateScore=2.0]: The tone is crypto-native, direct, and product-driven rather than corporate.
- @anhtunbi536660 [NONWIN, gateScore=2.0]: No data or statistics claims are made that could be verified or falsified.
- @carte_free [NONWIN, gateScore=2.0]: The tweet correctly presents FUD as a product for taking visible positions rather than just posting takes.

### OAA / accuracy_claim_boundary
- @sultannasir51 [NONWIN, gateScore=1.0]: It follows the now-common pattern of: strong opening claim, explanation of the product loop, bullet list of current features/updates, then CTA plus a closing question.
- @cuemnee [NONWIN, gateScore=2.0]: The mention of specific phrases like 'This token will break ATH' and 'This launch is underrated' adds a layer of authentic trader-native context that feels personal rather than templated.
- @siavash33339 [NONWIN, gateScore=1.0]: While the execution is more authentic and readable than the derivative long-form posts, the underlying insight lacks distinctiveness within this campaign context.
- @oralyth [NONWIN, gateScore=1.0]: The opening hook ('I opened FUD with one question: would I use this outside the campaign?') is genuinely distinctive and creates real tension - it's honest about the campaign context while establishing credibility.

### OAA / brand_bridge_promotional
- @_dripxel [NONWIN, gateScore=1.0]: The language is natural and conversational, adhering to the campaign's crypto-native style without corporate clichés.
- @0x_4444 [NONWIN, gateScore=2.0]: The detail about spending more time on FUD than Twitter, plus the direct '这玩意儿越用越上头' observation, feels genuinely experienced rather than campaign-prompted.
- @0xqingmei [NONWIN, gateScore=2.0]: The shipping updates section is somewhat similar to other campaign content, but the overall structure and phrasing—especially the closing take ('The timeline is where the argument starts.
- @hexzypher [NONWIN, gateScore=1.0]: This tweet demonstrates solid originality within the campaign framework.
- @dennis92z [NONWIN, gateScore=1.0]: However, there are notable weaknesses: the post is quite long and polished, bordering on AI-style paragraph structure that the campaign style guide explicitly discourages.

### OAA / concrete_specificity
- @0x_4444 [NONWIN, gateScore=2.0]: The detail about spending more time on FUD than Twitter, plus the direct '这玩意儿越用越上头' observation, feels genuinely experienced rather than campaign-prompted.
- @bencrypz [NONWIN, gateScore=2.0]: The inclusion of a specific question at the end to drive community engagement further enhances its organic feel rather than appearing as a static advertisement.
- @_blockbelle [NONWIN, gateScore=1.0]: However, the voice does not go very deep into a specific personal experience, concrete market interacted with, or an idiosyncratic reaction.
- @_blockbelle [NONWIN, gateScore=1.0]: The tweet is highly similar to the provided comparison set in narrative flow, claims, and even recurring language patterns: CT disagreement, takes becoming positions, screenshot as proof of use, shipping cadence, FUD Points, badges, creator quests, community XP, Solana USDC deposits, and new markets around live narratives.
- @_blockbelle [NONWIN, gateScore=1.0]: It demonstrates acceptable originality through a modestly distinct framing around the pre-consensus window, yet it remains substantially derivative of the campaign prompt and similar example tweets.

### OAA / cta_reply_engine
- @_dripxel [NONWIN, gateScore=1.0]: However, the content is largely derivative of the similar tweets, sharing common themes such as the transient nature of CT takes, FUD's role in turning takes into markets, lists of shipping updates, and a similar structure ending with links and a question.
- @mdmarufgnoma [NONWIN, gateScore=2.0]: Compared to similar tweets, it stands out by emphasizing how FUD 'builds directly on top of' existing CT behavior rather than fighting it, and by framing the product as a place where 'the market can respond to the take.' It avoids cliches, overexplanation, and em dashes.
- @hexzypher [NONWIN, gateScore=1.0]: The call-to-action section is also formulaic and nearly identical to other submissions.
- @hexzypher [NONWIN, gateScore=1.0]: The engagement question at the end ('What is one CT take you would actually want to see tested on FUD?') is a nice touch that invites genuine community interaction.
- @dennis92z [NONWIN, gateScore=1.0]: The language is somewhat corporate-adjacent in places ('That simple change makes the conversation more interesting').

### OAA / distinctiveness_saturation
- @_dripxel [NONWIN, gateScore=1.0]: The tweet exhibits a strong personal voice with authentic product usage, as evidenced by the author's description of trying FUD as a new user and including a screenshot from their session.
- @_dripxel [NONWIN, gateScore=1.0]: However, the content is largely derivative of the similar tweets, sharing common themes such as the transient nature of CT takes, FUD's role in turning takes into markets, lists of shipping updates, and a similar structure ending with links and a question.
- @0x_4444 [NONWIN, gateScore=2.0]: It offers a fresh, trader-native comparison of CT 'narratives' becoming casino-like while FUD converts them into actual tradable positions, avoiding the English templated structures and repetitive 'takes become markets' phrasing seen in all similar tweets.
- @mdmarufgnoma [NONWIN, gateScore=2.0]: Compared to similar tweets, it stands out by emphasizing how FUD 'builds directly on top of' existing CT behavior rather than fighting it, and by framing the product as a place where 'the market can respond to the take.' It avoids cliches, overexplanation, and em dashes.
- @0xqingmei [NONWIN, gateScore=2.0]: The shipping updates section is somewhat similar to other campaign content, but the overall structure and phrasing—especially the closing take ('The timeline is where the argument starts.

### OAA / hook_stop_power
- @hexzypher [NONWIN, gateScore=1.0]: The opening hook 'FUD clicked for me when I realized it is not trying to replace CT.
- @dmlxbt [NONWIN, gateScore=1.0]: While the opening line provides a relatable hook about crypto conversations fading, the overall structure and phrasing closely mirror the provided similar tweets.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: The tweet demonstrates a personal and authentic voice, with specific mention of using FUD by opening a position on ANSEM, which adds credibility.
- @yantowid1 [NONWIN, gateScore=1.0]: However, the opening line and engagement question resemble common tropes in the provided similar tweets, reducing distinctiveness.
- @mjavad7596 [NONWIN, gateScore=2.0]: It opens with a personal, narrative-driven hook ('I opened FUD today...') rather than the campaign's common 'CT takes are free' opener seen in similar tweets.

### OAA / mechanism_clarity
- @hexzypher [NONWIN, gateScore=1.0]: The core insight about FUD as a 'product layer' for existing CT behavior is well-articulated and distinct.
- @emef0815 [NONWIN, gateScore=1.0]: Rather than simply saying "every take becomes a position" or "CT opinions become markets," it frames FUD as a mechanism for forcing intellectual honesty and deeper engagement with opposing views.
- @emef0815 [NONWIN, gateScore=1.0]: While the central behavioral insight is distinctive, the surrounding structure still overlaps heavily with the campaign's expected messaging and the broader set of similar posts: mention points since launch, reference product usage, explain that taking a side changes the conversation, and conclude that "the product is working." Those are all campaign-aligned and somewhat familiar.
- @lovaniceth [NONWIN, gateScore=1.0]: The line about higher odds meaning the market is saying “prove it” is the most original idea in the piece and adds a real interpretive layer rather than just repeating the slogan.
- @cuemnee [NONWIN, gateScore=2.0]: The mention of specific phrases like 'This token will break ATH' and 'This launch is underrated' adds a layer of authentic trader-native context that feels personal rather than templated.

### OAA / media_format_technical
- @dennis92z [NONWIN, gateScore=1.0]: The inclusion of a referral link is fine per rules.
- @mjavad7596 [NONWIN, gateScore=2.0]: While it does include standard CT elements like the Discord invite and app link at the end, the core message—reframing FUD as a platform for non-traders—is distinct from the similar tweets, which focus more on the trader's perspective or generic 'turns takes into positions' language.
- @kmwscan18970 [NONWIN, gateScore=1.0]: It includes required campaign elements (@FUDmarkets, product link, Discord) and attaches a screenshot.
- @cryptodragon [NONWIN, gateScore=2.0]: Creative Expression: Using a minor visual detail as a macro narrative hook shows sophisticated, original thinking.
- @longp9981 [NONWIN, gateScore=1.0]: Several lines read like campaign copy assembled into a thread rather than spontaneous user commentary.

### OAA / readthrough_density
- @_dripxel [NONWIN, gateScore=1.0]: However, the content is largely derivative of the similar tweets, sharing common themes such as the transient nature of CT takes, FUD's role in turning takes into markets, lists of shipping updates, and a similar structure ending with links and a question.
- @0xqingmei [NONWIN, gateScore=2.0]: The shipping updates section is somewhat similar to other campaign content, but the overall structure and phrasing—especially the closing take ('The timeline is where the argument starts.
- @dennis92z [NONWIN, gateScore=1.0]: However, there are notable weaknesses: the post is quite long and polished, bordering on AI-style paragraph structure that the campaign style guide explicitly discourages.
- @trita_a [WIN, gateScore=2.0]: It avoids generic promotional language and instead focuses on personal experience ('I have been using @FUDmarkets long enough to have an actual opinion on it'), which enhances authenticity.
- @_blockbelle [NONWIN, gateScore=1.0]: The tweet shows real product usage and contains a coherent product-centered take, but its originality is limited because it closely mirrors the campaign template and the supplied similar tweets in both structure and phrasing.

### OAA / tactical_value_payload
- @hexzypher [NONWIN, gateScore=1.0]: It is trying to make CT more useful.' is a genuinely fresh framing that differentiates it from similar submissions which focus on 'takes disappearing' or 'takes becoming markets.' The 'not replacing but enhancing' angle is unique among the comparable tweets provided.
- @ahonjumaidil [NONWIN, gateScore=1.0]: Compared to similar tweets, it shares themes of FUD adding value to CT opinions but distinguishes itself through a concise, story-driven narrative.
- @lovaniceth [NONWIN, gateScore=1.0]: Real crowd money behind them.” and “This is actually useful, not another app that just looks cool” still feel somewhat campaign-shaped.
- @shuyue_ai [NONWIN, gateScore=2.0]: The author uses a unique perspective by describing CT takes as 'screenshots waiting to be deleted' and positions FUD as the tool that creates 'receipts.' The language is punchy and direct, adhering to the 'no em dashes' rule and avoiding the generic AI tone found in many of the similar tweets provided.
- @rasdamsama [NONWIN, gateScore=2.0]: The tweet offers a highly original perspective by reframing FUD markets not as a prediction tool, but as a test of honesty and accountability.

### OAA / unknown_or_nuance
- @_dripxel [NONWIN, gateScore=1.0]: While there are creative touches, like breaking down the core loop into steps and emphasizing real usage, the unique perspective and distinctiveness are modest, placing it in the acceptable but not exceptional category.
- @hexzypher [NONWIN, gateScore=1.0]: The screenshot inclusion and real product usage are evident.
- @dennis92z [NONWIN, gateScore=1.0]: The core insight about CT predictions disappearing into the feed without accountability is well-articulated and shows real product understanding.
- @_blockbelle [NONWIN, gateScore=1.0]: Unique Perspective: There is a slightly differentiated angle in focusing on the timing of disagreement, specifically the "window where crypto is still undecided," and the contrast with recap threads and hindsight posting is a decent framing device.
- @_blockbelle [NONWIN, gateScore=1.0]: It feels more like a competent variation than a fresh insight.

### RQ / accuracy_claim_boundary
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: The last two replies about AI agents and dispute resolution appear completely off-topic and seem copy-pasted from a different campaign or context entirely.
- @yantowid1 [NONWIN, gateScore=2.0]: There is little evidence of real product usage, no references to screenshots, markets, FUD Points, or specific features from the post/knowledge base.
- @carte_free [NONWIN, gateScore=1.0]: Most do not meaningfully engage with the product claim that FUD turns CT takes into tradable positions, nor do they reference specific features like real markets, screenshots, leaderboard progress, weekly shipping, FUD Points, or Solana deposits.
- @longp9981 [NONWIN, gateScore=3.0]: It directly engages with the core claim that CT already runs on opinions and that FUD turns those opinions into something tradable or measurable.

### RQ / brand_bridge_promotional
- @_dripxel [NONWIN, gateScore=1.0]: The replies are mostly short, generic phrases that repeat campaign slogans without demonstrating real product usage, screenshots, or personal reasoning.
- @_dripxel [NONWIN, gateScore=1.0]: Corporate or templated language appears in several (e.g., 'revolutionize', emoji hype).
- @_dripxel [NONWIN, gateScore=1.0]: No replies meet the campaign requirement for original takes tied to actual app interaction.
- @0x_4444 [NONWIN, gateScore=4.0]: The second reply stands out significantly, showing personal experience, critical thinking, and specific product knowledge (mentioning liquidation history, whale dumping, and asking about stop-losses), which aligns perfectly with the campaign's goal of real product usage and trader-native tone.
- @hexzypher [NONWIN, gateScore=1.0]: The provided replies collectively fall far short of the campaign's strict standards for authenticity, specificity, and subject-matter engagement.

### RQ / concrete_specificity
- @0x_4444 [NONWIN, gateScore=4.0]: The second reply stands out significantly, showing personal experience, critical thinking, and specific product knowledge (mentioning liquidation history, whale dumping, and asking about stop-losses), which aligns perfectly with the campaign's goal of real product usage and trader-native tone.
- @0x_4444 [NONWIN, gateScore=4.0]: Collectively, they show genuine interaction, specific references to the product (FUD markets, short positions, Solana deposits implied by the app usage), and a lack of corporate or AI-generated fluff.
- @hexzypher [NONWIN, gateScore=1.0]: The provided replies collectively fall far short of the campaign's strict standards for authenticity, specificity, and subject-matter engagement.
- @hexzypher [NONWIN, gateScore=1.0]: While two responses meaningfully answer the prompt's direct question by proposing concrete markets (Luna 2.0 price floor and ETH/BTC flippening), the overwhelming majority (14 out of 17) are generic, repetitive, or low-effort.
- @trita_a [WIN, gateScore=1.0]: The reply about 'Conviction deserves a market, not just a tweet. 🚀' is slightly more thematically relevant but is still a polished platitude with no specificity.

### RQ / cta_reply_engine
- @_dripxel [NONWIN, gateScore=1.0]: The replies are mostly short, generic phrases that repeat campaign slogans without demonstrating real product usage, screenshots, or personal reasoning.
- @_dripxel [NONWIN, gateScore=1.0]: No replies meet the campaign requirement for original takes tied to actual app interaction.
- @_dripxel [NONWIN, gateScore=1.0]: Overall low substance and engagement quality.
- @0x_4444 [NONWIN, gateScore=4.0]: The replies demonstrate a mix of engagement levels.
- @0x_4444 [NONWIN, gateScore=4.0]: The second reply stands out significantly, showing personal experience, critical thinking, and specific product knowledge (mentioning liquidation history, whale dumping, and asking about stop-losses), which aligns perfectly with the campaign's goal of real product usage and trader-native tone.

### RQ / distinctiveness_saturation
- @_dripxel [NONWIN, gateScore=1.0]: The replies are mostly short, generic phrases that repeat campaign slogans without demonstrating real product usage, screenshots, or personal reasoning.
- @_dripxel [NONWIN, gateScore=1.0]: Corporate or templated language appears in several (e.g., 'revolutionize', emoji hype).
- @_dripxel [NONWIN, gateScore=1.0]: No replies meet the campaign requirement for original takes tied to actual app interaction.
- @0x_4444 [NONWIN, gateScore=4.0]: Collectively, they show genuine interaction, specific references to the product (FUD markets, short positions, Solana deposits implied by the app usage), and a lack of corporate or AI-generated fluff.
- @hexzypher [NONWIN, gateScore=1.0]: While two responses meaningfully answer the prompt's direct question by proposing concrete markets (Luna 2.0 price floor and ETH/BTC flippening), the overwhelming majority (14 out of 17) are generic, repetitive, or low-effort.

### RQ / hook_stop_power
- @0x_4444 [NONWIN, gateScore=4.0]: The second reply stands out significantly, showing personal experience, critical thinking, and specific product knowledge (mentioning liquidation history, whale dumping, and asking about stop-losses), which aligns perfectly with the campaign's goal of real product usage and trader-native tone.
- @trita_a [WIN, gateScore=1.0]: The vast majority are one-liners like 'Good job my friend,' 'Best one,' 'Keep cooking! 🔥,' 'lfg very good,' 'Great job buddy keep it up,' and 'Worth paying attention to. 👏' — these are textbook engagement farm replies with zero substance, no product knowledge, no personal take, and no connection to the actual FUD.markets product or the campaign topic.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: A few replies show marginal engagement: the one noting 'it's not a new concept, decentralized markets have been around in other forms too' shows at least a counterpoint; 'Opening a first position is usually the best way to understand how a product really works' has a mild point but is still generic; 'First post, full send on ANSEM.
- @cryptodragon [NONWIN, gateScore=2.0]: Reply 1 ('fr3n') shows real engagement - asks a specific question about spreads on neutral settlement markets, demonstrating product curiosity and topic awareness.
- @cryptodragon [NONWIN, gateScore=2.0]: The genuine technical curiosity in replies 1 and 2 is what separates them from the generic responses.

### RQ / mechanism_clarity
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: A few replies show marginal engagement: the one noting 'it's not a new concept, decentralized markets have been around in other forms too' shows at least a counterpoint; 'Opening a first position is usually the best way to understand how a product really works' has a mild point but is still generic; 'First post, full send on ANSEM.
- @cryptodragon [NONWIN, gateScore=2.0]: The genuine technical curiosity in replies 1 and 2 is what separates them from the generic responses.
- @shuyue_ai [NONWIN, gateScore=3.0]: Several mention specific concepts from the post such as receipts, pressure, weekly updates, creator quests, interface elements like LONG/SHORT, and liquidity concerns.
- @rasdamsama [NONWIN, gateScore=1.0]: Subject-matter engagement is shallow: commenters recognize the idea of accountability in prediction markets, but they do not reason about how FUD works or contribute meaningful counterpoints, examples, or firsthand observations.

### RQ / media_format_technical
- @0x_4444 [NONWIN, gateScore=4.0]: While a couple are brief, the thread as a whole displays high authenticity, constructive discussion, and strong subject-matter engagement.

### RQ / readthrough_density
- @cuemnee [NONWIN, gateScore=2.0]: The tone is mostly on-brand, though slightly long and over-explained in places.
- @shuyue_ai [NONWIN, gateScore=3.0]: Several mention specific concepts from the post such as receipts, pressure, weekly updates, creator quests, interface elements like LONG/SHORT, and liquidity concerns.

### RQ / rq_reply_quality
- @_dripxel [NONWIN, gateScore=1.0]: The replies are mostly short, generic phrases that repeat campaign slogans without demonstrating real product usage, screenshots, or personal reasoning.
- @_dripxel [NONWIN, gateScore=1.0]: No replies meet the campaign requirement for original takes tied to actual app interaction.
- @0x_4444 [NONWIN, gateScore=4.0]: The replies demonstrate a mix of engagement levels.
- @0x_4444 [NONWIN, gateScore=4.0]: The other replies are shorter but still relevant and crypto-native in tone.
- @0x_4444 [NONWIN, gateScore=4.0]: While a couple are brief, the thread as a whole displays high authenticity, constructive discussion, and strong subject-matter engagement.

### RQ / tactical_value_payload
- @hexzypher [NONWIN, gateScore=1.0]: Many replies simply parrot the original tweet's phrasing ('FUD makes CT useful', 'make conviction visible', 'FUD clicked for me when...'), offer vague platitudes ('Keep building in', 'Let the market decided'), or exhibit clear engagement-farming behavior ('Where to buy fud and earn points 😅😅').
- @bencrypz [NONWIN, gateScore=1.0]: Civility is fine, but engagement quality and information value are weak overall.
- @yantowid1 [NONWIN, gateScore=2.0]: Replies like “now the takes actually mean something,” “Ct finally has skin in the game,” and “FUD brings accountability to CT takes” are on-topic but shallow and templated, with minimal originality or information value.
- @mjavad7596 [NONWIN, gateScore=0.0]: They completely lack relevance, subject-matter understanding, constructiveness, and information value.
- @emef0815 [NONWIN, gateScore=2.0]: Civility is maintained, but information value, engagement quality, and relevance are weak overall, resulting in a low collective score.

### RQ / unknown_or_nuance
- @_dripxel [NONWIN, gateScore=1.0]: A few show minor topic awareness (e.g., skin in the game, measurable outcomes) but lack originality, depth, or authenticity.
- @dmlxbt [NONWIN, gateScore=3.0]: The tone is civil, analytical, and aligned with a crypto-native audience.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: It's not exceptional but it's genuine and product-aware.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: Nailing the vibe' shows crypto-native awareness of ANSEM specifically.
- @mdabdurrahim98 [NONWIN, gateScore=1.0]: This significantly drags down the overall submission quality.

### TQ / accuracy_claim_boundary
- @_dripxel [NONWIN, gateScore=5.0]: Media integration is proper: the photo is referenced directly in context, URLs are expanded correctly in entities, and the screenshot enhances the product-focused message rather than detracting.
- @mjavad7596 [NONWIN, gateScore=4.0]: Media integration is correctly formatted, with an attached photo that validates the author's FUDP ranking claim and fulfills the campaign's proof-of-usage mandate.
- @mjavad7596 [NONWIN, gateScore=4.0]: As a standalone post, it requires no thread scaffolding and flows logically from a clear hook to product context and a direct call-to-action.
- @carte_free [NONWIN, gateScore=4.0]: Minor issues: one sentence is slightly awkward, "The feature that stands out the most to me is that every screenshot becomes a statement," because screenshots are not fully explained in-context as a product mechanic.
- @_maki29_ [NONWIN, gateScore=4.0]: The media appears to reinforce the claim of real product usage rather than distract from it.

### TQ / brand_bridge_promotional
- @0xqingmei [NONWIN, gateScore=5.0]: It also leans slightly promotional in the middle, though it still stays within a user-testimonial style.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: It includes a mention, direct links, and a screenshot reference aligned with the campaign goal.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: It does lean slightly long and polished relative to the campaign preference for sharper, punchier delivery.
- @m_amarudinn2 [NONWIN, gateScore=4.0]: The post uses a strong opening line, includes the required mention, links, screenshot reference, and a closing question to drive engagement.
- @m_amarudinn2 [NONWIN, gateScore=4.0]: However, it is somewhat lengthy and dense in the middle, with several polished multi-sentence paragraphs that slightly conflict with the campaign guidance to avoid long AI-style paragraphs.

### TQ / concrete_specificity
- @mjavad7596 [NONWIN, gateScore=4.0]: Media integration is correctly formatted, with an attached photo that validates the author's FUDP ranking claim and fulfills the campaign's proof-of-usage mandate.
- @anhtunbi536660 [NONWIN, gateScore=4.0]: The main tweet demonstrates strong technical execution with excellent narrative flow, effective use of line breaks to create pacing, and a compelling personal story about deleting a reply and turning opinions into markets.
- @carte_free [NONWIN, gateScore=4.0]: It opens with a hook, explains the product value, adds personal usage proof, includes leaderboard stats, and closes with links and CTA elements.
- @lovaniceth [NONWIN, gateScore=4.0]: Flow moves from hook → specific examples → value proposition → call to action.
- @lovaniceth [NONWIN, gateScore=4.0]: Specific numbers (2.8x, 1.9x) add credibility.

### TQ / cta_reply_engine
- @dennis92z [NONWIN, gateScore=5.0]: External links and the Discord invite are cleanly formatted and separated to prevent visual clutter while maintaining accessibility.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: The progression is logical: strong hook, product explanation, usage framing, product update list, and CTA.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: The CTA is clear without feeling like pure link spam.
- @_blockbelle [NONWIN, gateScore=5.0]: Platform optimization is strong; the post stays well within character limits while maximizing engagement potential through clear calls to action and proper use of mentions.
- @m_amarudinn2 [NONWIN, gateScore=4.0]: It uses short paragraphs, clear spacing, and a progression from hook to product differentiation to recent updates to call to action.

### TQ / distinctiveness_saturation
- @bencrypz [NONWIN, gateScore=5.0]: It avoids prohibited em dashes and does not read like generic corporate copy.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: It is optimized for longform posting rather than standard tweet brevity, and within that format it performs strongly.
- @ahonjumaidil [NONWIN, gateScore=5.0]: One minor weakness is that the post is slightly repetitive in its core idea of 'takes becoming positions' and leans on a familiar CT framing, but this does not materially hurt technical execution.
- @cryptodragon [NONWIN, gateScore=4.0]: Media integration includes a photo attachment plus three properly formatted links (main site, Discord, referral link), all of which serve distinct purposes and are clearly labeled.
- @shuyue_ai [NONWIN, gateScore=4.0]: However, it is longform at 712 characters, which is acceptable for premium long posts but less optimized for rapid engagement than a tighter standard-length tweet.

### TQ / hook_stop_power
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: The progression is logical: strong hook, product explanation, usage framing, product update list, and CTA.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: The opening line creates tension and fits X well.
- @_blockbelle [NONWIN, gateScore=5.0]: Although this is a single-tweet submission rather than a thread, it stands alone effectively with a logical flow from hook to product insight to conclusion.
- @m_amarudinn2 [NONWIN, gateScore=4.0]: It uses short paragraphs, clear spacing, and a progression from hook to product differentiation to recent updates to call to action.
- @m_amarudinn2 [NONWIN, gateScore=4.0]: The post uses a strong opening line, includes the required mention, links, screenshot reference, and a closing question to drive engagement.

### TQ / mechanism_clarity
- @dennis92z [NONWIN, gateScore=5.0]: The only minor technical quirk is a double forward-slash in the referral URL, which is functionally harmless but slightly imprecise.
- @bencrypz [NONWIN, gateScore=5.0]: The capitalization of "LONG or SHORT" works as emphasis and fits platform norms.
- @bencrypz [NONWIN, gateScore=5.0]: The only technical limitation is that some sections are slightly verbose, which marginally reduces punchiness and could affect retention on X.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: There is some repetition of sentence-openers like "That is" and "If you think," but this does not create technical issues.
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: From a technical execution standpoint, this is high quality.

### TQ / media_format_technical
- @_dripxel [NONWIN, gateScore=5.0]: Language mechanics are solid with correct grammar, spelling, and punctuation in an informal but appropriate crypto-native style.
- @_dripxel [NONWIN, gateScore=5.0]: Media integration is proper: the photo is referenced directly in context, URLs are expanded correctly in entities, and the screenshot enhances the product-focused message rather than detracting.
- @mdmarufgnoma [NONWIN, gateScore=5.0]: Thread composition is not applicable as this is a standalone tweet, but it maintains coherent and logical progression.
- @0xqingmei [NONWIN, gateScore=5.0]: The presence of media does not distract from the text.
- @dennis92z [NONWIN, gateScore=5.0]: External links and the Discord invite are cleanly formatted and separated to prevent visual clutter while maintaining accessibility.

### TQ / readthrough_density
- @0xqingmei [NONWIN, gateScore=5.0]: Minor weaknesses: the tweet is a bit long and dense, with several repeated ideas about disagreement and pricing.
- @dennis92z [NONWIN, gateScore=5.0]: Platform Optimization: Effectively leverages X's long-form capability without feeling bloated.
- @dennis92z [NONWIN, gateScore=5.0]: External links and the Discord invite are cleanly formatted and separated to prevent visual clutter while maintaining accessibility.
- @dennis92z [NONWIN, gateScore=5.0]: The internal pacing and structural completeness eliminate the need for a multi-tweet thread, delivering a self-contained, persuasive narrative.
- @trita_a [WIN, gateScore=5.0]: It utilizes the long-form tweet feature effectively, maintaining readability through short, punchy sentences and clear line breaks.

### TQ / rq_reply_quality
- @joshepsmitxu9b [NONWIN, gateScore=4.0]: The CTA is clear without feeling like pure link spam.
- @anhtunbi536660 [NONWIN, gateScore=4.0]: However, the thread composition suffers from an extremely weak second tweet - the reply simply restates the main message without adding substantive value, making it feel like a perfunctory compliance addition rather than meaningful thread continuation.
- @shuyue_ai [NONWIN, gateScore=4.0]: It avoids hashtag clutter and does not read like link spam.

### TQ / tactical_value_payload
- @anhtunbi536660 [NONWIN, gateScore=4.0]: However, the thread composition suffers from an extremely weak second tweet - the reply simply restates the main message without adding substantive value, making it feel like a perfunctory compliance addition rather than meaningful thread continuation.
- @carte_free [NONWIN, gateScore=4.0]: It opens with a hook, explains the product value, adds personal usage proof, includes leaderboard stats, and closes with links and CTA elements.
- @carte_free [NONWIN, gateScore=4.0]: Including both the referral/product link and Discord invite is useful, though the presence of multiple links plus multiple images makes the post slightly dense and closer to campaign content than organic posting.
- @lovaniceth [NONWIN, gateScore=4.0]: Flow moves from hook → specific examples → value proposition → call to action.
- @lovaniceth [NONWIN, gateScore=4.0]: Main weakness: slightly explanatory in places ('The higher the odds, the more the market is saying prove it' and 'This is actually useful') which borders on overexplaining per campaign guidelines.

### TQ / unknown_or_nuance
- @_dripxel [NONWIN, gateScore=5.0]: Minor deductions only for very slight run-on tendencies in the middle section, but overall highly polished for the platform.
- @0xqingmei [NONWIN, gateScore=5.0]: The tone is crypto-native and product-driven rather than corporate, which matches the brief well.
- @hexzypher [NONWIN, gateScore=5.0]: Platform optimization is strong, utilizing longform X features effectively while maintaining a conversational flow.
- @bencrypz [NONWIN, gateScore=5.0]: Sentence construction is clear and consistent, and the repetition pattern ("People say...") is used intentionally for rhetorical effect rather than feeling sloppy.
- @bencrypz [NONWIN, gateScore=5.0]: It is longform, but the formatting keeps it readable despite the high character count.

## Winner positive patterns (sample)
- @trita_a [OAA]: The tweet demonstrates a strong alignment with the campaign's goals and style, offering a unique perspective by emphasizing the transformation of 'CT takes' into actionable positions.
- @trita_a [CA]: The user provides proof of real product usage by mentioning their specific FUDP (217) and rank (80), which aligns with the 'Prove You Are Early' mission.
- @trita_a [IA]: The tweet accurately reflects the technical features and campaign data provided in the documentation.
- @trita_a [CC]: It includes the mandatory @FUDmarkets mention, the platform URL, and the specific Discord invite link.
- @trita_a [CC]: The text is original, highlights Solana deposits and Season 1, and meets all programmatic checks.
- @trita_a [EP]: The tweet is a strong execution of the 'trader-native' campaign style.
- @trita_a [EP]: The hook is excellent, using specific personal stats (217 FUDP, Rank 80) to establish immediate credibility and social proof.
- @trita_a [EP]: This is not another points grind.' The content structure is clean with short, digestible sentences and no em-dashes.
- @trita_a [EP]: The call-to-action is multi-layered: it provides the necessary links (website and Discord) and ends with a high-conviction question that invites users to share their own market ideas, driving conversation potential.
- @trita_a [TQ]: The tweet demonstrates high technical proficiency and adherence to the platform's constraints.
- @trita_a [TQ]: The overall structure follows the 'crypto-native' style guide, opening with a strong hook and ending with a direct engagement question.
- @trita_a [RQ]: The replies to this tweet are almost entirely low-effort engagement farming.
- @trita_a [RQ]: The vast majority are one-liners like 'Good job my friend,' 'Best one,' 'Keep cooking! 🔥,' 'lfg very good,' 'Great job buddy keep it up,' and 'Worth paying attention to. 👏' — these are textbook engagement farm replies with zero substance, no product knowledge, no personal take, and no connection to the actual FUD.markets product or the campaign topic.
- @trita_a [RQ]: The only reply with any real substance is the first one, which mentions 'real skin in the game' and proposes a specific market idea (DeFi summer this cycle) — this shows some engagement with the product concept and offers an actual answer to the question posed in the tweet.
- @trita_a [RQ]: Overall, the reply set is dominated by spam-tier engagement farming with almost no authentic, product-aware, or insightful content.
