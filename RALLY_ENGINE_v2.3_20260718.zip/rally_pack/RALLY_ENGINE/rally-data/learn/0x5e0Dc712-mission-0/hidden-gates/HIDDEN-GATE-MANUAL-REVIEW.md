# Hidden Gate Manual Review - mission-0

## Manual interpretation

Use this file to decide which tool-mined candidates become drafting law. Do not blindly convert every phrase into a hard rule.

## High-confidence hidden/mission gates to enforce pre-draft

### CTA reply engine
- Tool evidence count: see candidate map
- Manual decision: ACCEPT
- Drafting rule: CTA must be direct, answerable in under 5 seconds, and use concrete options tied to the thesis.
- Rebuild trigger: a fair judge could write a positive-but-capping sentence about this.

### Read-through density
- Tool evidence count: see candidate map
- Manual decision: ACCEPT
- Drafting rule: Use short paragraphs; avoid mini-essay density unless each extra line adds concrete mechanism or tension.
- Rebuild trigger: a fair judge could write a positive-but-capping sentence about this.

### Concrete scenario
- Tool evidence count: see candidate map
- Manual decision: ACCEPT
- Drafting rule: Use one specific scenario with receipts/proof/details; abstract stack language alone is not enough.
- Rebuild trigger: a fair judge could write a positive-but-capping sentence about this.

### Mechanism clarity
- Tool evidence count: see candidate map
- Manual decision: ACCEPT
- Drafting rule: Explain what the protocol/interface actually carries or decides, not only why it matters.
- Rebuild trigger: a fair judge could write a positive-but-capping sentence about this.

### Pool distinctiveness
- Tool evidence count: see candidate map
- Manual decision: ACCEPT
- Drafting rule: Avoid crowded frames unless adding a concrete twist; compare against nearest non-winner openings before drafting.
- Rebuild trigger: a fair judge could write a positive-but-capping sentence about this.

### Actionable value
- Tool evidence count: see candidate map
- Manual decision: ACCEPT
- Drafting rule: Include a rule/test/checklist that a reader can apply to an agent deal.
- Rebuild trigger: a fair judge could write a positive-but-capping sentence about this.

## Candidate class decisions

Every candidate must receive both a manual decision and a scope. Default scope is MISSION_ONLY.

### brand_bridge_promotional
- Count: 561
- Non-winner: 555
- Winner: 6
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### cta_reply_engine
- Count: 520
- Non-winner: 512
- Winner: 8
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### unknown_or_nuance
- Count: 481
- Non-winner: 481
- Winner: 0
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### distinctiveness_saturation
- Count: 387
- Non-winner: 382
- Winner: 5
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### media_format_technical
- Count: 313
- Non-winner: 313
- Winner: 0
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### readthrough_density
- Count: 287
- Non-winner: 283
- Winner: 4
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### hook_stop_power
- Count: 191
- Non-winner: 190
- Winner: 1
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### concrete_specificity
- Count: 188
- Non-winner: 185
- Winner: 3
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### rq_reply_quality
- Count: 161
- Non-winner: 156
- Winner: 5
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### tactical_value_payload
- Count: 128
- Non-winner: 127
- Winner: 1
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### mechanism_clarity
- Count: 118
- Non-winner: 117
- Winner: 1
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

### accuracy_claim_boundary
- Count: 104
- Non-winner: 104
- Winner: 0
- Manual decision: ACCEPT / REJECT / WATCH
- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY
- Reason:
- Rule to add if accepted:
- Example fail:
- Example pass:
- Promotion evidence needed if broader than MISSION_ONLY:

