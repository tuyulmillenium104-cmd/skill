# Winner Pull Map - mission-0

- Submissions: 44
- Winner/near-winner positive rows: 22
- Winner samples: 1
- Winner/near-winner samples used: 1

## Positive pull classes

| Class | Count |
|---|---:|
| brand_integration | 8 |
| concrete_scenario | 6 |
| fresh_frame | 4 |
| hook_magnet | 4 |
| conversation_trigger | 4 |
| human_voice | 3 |
| positive_general | 3 |
| shareable_line | 3 |
| technical_accuracy | 2 |
| structure_pacing | 2 |

## Gate x positive class

- **OAA / fresh_frame**: 3
- **OAA / brand_integration**: 2
- **IA / concrete_scenario**: 2
- **CC / brand_integration**: 2
- **EP / brand_integration**: 2
- **EP / hook_magnet**: 2
- **EP / shareable_line**: 2
- **TQ / hook_magnet**: 2
- **TQ / structure_pacing**: 2
- **RQ / conversation_trigger**: 2
- **OAA / human_voice**: 1
- **CA / brand_integration**: 1
- **CA / concrete_scenario**: 1
- **CA / positive_general**: 1
- **IA / positive_general**: 1
- **IA / technical_accuracy**: 1
- **IA / brand_integration**: 1
- **CC / concrete_scenario**: 1
- **CC / fresh_frame**: 1
- **EP / concrete_scenario**: 1
- **EP / human_voice**: 1
- **EP / conversation_trigger**: 1
- **TQ / technical_accuracy**: 1
- **TQ / shareable_line**: 1
- **TQ / positive_general**: 1
- **TQ / conversation_trigger**: 1
- **RQ / concrete_scenario**: 1
- **RQ / human_voice**: 1

## Winner / near-winner content mechanisms

- Opener types: {'declarative': 1}
- Median chars: 0
- Median paragraphs: 0

### CTA tails / endings
- ``

### Top winner/near-winner trigrams to understand, not blindly copy

## Positive evidence examples

### CA / brand_integration
- @trita_a [WIN, gateScore=2.0]: The tweet demonstrates exceptional alignment with the campaign objectives.

### CA / concrete_scenario
- @trita_a [WIN, gateScore=2.0]: The user provides proof of real product usage by mentioning their specific FUDP (217) and rank (80), which aligns with the 'Prove You Are Early' mission.

### CA / positive_general
- @trita_a [WIN, gateScore=2.0]: The user avoids prohibited elements like em dashes and corporate jargon, successfully positioning FUD as a place where 'takes become positions.'

### CC / brand_integration
- @trita_a [WIN, gateScore=2.0]: The tweet demonstrates exceptional compliance with all campaign requirements.
- @trita_a [WIN, gateScore=2.0]: It includes the mandatory @FUDmarkets mention, the platform URL, and the specific Discord invite link.

### CC / concrete_scenario
- @trita_a [WIN, gateScore=2.0]: It includes the mandatory @FUDmarkets mention, the platform URL, and the specific Discord invite link.

### CC / fresh_frame
- @trita_a [WIN, gateScore=2.0]: The text is original, highlights Solana deposits and Season 1, and meets all programmatic checks.

### EP / brand_integration
- @trita_a [WIN, gateScore=5.0]: The tweet is a strong execution of the 'trader-native' campaign style.
- @trita_a [WIN, gateScore=5.0]: It follows the campaign guidelines by avoiding corporate jargon and instead using punchy, direct language like 'This is not a dashboard.

### EP / concrete_scenario
- @trita_a [WIN, gateScore=5.0]: The hook is excellent, using specific personal stats (217 FUDP, Rank 80) to establish immediate credibility and social proof.

### EP / conversation_trigger
- @trita_a [WIN, gateScore=5.0]: The call-to-action is multi-layered: it provides the necessary links (website and Discord) and ends with a high-conviction question that invites users to share their own market ideas, driving conversation potential.

### EP / hook_magnet
- @trita_a [WIN, gateScore=5.0]: The hook is excellent, using specific personal stats (217 FUDP, Rank 80) to establish immediate credibility and social proof.
- @trita_a [WIN, gateScore=5.0]: It follows the campaign guidelines by avoiding corporate jargon and instead using punchy, direct language like 'This is not a dashboard.

### EP / human_voice
- @trita_a [WIN, gateScore=5.0]: The hook is excellent, using specific personal stats (217 FUDP, Rank 80) to establish immediate credibility and social proof.

### EP / shareable_line
- @trita_a [WIN, gateScore=5.0]: It follows the campaign guidelines by avoiding corporate jargon and instead using punchy, direct language like 'This is not a dashboard.
- @trita_a [WIN, gateScore=5.0]: The call-to-action is multi-layered: it provides the necessary links (website and Discord) and ends with a high-conviction question that invites users to share their own market ideas, driving conversation potential.

### IA / brand_integration
- @trita_a [WIN, gateScore=2.0]: The tweet includes all mandatory links (website, Discord, and @FUDmarkets mention) and provides proof of product usage through screenshots as required by the mission.

### IA / concrete_scenario
- @trita_a [WIN, gateScore=2.0]: The claim regarding 'Week 4' and 'rank 80' aligns with the context of an active user participating in the live Season 1.
- @trita_a [WIN, gateScore=2.0]: The tweet includes all mandatory links (website, Discord, and @FUDmarkets mention) and provides proof of product usage through screenshots as required by the mission.

### IA / positive_general
- @trita_a [WIN, gateScore=2.0]: The author follows the required style by using a 'trader-native' tone and avoids prohibited elements like em dashes or financial advice.

### IA / technical_accuracy
- @trita_a [WIN, gateScore=2.0]: The claim regarding 'Week 4' and 'rank 80' aligns with the context of an active user participating in the live Season 1.

### OAA / brand_integration
- @trita_a [WIN, gateScore=2.0]: The tweet demonstrates a strong alignment with the campaign's goals and style, offering a unique perspective by emphasizing the transformation of 'CT takes' into actionable positions.
- @trita_a [WIN, gateScore=2.0]: The language is natural, conversational, and avoids cliches, while the creative expression ties the campaign elements (e.g., 'FUD changes that') to a clear, original take.

### OAA / fresh_frame
- @trita_a [WIN, gateScore=2.0]: The tweet demonstrates a strong alignment with the campaign's goals and style, offering a unique perspective by emphasizing the transformation of 'CT takes' into actionable positions.
- @trita_a [WIN, gateScore=2.0]: The content is distinct from similar tweets by highlighting the product's speed ('The product is moving faster than most people realize') and its differentiation from dashboards or points systems.
- @trita_a [WIN, gateScore=2.0]: The language is natural, conversational, and avoids cliches, while the creative expression ties the campaign elements (e.g., 'FUD changes that') to a clear, original take.

### OAA / human_voice
- @trita_a [WIN, gateScore=2.0]: The language is natural, conversational, and avoids cliches, while the creative expression ties the campaign elements (e.g., 'FUD changes that') to a clear, original take.

### RQ / concrete_scenario
- @trita_a [WIN, gateScore=1.0]: The only reply with any real substance is the first one, which mentions 'real skin in the game' and proposes a specific market idea (DeFi summer this cycle) — this shows some engagement with the product concept and offers an actual answer to the question posed in the tweet.

### RQ / conversation_trigger
- @trita_a [WIN, gateScore=1.0]: The only reply with any real substance is the first one, which mentions 'real skin in the game' and proposes a specific market idea (DeFi summer this cycle) — this shows some engagement with the product concept and offers an actual answer to the question posed in the tweet.
- @trita_a [WIN, gateScore=1.0]: Overall, the reply set is dominated by spam-tier engagement farming with almost no authentic, product-aware, or insightful content.

### RQ / human_voice
- @trita_a [WIN, gateScore=1.0]: Overall, the reply set is dominated by spam-tier engagement farming with almost no authentic, product-aware, or insightful content.

### TQ / conversation_trigger
- @trita_a [WIN, gateScore=5.0]: The overall structure follows the 'crypto-native' style guide, opening with a strong hook and ending with a direct engagement question.

### TQ / hook_magnet
- @trita_a [WIN, gateScore=5.0]: It utilizes the long-form tweet feature effectively, maintaining readability through short, punchy sentences and clear line breaks.
- @trita_a [WIN, gateScore=5.0]: The overall structure follows the 'crypto-native' style guide, opening with a strong hook and ending with a direct engagement question.

### TQ / positive_general
- @trita_a [WIN, gateScore=5.0]: The media integration (screenshots) aligns with the mission to show real product usage.

### TQ / shareable_line
- @trita_a [WIN, gateScore=5.0]: It utilizes the long-form tweet feature effectively, maintaining readability through short, punchy sentences and clear line breaks.

### TQ / structure_pacing
- @trita_a [WIN, gateScore=5.0]: It utilizes the long-form tweet feature effectively, maintaining readability through short, punchy sentences and clear line breaks.
- @trita_a [WIN, gateScore=5.0]: The overall structure follows the 'crypto-native' style guide, opening with a strong hook and ending with a direct engagement question.

### TQ / technical_accuracy
- @trita_a [WIN, gateScore=5.0]: The tweet demonstrates high technical proficiency and adherence to the platform's constraints.

## Sample winner/near-winner content starts

### @trita_a winner=True
```text

```
