# WINNER-PULL CONTRACT STUB - mission-0

Fill manually before drafting. Use mechanisms, not copied winner phrases.

## Expected positive verdict lines

1.
2.
3.
4.
5.

## Winner mechanisms selected

| Mechanism | Evidence | Use now? | Expression without copying |
|---|---|---|---|
| brand_integration | see map | YES / NO |  |
| concrete_scenario | see map | YES / NO |  |
| fresh_frame | see map | YES / NO |  |
| hook_magnet | see map | YES / NO |  |
| conversation_trigger | see map | YES / NO |  |
| human_voice | see map | YES / NO |  |
| positive_general | see map | YES / NO |  |
| shareable_line | see map | YES / NO |  |
| technical_accuracy | see map | YES / NO |  |
| structure_pacing | see map | YES / NO |  |

## Planned evidence lines

- Hook:
- Scenario:
- Mechanism:
- Value rule:
- CTA:

## Anti-copy safety

- Winner phrase/motif to avoid copying:
- Our fresh expression:

