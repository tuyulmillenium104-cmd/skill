# Winner Build Spec - FUD Is Shipping (mission-0)

## Winner DNA Pattern (@trita_a, 100% gate score)

### What Won
1. **Personal proof as hook**: "I have been using @FUDmarkets long enough to have an actual opinion on it" + specific stats (217 FUDP, Rank 80)
2. **Strong tension hook**: "CT has been calling tops and bottoms for free for too long."
3. **Trader-native voice**: Punchy, direct, no corporate speak, no em dashes
4. **Structure**: Short sentences, clean line breaks, mobile-optimized
5. **CTA**: Ends with engagement question ("What market should I open next?")
6. **Required elements**: All present (@FUDmarkets, fud.markets, Discord, screenshot)

### What Judge Praised (EP 5/5)
- "The hook is excellent, using specific personal stats to establish immediate credibility"
- "Punchy, direct language like 'This is not a dashboard. This is not another points grind.'"
- "Clean structure with short, digestible sentences"
- "Multi-layered CTA that invites users to share their own market ideas"

### What Made Non-Winners Fail (97% = EP 4/5)
- Generic/polished AI-style writing ("the product feels smooth")
- Weak hooks ("Tried @FUDmarkets today and finally understand...")
- No specific product usage proof
- No personal stats/experience
- Softer CTA ("worth trying for yourself")

## Hidden Gates to Enforce

1. **CTA reply engine**: Direct, answerable in under 5 seconds, concrete options
2. **Read-through density**: Short paragraphs, no mini-essay density
3. **Concrete scenario**: One specific scenario with receipts/proof
4. **Mechanism clarity**: Explain what FUD actually does (takes become positions)
5. **Pool distinctiveness**: Avoid crowded frames ("FUD is great"), add concrete twist
6. **Actionable value**: Include something reader can apply

## Build Plan

### Hook (First 2 lines)
- Create tension: Problem with CT culture (free takes, no accountability)
- Establish credibility: Personal experience with specific stats
- Pattern: Declarative statement + personal proof

### Body (3-4 short paragraphs)
1. **Mechanism**: What FUD does differently (takes become positions)
2. **Proof**: Personal usage (FUDP, rank, specific markets interacted with)
3. **Fresh frame**: Not "FUD is great" but specific angle (speed, accountability, real conviction)

### CTA (Final line)
- Direct question that invites specific responses
- Pattern: "What market should I open next?" or "What's your take on [specific topic]?"
- Must be answerable in under 5 seconds

### Required Elements
- @FUDmarkets mention
- https://fud.markets (NO punctuation touching it)
- Discord invite: https://discord.gg/74hqWD75A
- Screenshot reference (user must provide)
- No em dashes anywhere
- ~600-850 chars (tactical genre)

### Voice Checklist
- Crypto-native (not corporate)
- Punchy (not polished)
- Direct (not explanatory)
- Trader-native (not generic)
- Short sentences (not paragraphs)

### Loser DNA to Avoid
- Generic AI phrases: "the product feels smooth", "worth trying for yourself"
- Weak hooks: "Tried X today", "I finally understand"
- No personal proof: Just describing features without personal usage
- Soft CTA: "you should try it" instead of specific question
- Em dashes (HARD FAIL)
- Punctuation touching URL (HARD FAIL)
