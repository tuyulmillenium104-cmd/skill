# LOSER-DNA STERILIZATION REPORT

Content: `content.txt`

Non-winner corpus: **43**

## Exact Overlap

| n-gram | total hits | unwhitelisted hits |
|---|---:|---:|
| 8 | 0 | 0 |
| 7 | 0 | 0 |
| 6 | 0 | 0 |
| 5 | 0 | 0 |
| 4 | 0 | 0 |

## Motif Hits

No motifs provided.

## Fatal Loser Patterns

- missing_clear_cta: CLEAR
- generic_hype: CLEAR
- unsupported_guarantee: CLEAR
- format_violation: CLEAR
- mention_tacked_on_end: CLEAR

## Decision: PASS
