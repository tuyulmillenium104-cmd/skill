# OAA STRUCTURE/TROPE AUDIT

- Opener family: most_generalization
- Non-winner opener hits: 0
- Decision: **PASS**

## Nearest Non-Winners
- @_dripxel sim=0.000 EP=5.0 — 
- @0x_4444 sim=0.000 EP=4.0 — 
- @mdmarufgnoma sim=0.000 EP=4.0 — 
- @0xqingmei sim=0.000 EP=4.0 — 
- @hexzypher sim=0.000 EP=4.0 — 
- @dennis92z sim=0.000 EP=4.0 — 
- @bencrypz sim=0.000 EP=4.0 — 
- @joshepsmitxu9b sim=0.000 EP=4.0 — 

## Warnings
- generic/template phrase hits: ['not just']

## Errors
- none
