# TACTICAL VALUE PAYLOAD CHECK

Decision: **PASS**

Score: **6/6**

## Checks

- hasMarker: True
- hasActionObject: True
- hasPayloadSentence: True
- applyToday: True
- notOnlyReflection: True
- integrated: True

## Payload candidates

- I opened my first @FUDmarkets position three weeks ago.
- Your track record goes onchain.
- Tell me your take: which market are you opening first?

## Reasons

- clear
