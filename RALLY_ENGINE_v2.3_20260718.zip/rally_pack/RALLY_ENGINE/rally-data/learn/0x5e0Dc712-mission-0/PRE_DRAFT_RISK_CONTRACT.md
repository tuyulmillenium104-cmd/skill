# PRE-DRAFT RISK CONTRACT

**Campaign:** 0x5e0Dc7129e9C67cC2e707ad7Ca8603e72bF0687c  
**Mission:** mission-0  
**Date:** 2026-07-18  
**Purpose:** Identify risks before content generation

---

## ⚠️ IDENTIFIED RISKS

### Risk 1: Em Dash Violation
**Severity:** CRITICAL (HARD FAIL)  
**Probability:** Medium (AI tends to use em dashes)  
**Mitigation:** 
- Consciously avoid em dashes
- Use periods, commas, or separate sentences instead
- Run TQ gate to catch any violations

**Contract:** I will NOT use em dashes anywhere in content.

---

### Risk 2: URL Punctuation Touching
**Severity:** CRITICAL (HARD FAIL)  
**Probability:** Medium (easy mistake)  
**Mitigation:**
- Place URLs on separate lines
- No punctuation immediately before/after URLs
- Run preflight gate to verify

**Contract:** URLs will be on clean lines with spacing.

---

### Risk 3: Generic AI Writing
**Severity:** HIGH (OAA failure)  
**Probability:** High (AI default mode)  
**Mitigation:**
- Use personal voice and experience
- Avoid polished, corporate language
- Include specific stats and details
- Run OAA gate to verify

**Contract:** Content will sound human, not AI-generated.

---

### Risk 4: Weak Hook
**Severity:** HIGH (EP failure)  
**Probability:** Medium  
**Mitigation:**
- Start with specific stats or strong opinion
- Create tension or curiosity
- Avoid generic openings ("Tried FUD today...")
- Run EP gate to verify

**Contract:** First sentence will create immediate tension.

---

### Risk 5: No Personal Proof
**Severity:** HIGH (EP + OAA failure)  
**Probability:** Medium  
**Mitigation:**
- Include specific stats (FUDP, rank, timeframes)
- Show real product usage
- Not just feature description
- Run EP gate to verify

**Contract:** Content will include personal stats and proof.

---

### Risk 6: Soft CTA
**Severity:** MEDIUM (CTA failure)  
**Probability:** Medium  
**Mitigation:**
- Use direct command ("Tell me...")
- Include behavioral verb + concrete object
- Make it answerable in under 5 seconds
- Run CTA gate to verify

**Contract:** CTA will be direct, specific, and low-friction.

---

### Risk 7: Long Paragraphs
**Severity:** MEDIUM (TQ + EP failure)  
**Probability:** Medium (AI tendency)  
**Mitigation:**
- Max 20 words per sentence
- Clear line breaks between paragraphs
- Mobile-optimized formatting
- Run TQ gate to verify

**Contract:** Sentences will be short and punchy.

---

### Risk 8: Missing Required Elements
**Severity:** HIGH (CC failure)  
**Probability:** Low (easy to check)  
**Mitigation:**
- Checklist: @FUDmarkets, fud.markets, Discord, screenshot
- Run compliance gate to verify
- Double-check before finalizing

**Contract:** All required elements will be present.

---

### Risk 9: Copying Winner Content
**Severity:** CRITICAL (originality failure)  
**Probability:** Medium (temptation to copy)  
**Mitigation:**
- Use winner as benchmark, not template
- First-principles thesis generation
- Run anti-copy check
- Ensure unique angle and voice

**Contract:** Content will be original, not derivative.

---

### Risk 10: Assuming Data
**Severity:** CRITICAL (Meta-Rule #0 violation)  
**Probability:** Low (but happened in run 1)  
**Mitigation:**
- All data fetched from API
- No assumptions about campaign or product
- Verify all claims against knowledge base
- Run IA gate to verify

**Contract:** All claims will be verified against fetched data.

---

## 🎯 RISK MITIGATION STRATEGY

### Pre-Draft:
1. ✅ Review WINNER_DNA_ANALYSIS.md (what works)
2. ✅ Review LOSER_DNA_ANALYSIS.md (what fails)
3. ✅ Review MISSION_TRUTH.md (requirements)
4. ✅ Review SOURCE_TRUTH.md (benchmark)

### During Draft:
1. ✅ Follow first-principles approach (ORIGINAL-THESIS-ENGINE.md)
2. ✅ Apply exponential content standard
3. ✅ Avoid all 10 identified risks
4. ✅ Use personal voice, not AI voice

### Post-Draft:
1. ✅ Run all 11 content gates
2. ✅ Verify no em dashes
3. ✅ Verify URLs clean
4. ✅ Verify all required elements
5. ✅ Verify originality (not copy of winner)

---

## 📋 COMPLIANCE CHECKLIST

Before content is considered final, verify:

- [ ] No em dashes anywhere
- [ ] URLs on clean lines (no punctuation touching)
- [ ] Sounds human, not AI-generated
- [ ] Strong hook (tension/curiosity)
- [ ] Personal proof (specific stats)
- [ ] Direct CTA (behavioral verb + concrete object)
- [ ] Short sentences (max 20 words)
- [ ] All required elements present
- [ ] Original thesis (not copy of winner)
- [ ] All claims verified against data
- [ ] Crypto-native voice (not corporate)
- [ ] Mobile-optimized formatting

---

## 🔒 CONTRACT SEALED

This risk contract is now binding.  
I will not proceed to content generation until all risks are acknowledged.  
I will verify compliance at every stage.  
Any violation = RESTART from the point of violation.

---

**Status:** ✅ PRE-DRAFT RISK CONTRACT SEALED  
**Next:** PHASE 3 - Content Generation (First-Principles)

**Compliance:** RALLY_FUNDAMENTAL_LAW v1.0 - Step 2.6  
**Verified by:** AI Agent  
**Date:** 2026-07-18
