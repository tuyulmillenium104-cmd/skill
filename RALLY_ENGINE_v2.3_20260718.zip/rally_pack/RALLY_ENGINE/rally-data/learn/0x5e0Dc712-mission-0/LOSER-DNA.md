# LOSER-DNA STERILIZATION REPORT

Content: `rally-data/learn/0x5e0Dc712-mission-0/content_candidate7.txt`

Non-winner corpus: **43**

## Exact Overlap

| n-gram | total hits | unwhitelisted hits |
|---|---:|---:|
| 8 | 0 | 0 |
| 7 | 0 | 0 |
| 6 | 0 | 0 |
| 5 | 6 | 6 |
| 4 | 13 | 13 |

## Motif Hits

No motifs provided.

## Fatal Loser Patterns

- missing_clear_cta: CLEAR
- generic_hype: CLEAR
- unsupported_guarantee: CLEAR
- format_violation: CLEAR
- mention_tacked_on_end: CLEAR

## Decision: FAIL
Reasons: unwhitelisted_5gram_plus=6
