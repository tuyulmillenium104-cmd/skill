# RQ MECHANICS CALIBRATION CHECK - GOLD V3

Decision: **FAIL**

- protocol/product campaign: True
- mechanics: 15/20 (75%)
- decision markers: 1/20 (5%)
- decision words: 20/20 (100%)
- skeptic: 7/20 (35%)

## Reasons
- 4 rows fail per-row subject/decision/skeptic standard
- decision-marker coverage 5% < 75%

## Failures
- R9: low-effort/generic/metadata
- R12: low-effort/generic/metadata
- R13: low-effort/generic/metadata
- R16: missing campaign/post mechanism or source reference
