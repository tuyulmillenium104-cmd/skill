# QNA GOLD AUDIT - GOLD V3

Decision: **FAIL**

- pairs: 20
- type counts: {'Challenge': 5, 'Technical Deep-Dive': 5, 'Specific Probe': 5, 'Hot Take': 4, 'Real Experience': 1}
- pairs Q/A/Feel>=4: 12/20

## Reasons
- type distribution Specific Probe: 5 != 4
- type distribution Real Experience: 1 != 2
- 8 pairs have Q/A/Feel score below 4

## Failures
- R3: Q=3, A=4, Feel=5; Specific Probe lacks exact source quote; A lacks decision/action word
- R7: Q=3, A=5, Feel=5; Specific Probe lacks exact source quote
- R9: Q=4, A=3, Feel=5; Hot Take lacks bold/alternative thesis; A low-effort phrase
- R11: Q=3, A=5, Feel=5; Specific Probe lacks exact source quote
- R12: Q=5, A=3, Feel=5; A low-effort phrase
- R13: Q=4, A=3, Feel=5; Hot Take lacks bold/alternative thesis; A low-effort phrase
- R15: Q=3, A=4, Feel=5; Specific Probe lacks exact source quote; A lacks decision/action word
- R20: Q=3, A=4, Feel=5; Specific Probe lacks exact source quote; A lacks decision/action word
