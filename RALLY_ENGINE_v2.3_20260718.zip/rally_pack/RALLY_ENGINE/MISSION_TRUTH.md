# MISSION TRUTH LOCK

**Campaign:** 0x5e0Dc7129e9C67cC2e707ad7Ca8603e72bF0687c  
**Mission:** mission-0  
**Date:** 2026-07-18

---

## 📋 Campaign Overview

**Title:** FUD Is Shipping. Prove You Were Early.  
**Creator:** FUD Markets (@fudmarkets)  
**Token:** FUDP (FUD Points) - Season 1  
**Duration:** 15 days (July 7-22, 2026)  
**Status:** Active

---

## 🎯 Mission: PROVE YOU ARE EARLY

### Mission Description:
Use FUD, open or interact with a real market, take a screenshot, and publish an original X post about why FUD is growing.

Your post should show real product usage, include a clear take, and help bring more people into the FUD ecosystem.

### Mission Rules (Key Points):

**Required Elements:**
1. ✅ Screenshot from FUD (market opened/interacted, profile, FUD Points, badges, etc.)
2. ✅ @FUDmarkets mention
3. ✅ https://fud.markets URL
4. ✅ Discord invite: https://discord.gg/74hqWD75A
5. ✅ Real take about FUD, the market, or the product

**Good Angles:**
- FUD is shipping every week
- Every take becomes a position
- CT takes are not free anymore
- Open a market, take a side
- Solana deposits are live
- FUD Points Season 1 is live
- FUD is turning crypto attention into markets
- Consumer crypto needs apps people actually use

**Bad Submissions (DO NOT):**
- ❌ Link-only posts
- ❌ Fake screenshots
- ❌ Copied content
- ❌ Generic AI text
- ❌ Low-effort "join FUD" posts
- ❌ Financial advice
- ❌ Airdrop language
- ❌ Token allocation language
- ❌ Claims that FUDP converts to $FUD
- ❌ **Em dashes** (HARD FAIL)

**Style Guide:**
- Crypto-native, sharp, direct, product-driven
- Punchy, honest, meme-aware, trader-native
- First sentence should create tension, curiosity, or clear opinion
- No corporate speak, no generic AI copy, no empty hype
- No em dashes

---

## 🎓 Campaign Goal

The goal is NOT generic awareness.  
The goal is:
- Real app usage
- Real screenshots
- Real takes
- Real community growth
- More people joining the FUD ecosystem

Good content should make people want to:
- Open FUD
- Join the Discord
- Take a side
- Long or short a market
- Follow or fade a call
- Understand why FUD is becoming a new consumer crypto app

---

## 📊 Knowledge Base (Key Facts)

**What is FUD.markets?**
- Crypto-native prediction market
- Every take can become a position
- Users open/interact with markets around tokens, narratives, sports, crypto events
- Instead of "I called it", users put conviction onchain

**Recent Updates:**
- FUD Points Season 1
- Creator quests and community XP
- Profile modal updates with FUD Points and badges
- Solana USDC deposits into the FUD vault
- Bradbury shadow oracle running in production
- New markets around trending crypto narratives

**FUD Points (FUDP):**
- Season 1 points tracking activity and contribution
- NOT redeemable for money
- NOT a promise of $FUD
- Do NOT guarantee airdrop, allocation, snapshot, conversion, or future reward
- Approved submissions may earn FUDP from creator/community side

---

## 🔒 Mission Truth - LOCKED

This mission truth is now the foundation for all content generation.  
All content must align with:
1. Campaign ask (real usage, real take, bring people to FUD)
2. Rally judge desire (crypto-native, sharp, direct, no em dashes)
3. Campaign rules (all required elements, no prohibited content)
4. Style guide (punchy, trader-native, no corporate speak)

**Formula:** Campaign Ask × Rally Judge Desire

---

**Status:** ✅ MISSION TRUTH LOCKED  
**Next:** Step 1.4 - Source Truth Snapshot

**Compliance:** RALLY_FUNDAMENTAL_LAW v1.0 - Step 1.3  
**Verified by:** AI Agent  
**Date:** 2026-07-18
