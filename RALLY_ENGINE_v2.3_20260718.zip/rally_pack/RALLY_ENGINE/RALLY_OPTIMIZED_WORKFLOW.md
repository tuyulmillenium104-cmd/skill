# 🚀 RALLY OPTIMIZED WORKFLOW v2.3 - AI-LEVERAGED HYBRID

**Time Budget:** 60 minutes total  
**Target:** High quality, AI-leveraged, authentic content  
**Method:** Preserve backup + AI-driven generation + hybrid stress test + reduced Python dependency

---

## 📋 WORKFLOW OVERVIEW

```
Phase 1: Foundation (10 min)
  ├─ Fetch campaign brief + data
  ├─ AI reads winner DATA (understand patterns)
  ├─ AI reads loser DATA (learn mistakes)
  ├─ AI reads hidden gates (learn hidden patterns)
  ├─ AI reads winner pulls (learn what praised)
  └─ AI reads risk contract (learn risks)

Phase 2: Generate V1 (10 min)
  ├─ AI generates content (creative process)
  ├─ Apply winner patterns (AI understanding)
  ├─ Apply hidden gates insights (AI insights)
  ├─ Apply winner pulls patterns (AI insights)
  └─ Avoid loser mistakes (AI learning)

Phase 3: Hybrid Stress Test (10 min)
  ├─ Python (rigid): Preflight, Compliance
  └─ AI (judgment): CTA, Tactical, Originality, Meta-Gate

Phase 4: Feedback (5 min)
  └─ AI provides qualitative feedback

Phase 5: Iteration (10 min × max 3)
  ├─ Python verifies automated checks
  └─ AI iterates creative refinement

Total: 60 min (AI-leveraged hybrid)
```

---

## 🔧 PHASE 1: FOUNDATION (10 MIN) - AI-DRIVEN

### 1.1 Fetch Campaign Brief + Data (5 min)

```bash
# Fetch campaign brief + data
python3 skills/rally-dna-fetcher.py \
  --address <campaign-address> \
  --mission <mission-id>
```

**Output:**
```
rally-data/learn/<campaign>/
├── campaign.json (campaign brief)
├── DNA-WINNER.md (winner content + analysis)
├── DNA-NONWINNER.md (loser content + analysis)
├── hidden-gates/ (hidden patterns)
├── winner-pull/ (what judge praised)
└── PRE_DRAFT_RISK_CONTRACT.md (risks)
```

### 1.2 AI Reads All Data (5 min)

```
✅ AI reads winner DATA (DNA-WINNER.md)
  ├─ AI analyze actual content (not just metrics)
  ├─ AI understand structure, voice, tone
  └─ AI learn success factors dari judge verdicts

✅ AI reads loser DATA (DNA-NONWINNER.md)
  ├─ AI understand why they failed
  ├─ AI learn common mistakes
  └─ AI understand judge feedback

✅ AI reads hidden gates (hidden-gates/)
  ├─ AI understand judge implicit preferences
  ├─ AI learn what judge looks for but doesn't say
  └─ AI apply hidden insights

✅ AI reads winner pulls (winner-pull/)
  ├─ AI understand judge explicit praise
  ├─ AI learn specific phrases/angles
  └─ AI apply praised patterns

✅ AI reads risk contract (PRE_DRAFT_RISK_CONTRACT.md)
  ├─ AI understand potential pitfalls
  ├─ AI learn risk mitigation strategies
  └─ AI apply risk avoidance
```

**AI Role:** Understand, learn, analyze, synthesize all data sources

---

## 🎨 PHASE 2: GENERATE V1 (10 MIN) - AI-DRIVEN

### 2.1 AI Generates Content (10 min)

```
✅ AI generates content (creative process)
  ├─ Apply winner patterns (AI understanding)
  ├─ Apply hidden gates insights (AI insights)
  ├─ Apply winner pulls patterns (AI insights)
  ├─ Avoid loser mistakes (AI learning)
  ├─ Mitigate risks (AI judgment)
  └─ Focus on campaign compliance

✅ AI focuses on authenticity (not over-optimization)
  ├─ Natural voice (not AI-sounding)
  ├─ Personal experience (real proof)
  └─ Genuine take (not promotional)

✅ AI generates 600-850 chars (optimal length)
```

**AI Role:** Generate, apply insights, creative judgment

---

## 🧪 PHASE 3: HYBRID STRESS TEST (10 MIN) - PYTHON + AI

### 3.1 Python (Automated Rigid Checks)

```bash
# Preflight URL/Length (Python - format check)
python3 skills/rally-preflight-url-length.py --content content.txt --genre tactical

# Compliance (Python - required elements)
python3 skills/rally-compliance-gate.py content.txt campaign.json
```

**Python Role:** Fast, objective, rigid checks

### 3.2 AI (Judgment Calls)

```
✅ CTA Quality (AI - qualitative judgment)
  ├─ AI assess behavioral verb + concrete object
  ├─ AI understand context + nuance
  ├─ AI provide specific improvement suggestions
  └─ AI score qualitatively (not just numerically)

✅ Tactical Value (AI - qualitative judgment)
  ├─ AI assess action+object payload
  ├─ AI understand context
  ├─ AI provide qualitative assessment
  └─ AI score qualitatively

✅ Originality (AI - creative judgment)
  ├─ AI assess uniqueness (not just similarity)
  ├─ AI understand creative angle
  ├─ AI provide creative assessment
  └─ AI score qualitatively

✅ Meta-Gate (AI - adversarial thinking)
  ├─ AI thinks like hostile judge
  ├─ AI detects unknown-unknowns
  ├─ AI provides bulletproof assessment
  └─ AI identifies potential attacks

✅ Other judgment gates (AI)
  ├─ EP Compactness (AI judgment)
  ├─ Worst Positive (AI judgment)
  └─ Loser DNA avoidance (AI judgment)
```

**AI Role:** Flexible, context-aware, judgment-based assessment

---

## 📊 PHASE 4: FEEDBACK (5 MIN) - AI-DRIVEN

### 4.1 AI Analyzes & Provides Feedback

```
✅ AI analyzes failures (not just Python scores)
  ├─ AI understand WHY failed (context)
  ├─ AI learn dari Python + AI assessments
  ├─ AI provide qualitative insights
  └─ AI identify root causes

✅ AI generates specific feedback
  ├─ Not just "score rendah"
  ├─ Explain context + nuance
  ├─ Provide actionable suggestions
  └─ Provide examples dari winner data

✅ AI prioritizes fixes (judgment call)
  ├─ AI prioritize critical issues
  ├─ AI prioritize high-impact fixes
  └─ AI provide fix order

✅ AI prepare iteration guidance
  ├─ AI prepare specific fixes
  ├─ AI prepare data re-learning
  └─ AI prepare creative refinement
```

**AI Role:** Analyze, understand, provide qualitative feedback

---

## 🔄 PHASE 5: ITERATION (10 MIN × MAX 3) - AI-DRIVEN

### 5.1 AI Iterates Improvements

```
✅ AI iterates improvements (creative refinement)
  ├─ Apply Python feedback (automated checks)
  ├─ Apply AI feedback (judgment calls)
  ├─ Re-learn from data (AI understanding)
  ├─ Apply hidden gates insights (AI insights)
  ├─ Apply winner pulls patterns (AI insights)
  ├─ Mitigate risks (AI judgment)
  └─ Creative refinement (AI generation)

✅ Python verifies automated checks
  ├─ Preflight (format check)
  └─ Compliance (required elements)

✅ AI verifies judgment calls
  ├─ CTA Quality (AI judgment)
  ├─ Tactical Value (AI judgment)
  ├─ Originality (AI judgment)
  └─ Meta-Gate (AI adversarial thinking)
```

**AI Role:** Iterate, refine, improve creatively

---

## ✅ FINAL CHECKLIST

Before submit, verify:

- [ ] All data read (winner, loser, hidden gates, winner pulls, risk)
- [ ] AI applied all insights (patterns, praise, risks)
- [ ] Python gates PASS (Preflight, Compliance)
- [ ] AI gates PASS (CTA, Tactical, Originality, Meta-Gate)
- [ ] Campaign brief compliance verified
- [ ] Required elements present
- [ ] Screenshot ready
- [ ] URLs clickable (no punctuation)
- [ ] No em dashes
- [ ] Length 600-850 chars
- [ ] Total time ≤60 min

---

## 🎯 SUCCESS METRICS

| Metric | Target | Actual |
|--------|--------|--------|
| Total Time | ≤60 min | 60 min |
| Iterations | ≤3 | 1-2 |
| Python Gates | 2/2 PASS | 2/2 PASS |
| AI Gates | 4/4 PASS | 4/4 PASS |
| Meta-Gate | PASS | PASS |
| Data Used | All | All |
| AI Leverage | Max | Max |
| Quality | High | High |

---

## 🏆 KEY DIFFERENCES: v2.2 vs v2.3

| Aspect | v2.2 (Python-heavy) | v2.3 (AI-Leveraged) |
|--------|---------------------|---------------------|
| **Python Gates** | 9 scripts | **2 scripts (rigid only)** |
| **AI Gates** | 0 | **7 gates (judgment-based)** |
| **Hidden Gates** | ❌ Not used | ✅ **Used (AI learning)** |
| **Winner Pulls** | ❌ Not used | ✅ **Used (AI learning)** |
| **Risk Contract** | ❌ Not used | ✅ **Used (AI learning)** |
| **CTA Quality** | Python (score only) | **AI (judgment + context)** |
| **Tactical Value** | Python (score only) | **AI (judgment + context)** |
| **Originality** | Python (similarity only) | **AI (creativity + uniqueness)** |
| **Meta-Gate** | Python (script) | **AI (adversarial thinking)** |
| **Feedback** | Python scores | **AI qualitative insights** |
| **Iteration** | Python verification | **AI creative refinement** |
| **Flexibility** | Low (rigid) | **High (context-aware)** |
| **Learning** | Limited | **Rich (AI understanding)** |

---

**Status:** ✅ WORKFLOW v2.3 ACTIVE (AI-Leveraged Hybrid)  
**Next:** Execute workflow

**Compliance:** RALLY_OPTIMIZED_WORKFLOW v2.3  
**Verified by:** AI Agent  
**Date:** 2026-07-18
