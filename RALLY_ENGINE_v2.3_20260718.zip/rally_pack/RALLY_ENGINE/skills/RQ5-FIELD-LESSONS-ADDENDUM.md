# ARCHIVED POINTER - RQ5-FIELD-LESSONS-ADDENDUM.md

This legacy protocol/reference file has been archived and is **not active authority**.

Active authority is declared in:

`ACTIVE_SKILL_MANIFEST.md`

Current drafting workflow uses mission-specific evidence, hidden-gate mining, winner-pull mining, manual no-cut review, and Python checkers as safety nets.

Historical file location:

`skills/_archive/legacy_protocol_docs/RQ5-FIELD-LESSONS-ADDENDUM.md`

Do not load archived legacy protocol rules by default. They are historical reference only.
