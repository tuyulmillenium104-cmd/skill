# HIDDEN GATE SCOPE REGISTRY

Status: ACTIVE reference
Purpose: prevent mission-specific hidden gates from contaminating unrelated campaigns.

## Default rule

All newly discovered hidden gates default to `MISSION_ONLY`.

Promotion requires evidence:

- `MISSION_ONLY`: one mission's data.
- `CAMPAIGN_ONLY`: repeated across multiple missions in the same campaign.
- `CAMPAIGN_FAMILY`: repeated across similar mission types in different campaigns.
- `GLOBAL`: repeated across unrelated campaigns and safe for all mission types.

## Global rules currently allowed

These are safe universal principles:

- Follow literal mission brief.
- Do not fabricate claims.
- Do not leak private skill/checker/audit language into public copy.
- Avoid generic hype unless the brief explicitly asks for hype.
- CTA should be answerable and concrete when engagement matters.
- If a rule conflicts with the literal brief, the brief wins.

## Campaign-family examples

### Quote/reply launch missions

- Content must feel like a response to the quoted/replied source, not a standalone essay only.
- The launch relevance should be visible before the final third.

### Product/protocol explainers

- Mechanism must be clear in plain language.
- Metaphor must resolve into mechanism within 1-2 paragraphs.
- Concrete scenario should prove the product need.

### Personal/story missions

- Personal stake and decision are primary.
- Product mechanics should not overpower the story unless brief asks for it.

## Mission-only examples

- Required handle/link/quote for a specific mission.
- A saturated motif found only in one mission pool.
- A phrase or analogy specific to one product's current campaign.

## Forbidden behavior

Do not globally ban or require campaign-specific concepts such as:

- proof bundle
- claim number
- itinerary
- CampaignSpecificToken
- CampaignSpecificMascot
- CampaignSpecificProductName
- CampaignSpecificAllowlistTerm
- CampaignSpecificAnalogy

unless the current mission evidence and brief require them.
