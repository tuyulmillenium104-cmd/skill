# KNOWN-GATE ABSOLUTE REPORT TEMPLATE

Campaign:
Mission:
Address:
Draft version:
Date:

## 0. Truth statement

This is not a guarantee of external Rally all-max, winner, or top 1%.

Known-Gate Absolute means all known controllable cut surfaces in current evidence are closed.

## 1. Final content

```text
...
```

## 2. Campaign Ask closure

| Requirement | Evidence | Status |
|---|---|---|
| Mission ID correct |  | PASS / FAIL |
| Required quote/reply/link |  | PASS / FAIL |
| Required handles |  | PASS / FAIL |
| Negative constraints |  | PASS / FAIL |
| Literal ask answered |  | PASS / FAIL |

## 3. Source Truth closure

| Claim / Mechanism | Source evidence | Status |
|---|---|---|
|  |  | PASS / FAIL |

## 4. EP known deduction closure

| Known EP cut surface | How this draft closes it | Status |
|---|---|---|
| cta_weak |  | PASS / FAIL |
| conversation_limited |  | PASS / FAIL |
| value_not_exceptional |  | PASS / FAIL |
| structure_density |  | PASS / FAIL |
| hook_weak |  | PASS / FAIL |
| specificity_missing |  | PASS / FAIL |
| generic_formulaic |  | PASS / FAIL |
| brand_promotional |  | PASS / FAIL |
| too_niche_or_abstract |  | PASS / FAIL |
| mechanism_unclear |  | PASS / FAIL |
| media_format_issue |  | PASS / FAIL |
| authenticity_polish_tax |  | PASS / FAIL |

## 5. Winner-pull evidence

| Praise area | Evidence line | Status |
|---|---|---|
| Hook |  | PASS / FAIL |
| Concrete scenario |  | PASS / FAIL |
| Mechanism clarity |  | PASS / FAIL |
| Value payload |  | PASS / FAIL |
| CTA/conversation |  | PASS / FAIL |
| Human voice |  | PASS / FAIL |
| Structure/read-through |  | PASS / FAIL |
| Brand/source integration |  | PASS / FAIL |
| Distinctiveness |  | PASS / FAIL |

## 6. Human-typed closure

- Public skill leakage: PASS / FAIL
- Label-like shells: PASS / FAIL
- Audit voice: PASS / FAIL
- Human main content: PASS / FAIL
- Human Q/A: PASS / FAIL

## 7. Irreducible closure

- Line necessity: PASS / FAIL
- Substitution test: PASS / FAIL
- Compression test: PASS / FAIL
- Expansion test: PASS / FAIL
- Hostile judge 10-attack: PASS / FAIL
- Non-expert retell: PASS / FAIL
- Expert respect: PASS / FAIL

## 8. Local gate closure

| Gate | Result |
|---|---|
| Compliance |  |
| CTA |  |
| Tactical value |  |
| Compactness |  |
| Loser-DNA |  |
| Originality |  |
| TQ |  |
| OAA |  |
| IA |  |
| EP semantic |  |
| Worst-positive |  |
| RQ prompt-answer |  |
| RQ mechanics |  |
| Naturalness |  |
| QNA Gold |  |
| RQ Gold policy |  |
| Final integrity |  |

## 9. Remaining unknown risk

Remaining risk is limited to:

- unknown/future judge gates;
- judge variance;
- external engagement;
- account/timing behavior;
- organic reply quality;
- competitor pool.

## 10. Final decision

`KNOWN-GATE ABSOLUTE PASS / NOT ABSOLUTE`

Reason:
