# ONE SESSION / ONE RUN PROTOCOL

Status: ACTIVE
Date: 2026-07-18 Asia/Jakarta

## Purpose

Run Rally generation and stress in one chat/session while keeping roles internally separated.

Trigger:

```text
/rally <campaign-address> misi <number>
```

Default behavior:

```text
one command = one complete fail-fast run
```

A run may end early with a STOP report. It must not force a weak draft to final.

## Internal role separation

Even inside one chat, roles are locked:

1. `GENERATE MODE` - creates main-content candidates.
2. `STRESS MODE` - judges candidates, fail-fast.
3. `REGENERATE MODE` - creates a new candidate from stress feedback if core fail.
4. `Q&A MODE` - runs only after main content passes.
5. `FINAL MODE` - runs only after main content and Q&A pass.

## Core law

```text
Campaign Ask x Rally Judge Desire
Data does not write. Data judges.
```

## One-run candidate loop

Default max candidates:

```text
main_content_candidates_max = 3
```

For each candidate:

1. Generate main content from truth lock, EP surface selection, original thesis, and creative intelligence.
2. Stress main content with fail-fast stages.
3. If main content passes, stop candidate search and proceed to Q&A.
4. If main content fails because of HARD FAIL or core CREDIBLE DEDUCTION, reject candidate and generate a new one from feedback.
5. Do not patch/tambal-sulam core failures.
6. Surgical rewrite is allowed only for minor technical issues or SOFT WATCH-level issues.

## Regenerate versus surgical rewrite

### Regenerate new content when failure touches core angle

Examples:

- hook is crowded or weak,
- screenshot cannot support the chosen surface,
- brand-tone risk hits the thesis,
- content is too generic or AI/corporate,
- product mechanism is unclear,
- originality/pool overlap is material,
- unmapped risk gate finds a credible core deduction.

Action:

```text
CANDIDATE_REJECTED
REGENERATE_WITH_FEEDBACK
```

### Surgical rewrite allowed only for minor issues

Examples:

- one missing URL,
- typo,
- URL punctuation,
- one forbidden punctuation character,
- CTA option wording adjustment,
- slight length trim,
- one phrase too sharp while core angle remains sound.

Action:

```text
SURGICAL_REWRITE_ALLOWED
```

## Fail-fast stress stages

Main-content stress stages:

0. Intake validity.
1. Hard compliance.
2. Campaign/source/media fit.
3. Creative viability.
4. Unmapped Risk Gate.
5. Known gate stress.

If a HARD FAIL appears, stop immediately.
If a CREDIBLE DEDUCTION hits the core angle, reject candidate and regenerate.

## Unmapped Risk Gate

Required in every main-content stress.

Question:

```text
What would a real Rally judge dislike or cap even if all known checkers pass?
```

Classify issues:

- HARD FAIL
- CREDIBLE DEDUCTION
- SOFT WATCH
- TASTE PREFERENCE
- FALSE POSITIVE

Only HARD FAIL and core CREDIBLE DEDUCTION can stop candidate progression.

## Q&A rule

Q&A must not be generated until:

```text
MAIN_CONTENT_STRESS_PASS
```

If all main-content candidates fail:

```text
Q&A NOT GENERATED
RUN STOP REPORT
```

## Q&A failure loop

Default max Q&A attempts:

```text
qna_attempts_max = 2
```

If Q&A fails because of formulaic set-level smell or RQ mechanics failure, regenerate Q&A from the passed main content. Do not change main content unless Q&A failure reveals a main-content CTA flaw.

## Run outcomes

### Main content all candidates fail

Output:

```text
RUN_STOP_MAIN_CONTENT_FAILED
Q&A NOT GENERATED
```

Report must include:

- each candidate,
- failure reason,
- repeated failure pattern,
- what generate should try next,
- whether user/screenshot input is needed.

### Main content pass, Q&A fail

Output:

```text
MAIN_CONTENT_PASS
Q&A_FAIL
FINAL NOT READY
```

### Full pass

Output:

```text
LOCAL STRICT PASS
KNOWN-GATE ABSOLUTE LOCAL PASS
CONTROLLABLE-SIDE PASS
```

Still forbidden:

```text
guaranteed all-max
guaranteed winner
guaranteed top 1%
guaranteed RQ5
```

## Required final report sections

Every one-run folder must include:

- `RUN_MODE.md`
- `CANDIDATE_LEDGER.md`
- `MAIN_CONTENT_STRESS_REPORT.md`
- `QNA_STRESS_REPORT.md` if Q&A generated
- `FINAL_REPORT.md` if final pass
- `STOP_REPORT.md` if stopped early

## Active instruction for this chat

When the user sends `/rally <address> misi <number>`, run this protocol automatically unless the user explicitly asks for step-by-step mode.

## One-run completeness enforcement

Every final one-run must pass:

```bash
python3 skills/rally-one-run-completeness-check.py \
  --run-dir <run-dir> \
  --mode final \
  --out-json <run-dir>/reports/one-run-completeness.json \
  --out-md <run-dir>/reports/ONE-RUN-COMPLETENESS.md
```

This checker requires both the older full-workflow artifacts and the newer one-run artifacts. It prevents the split generate/stress mode from accidentally dropping files from the old workflow.

## Fresh-but-inevitable surface requirement

Every main-content candidate must apply:

`skills/FRESH-BUT-INEVITABLE-CONTENT-PROTOCOL.md`

Generate must identify crowded surfaces and choose a non-crowded but campaign-native surface before drafting. Stress must verify the chosen surface is fresh, clear, supported, and not merely weird.

If the surface is crowded or weird, reject the candidate and generate a new surface rather than patching one line.
