# PRE-DRAFT HIDDEN-GATE CONTRACT TEMPLATE

Campaign:
Mission:
Address:
Evidence refresh:
Submissions mined:
Winners:
Non-winners:
Full content coverage:

## 1. Literal mission ask

- Required action:
- Required mentions/quote/reply/link:
- Negative constraints:
- Product/brand truth boundaries:

## 2. Winner DNA anchors

- Winning hook pattern:
- Winning structure:
- Winning mechanism explanation:
- Winning CTA pattern:
- Winning tone:

## 3. Hidden-gate candidates reviewed

| Candidate | Tool evidence | Manual decision | Scope | Reason |
|---|---:|---|---|---|
| cta_reply_engine |  | ACCEPT / WATCH / REJECT | GLOBAL / FAMILY / CAMPAIGN / MISSION |  |
| mechanism_clarity |  | ACCEPT / WATCH / REJECT | GLOBAL / FAMILY / CAMPAIGN / MISSION |  |
| readthrough_density |  | ACCEPT / WATCH / REJECT | GLOBAL / FAMILY / CAMPAIGN / MISSION |  |
| distinctiveness_saturation |  | ACCEPT / WATCH / REJECT | GLOBAL / FAMILY / CAMPAIGN / MISSION |  |
| unknown_or_nuance |  | ACCEPT / WATCH / REJECT | GLOBAL / FAMILY / CAMPAIGN / MISSION |  |

## 4. Accepted rules for this mission

Only include rules that apply to the current campaign/mission.

| Rule | Scope | Evidence | Why it applies now |
|---|---|---|---|
|  | MISSION_ONLY |  |  |

## 5. Global/family promotion candidates

Do not promote without multi-campaign evidence.

| Candidate rule | Proposed scope | Evidence needed before promotion |
|---|---|---|
|  | CAMPAIGN_FAMILY / GLOBAL |  |

## 6. Rebuild triggers

Rebuild, do not patch, if a fair judge could write:

- "Strong, but ..."
- "Clear, but ..."
- "Aligned, but ..."

Specific triggers:

1.
2.
3.

## 7. Watch-only risks

Risks to monitor but not overfit:

- 

## 8. Angle contract

This draft will win by using:

- Concrete scenario:
- Core thesis:
- Mechanism sentence:
- Value rule/test:
- CTA:
- Distinctive frame not crowded in pool:

## 9. Manual no-cut decision

Manual decision before drafting:

`PASS / REBUILD`

Reason:
