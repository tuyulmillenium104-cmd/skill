# IRREDUCIBLE APEX REPORT TEMPLATE

Campaign:
Mission:
Address:
Draft version:
Date:

## Final content

```text
...
```

## 1. Line Necessity Test

| Line | Function | If removed, what is lost? | Keep / rewrite / cut |
|---|---|---|---|
|  |  |  |  |

## 2. Substitution Test

| Key phrase | Alternative considered | Decision | Reason |
|---|---|---|---|
|  |  |  |  |

## 3. Compression Test

Can the post be 10% shorter without losing force?

Answer:

If no, why:

If yes, revised text:

## 4. Expansion Test

Is one missing detail worth adding?

Answer:

If yes, detail:

If no, why:

## 5. Hostile Judge 10-Attack Test

1. Strong, but ...
2. Clear, but ...
3. Aligned, but ...
4. Useful, but ...
5. Original, but ...
6. Human, but ...
7. Technically accurate, but ...
8. CTA is present, but ...
9. Concrete, but ...
10. Memorable, but ...

Credible unresolved deductions:

## 6. Non-Expert Retell Test

A normal reader would say:

```text
...
```

PASS / FAIL:

## 7. Expert Respect Test

Accuracy risks:

Overclaim risks:

Oversimplification risks:

PASS / FAIL:

## 8. Product Inevitability Test

What breaks without the product/protocol?

Why does the product feel necessary, not optional?

PASS / FAIL:

## 9. Winner Without Copying Test

Winner surface pattern avoided:

Underlying mechanism used:

Fresh expression:

Copy-risk level:

PASS / FAIL:

## 10. Manual Irreducible Apex Score

| Axis | Score /5 | Reason |
|---|---:|---|
| Line necessity |  |  |
| Substitution strength |  |  |
| Compression |  |  |
| Necessary expansion |  |  |
| Hostile judge resistance |  |  |
| Non-expert retell |  |  |
| Expert respect |  |  |
| Product inevitability |  |  |
| Winner-without-copying |  |  |
| Final local gate alignment |  |  |

Total: /50

Decision:

`IRREDUCIBLE APEX PASS / REBUILD`

## 11. Local gate confirmation

| Gate | Result |
|---|---|
| Compliance |  |
| CTA |  |
| Tactical value |  |
| Compactness |  |
| Loser-DNA |  |
| Originality |  |
| TQ |  |
| OAA |  |
| IA |  |
| EP semantic |  |
| Worst-positive |  |
