#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""One-session/one-run completeness checker.

This checks that the new one-run workflow did not leave behind artifacts from the
older full workflow while also requiring the new generate/stress/fail-fast ledger files.
"""
import argparse, json, time, sys
from pathlib import Path

BASE_FINAL = [
    'RUN_MODE.md',
    'campaign.json',
    'submissions_enriched.json',
    'content.txt',
    'contract.json',
    'GENERATE_OUTPUT_FOR_STRESS.md',
    'CANDIDATE_LEDGER.md',
    'MAIN_CONTENT_STRESS_REPORT.md',
    'UNMAPPED_RISK_GATE.md',
    'artifacts/ORIGINAL-THESIS.md',
    'artifacts/DATA-JUDGE-REVIEW.md',
    'reports/REQUIREMENT-PROVENANCE.md',
    'reports/requirement-provenance.json',
    'reports/mission-contract.json',
    'reports/submission-plan.json',
    'reports/RELATION.md',
    'reports/relation.json',
    'reports/DATA-SUFFICIENCY.md',
    'hidden-gates/HIDDEN-GATE-CANDIDATES.md',
    'hidden-gates/hidden-gate-candidates.json',
    'winner-pull/WINNER-PULL-MAP.md',
    'winner-pull/winner-pull-map.json',
    'reports/compliance.txt',
    'reports/CTA.md',
    'reports/cta.json',
    'reports/TACTICAL.md',
    'reports/tactical.json',
    'reports/tactical-value.json',
    'reports/COMPACTNESS.md',
    'reports/compactness.json',
    'reports/LOSER-DNA.md',
    'reports/loser-dna.json',
    'reports/ORIGINALITY.md',
    'reports/originality.json',
    'reports/TQ.md',
    'reports/tq.json',
    'reports/OAA.md',
    'reports/oaa.json',
    'reports/IA.md',
    'reports/ia.json',
    'reports/EP-SEMANTIC.md',
    'reports/ep-semantic.json',
    'reports/WORST-POSITIVE.md',
    'reports/worst-positive.json',
    'reports/HUMAN.md',
    'reports/human.json',
    'EXPONENTIAL-CONTENT-REPORT.md',
    'IRREDUCIBLE_APEX_REPORT.md',
    'KNOWN_GATE_ABSOLUTE_REPORT.md',
]


BASE_STOP = [
    'RUN_MODE.md',
    'campaign.json',
    'submissions_enriched.json',
    'content.txt',
    'contract.json',
    'GENERATE_OUTPUT_FOR_STRESS.md',
    'CANDIDATE_LEDGER.md',
    'MAIN_CONTENT_STRESS_REPORT.md',
    'UNMAPPED_RISK_GATE.md',
    'STOP_REPORT.md',
    'artifacts/ORIGINAL-THESIS.md',
    'artifacts/DATA-JUDGE-REVIEW.md',
    'reports/REQUIREMENT-PROVENANCE.md',
    'reports/requirement-provenance.json',
    'reports/mission-contract.json',
    'reports/submission-plan.json',
    'reports/RELATION.md',
    'reports/relation.json',
    'reports/DATA-SUFFICIENCY.md',
    'hidden-gates/HIDDEN-GATE-CANDIDATES.md',
    'winner-pull/WINNER-PULL-MAP.md',
]

FINAL_QNA = [
    'combined.md',
    'qa_ranking.json',
    'QNA_STRESS_REPORT.md',
    'FINAL_REPORT.md',
    'reports/RQ-PROMPT-ANSWER.md',
    'reports/rq-prompt-answer.json',
    'reports/RQ-MECHANICS.md',
    'reports/rq-mechanics.json',
    'reports/NATURALNESS.md',
    'reports/naturalness.json',
    'reports/QNA-GOLD.md',
    'reports/qna-gold.json',
    'reports/RQ-GOLD-V3-POLICY.md',
    'reports/rq-gold-v3-policy.json',
    'reports/HUMAN-COMBINED.md',
    'reports/human-combined.json',
    'reports/final-integrity.txt',
    'reports/RUN-COMPLETENESS.md',
    'reports/run-completeness.json',
]

STOP_ONLY = [
    'STOP_REPORT.md',
]


def load_decision(path):
    try:
        data=json.load(open(path,encoding='utf-8'))
        return data.get('decision')
    except Exception:
        return None


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--run-dir', required=True)
    ap.add_argument('--mode', choices=['final','stop','auto'], default='auto')
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    root=Path(args.run_dir)
    mode=args.mode
    if mode=='auto':
        mode='final' if (root/'combined.md').exists() and (root/'qa_ranking.json').exists() else 'stop'
    required=(list(BASE_FINAL)+FINAL_QNA) if mode=='final' else list(BASE_STOP)
    missing=[p for p in required if not (root/p).exists()]
    present=[p for p in required if (root/p).exists()]
    bad=[]
    for p in present:
        if p.endswith('.json'):
            dec=load_decision(root/p)
            if dec and dec!='PASS':
                # data sufficiency may use PASS decision with LOW_DATA mode, okay. Anything non-PASS should be surfaced.
                bad.append({'file':p,'decision':dec})
    text_checks=[]
    # Ensure the one-run docs tell the truth about Q&A ordering.
    if mode=='final':
        qna_report=(root/'QNA_STRESS_REPORT.md').read_text(encoding='utf-8', errors='ignore') if (root/'QNA_STRESS_REPORT.md').exists() else ''
        if 'after main content pass' not in qna_report.lower() and 'after main content received' not in qna_report.lower():
            text_checks.append({'file':'QNA_STRESS_REPORT.md','issue':'does not state Q&A was after main content pass'})
    final_integrity=''
    if (root/'reports/final-integrity.txt').exists():
        final_integrity=(root/'reports/final-integrity.txt').read_text(encoding='utf-8', errors='ignore')
        if 'PASS' not in final_integrity:
            text_checks.append({'file':'reports/final-integrity.txt','issue':'final integrity text does not contain PASS'})
    decision='PASS' if not missing and not bad and not text_checks else 'FAIL'
    result={
        'tool':'rally-one-run-completeness-check.py',
        'generated':time.strftime('%Y-%m-%d %H:%M:%S'),
        'runDir':str(root),
        'mode':mode,
        'requiredCount':len(required),
        'presentCount':len(present),
        'missing':missing,
        'badDecisions':bad,
        'textChecks':text_checks,
        'finalIntegrity':final_integrity.strip(),
        'decision':decision,
    }
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append('# ONE-RUN COMPLETENESS CHECK\n\n')
    md.append(f'Decision: **{decision}**\n\n')
    md.append(f'- Mode: {mode}\n')
    md.append(f'- Required files: {len(required)}\n')
    md.append(f'- Present: {len(present)}\n')
    md.append(f'- Missing: {len(missing)}\n')
    md.append(f'- Bad JSON decisions: {len(bad)}\n')
    md.append(f'- Text check issues: {len(text_checks)}\n\n')
    md.append('## Missing\n')
    md += [f'- {m}\n' for m in missing] or ['- none\n']
    md.append('\n## Bad JSON decisions\n')
    md += [f'- {b}\n' for b in bad] or ['- none\n']
    md.append('\n## Text check issues\n')
    md += [f'- {t}\n' for t in text_checks] or ['- none\n']
    md.append('\n## Final integrity\n')
    md.append('```text\n'+(final_integrity.strip() or 'not present')+'\n```\n')
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'ONE-RUN COMPLETENESS CHECK: {decision} [mode={mode}, missing={len(missing)}, bad={len(bad)}, text={len(text_checks)}]')
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__':
    main()
