# FRESH BUT INEVITABLE CONTENT PROTOCOL

Status: ACTIVE
Date: 2026-07-18 Asia/Jakarta

## Purpose

Increase Engagement Potential by making the core public surface non-crowded while still feeling campaign-native, clear, and inevitable.

This protocol exists because a truly fresh angle can improve EP, but a merely weird angle can reduce EP.

## Core rule

```text
Fresh is useful only when it feels inevitable after reading.
```

Target:

```text
non-crowded core surface + clear campaign mechanism + human object + fast payoff + CTA-integrated reply path
```

Not target:

```text
literal 0% lexical overlap
```

Mandatory campaign terms, handles, URLs, product nouns, and knowledge-base facts may overlap. What must be fresh is the public surface, hook, progression, mental model, and CTA framing.

## Definitions

### Good fresh

A fresh angle is good when it is:

- campaign-native,
- concrete,
- easy to retell,
- supported by screenshot/media/source truth,
- not copied from winners,
- not the crowded pool phrase as the main hook,
- clear enough for target audience,
- tied to a practical CTA.

### Bad fresh

A fresh angle is bad when it is:

- weird but unclear,
- too distant from product truth,
- clever but not useful,
- too metaphor-heavy,
- unsupported by screenshot/media,
- impossible for target audience to retell,
- fresh only because it avoids campaign language too much.

## Generate-stage requirements

Before drafting, generate must produce a Fresh Surface Map:

```text
Crowded surfaces to avoid as main hook:
- ...

Mandatory overlap allowed:
- ...

Candidate fresh surfaces:
1. ...
2. ...
3. ...

Chosen surface:
...

Why it is fresh:
...

Why it is inevitable/campaign-native:
...

Why it is not too weird:
...
```

## Candidate tournament rule

Generate at least three candidate surfaces unless the user explicitly asks for speed:

1. safest campaign-native surface,
2. freshest non-crowded surface,
3. broadest/most accessible surface.

Select the surface that best balances:

```text
freshness x campaign fit x clarity x human voice x CTA potential
```

Do not select the most unique surface if it weakens product clarity.

## Stress-stage requirements

Stress must include a Freshness/Inevitability check:

Questions:

1. Is the core hook/surface crowded in the campaign pool?
2. Does the surface still explain the product/campaign?
3. Can a target reader retell it in one sentence?
4. Does screenshot/media/source truth support it?
5. Is it fresh or merely weird?
6. Does the CTA naturally follow from it?
7. Would a Rally judge call it original and useful, or clever but unclear?

## Pass labels

Allowed:

```text
FRESH-BUT-INEVITABLE PASS
NON-CROWDED SURFACE PASS
```

Forbidden:

```text
0% overlap guaranteed
EP5 guaranteed
winner guaranteed
```

## Failure handling

If a draft fails because the surface is crowded or too weird, do not patch one line. Reject the candidate and generate a new surface.

```text
CANDIDATE_REJECTED
REGENERATE_WITH_NEW_SURFACE
```

Surgical rewrite is allowed only if the surface is strong and the issue is a small wording, CTA, or proof mismatch.

## Examples

### FUD

Crowded:

```text
FUD turns takes into positions.
Talk is cheap.
CT takes are not free anymore.
```

Better fresh surface:

```text
FUD as CT before cleanup: messy market boards with side, timer, and receipt.
```

### Internet Court

Crowded:

```text
Trust layer for agent commerce.
Dispute resolution for agents.
```

Better fresh surface:

```text
Lost-bag tag / shared case file before the trip breaks.
```

## Final law

```text
Do not chase novelty. Build a fresh surface that makes the campaign feel obvious.
```
