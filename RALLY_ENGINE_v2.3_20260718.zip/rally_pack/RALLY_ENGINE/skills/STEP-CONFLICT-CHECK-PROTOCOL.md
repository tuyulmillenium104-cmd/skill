# STEP CONFLICT CHECK PROTOCOL

Status: ACTIVE
Purpose: prevent each step in a `/rally` run from creating contradictions, overfitting, stale assumptions, or output degradation.

## Core principle

Every major step must ask:

```text
Did this step create a conflict with the brief, source truth, data scope, human voice, or final output quality?
```

If yes, stop and resolve before moving forward.

## Conflict checks by step

### 1. Mission truth lock

Check:

- Is the mission ID correct?
- Does the UI title match API title?
- Are required quote/reply links correct?
- Are required handles correct?
- Are forbidden formats clear?

Conflict action:

- If mission title/link/handle is ambiguous, ask user or fetch again. Do not draft.

### 2. Source truth snapshot

Check:

- Does source post text match campaign rules?
- Is quote/reply requirement clear?
- Are campaign facts pulled from KB, not memory?

Conflict action:

- If source cannot be fetched, mark confidence and use campaign rule as authority.

### 3. Data sufficiency

Check:

- Are there enough submissions/winners?
- Is content retrieval coverage high?
- Is data mission-scoped?

Conflict action:

- If low data, do not create hard mission-specific rules. Use brief-first and family priors.

### 4. Hidden-gate mining

Check:

- Is the candidate gate truly a rule or just noise?
- Is scope set to MISSION_ONLY by default?
- Would promoting it globally harm other campaigns?

Conflict action:

- Keep as WATCH unless manual evidence supports ACCEPT.

### 5. Winner-pull mining

Check:

- Are we copying winner surface or extracting mechanism?
- Does the draft use a fresh expression?

Conflict action:

- If copy-risk is high, rebuild the concept.

### 6. Original thesis

Check:

- Did the thesis come from the brief and human problem, not from copying winner examples?
- Is it true and specific?

Conflict action:

- If generic or derivative, generate new thesis.

### 7. Exponential / Irreducible Apex review

Check:

- Does every line have a function?
- Does a fair `strong, but...` remain?
- Is there a better obvious phrase?
- Is content human-typed, not engineered?

Conflict action:

- Rewrite or rebuild before Python gates.

### 8. AI Human Taste Director

Check:

- Does normal reader understand it?
- Does skeptical judge see a credible cut?
- Does human voice editor detect template smell?
- Does brand/accuracy editor see overclaim?

Conflict action:

- Any credible issue means rewrite/rebuild.

### 9. Python gates

Check:

- Are failures content-specific or corpus/review dependency?
- Did a checker force unnatural wording?

Conflict action:

- Fix real risks. Do not damage human voice just to satisfy a heuristic.

### 10. Q&A generation

Check:

- Does Q&A reflect final content, not old content?
- Do Q/A sound human-typed?
- Are simulated experiences marked externally?
- Is `qa_ranking.json` present?

Conflict action:

- Rebuild Q&A if formulaic or stale.

### 11. Final integrity

Check:

- Does `combined.md` contain exact current `content.txt`?
- Are reports current, not stale?
- Did content change after reports?

Conflict action:

- Rerun reports. Do not ship stale pass.

## Output requirement

For strict/Irreducible runs, produce:

```text
STEP-CONFLICT-CHECK-REPORT.md
```

with:

- step name;
- conflict found yes/no;
- action taken;
- final decision.
