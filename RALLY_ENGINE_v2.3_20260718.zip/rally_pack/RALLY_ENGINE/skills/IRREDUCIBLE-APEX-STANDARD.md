# IRREDUCIBLE APEX STANDARD

Status: ACTIVE - highest content quality standard
Purpose: lock final content above ordinary Apex by requiring every line and every key phrase to be necessary.

## Core definition

Irreducible Apex content is content where:

```text
1. every line has a function;
2. no obvious stronger substitution remains;
3. no fair hostile judge deduction remains;
4. the product/protocol feels necessary, not merely useful;
5. a non-expert can retell the idea in 10 seconds;
6. an expert does not see an accuracy shortcut;
7. the content passes local gates after manual review.
```

Irreducible Apex is not a guarantee of external Rally all-max. It is the highest controllable content standard in this skill.

## Authority rule

If `EXPONENTIAL-CONTENT-STANDARD.md` and this file conflict, this file wins for final content.

## Required tests

### 1. Line Necessity Test

For every line, answer:

```text
If this line is removed, what specific force is lost?
```

Allowed functions:

- hook
- tension
- concrete proof
- mechanism
- value rule
- CTA
- rhythm/readability
- emotional compression
- product inevitability

If no function exists, cut or rewrite.

### 2. Substitution Test

For every key phrase, ask:

```text
Is there a more precise, more human, more memorable phrase?
```

If yes, replace.

### 3. Compression Test

Ask:

```text
Can this be 10% shorter without losing force?
```

If yes, compress.

### 4. Expansion Test

Ask:

```text
Is one missing detail worth adding because it makes the product inevitable?
```

If yes, add only that detail.

### 5. Hostile Judge 10-Attack Test

Write ten attempted deductions:

```text
Strong, but ...
Clear, but ...
Aligned, but ...
Useful, but ...
Original, but ...
Human, but ...
Technically accurate, but ...
CTA is present, but ...
Concrete, but ...
Memorable, but ...
```

If any deduction sounds fair, rebuild the cause.

### 6. Non-Expert Retell Test

A normal reader should be able to retell the point in one sentence after one read.

Template:

```text
This is about [product] giving [specific thing] so [specific failure] can be handled.
```

If they cannot, simplify.

### 7. Expert Respect Test

An informed reader should not feel the post is wrong, overclaimed, or misleading.

Check:

- no false mechanism;
- no unsupported guarantee;
- no claim beyond KB;
- no oversimplification that changes meaning.

### 8. Product Inevitability Test

The post must make the product feel necessary.

Weak:

```text
This product could help.
```

Strong:

```text
Without this, every tool can be right and the deal can still be wrong.
```

### 9. Winner Without Copying Test

The draft must not be a surface variation of a winner.

Required transform:

```text
winner surface -> underlying mechanism -> fresh expression
```

If it feels copied, rebuild.

## Manual score

Score 1-5:

- Line necessity:
- Substitution strength:
- Compression:
- Necessary expansion:
- Hostile judge resistance:
- Non-expert retell:
- Expert respect:
- Product inevitability:
- Winner-without-copying:
- Final local gate alignment:

Rules:

- Any axis below 4.8 = rebuild.
- Total below 48/50 = rebuild.

## Final label

Allowed:

```text
Irreducible Apex local PASS
```

Forbidden:

```text
Guaranteed Rally all-max
Guaranteed winner
Guaranteed top 1%
```
