---
name: rally-qna-engine
version: V3.1.3 GOLD (compatibility alias replacing old V1)
status: ACTIVE - replaces V1/V2 QnA engines
highest_authority_after_brief: GOLD_RQ_STANDARD_CALIBRATED.md
style_authority: RALLY_QA_GENERATOR_GOLD_STANDARD.txt
machine_policy: rq-gold-policy-v3.json
required_checkers:
  - rally-rq-prompt-answer-check.py
  - rally-rq-mechanics-calibration-check.py
  - rally-naturalness-variance-check.py
  - rally-qna-gold-audit.py
  - rally-rq-v3-policy-check.py
---

# RALLY QNA-ENGINE V3.1.3 GOLD - COMPATIBILITY ALIAS

This file replaces the older V1/V2 Q&A rules. If any older file, memory, or instruction
conflicts with this file, follow this V3.1.3 Gold engine, the literal campaign brief,
and fresh mission evidence.

## 0. Truth law

- A pack may be called `RQ5-ready` only after every required gate passes.
- Never call a pack `guaranteed RQ5` or guaranteed RQ 5/5.
- `PASS` means the controllable side is strong and evidence-calibrated. It is not a
  score prediction, probability, winner promise, or external verdict.

## 1. Evidence hierarchy

Use evidence in this order:

1. Literal campaign and mission brief.
2. Current mission-scoped real RQ5 replies and judge verdicts.
3. User-supplied Gold Standard when compatible with real evidence.
4. Global RQ verdict corpus and field lessons.
5. Automated gates and heuristics.

Fresh real evidence outranks a generic template or old threshold. Any conflict must be
written in the calibration report and resolved evidence-first.

## 2. Required pack

Default English pack:

- 20 Q-COPY/A-COPY pairs.
- Specific Probe: 4.
- Challenge: 5.
- Technical Deep-Dive: 5.
- Hot Take: 4.
- Real Experience: 2.
- Ranked strongest to weakest.
- Tier score convention: Tier S=9, Tier A=7, Tier B=4, Tier C=0.
- `qa_ranking.json` is mandatory and must contain `voicePersona` and `voiceMode` for
  every row.

AI-generated Real Experience rows:

- must be marked `SIMULATED_ARCHETYPE` in heading/type metadata;
- must be marked `CONDITIONAL_ORGANIC_MATCH_ONLY` in ranking/deployment metadata;
- must be ranked last unless real mission evidence justifies otherwise;
- are not deployable as fake testimony;
- must not put warning labels inside Q-COPY.

## 3. Q-COPY construction

Every Q must:

- read like a real public X/Twitter reply, not an interview question;
- carry a personal opinion, stake, decision, objection, or experience;
- reference the final post, CTA, mechanism, timing, number, or exact phrase;
- add a new angle instead of paraphrasing the post;
- be 160-260 characters under the current hash-backed workflow;
- avoid generic praise, FAQ language, and writing-craft commentary;
- stay within factual boundaries; hypothetical scenarios must read as hypothetical;
- contain no internal metadata, warning label, persona label, tier label, type label,
  deployment label, audit note, or scaffold placeholder.

Q-COPY is public copy only. Metadata belongs in the heading, audit table, or
`qa_ranking.json`, never inside the Q body.

### Type rules

**Specific Probe**
- Quote an exact phrase from the final post.
- Probe a new consequence, edge case, or domain.
- Generic `What is X?` questions fail.

**Challenge**
- Include a claim plus mechanism/evidence/scenario plus a precise doubt.
- Flat disagreement fails.
- Unsupported market facts fail; phrase uncertainty as a hypothesis.

**Technical Deep-Dive**
- Reference a specific post mechanism.
- Ask a bounded technical question or state a concrete technical concern.
- Generic `How does X work?` fails.

**Hot Take**
- Make a bold claim and provide an alternative thesis.
- Generic opposition fails.

**Real Experience**
- Use a mini-story from the replier's perspective.
- AI-generated examples must carry metadata outside the Q body only.
- Never seed simulated testimony as fake organic engagement.


## Public-copy privacy rule

Apply `skills/PUBLIC_COPY_LEAKAGE_POLICY.md` in prompt mode:

> Q-COPY and A-COPY must read as public replies from real people. Do not include language
> that reveals private skill files, checker workflow, audit process, internal metadata,
> or generation scaffolding. Official Rally/campaign/community terms are allowed when
> natural in context. If unsure, ask whether a normal Rally participant would write it
> publicly without seeing the skill files. If not, rewrite into plain public language.

Do not create broad hard-ban vocabulary for normal Rally/campaign terms. Leakage control
is lightweight; everything else is a naturalness/style decision.

## 4. Pack-level Q controls

Default V3 thresholds:

- Decision-marker coverage: 75-80%.
- Decision-word coverage: >=50%.
- CTA-aligned Q: >=40%.
- Specific Probe exact-source quote: 100%.
- Q using `because`: <=35%.
- Q using `I would`: <=25%.
- Q using `my decision`: <=20%.
- Q-length coefficient of variation: >=9%.
- At least three sentence-count structures across the pack.
- Journalist framing: 0.
- Generic FAQ: 0.
- Exact duplicate Q: 0.

Coverage targets prevent rigid per-pair formula. Distinct voices outrank cosmetic
uniformity.

## 5. Voice-diversity controls

Across the 20 pairs:

- Explicit first-person Q <=75%.
- Decision-marker Q must also be <=80%.
- Casual/contraction voice >=35%.
- Anecdotal or applied-experience surface >=35%.
- Distinct first-two-word Q openers >=15.
- Same first Q word <=25%.
- Same first-two-word Q shell <=15%.
- First-person Q openings <=40%.
- Direct-question Q =20-35%.
- Two-sentence shell <=50%.
- Semicolon usage <=15%.
- Formal/abstract register <=40%.
- At least ten distinct personas and five distinct voice modes.
- No adjacent rows may use the same persona.
- Scaffold `EVIDENCE_PERSONA_*` / `EVIDENCE_VOICE_*` placeholders are planning markers
  only and are rejected in final ranking.

Lexical uniqueness alone is insufficient. A pack fails if different words still carry
the same polished analytical voice.

## 6. A-COPY construction

For an English pack:

- 40-45 words when possible.
- Hard maximum 280 characters.
- One line per answer.
- Direct response plus a new insight, implication, or honest boundary.
- Writer presence consistent with the main post.
- Include a decision/action word.
- Weave facts naturally; do not recite the knowledge base.
- Zero fabricated facts or fake experience.
- Vary openings and closings.
- Question-ending coverage is 50-75%, not a per-pair law.
- Statement closes are valid when they sound natural and evidence supports them.

Follow the FEEL, not a formula. If three adjacent answers start or end with the same
pattern, rewrite.

## 7. Quality gate per pair

Every pair must be reviewed on three 1-5 dimensions:

- Q Quality: persona-driven, specific, references the post.
- A Insight: concise, adds perspective, not KB documentation.
- Conversational Feel: reads like a real X/Twitter exchange.

Required: every pair Q/A/Feel >=4.

## 8. Ranking protocol

Rank strongest to weakest for response speed:

1. Honest, specific objections.
2. Deep mechanism questions tied to the post.
3. Concrete domain probes answering the CTA.
4. Alternative theses and controlled humor.
5. Simulated archetypes last and non-deployable.

Internal ranking scores are prioritization indices only. Never label them Rally scores
or RQ probabilities.

## 9. Required output format

Use this combined.md block format so all tools can parse it:

```md
## R01 [Tier S=9] (Challenge)
**Q-COPY**
```text
<public reply only, 160-260 chars, no metadata>
```
**A-COPY**
```text
<one-line answer, <=280 chars>
```
```

For simulated Real Experience only, put metadata in the heading, never Q-COPY:

```md
## R20 [Tier C=0] (Real Experience | SIMULATED_ARCHETYPE)
```

Also write `qa_ranking.json` next to combined.md:

```json
{
  "rows": [
    {
      "idx": 1,
      "type": "Challenge",
      "tier": "S",
      "tierScore": 9,
      "voicePersona": "skeptical protocol user",
      "voiceMode": "constructive skeptical",
      "deployment": "DEPLOYABLE"
    }
  ]
}
```

## 10. Mandatory gates

Run all five after the pack is generated:

```bash
python3 skills/rally-rq-prompt-answer-check.py \
  --content content.txt --combined combined.md \
  --out-json rq-prompt-answer.json --out-md RQ-PROMPT-ANSWER.md

python3 skills/rally-rq-mechanics-calibration-check.py \
  --content content.txt --combined combined.md \
  --campaign campaign.json --mission <mission> \
  --out-json rq-mechanics.json --out-md RQ-MECHANICS.md

python3 skills/rally-naturalness-variance-check.py \
  --content content.txt --combined combined.md \
  --out-json naturalness.json --out-md NATURALNESS.md

python3 skills/rally-qna-gold-audit.py \
  --content content.txt --combined combined.md \
  --out-json qna-gold.json --out-md QNA-GOLD.md

python3 skills/rally-rq-v3-policy-check.py \
  --content content.txt --combined combined.md \
  --ranking-json qa_ranking.json \
  --out-json rq-gold-v3-policy.json --out-md RQ-GOLD-V3-POLICY.md
```

Required result:

- every checker PASS;
- every pair Q/A/Feel >=4;
- RQ prompt-answer pass 20/20;
- mechanics >=70%;
- decision >=75%;
- skeptic >=25%;
- no naturalness FAIL or unresolved review;
- V3 policy PASS.

## 11. Deployment law

- Q-COPY models likely incoming replies; do not post all Qs yourself.
- Select only the A-COPY matching a real organic reply.
- Prioritize real confession, serious skepticism, and technical questions.
- Reply quickly when possible, but never sacrifice substance for speed.
- Do not post fake experiences, fake community conversation, or synthetic testimony.
- Re-audit any edited answer before deployment.

Allowed final status language:

- `RQ5-ready`
- `Gold V3 PASS`
- `mission-calibrated RQ5 pressure`

Forbidden final status language:

- `guaranteed RQ5`
- `guaranteed RQ 5/5`
