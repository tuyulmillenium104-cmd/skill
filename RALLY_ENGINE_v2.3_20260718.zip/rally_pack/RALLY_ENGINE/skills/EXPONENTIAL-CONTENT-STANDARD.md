# EXPONENTIAL CONTENT STANDARD v2 - APEX LEVEL

Status: ACTIVE
Purpose: define the standard for content that is not merely safe, not merely winner-like, but built to create maximum positive judge pressure.

## Core definition

Exponential content is content where every major part strengthens the next part:

```text
Hook -> Scenario -> Mechanism -> Value Rule -> CTA
```

Apex exponential content adds five higher locks:

```text
Inevitability + Emotional Compression + Pool Dominance + Specific Positive Verdict + Frictionless Reader Path
```

Safe content avoids deductions. Exponential content gives the judge many reasons to praise it. Apex content makes the product feel necessary, memorable, and hard to cap.

## Exponential formula

```text
Apex Exponential =
Hook x Concrete Object x Scenario Proof x Mechanism Bridge x Value Rule x CTA Engine x Human Voice
x Inevitability x Emotional Compression x Pool Dominance x Frictionless Reader Path
```

If any core element is weak, the post becomes merely good, not exponential.

---

# PART 1 - Core exponential locks

## 1. Contradiction Hook Lock

The opening must contain tension:

```text
A works, but B fails.
```

Examples:

```text
The money moved. The promise did not.
The app said delivered. The deal still failed.
The claim number mattered more than the court word.
```

## 2. Concrete Object Lock

The post must use a concrete object that makes the abstract product or campaign obvious.

Examples:

- claim number
- itinerary
- lab order
- work order
- proof bundle
- delivery trail
- cold-chain log
- release rule
- inspection sheet
- receipt bundle

## 3. Scenario Proof Lock

The example must prove the thesis, not decorate it.

A strong scenario includes:

- actor
- task
- system success signal
- actual failure
- why existing stack cannot settle it

## 4. Mechanism Bridge Lock

The product/protocol must enter as the natural answer to the scenario.

Weak:

```text
That is why the product matters.
```

Strong:

```text
The product turns the proof bundle into a case, not a support ticket.
```

## 5. Value Rule Lock

The reader must receive a rule, test, checklist, or mental model.

Do not force literal labels such as `My rule:` or `My test:`. Use the most human phrasing.

Examples:

```text
Before agents do real work, write the itinerary for terms, proof, release, and appeal.
I would lock proof, release, and appeal before execution.
If proof cannot be named before work starts, the deal is not ready for agents.
```

## 6. CTA Continuity Lock

The CTA must reopen the same conflict introduced by the post.

Strong:

```text
Which proof dispute would you test first? Reply: reused photos, stale data, late compute, or stuck escrow.
```

Weak:

```text
Thoughts?
```

## 7. No Dead Line Lock

Every line must serve one of these functions:

- hook
- tension
- concrete detail
- mechanism
- value
- CTA
- rhythm/readability

If a line does none of these, cut it.

## 8. Distinctiveness Lock

The frame must not feel like a standard pool entry.

Ask:

```text
What would most competitors write?
What does this post say differently?
```

## 9. Positive Verdict Density Lock

Before finalizing, write at least seven positive verdict lines the judge could write.

Examples:

- strong hook
- fresh frame
- concrete example
- clear mechanism
- useful rule
- strong CTA
- natural brand integration
- authentic voice
- readable pacing

---

# PART 2 - Apex exponential locks

## 10. Inevitability Lock

The post must make the product/protocol feel necessary, not merely useful.

Ask:

```text
After reading this, does the reader feel the product has to exist?
```

Weak:

```text
This could help agent commerce.
```

Strong:

```text
Without a shared case file, every agent deal eventually becomes a pile of receipts nobody owns.
```

Apex requirement:

- The scenario must make the product feel like the missing inevitable answer.
- The product must not feel like an optional add-on.

## 11. Emotional Compression Lock

There must be at least one line that compresses the pain into a memorable, human-readable sentence.

Examples:

```text
The money moved. The promise did not.
Every app can be right, and the trip can still be wrong.
The file arrived. The proof failed.
```

Ask:

```text
Is there a line that makes the reader think: damn, yes?
```

## 12. Pool Dominance Lock

The post must not merely avoid similarity. It must be stronger than the likely pool.

Ask:

```text
Is this hook top 5% of the pool?
Is this example top 5% of the pool?
Is this CTA top 5% of the pool?
```

If the answer is only "it passes originality," the draft is not apex.

## 13. Specific Positive Verdict Lock

Expected judge praise must be specific enough to sound like a real Rally verdict.

Weak expected praise:

```text
Strong hook and clear CTA.
```

Strong expected praise:

```text
The post turns the abstract idea of agentic trust into a familiar travel-claim problem, making Internet Court feel necessary as a shared case memory for agent deals.
```

Apex requirement:

- At least seven specific praise lines.
- Each praise line must point to exact evidence in the content.

## 14. Frictionless Reader Path Lock

A non-expert should be able to retell the point in 10 seconds.

Ask:

```text
Can a normal reader explain the post after one read?
```

If the reader must decode jargon, rebuild.

## 15. Winner-Without-Copying Lock

The post must beat winner-level mechanisms without copying winner surface patterns.

Required:

```text
winner surface -> underlying mechanism -> fresh expression
```

If the draft feels like a variation of a winner example, rebuild or add a major transformation.

---

# Manual apex score

Score each 1-5:

- Hook contradiction:
- Concrete object:
- Scenario proof:
- Mechanism bridge:
- Value rule:
- CTA engine:
- Distinctiveness:
- Read-through:
- Positive verdict density:
- Inevitability:
- Emotional compression:
- Pool dominance:
- Frictionless reader path:
- Winner-without-copying:

Rules:

- Any axis below 4.7 = rebuild.
- Total below 67/70 = rebuild.
- If Python gates pass but apex score fails, content is not final.

## Relationship to data

Data does not write exponential content. Data judges it.

Use winner-pull mining and hidden-gate mining after the original thesis and draft chain exist.

## Relationship to Python gates

Python gates are safety nets. Exponential content must pass manual apex review first.
