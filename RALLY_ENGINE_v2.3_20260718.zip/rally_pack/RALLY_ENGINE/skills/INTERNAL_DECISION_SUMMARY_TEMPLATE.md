# ARCHIVED POINTER - INTERNAL_DECISION_SUMMARY_TEMPLATE.md

This legacy protocol/reference file has been archived and is **not active authority**.

Active authority is declared in:

`ACTIVE_SKILL_MANIFEST.md`

Current drafting workflow uses mission-specific evidence, hidden-gate mining, winner-pull mining, manual no-cut review, and Python checkers as safety nets.

Historical file location:

`skills/_archive/legacy_protocol_docs/INTERNAL_DECISION_SUMMARY_TEMPLATE.md`

Do not load archived legacy protocol rules by default. They are historical reference only.
