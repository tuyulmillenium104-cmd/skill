# WINNER-PULL CONTRACT TEMPLATE

Campaign:
Mission:
Address:
Evidence refresh:
Winner samples:
Near-winner samples:

## 1. Winner mechanisms selected for this draft

| Mechanism | Evidence from winners | Use now? | How we will express it without copying |
|---|---|---|---|
| Hook mechanism |  | YES / NO |  |
| Concrete scenario |  | YES / NO |  |
| Mechanism clarity |  | YES / NO |  |
| Value payload |  | YES / NO |  |
| CTA pattern |  | YES / NO |  |
| Voice/persona |  | YES / NO |  |
| Brand bridge |  | YES / NO |  |

## 2. Expected positive verdict lines

The draft should make a Rally judge write:

1.
2.
3.
4.
5.

## 3. Planned evidence lines in the draft

- Hook line:
- Concrete scenario line:
- Mechanism line:
- Value/rule line:
- CTA line:
- Brand bridge line:

## 4. Anti-copy safety

- Winner phrase/motif we must not copy:
- How our version differs:
- Why it is still mission-aligned:

## 5. Winner-pull decision

Manual decision before drafting:

`PASS / REBUILD`

Reason:
