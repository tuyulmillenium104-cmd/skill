# EXPONENTIAL CONTENT REPORT TEMPLATE v2 - APEX

Campaign:
Mission:
Address:
Date:
Draft version:

## 1. Core exponential chain

### Hook

Hook line:

Why it stops scroll:

Contradiction/tension:

### Concrete object

Object:

Why it makes the abstract mission concrete:

Copy-risk vs winner pool:

### Scenario proof

Scenario:

Actor:
Task:
System success signal:
Actual failure:
Why existing stack cannot settle it:

### Mechanism bridge

Product/protocol bridge line:

Why product becomes the natural answer:

### Value rule

Rule/test/checklist:

Why reader can apply it:

### CTA engine

CTA:

Verb:
Concrete object:
Choices:
How it reopens the same conflict:

## 2. Apex locks

### Inevitability

Why the product/protocol feels necessary, not optional:

What would break without it:

### Emotional compression

Pain-compression line:

Why it is memorable:

### Pool dominance

Why this hook is stronger than likely pool entries:

Why this scenario is stronger than likely pool entries:

Why this CTA is stronger than likely pool entries:

### Frictionless reader path

10-second retell:

```text
A normal reader would say: ...
```

### Winner-without-copying

Winner surface pattern avoided:

Underlying mechanism used:

Fresh expression:

Copy-risk level: LOW / MEDIUM / HIGH

## 3. Positive verdict map

The judge should be able to praise:

| Positive verdict line | Evidence line in content |
|---|---|
| 1. |  |
| 2. |  |
| 3. |  |
| 4. |  |
| 5. |  |
| 6. |  |
| 7. |  |
| 8. |  |
| 9. |  |
| 10. |  |

## 4. No-dead-line audit

| Line | Function | Keep / Cut / Rewrite |
|---|---|---|
|  |  |  |

## 5. Fair hostile judge attack

Write the strongest possible deduction sentences:

1. Strong, but ...
2. Clear, but ...
3. Aligned, but ...
4. Useful, but ...
5. Original, but ...

Are any credible?

If yes, rebuild cause:

## 6. Manual apex score

| Axis | Score /5 | Reason |
|---|---:|---|
| Hook contradiction |  |  |
| Concrete object |  |  |
| Scenario proof |  |  |
| Mechanism bridge |  |  |
| Value rule |  |  |
| CTA engine |  |  |
| Distinctiveness |  |  |
| Read-through |  |  |
| Positive verdict density |  |  |
| Inevitability |  |  |
| Emotional compression |  |  |
| Pool dominance |  |  |
| Frictionless reader path |  |  |
| Winner-without-copying |  |  |

Total: /70

Decision:

`PASS / REBUILD`

## 7. Data judge review

Hidden-gate pressure:

Winner-pull pressure:

Loser similarity risk:

Anti-copy transform:

## 8. Final decision before Python gates

`PASS / REBUILD`

Reason:
