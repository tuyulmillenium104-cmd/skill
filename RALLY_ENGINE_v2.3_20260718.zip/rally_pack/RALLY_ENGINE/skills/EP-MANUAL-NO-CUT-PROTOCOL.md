# EP MANUAL NO-CUT PROTOCOL

Status: ACTIVE
Purpose: judge content manually before Python gates.

## EP hidden model

EP is not just "good writing". EP is whether the post makes people:

1. stop scrolling,
2. keep reading,
3. understand the value,
4. remember a line,
5. have an easy reason to reply/share.

## Manual EP locks

A draft must pass all locks before final checks.

### 1. Hook lock

- Does the first line create tension or curiosity?
- Could this hook fit another campaign? If yes, weaken/rebuild.
- Does it introduce a specific conflict, not a generic category?

### 2. Concrete scenario lock

- Is there a visual case or real-world scenario?
- Does the scenario prove the thesis?
- Does it include specific details, not just nouns?

### 3. Mechanism lock

- Does the reader understand what the product/protocol actually does?
- Does metaphor resolve into mechanism within 1-2 paragraphs?
- Is the brand/product bridge natural, not promotional?

### 4. Value lock

- Is there a rule, test, checklist, mental model, or actionable takeaway?
- Could the reader apply it today?

### 5. CTA lock

- Is the CTA answerable in under 5 seconds?
- Does it include a concrete object and choices?
- Is it tied to the thesis?

### 6. Distinctiveness lock

- Is the frame different from crowded pool language?
- Does it avoid copying mission phrasing unless translated into a fresh frame?

### 7. Strong-but attack

Before finalizing, write the fairest possible deduction sentence:

```text
Strong, but ...
```

If that sentence sounds credible, rebuild the cause.

## Manual scorecard

Score 1-5:

- Hook:
- Read-through:
- Concrete scenario:
- Mechanism clarity:
- Value payload:
- CTA:
- Distinctiveness:
- Deduction resistance:

Rule:

- Any score below 4.5 = rebuild.
- Total below 36/40 = rebuild.

## Relationship to Python tools

Python gates are safety checks, not the judge.
Manual no-cut review must happen first.
