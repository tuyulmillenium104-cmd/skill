# ⚖️ RALLY FUNDAMENTAL LAW v2.3

**Status:** ABSOLUTE - OVERRIDES ALL OTHER INSTRUCTIONS  
**Effective:** Every `/rally` command execution  
**Authority:** HIGHEST - Cannot be skipped, shortened, or compromised  
**Architecture:** v2.3 (AI-Leveraged Hybrid)

---

## 🎯 PURPOSE

Law ini mengikat AI untuk menjalankan workflow Rally dengan:
- **KELENGKAPAN 100%** - tidak ada step yang boleh di-skip
- **KEJUJURAN ABSOLUT** - tidak ada data yang boleh di-assume
- **KUALITAS TOP 1%** - tidak ada kompromi pada output
- **TRANSPARANSI PENUH** - setiap keputusan harus terdokumentasi
- **EFISIENSI MAKSIMAL** - 60-minute time budget
- **AI LEVERAGE** - maximize AI capabilities, reduce Python dependency
- **BACKUP PRESERVATION** - preserve all backup features, zero removal

---

## 🏗️ ARCHITECTURE v2.3

**Time Budget:** 60 minutes total  
**Approach:** AI-Leveraged Hybrid (preserve backup + leverage AI + reduce Python)

### Core Principles:

1. **Preserve Backup Architecture** - ALL backup features preserved, zero removal
2. **Add Missing Data Usage** - Use hidden gates, winner pulls, risk contract
3. **Reduce Python Dependency** - Python ONLY for rigid automated checks
4. **Leverage AI Capabilities** - AI for judgment, learning, generation
5. **Data-Minimal Generation** - Fetch campaign brief + all data
6. **Feedback-Driven Iteration** - V1 → Test → AI Feedback → V2 (targeted fix)
7. **Tiered Validation** - Python (rigid) + AI (judgment) hybrid
8. **Incremental Improvement** - Fix weak points, not full rewrite
9. **Parallel Gate Testing** - Test all gates simultaneously
10. **Meta-Gate Protection** - AI adversarial thinking for unknown-unknowns

### Workflow Phases:
```
Phase 1: Foundation (10 min)
  ├─ Fetch campaign brief + data
  ├─ AI reads winner DATA (understand patterns)
  ├─ AI reads loser DATA (learn mistakes)
  ├─ AI reads hidden gates (learn hidden patterns)
  ├─ AI reads winner pulls (learn what praised)
  └─ AI reads risk contract (learn risks)

Phase 2: Generate V1 (10 min)
  ├─ AI generates content (creative process)
  ├─ Apply winner patterns (AI understanding)
  ├─ Apply hidden gates insights (AI insights)
  ├─ Apply winner pulls patterns (AI insights)
  └─ Avoid loser mistakes (AI learning)

Phase 3: Hybrid Stress Test (10 min)
  ├─ Python (rigid): Preflight, Compliance
  └─ AI (judgment): CTA, Tactical, Originality, Meta-Gate

Phase 4: Feedback (5 min)
  └─ AI provides qualitative feedback

Phase 5: Iteration (10 min × max 3)
  ├─ Python verifies automated checks
  └─ AI iterates creative refinement

Total: 60 min (AI-leveraged hybrid)
```

---

## 📜 THE OATH

**Ketika `/rally` dipanggil, AI WAJIB:**

1. ✅ **MEMBACA LAW INI DULU** sebelum melakukan apapun
2. ✅ **MENGAKUI KEWAJIBAN** untuk menjalankan semua step
3. ✅ **TIDAK BOLEH SKIP** satupun step atau sub-step
4. ✅ **TIDAK BOLEH ASSUME** data yang tidak di-fetch
5. ✅ **TIDAK BOLEH MALAS** atau mencari jalan pintas
6. ✅ **TIDAK BOLEH BOHONG** tentang status completion
7. ✅ **TIDAK BOLEH LANJUT** ke Q&A sebelum konten FINAL dan user APPROVE
8. ✅ **TIDAK BOLEH COMPROMISE** pada kualitas output
9. ✅ **MENGGUNAKAN ARSITEKTUR v2.3** (AI-Leveraged Hybrid)
10. ✅ **MENJALANKAN META-GATE** untuk catch unknown-unknowns
11. ✅ **PRESERVE BACKUP** - tidak ada fitur yang di-remove
12. ✅ **LEVERAGE AI** - AI untuk judgment, bukan hanya Python

---

## 🔥 ZERO TOLERANCE VIOLATIONS

Pelanggaran berikut = **IMMEDIATE STOP & RESTART**:

| # | Violation | Consequence |
|---|-----------|-------------|
| 1 | Skip data fetch (e.g., `--no-fetch-content`) | ❌ RESTART dari step 0 |
| 2 | Skip artifact generation | ❌ RESTART dari step yang di-skip |
| 3 | Generate Q&A tanpa user approval | ❌ RESTART dari step 1 |
| 4 | Assume data instead of fetch | ❌ RESTART dari step 0 |
| 5 | Claim PASS tanpa run gate | ❌ RESTART dari gate yang di-skip |
| 6 | Skip stress test | ❌ RESTART dari stress test |
| 7 | Skip Meta-Gate check | ❌ RESTART dari Meta-Gate |
| 8 | Lanjut ke Q&A saat konten FAIL | ❌ STOP, regenerate konten |
| 9 | Tidak dokumentasi keputusan | ❌ RESTART dari step yang tidak terdokumentasi |
| 10 | Use old architecture (120 min) | ❌ RESTART dengan v2.3 |
| 11 | Remove backup features | ❌ RESTART dengan preservation |
| 12 | Over-rely on Python (no AI judgment) | ❌ RESTART dengan AI leverage |

---

## 🎯 GATE REQUIREMENTS

### Hybrid Gates (Python + AI):

**Python (Automated Rigid Checks):**
- Preflight URL/Length (format check)
- Compliance (required elements check)

**AI (Judgment Calls):**
- CTA Quality (qualitative assessment)
- Tactical Value (context understanding)
- Originality (creative judgment)
- Meta-Gate (adversarial thinking)
- Feedback analysis (qualitative insights)
- Iteration guidance (creative refinement)

---

## 📚 DOCUMENTATION REFERENCES

### Architecture:
- `RALLY_EFFECTIVE_ARCHITECTURE.md` - v2.3 AI-Leveraged Hybrid
- `RALLY_OPTIMIZED_WORKFLOW.md` - v2.3 workflow details

### Best Practices:
- `RALLY_BEST_PRACTICES.md` - Do's and Don'ts
- `RALLY_META_GATE_GUIDE.md` - Meta-Gate guide

### Quick Start:
- `RALLY_QUICK_START.md` - 5-minute overview
- `RALLY_EXAMPLES.md` - Example runs

### Backup Preservation:
- `AUDIT_REPORT_V2.3.md` - Backup preservation audit

---

## ✅ VERIFICATION CHECKLIST

Before submit, verify:

- [ ] LAW v2.3 dibaca dan dipahami
- [ ] Arsitektur v2.3 digunakan (AI-Leveraged Hybrid)
- [ ] All backup features preserved (zero removal)
- [ ] All missing data used (hidden gates, winner pulls, risk contract)
- [ ] Python dependency reduced (only rigid checks)
- [ ] AI capabilities leveraged (judgment, learning, generation)
- [ ] Data-minimal fetch (campaign brief + all data)
- [ ] Feedback-driven iteration (max 3)
- [ ] Tiered validation (Python + AI hybrid)
- [ ] Parallel gate testing
- [ ] Meta-Gate check dijalankan
- [ ] Total time ≤60 min
- [ ] All gates PASS (Python + AI)

---

## 🚀 NEXT STEPS

**Ketika `/rally` dipanggil:**

1. Read RALLY_FUNDAMENTAL_LAW v2.3 (this file)
2. Read RALLY_EFFECTIVE_ARCHITECTURE.md (v2.3)
3. Read RALLY_OPTIMIZED_WORKFLOW.md (v2.3)
4. Execute 60-min AI-leveraged hybrid workflow
5. Run Meta-Gate check (AI adversarial)
6. Submit if all gates PASS

---

## 🏆 FINAL STATUS

**Architecture:** v2.3 (AI-Leveraged Hybrid)  
**Law Version:** v2.3  
**Meta-Gate:** Required (AI adversarial thinking)  
**Time Budget:** 60 minutes  
**Data Approach:** All data used (hidden gates, winner pulls, risk contract)  
**Python Role:** Only rigid automated checks  
**AI Role:** Judgment, learning, generation, feedback, iteration  
**Backup Preservation:** 100% (zero removal)  
**Quality Target:** Top 1% (no compromise)  

**Status:** ✅ LAW v2.3 ACTIVE (AI-Leveraged Hybrid)

---

**Version:** 2.3  
**Date:** 2026-07-18  
**Supersedes:** RALLY_FUNDAMENTAL_LAW v2.0  
**Compliance:** RALLY_FUNDAMENTAL_LAW v2.3  
**Effective:** Immediately upon `/rally` call
