# 🛡️ RALLY META-GATE GUIDE

**Version:** 1.0  
**Date:** 2026-07-18  
**Status:** REQUIRED in RALLY_FUNDAMENTAL_LAW v2.0

---

## 🎯 WHAT IS META-GATE?

Meta-Gate adalah **ultimate protection gate** yang catch **unknown-unknowns** - hal-hal yang tidak terdeteksi oleh regular gates.

**Regular Gates:** Catch known-unknowns (hal yang sudah kita petakan)  
**Meta-Gate:** Catch unknown-unknowns (hal yang belum kita petakan)

---

## 🔍 WHAT DOES META-GATE CHECK?

### 1. Adversarial Thinking
```
"How would a hostile judge attack this content?"
```
- Generic AI phrase detection
- Over-optimization detection
- Lack of authenticity detection
- Missing specific proof detection

### 2. Blind Spot Detection
```
"What haven't we considered?"
```
- Missing required elements
- Missing key features
- No call-to-action detection

### 3. Edge Case Analysis
```
"What edge cases could fail?"
```
- URL formatting issues
- Em dash detection
- Length issues

### 4. Multi-Perspective Review
```
"How would different judges see this?"
```
- Skeptical judge perspective
- New user perspective
- Power user perspective

### 5. Unknown-Unknown Detection
```
"What don't we know that could hurt us?"
```
- Campaign rule changes
- Implicit requirements
- Judge preferences

---

## 🚀 HOW TO USE META-GATE

### Command:
```bash
python3 skills/rally-meta-gate.py \
  --content <content-file> \
  --campaign <campaign.json> \
  --out-json <output.json> \
  --out-md <output.md>
```

### Example:
```bash
python3 skills/rally-meta-gate.py \
  --content content.txt \
  --campaign campaign.json \
  --out-json meta-gate.json \
  --out-md META-GATE-REPORT.md
```

---

## 📊 META-GATE OUTPUT

### Status:
- **PASS** - Content is bulletproof, ready for submission
- **WARNING** - High-severity issues detected, review recommended
- **FAIL** - Critical issues detected, must fix before submission

### Issues:
Each issue includes:
- **Type:** Issue category
- **Severity:** CRITICAL / HIGH / MEDIUM / LOW
- **Description:** Detailed explanation
- **Recommendations:** How to fix

---

## 🔧 META-GATE IN WORKFLOW

### Phase 3: Stress Test (Updated)

```bash
# Tier 1: Critical Gates
python3 skills/rally-preflight-url-length.py --content content.txt
python3 skills/rally-compliance-gate.py content.txt campaign.json
python3 skills/rally-ia-claim-boundary.py --content content.txt

# Tier 2: Optimization Gates
python3 skills/rally-cta-quality-check.py --content content.txt
python3 skills/rally-tactical-value-check.py --content content.txt
python3 skills/rally-ep-compactness-check.py --content content.txt

# Tier 3: Quality Gates
python3 skills/rally-originality-saturation-check.py --content content.txt
python3 skills/rally-worst-positive-verdict-check.py --content content.txt

# Meta-Gate: Ultimate Protection (NEW!)
python3 skills/rally-meta-gate.py --content content.txt --campaign campaign.json
```

---

## ✅ META-GATE CHECKLIST

Before submit, verify:

- [ ] Meta-Gate executed
- [ ] Meta-Gate status: PASS
- [ ] No CRITICAL issues
- [ ] No HIGH issues (or addressed)
- [ ] All recommendations reviewed
- [ ] Content updated based on feedback

---

## 🎯 META-GATE BEST PRACTICES

### DO:
- ✅ Run Meta-Gate after all other gates PASS
- ✅ Review all issues, even LOW severity
- ✅ Address CRITICAL and HIGH issues immediately
- ✅ Use Meta-Gate recommendations untuk improve content

### DON'T:
- ❌ Skip Meta-Gate check
- ❌ Ignore CRITICAL issues
- ❌ Submit if Meta-Gate FAIL
- ❌ Use Meta-Gate as replacement for other gates

---

## 📚 META-GATE EXAMPLES

### Example 1: PASS
```
META-GATE CHECK: PASS
  Meta-Gate PASSED: Content is bulletproof
  Total issues: 4
  Critical: 0
  High: 0
```
**Result:** Content ready for submission

### Example 2: WARNING
```
META-GATE CHECK: WARNING
  Meta-Gate WARNING: 2 high-severity issues detected
  Total issues: 8
  Critical: 0
  High: 2
```
**Result:** Review high-severity issues, fix if possible

### Example 3: FAIL
```
META-GATE CHECK: FAIL
  Meta-Gate FAILED: 1 critical issues detected
  Total issues: 5
  Critical: 1
  High: 2
```
**Result:** Must fix critical issues before submission

---

## 🔗 META-GATE INTEGRATION

### In RALLY_FUNDAMENTAL_LAW v2.0:
- Meta-Gate is **REQUIRED**
- Must PASS before submission
- Zero tolerance for CRITICAL issues

### In RALLY_OPTIMIZED_WORKFLOW.md:
- Meta-Gate is part of Phase 3 (Stress Test)
- Run after all other gates
- Final line of defense

### In RALLY_BEST_PRACTICES.md:
- DO: Run Meta-Gate check
- DON'T: Skip Meta-Gate
- Best practice: Address all issues

---

## 🏆 META-GATE BENEFITS

### Quality:
- ✅ Catch unknown-unknowns
- ✅ Multi-perspective review
- ✅ Adversarial thinking
- ✅ Comprehensive protection

### Safety:
- ✅ Final line of defense
- ✅ Zero tolerance for critical issues
- ✅ Bulletproof content
- ✅ Reduced risk

### Efficiency:
- ✅ Automated detection
- ✅ Clear recommendations
- ✅ Quick feedback
- ✅ Save time on revisions

---

## 🎯 META-GATE STATUS

**Version:** 1.0  
**Status:** ACTIVE  
**Required:** YES (in LAW v2.0)  
**Integration:** Complete  
**Testing:** PASS  

**Status:** 🛡️ **META-GATE ACTIVE**

---

**Version:** 1.0  
**Date:** 2026-07-18  
**Compliance:** RALLY_FUNDAMENTAL_LAW v2.0  
**Verified by:** AI Agent
