# 🚀 RALLY QUICK START GUIDE

**Time:** 5 minutes to understand  
**Goal:** Run Rally workflow efficiently in 60 minutes

---

## 📋 WHAT IS RALLY EFFECTIVE WORKFLOW?

New architecture yang:
- 2X faster (60 min vs 120 min)
- Better quality (no over-optimization)
- Data-minimal generation
- Feedback-driven iteration

---

## 🎯 5-MINUTE OVERVIEW

### Step 1: Fetch Campaign Brief (2 min)
```bash
python3 skills/rally-dna-fetcher.py --address <addr> --mission mission-0
```

### Step 2: Generate V1 (10 min)
- Focus: Campaign compliance ONLY
- Ignore: Originality, patterns, DNA

### Step 3: Stress Test (10 min)
- Tier 1: Critical gates (must pass)
- Tier 2: Optimization gates (should pass)
- Tier 3: Quality gates (nice to have)

### Step 4: Feedback (5 min)
- Identify weak points
- Generate specific feedback

### Step 5: Iterate (10 min × max 3)
- Fix weak points (not full rewrite)
- Re-test
- Max 3 iterations

**Total: 60 minutes**

---

## 🔧 FIRST RUN GUIDE

### Before You Start

1. **Read Architecture** (2 min)
   ```bash
   cat RALLY_EFFECTIVE_ARCHITECTURE.md
   ```

2. **Read Workflow** (2 min)
   ```bash
   cat RALLY_OPTIMIZED_WORKFLOW.md
   ```

3. **Read Best Practices** (1 min)
   ```bash
   cat RALLY_BEST_PRACTICES.md
   ```

### Run Workflow

1. **Fetch Campaign** (5 min)
   ```bash
   python3 skills/rally-dna-fetcher.py --address 0x5e0Dc... --mission mission-0
   ```

2. **Generate V1** (10 min)
   - Use campaign brief ONLY
   - Focus on compliance
   - 600-850 chars

3. **Stress Test** (10 min)
   ```bash
   python3 skills/rally-preflight-url-length.py --content content.txt
   python3 skills/rally-cta-quality-check.py --content content.txt
   python3 skills/rally-tactical-value-check.py --content content.txt
   ```

4. **Feedback** (5 min)
   - Analyze failures
   - Generate specific feedback

5. **Iterate** (10 min × max 3)
   - Fix weak points
   - Re-test
   - Until PASS

---

## ❓ COMMON QUESTIONS

### Q: Kenapa data-minimal generation?
**A:** Faster, clearer focus, avoid over-optimization. Stress test handle quality factors.

### Q: Kenapa max 3 iterations?
**A:** Diminishing returns after 3 iterations. If still fail, different approach needed.

### Q: Kenapa tiered validation?
**A:** Clear priorities. Critical gates MUST pass, optimization SHOULD pass, quality NICE TO HAVE.

### Q: Kenapa parallel gate testing?
**A:** 2-3X faster. Test all gates simultaneously instead of sequentially.

### Q: Kenapa incremental improvement?
**A:** Reuse working components. Don't rebuild everything each iteration.

### Q: Kenapa feedback-driven?
**A:** Learn from failures. Each iteration improves based on specific weak points.

### Q: Apa yang harus di-fetch?
**A:** Campaign brief ONLY. Not all DNA/patterns/hidden gates.

### Q: Apa yang di-stress test?
**A:** Everything: originality, CTA, tactical, compliance, patterns, DNA.

### Q: Kalau V1 langsung PASS?
**A:** Great! Skip iteration, submit content.

### Q: Kalau setelah 3 iterations masih FAIL?
**A:** Different approach needed. Maybe different angle, different framework.

---

## ✅ QUICK CHECKLIST

### Before Run
- [ ] Read architecture (2 min)
- [ ] Read workflow (2 min)
- [ ] Read best practices (1 min)

### During Run
- [ ] Fetch campaign brief (5 min)
- [ ] Generate V1 (10 min)
- [ ] Stress test (10 min)
- [ ] Feedback (5 min)
- [ ] Iterate (10 min × max 3)

### After Run
- [ ] All Tier 1 gates PASS
- [ ] Most Tier 2 gates PASS
- [ ] Screenshot ready
- [ ] Submit content

---

## 🎯 SUCCESS CRITERIA

| Criteria | Target |
|----------|--------|
| Total Time | ≤60 min |
| Iterations | ≤3 |
| Tier 1 Pass | 100% |
| Tier 2 Pass | ≥67% |
| Quality | High |

---

## 📚 NEXT STEPS

1. **First Run:** Follow this guide
2. **Learn:** Apply best practices
3. **Improve:** Document lessons learned
4. **Scale:** Use for multiple campaigns

---

## 🔗 RESOURCES

- **Architecture:** `RALLY_EFFECTIVE_ARCHITECTURE.md`
- **Workflow:** `RALLY_OPTIMIZED_WORKFLOW.md`
- **Best Practices:** `RALLY_BEST_PRACTICES.md`
- **Examples:** `RALLY_EXAMPLES.md`

---

## 💡 TIPS

### Tip 1: Don't Over-Analyze
```
Spend max 10 min on analysis.
Focus on campaign brief.
Don't over-think patterns.
```

### Tip 2: Generate Fast
```
V1 dalam 10 min.
Use proven framework.
Don't over-think first version.
```

### Tip 3: Test Parallel
```
Test all gates simultaneously.
Don't test sequentially.
2-3X faster feedback.
```

### Tip 4: Fix Specific
```
Fix weak points only.
Don't full rewrite.
Reuse working components.
```

### Tip 5: Learn dari Failures
```
Each failure = learning opportunity.
Track what works/doesn't.
Improve progressively.
```

---

**Status:** ✅ QUICK START READY  
**Next:** Run workflow

**Time to First Run:** 5 minutes (read) + 60 minutes (execute)  
**Total:** 65 minutes

**Compliance:** RALLY_QUICK_START v2.0  
**Date:** 2026-07-18
