# ✅ RALLY BEST PRACTICES v2.0

**Date:** 2026-07-18  
**Based on:** Lessons learned from multiple runs

---

## 🎯 DO's (Best Practices)

### ✅ DO: Data-Minimal Generation
```
✅ DO: Fetch campaign brief ONLY
❌ DON'T: Fetch all DNA/patterns upfront

Why: Faster generation, clearer focus, avoid over-optimization
```

### ✅ DO: Campaign Compliance First
```
✅ DO: Focus V1 on campaign compliance
❌ DON'T: Try to optimize everything upfront

Why: Clear priorities, avoid content damage
```

### ✅ DO: Feedback-Driven Iteration
```
✅ DO: Generate V1 → Test → Feedback → V2 (dengan feedback)
❌ DON'T: V1 → V2 (full rewrite) → V3 (full rewrite)

Why: Learn from failures, targeted improvement
```

### ✅ DO: Tiered Validation
```
✅ DO: Run Tier 1 (critical) → Tier 2 (optimization) → Tier 3 (quality)
❌ DON'T: Run all gates equally

Why: Clear priorities, graceful degradation
```

### ✅ DO: Parallel Gate Testing
```
✅ DO: Test multiple gates simultaneously
❌ DON'T: Test gates sequentially

Why: 2-3X faster feedback
```

### ✅ DO: Incremental Improvement
```
✅ DO: Fix specific weak points (not full rewrite)
❌ DON'T: Rebuild everything each iteration

Why: Reuse working components, faster iteration
```

### ✅ DO: State Management
```
✅ DO: Track what works/doesn't across iterations
❌ DON'T: Forget previous test results

Why: Don't repeat mistakes, progressive improvement
```

### ✅ DO: Stress Test as Learning
```
✅ DO: Use stress test for feedback + learning
❌ DON'T: Use stress test only for verification

Why: Clear understanding of failures
```

### ✅ DO: Real Experience
```
✅ DO: Use FUD.markets first, track real stats
❌ DON'T: Generate content without real experience

Why: Authentic content, campaign compliant
```

### ✅ DO: Balanced Optimization
```
✅ DO: Optimize ALL factors (originality + compliance + authenticity)
❌ DON'T: Over-optimize single factor (originality only)

Why: No content damage, balanced quality
```

---

## ❌ DON'Ts (Common Mistakes)

### ❌ DON'T: Skip Data Fetch
```
❌ MISTAKE: Use --no-fetch-content
✅ CORRECT: Fetch with content

Impact: Missing winner DNA, can't learn patterns
```

### ❌ DON'T: Over-Iterate
```
❌ MISTAKE: V1→V2→V3→V4→V5→V6
✅ CORRECT: Max 3 iterations

Impact: Wasted time, diminishing returns
```

### ❌ DON'T: Over-Optimize Originality
```
❌ MISTAKE: Sacrifice campaign compliance for originality
✅ CORRECT: Balance all factors

Impact: Content damaged, missing features
```

### ❌ DON'T: Full Rewrite Each Iteration
```
❌ MISTAKE: Generate V2 dari nol
✅ CORRECT: Fix specific weak points dari V1

Impact: Wasted effort, no learning
```

### ❌ DON'T: Generate Q&A Without Approval
```
❌ MISTAKE: Auto-generate Q&A setelah content
✅ CORRECT: Ask user first

Impact: Wasted effort if user tidak mau Q&A
```

### ❌ DON'T: Ignore False Positives
```
❌ MISTAKE: Try to fix Loser DNA URLs overlap
✅ CORRECT: Accept as known limitation

Impact: Wasted time on unfixable issue
```

### ❌ DON'T: Sequential Testing
```
❌ MISTAKE: Test gate 1 → wait → test gate 2 → wait
✅ CORRECT: Test all gates parallel

Impact: 2-3X slower
```

### ❌ DON'T: Skip Tiered Validation
```
❌ MISTAKE: Run all 9 gates equally
✅ CORRECT: Tier 1 (critical) → Tier 2 → Tier 3

Impact: Wasted time on non-critical gates
```

### ❌ DON'T: Generate Without Framework
```
❌ MISTAKE: Generate content dari scratch
✅ CORRECT: Use proven framework/structure

Impact: Inconsistent quality, slower generation
```

### ❌ DON'T: Ignore Campaign Goal
```
❌ MISTAKE: Focus on technical gates only
✅ CORRECT: Align with campaign goal

Impact: Content technically PASS tapi not aligned
```

---

## 📊 QUALITY PRINCIPLES

### 1. No Compromise on Quality
```
Quality is non-negotiable.
Time is flexible.

If quality compromised → iterate more.
If time exceeded → accept, don't sacrifice quality.
```

### 2. Progressive Enhancement
```
V1: Campaign compliant (baseline)
V2: + Originality (learned from stress test)
V3: + CTA quality (learned from stress test)
V4: + All factors (learned from stress test)

Each iteration adds one quality layer.
```

### 3. Authentic Content
```
Real experience + AI optimization = Authentic

❌ AI-generated content (no real experience)
✅ Human experience + AI enhancement = Authentic
```

### 4. Balanced Optimization
```
Optimize ALL factors:
- Originality (unique angle)
- Campaign compliance (mention features)
- Authenticity (real experience)
- Compelling (specific stats)
- Clear mechanism (how it works)
- Strong CTA (drive action)

Don't over-optimize single factor.
```

### 5. Graceful Degradation
```
Tier 1 MUST PASS (critical)
Tier 2 SHOULD PASS (optimization)
Tier 3 NICE TO HAVE (quality)

If Tier 3 FAIL but Tier 1+2 PASS → Accept.
```

---

## 🔧 WORKFLOW TIPS

### Tip 1: Quick Analysis
```
Spend max 10 min on analysis.
Don't over-analyze patterns.
Focus on campaign brief requirements.
```

### Tip 2: Fast Generation
```
Generate V1 dalam 10 min.
Use proven framework.
Don't over-think first version.
```

### Tip 3: Efficient Testing
```
Test gates parallel.
Skip non-critical gates if critical fail.
Max 10 min for full stress test.
```

### Tip 4: Clear Feedback
```
Feedback harus specific:
❌ "Content not good enough"
✅ "Originality 0.19, target <0.15, improve unique angle"
```

### Tip 5: Targeted Fix
```
Fix specific weak points:
❌ Full rewrite
✅ "Keep hook, fix CTA, improve mechanism"
```

---

## 📋 CHECKLISTS

### Pre-Generation Checklist
- [ ] Campaign brief fetched
- [ ] Requirements extracted
- [ ] Framework selected
- [ ] Style guide understood

### Generation Checklist
- [ ] V1 generated (10 min)
- [ ] Campaign compliant
- [ ] Required elements included
- [ ] Style guide followed

### Stress Test Checklist
- [ ] Tier 1 gates tested (critical)
- [ ] Tier 2 gates tested (optimization)
- [ ] Tier 3 gates tested (quality)
- [ ] Results documented

### Feedback Checklist
- [ ] Weak points identified
- [ ] Fixes prioritized
- [ ] Specific feedback generated
- [ ] V2 generation prompt created

### Iteration Checklist
- [ ] V2 generated dengan feedback
- [ ] Stress test re-run
- [ ] Improvements verified
- [ ] Max 3 iterations

### Pre-Submit Checklist
- [ ] All Tier 1 gates PASS
- [ ] Most Tier 2 gates PASS
- [ ] Tier 3 acceptable
- [ ] Screenshot ready
- [ ] URLs clickable
- [ ] No em dashes
- [ ] Length 600-850 chars
- [ ] Total time ≤60 min

---

## 🎯 SUCCESS METRICS

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Total Time | ≤60 min | Track phase times |
| Iterations | ≤3 | Count V1, V2, V3 |
| Tier 1 Pass Rate | 100% | All critical gates |
| Tier 2 Pass Rate | ≥67% | 2/3 optimization gates |
| Tier 3 Pass Rate | ≥50% | 1/2 quality gates |
| Quality Score | High | Balanced optimization |

---

## 📚 LESSONS LEARNED

### Lesson 1: Data-Minimal > Data-Heavy
```
Before: Fetch all data → over-optimize → content damaged
After: Fetch brief only → generate → stress test → iterate
Result: 2X faster, better quality
```

### Lesson 2: Feedback > Full Rewrite
```
Before: V1 → V2 (full rewrite) → V3 (full rewrite)
After: V1 → V1.1 (fix hook) → V1.2 (fix CTA)
Result: 3X less generation effort
```

### Lesson 3: Tiered > All-or-Nothing
```
Before: All 9 gates must PASS or iterate
After: Tier 1 MUST PASS, Tier 2 SHOULD PASS, Tier 3 NICE TO HAVE
Result: Graceful degradation, faster delivery
```

### Lesson 4: Parallel > Sequential
```
Before: Test gate 1 → wait → test gate 2 → wait
After: Test all gates parallel
Result: 2-3X faster testing
```

### Lesson 5: Balanced > Over-Optimized
```
Before: Optimize originality only → content damaged
After: Balance all factors → authentic content
Result: No content damage, better quality
```

---

**Status:** ✅ BEST PRACTICES DOCUMENTED  
**Next:** Apply to workflow

**Compliance:** RALLY_BEST_PRACTICES v2.0  
**Verified by:** AI Agent  
**Date:** 2026-07-18
