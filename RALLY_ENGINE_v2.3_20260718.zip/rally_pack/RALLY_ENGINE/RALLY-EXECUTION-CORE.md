# RALLY EXECUTION CORE - CURRENT ACTIVE FLOW

Status: ACTIVE
Purpose: the operating sequence for current `/rally` runs.

## Fundamental law

All content is governed by:

```text
Campaign Ask x Rally Judge Desire
```

The literal campaign/mission brief and real Rally judge evidence outrank all frameworks and tools.

## Current run sequence

1. Mission truth lock.
2. Source truth snapshot.
3. Data sufficiency check.
4. First-principles original thesis.
5. Hidden-gate mining and scoped manual review.
6. Winner-pull mining and anti-copy transform.
7. Exponential / Irreducible Apex content build.
8. Memetic / audience / contrarian / scene / reply-identity creative review.
9. AI Human Taste Director review if user does not review manually.
10. Known-Gate Absolute closure check.
11. Python content gates as safety net.
12. Q&A generation after content is stable.
13. Q&A Gold V3 gates.
14. Final integrity.
15. Public deliverable.

## Required pre-draft artifacts for strict/Irreducible runs

- `ORIGINAL-THESIS.md`
- `THESIS-OBJECT-CANDIDATES.md`
- `HIDDEN-GATE-CANDIDATES.md`
- `HIDDEN-GATE-MANUAL-REVIEW.md`
- `PRE-DRAFT-HIDDEN-GATE-CONTRACT.md`
- `WINNER-PULL-MAP.md`
- `WINNER-PULL-CONTRACT.md`
- `DATA-JUDGE-REVIEW.md`
- `EXPONENTIAL-CONTENT-REPORT.md`
- `IRREDUCIBLE_APEX_REPORT.md`
- `HUMAN-TASTE-DIRECTOR-REPORT.md` when user does not participate in taste decisions
- `KNOWN-GATE-ABSOLUTE-REPORT.md` when claiming known-gate absolute local pass

## Required content gates

Run after final content is stable:

```bash
python3 skills/rally-compliance-gate.py content.txt contract.json
python3 skills/rally-cta-quality-check.py --content content.txt --out-json cta.json --out-md CTA.md
python3 skills/rally-tactical-value-check.py --content content.txt --out-json tactical-value.json --out-md TACTICAL-VALUE.md
python3 skills/rally-ep-compactness-check.py --content content.txt --out-json compactness.json --out-md COMPACTNESS.md
python3 skills/rally-loser-dna-scan.py --content content.txt --submissions submissions_enriched.json --out-json loser-dna.json --out-md LOSER-DNA.md
python3 skills/rally-originality-saturation-check.py --content content.txt --submissions submissions_enriched.json --out-json originality.json --out-md ORIGINALITY.md
python3 skills/rally-tq-format-audit.py --content content.txt --out-json tq.json --out-md TQ.md --genre tactical
python3 skills/rally-oaa-structure-audit.py --content content.txt --submissions submissions_enriched.json --out-json oaa.json --out-md OAA.md
python3 skills/rally-ia-claim-boundary.py --content content.txt --campaign campaign.json --out-json ia.json --out-md IA.md
python3 skills/rally-ep-semantic-review.py --content content.txt --ep-map ep-deduction-map.json --cta-report cta.json --oaa-report oaa.json --tq-report tq.json --out-json ep-semantic.json --out-md EP-SEMANTIC.md
python3 skills/rally-worst-positive-verdict-check.py --content content.txt --tactical-report tactical-value.json --originality-report originality.json --compactness-report compactness.json --cta-report cta.json --out-json worst-positive.json --out-md WORST-POSITIVE.md
```

## Required Q&A gates

Run after content is final and Q&A exists:

```bash
python3 skills/rally-rq-prompt-answer-check.py --content content.txt --combined combined.md --out-json rq-prompt-answer.json --out-md RQ-PROMPT-ANSWER.md
python3 skills/rally-rq-mechanics-calibration-check.py --content content.txt --combined combined.md --campaign campaign.json --mission <mission> --out-json rq-mechanics.json --out-md RQ-MECHANICS.md
python3 skills/rally-naturalness-variance-check.py --content content.txt --combined combined.md --out-json naturalness.json --out-md NATURALNESS.md
python3 skills/rally-qna-gold-audit.py --content content.txt --combined combined.md --out-json qna-gold.json --out-md QNA-GOLD.md
python3 skills/rally-rq-v3-policy-check.py --content content.txt --combined combined.md --ranking-json qa_ranking.json --out-json rq-gold-v3-policy.json --out-md RQ-GOLD-V3-POLICY.md
```

## Final integrity

Run final integrity with current reports. Do not ship stale passes.

## Status language

Allowed:

- `local strict PASS`
- `Irreducible Apex local PASS`
- `Known-Gate Absolute local PASS`
- `RQ5-ready` if Q&A gates pass

Forbidden:

- `guaranteed all-max`
- `guaranteed winner`
- `guaranteed top 1%`
- `guaranteed RQ5`

## Workflow enforcement utilities

Strict runs can be checked with:

- `skills/rally-data-sufficiency-check.py`
- `skills/rally-human-typed-audit.py`
- `skills/rally-run-completeness-check.py`
- `skills/CANDIDATE-TOURNAMENT-PROTOCOL.md`

Use these to prevent skipped artifacts, over-mechanical public copy, and first-draft bias.
