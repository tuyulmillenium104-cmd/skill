# ACTIVE SKILL MANIFEST

Status: ACTIVE
Purpose: define the current authority order and prevent legacy/static rules from competing with the latest workflow.

## Active authority order

1. Literal campaign/mission brief and campaign rules.
2. `skills/RALLY-FUNDAMENTAL-LAW.md`
3. Current mission-scoped real Rally submissions, verdicts, winner/non-winner data, source post truth, and campaign knowledge base.
4. `skills/DATA_AS_JUDGE_NOT_WRITER_POLICY.md`
5. `skills/ORIGINAL-THESIS-ENGINE.md`
6. `skills/FIRST_PRINCIPLES_CONTENT_BUILD.md`
7. `skills/ANTI_COPY_WINNER_TRANSFORM.md`
8. `skills/HIDDEN-GATE-MINING-PROTOCOL.md`
9. `skills/HIDDEN_GATE_SCOPE_REGISTRY.md`
10. `skills/WINNER-PULL-MINING-PROTOCOL.md`
11. `skills/WINNER_PULL_CONTRACT_TEMPLATE.md`
12. `skills/EP-MANUAL-NO-CUT-PROTOCOL.md`
13. `skills/EXPONENTIAL-CONTENT-STANDARD.md`
14. `skills/IRREDUCIBLE-APEX-STANDARD.md`
15. `skills/HUMAN-TYPED-PUBLIC-COPY-STANDARD.md`
16. `skills/AI-HUMAN-TASTE-DIRECTOR.md`
17. `skills/MEMETIC-INSIGHT-ENGINE.md`
18. `skills/AUDIENCE-PSYCHOLOGY-MAP.md`
19. `skills/CONTRARIAN-POSITIONING-LOCK.md`
20. `skills/SCENE-VIVIDNESS-CHECK.md`
21. `skills/REPLY-IDENTITY-TEST.md`
22. `skills/COMPRESSION-VARIANT-TOURNAMENT.md`
23. `skills/KNOWN-GATE-ABSOLUTE-STANDARD.md`
24. `RALLY-EXECUTION-CORE.md`
25. `skills/RALLY-QNA-ENGINE-V3.1.3.md`
26. `skills/GOLD_RQ_STANDARD_CALIBRATED.md`
27. `skills/PUBLIC_COPY_LEAKAGE_POLICY.md`
28. Python checkers as safety nets.

## Core workflow order

1. Mission truth lock.
2. Source truth snapshot.
3. Data sufficiency check.
4. First-principles original thesis.
5. Hidden-gate mining and scoped manual review.
6. Winner-pull mining and anti-copy transform.
7. Exponential / Irreducible Apex concept build.
8. Memetic / audience / contrarian / scene / reply-identity creative review.
9. AI Human Taste Director review when user does not want to review manually.
10. Known-Gate Absolute closure check.
11. Python content gates as safety net.
12. Q&A generation only after content is stable.
13. Q&A Gold V3 gates.
14. Final integrity.
15. Public deliverable/export.

## Active operating tools

- `skills/rally-campaign-cartographer.py`
- `skills/rally-dna-fetcher.py`
- `skills/rally-hidden-gate-miner.py`
- `skills/rally-winner-pull-miner.py`
- `skills/rally-winner-dna-map.py`
- `skills/rally-ep-deduction-map.py`
- `skills/rally-pre-draft-risk-contract.py`
- content gate tools (`rally-cta-quality-check.py`, `rally-tactical-value-check.py`, etc.)
- Q&A Gold V3 tools.

## Not active by default

Archived/historical references must not drive current drafting:

- `skills/_archive/legacy_content_engines/`
- `skills/_archive/legacy_protocol_docs/`

Stub pointer files may remain at old paths only to avoid broken references.

## Core rule

Mission-specific evidence outranks static legacy rules. Original thesis, hidden-gate mining, winner-pull mining, human taste review, memetic review, Irreducible Apex review, and Known-Gate Absolute closure happen before finalization. Python checkers catch known risks but do not replace judgment.

## Scope rule

A hidden gate discovered in one mission defaults to `MISSION_ONLY` and must not become global unless proven across multiple unrelated campaigns.

## Data rule

Data does not write. Data judges. Winner examples are benchmarks and evidence, not templates.

## Final content rule

A draft that merely passes Python gates but lacks human-typed Irreducible Apex quality is not final.

## Known-Gate Absolute rule

`Known-Gate Absolute PASS` means all known controllable cut surfaces are closed. It does not mean guaranteed all-max, guaranteed winner, or guaranteed top 1%.

## Forbidden claims

Never claim:

- guaranteed all-max;
- guaranteed winner;
- guaranteed top 1%;
- guaranteed RQ5.

Allowed wording:

- local strict PASS;
- Irreducible Apex local PASS;
- Known-Gate Absolute local PASS;
- RQ5-ready, if Q&A gates pass;
- controllable-side PASS.

## Workflow enforcement utilities

Strict runs can be checked with:

- `skills/rally-data-sufficiency-check.py`
- `skills/rally-human-typed-audit.py`
- `skills/rally-run-completeness-check.py`
- `skills/CANDIDATE-TOURNAMENT-PROTOCOL.md`

Use these to prevent skipped artifacts, over-mechanical public copy, and first-draft bias.

---

## Real-verdict ratchet - 2026-07-18

Gold RQ policy updated to `3.1.4-real-rq-formula-cap` after a real Rally verdict on The Court of Internet mission-1 capped RQ at 3/5 for formulaic reply-set patterns despite substantive replies.

Active rule: Q&A packs must pass substance checks **and** formula-shell caps. Repeated public shells such as `My concern is...`, `My decision is...`, `My answer is...`, repeated `Hot take`, repeated `Wrong lesson`, or repeated direct mention starts are not acceptable as final public copy.

This ratchet is evidence-based and supersedes older Gold V3.1.3 optimism.

---

## GitHub selective adoption - 2026-07-18

The user-supplied GitHub skill repository was inspected and selectively adopted. The current engine is **not replaced**. Adopted material is active only where compatible with current authority law and real-verdict ratchets.

New active standards added:

- `skills/REAL-JUDGE-4CAP-CALIBRATION-PROTOCOL.md`
- `skills/EP-SURFACE-SELECTION-PROTOCOL.md`
- `skills/RUN-LEDGER-PROTOCOL.md`
- `skills/RELATION-MEDIA-PLAN-PROTOCOL.md`
- `skills/UNIVERSAL-RALLY-CAMPAIGN-SAFETY-PROTOCOL.md`

New adopted tools added as safety/provenance utilities:

- `skills/rally_common.py`
- `skills/rally-requirement-provenance.py`
- `skills/rally-mission-contract.py`
- `skills/rally-relation-compliance.py`

Adoption limits:

- Do not adopt old 100% / guaranteed-all-max language.
- Do not use old examples as templates.
- Do not replace current V3.1.4 real-formula-cap Q&A policy.
- Do not make one-shot automation the writing authority.

Workflow additions after Mission truth lock:

1. Requirement provenance artifact.
2. Mission contract artifact.
3. Relation/media plan artifact.
4. EP surface selection before drafting.
5. Run ledger/checklist must appear in final `.md` deliverable.


---

## ONE SESSION / ONE RUN active mode - 2026-07-18

Active protocol:

`skills/ONE-SESSION-ONE-RUN-PROTOCOL.md`

Default `/rally <address> misi <number>` behavior in this chat:

1. Generate main-content candidate.
2. Stress main content fail-fast.
3. If HARD FAIL or core CREDIBLE DEDUCTION: reject candidate and generate a new candidate from feedback, not tambal-sulam.
4. Max 3 main-content candidates by default.
5. Q&A is generated only after `MAIN_CONTENT_STRESS_PASS`.
6. If all candidates fail: output STOP report and do not generate Q&A.
7. Final local PASS labels are allowed only after content, Q&A, and final integrity pass.

This mode preserves creativity while still using stress gates as judge, not writer.

One-run completeness checker added:

`skills/rally-one-run-completeness-check.py`

This checker must be run for one-session final outputs. It requires old full-workflow artifacts plus new one-run artifacts such as `RUN_MODE.md`, `GENERATE_OUTPUT_FOR_STRESS.md`, `CANDIDATE_LEDGER.md`, `MAIN_CONTENT_STRESS_REPORT.md`, `UNMAPPED_RISK_GATE.md`, `QNA_STRESS_REPORT.md`, and `FINAL_REPORT.md`.

---

## Fresh-but-inevitable EP mode - 2026-07-18

Active protocol:

`skills/FRESH-BUT-INEVITABLE-CONTENT-PROTOCOL.md`

Generate stage must select a non-crowded but campaign-native surface before drafting. The goal is not literal 0% lexical overlap; mandatory campaign terms may overlap. The goal is a fresh core hook/surface/progression that still feels inevitable for the campaign.

Stress stage must check whether the surface is fresh-but-inevitable or merely weird. If it is crowded or weird, reject the candidate and regenerate with a new surface instead of patching.
