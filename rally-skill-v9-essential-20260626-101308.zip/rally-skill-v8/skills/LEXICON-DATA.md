# LEXICON DATA — V8.0 (Active Rules)

> Data terpisah dari logika. Tool baca file ini sebagai source-of-truth lexicon.
> Edit lexicon = WAJIB tag tanggal + sumber vonis + regression test.

---

## §EP-KILL (KONTEN langsung di-scan, exit 1 kalau hit)

Pola yang TERBUKTI memotong EP di vonis nyata Rally (global mining 2026-06-25 + sesi calibration).

### EP-KILL-1: Generic CTA (rank 6 di CTA-Quality)
```
thoughts?
what do you think?
agree?
agree or disagree?
drop yours below
let me know
share below
share your thoughts
lmk
your take?
```

### EP-KILL-2: Hype phrases tanpa substansi
```
game changer
game-changer
this is huge
to the moon
LFG
gm
this is everything
this hits different
mind blown
chef's kiss
```

### EP-KILL-3: Brand-bridge promotional
```
that is why @
this is exactly why @
@\w+ solves this
makes sense to me, that's why
shoutout to @
big things coming from @
```

### EP-KILL-4: Unsupported guarantee / earning claim
```
guaranteed
will make you
profit
100x
huge ROI
passive income
get rich
financial freedom
life changing money
```

### EP-KILL-5: Slow opener / weak hook
```
^so,
^well,
^honestly,
^to be honest
^just thinking
^random thought
^been thinking about
^lately I've been
```

### EP-KILL-6: AI signature
```
in this fast-paced world
in today's landscape
it's worth noting
delve into
let's unpack
moreover
furthermore
in summary
to put it simply
when it comes to
```

### EP-KILL-7: Fourth-wall / meta-commentary
```
this tweet
this post
reading this
as I write this
my thread
TL;DR (kecuali brief allow)
```

### EP-KILL-8: Slogan-cadence (3-beat rhetorical empty)
```
not X, but Y, and Z (without specific)
fast. cheap. decentralized.
secure. simple. powerful.
build. ship. iterate.
```

### EP-KILL-9: Dual CTA crowding
```
[content with ≥2 question marks in final 2 sentences without choice structure]
[content with both "?" and "comment below" combination]
```

### EP-KILL-10: Vocative-mention mid-sentence
```
[regex: ".*\\.\\s+@\\w+.*\\.\\s+.*"]  ← mention as standalone vocative line
[regex: ".*,\\s*@\\w+,.*"]  ← vocative comma-flanked mid-sentence
```

---

## §WIN-MECHANISM (positive patterns — content WAJIB punya ≥1)

### WIN-MECHANISM-1: NAMED_CONCEPT
Tanda: konten menamai konsep/pattern baru atau memberi label tajam.
Examples dari real winners:
```
"queue position"
"judgment laundering"
"correlation cosplay"
"creator access budget"
"founder mode is employee mode in formal clothes"
```
Detect heuristic:
- Ada noun-phrase yang di-bold/di-italic/di-tekankan, ATAU
- Ada definisi eksplisit "X is Y, not Z", ATAU
- Ada metaphor-label yang 2-4 kata diapply ke konsep abstrak.

### WIN-MECHANISM-2: CONTRARIAN_VERDICT
Tanda: konten berdiri lawan konsensus pool/community.
Detect heuristic:
- Pernyataan deklaratif yang mengandung negasi konsensus: "X is not Y, X is actually Z"
- Verdict klausa: "Genius/Mid/Cooked", "verdict:", "actually false:", "the truth is"
- Anti-trend frame: "everyone says X, but X is wrong because Y"

### WIN-MECHANISM-3: MECHANISM_REVEAL
Tanda: konten buka cara kerja sesuatu yang biasanya hidden.
Detect heuristic:
- Reveal phrase: "the way X actually works", "what no one explains", "the hidden cost", "the trick is"
- Step-by-step micro-tutorial yang tidak templated.

### WIN-MECHANISM-4: RESOURCE_ROUTING
Tanda: konten kasih kerangka cara alokasi waktu/uang/perhatian/RLP/etc.
Detect heuristic:
- CTA berbentuk "what would you spend your X on", "where would you put your Y"
- List bertingkat priority: "first X, then Y, only after Z"
- Budget frame: "I'd split it 70/20/10..."

### WIN-MECHANISM-5: VULNERABLE_SCENE
Tanda: scene konkret dengan stake personal nyata.
Detect heuristic:
- First-person past tense + specific time-place: "Last Tuesday at 3am I was..."
- Konkret artefak: "checked my dashboard", "refreshed 8 times", "called my partner"
- Stake terlihat: kerugian, kekecewaan, kemenangan kecil yang spesifik.

### WIN-MECHANISM-6: DATA_FRAME
Tanda: konten pakai angka/data sebagai tulang argumen.
Detect heuristic:
- Numerik dengan unit: "274 submissions", "24 winners", "1.6% rate"
- Komparasi terkuantifikasi: "5x more X than Y"
- Source-attributed: "from <known source>"

### WIN-MECHANISM-7: CATEGORY_CREATION
Tanda: konten menciptakan kategori baru yang reader bisa pakai.
Detect heuristic:
- "There are two types of X: Y and Z"
- "X has 3 modes: A, B, C"
- "I split Y into X kinds"

---

## §LOSER-SEMANTIC (25 pattern, scan semantik bukan n-gram saja)

### LOSER-EP-1: CTA tacked-on
- CTA terakhir di paragraf terakhir, tidak terkait thesis konten.
- Detect: cosine similarity antara CTA sentence dan rest-of-content <0.2

### LOSER-EP-2: Conversation potential tanpa CTA
- Question mark ada tapi tidak ada behavioral verb di final 2 kalimat.

### LOSER-EP-3: Value-not-exceptional
- Tidak ada NAMED_CONCEPT atau MECHANISM_REVEAL.
- Vocab dominan: generic abstract noun (importance, value, opportunity, future)

### LOSER-EP-4: Hook-not-sharp
- First 10 words tidak mengandung: number, verdict, contrarian negation, name, specific noun.
- First sentence > 18 words.

### LOSER-EP-5: Promotional density
- Brand name mention >2x dalam <280 chars
- ≥3 superlatif positif (best, ultimate, amazing, incredible)

### LOSER-OAA-1: Structure-mirror
- Opener-arc-CTA pattern matches >2 non-winners di pool.

### LOSER-OAA-2: Trope-overused
- Pakai motif yang sudah ≥3x di pool (analogy/metaphor reuse).

### LOSER-OAA-3: Voice-template
- "Founder mode is X, not Y" pattern ketika ≥2 pool sudah pakai
- "X is just Y in formal clothes" recycle

### LOSER-OAA-4: Opener-recycle
- Opening pattern in winners ratio >20% non-winner.

### LOSER-OAA-5: CTA-mirror
- CTA pattern matches ≥2 non-winner CTAs verbatim 4-gram.

### LOSER-IA-1: Overspecified-number
- Specific number without source/reference: "in 12 hours", "24% growth"
- Especially if number not in brief or campaign material.

### LOSER-IA-2: Causal-overreach
- "X causes Y" without supporting mechanism in same content.

### LOSER-IA-3: Unsupported-capability
- "@Brand will/can/does X" where X not in campaign material.

### LOSER-IA-4: Metaphor-as-fact
- Metaphor sentence read literally = false claim.

### LOSER-IA-5: Omission of required disclaimer
- Brief requires disclosure/risk note → content omits.

### LOSER-TQ-1: Density
- Avg sentence length >22 words, OR paragraph >5 sentences.

### LOSER-TQ-2: Punctuation drag
- 3+ em-dashes, OR 3+ ellipses, OR mixed quote styles.

### LOSER-TQ-3: Raw URL in body
- http(s):// in body without native link unfurl plan.

### LOSER-TQ-4: Vocative-mention
- @mention as standalone vocative line.

### LOSER-TQ-5: Awkward mention placement
- Mention not integrated (appended at end as afterthought, OR mid-sentence interruption).

### LOSER-CA-1: Brief-paraphrase
- Content paraphrases brief tagline verbatim (4-gram match with brief).

### LOSER-CA-2: Off-scope
- Content discusses topic outside brief scope.

### LOSER-CA-3: Format violation
- "one line" brief → content multi-line
- "thread" brief → content single tweet (or vice versa)
- "max X chars" → content >X

### LOSER-CA-4: Missing required element
- Brief mentions mandatory @mention/hashtag/url → content lacks.

### LOSER-CA-5: Voice mismatch
- Brief asks "witty" → content earnest; Brief asks "personal" → content corporate.

---

## §MISSION-TYPE TEMPLATES (preview, full di data/mission-type-templates.json)

| Mission Type | Opener Template | Structure | CTA Template |
|---|---|---|---|
| EXPLAIN | "X is Y, not Z" / "Most X think Y, but actually..." | insight → mechanism → why it matters → CTA | "Which part of X surprised you?" |
| IDENTIFY | "Take ResearchHub. They..." / "Look at <named project>." | named project → why breaks → specific fix → extend | "Which project would you point to first?" |
| PERSUADE | "Verdict: X." / "I'll defend Y here." | thesis → evidence chain → counter-acknowledge → conclusion | "What evidence would change your mind?" |
| PREDICT | "By 2027, X." / "The next 6 months: Y." | prediction → reasoning → stakes → measurement | "What would you bet against this?" |
| IMAGINE | "Imagine if X..." / "What if Y replaced Z?" | premise → world-building → mechanism → user-action | "What would you build first?" |
| REVIEW | "Used X for 3 weeks. Verdict: Y." | claim → use case → pros → cons → bottom line | "What should I try next?" |
| COMPARE | "X vs Y. X wins because..." | criteria → side-by-side → winner → caveat | "Which matters more to you: A or B?" |
| HOT-TAKE | "Unpopular: X is overrated." | claim → 2-3 evidence → invite pushback | "Argue with me: where am I wrong?" |
| BUILD | "Shipped X today. Here's how it works." | what built → mechanism → result → next step | "What should I add next?" |
| MEME | format match brief tightly | minimal text + native media | optional Q for engagement |
| STORY | "Last Tuesday at 3am..." | scene → conflict → turn → lesson | "What's your version of this?" |
| META | "How I write Rally content:" | process reveal → rule → result | "Try this and tell me what broke" |

---

## §VOCAB POOL (kalibrasi vocab vonis — JANGAN share antar gate, lesson V7.7)

| Gate | MAX vocab (5/5) | EP4 vocab (4/5) | Lower vocab (≤3/5) |
|---|---|---|---|
| EP | exceptional, masterful, exemplary, deeply engaging, exceptional hook, strong CTA | strong, effective, solid, engaging, well-crafted | moderate, competent, acceptable, decent |
| OAA | distinctive, fresh angle, novel structure, unique voice, original framing | recognizable but well-done, familiar but solid | derivative, formulaic, generic, template-feeling |
| TQ | platform-native, polished, fluid rhythm, perfectly scannable | clean, readable, well-formatted | dense, awkward, choppy |
| IA | precise, bounded, accurate, well-supported | reasonable, defensible | overclaims, unsupported, vague |
| CA | precisely on-brief, comprehensive coverage | meets brief, covers main asks | partially aligned, drifts from brief |

**HUKUM:** lexicon per-gate TIDAK BOLEH di-share. Bukti regresi V7.7: OAA 192→184, TQ 246→192 saat coba normalisasi.

---

## VERSION & UPDATE

- v8.0.0 (2026-06-26): inisial consolidation dari V7.7 16 file → 1 file lexicon.
- Setiap update: append `## v8.X.Y (date)` di bawah dengan tag sumber vonis + regression result.

---

**END OF LEXICON-DATA.md V8.0**
