# RUNTIME CHECKLIST — V8.0 (Mechanical, Per-Gate)

> Dibaca tiap gate. Centang per item. JANGAN narrative spillage di sini — ini check list, bukan dokumen.

---

## GATE 0 — PREFLIGHT (≤2 min)

```
[ ] DISCLAIMER MUTLAK di-output ke user (paste dari SKILL.md §0)
[ ] Skill files check: SKILL.md, RUNTIME-CHECKLIST.md, LEXICON-DATA.md
[ ] tools/ 13 files exist
[ ] data/ 5 files exist
[ ] rally-data/learn/<addr>/ writable
[ ] konten/<slug>/ writable
[ ] Timer started (budget 14400s = 4h)
[ ] calibration-memory.json loaded
[ ] confidence-priors.json loaded
[ ] User informed: estimated total time 85 min
```

## GATE 1 — BRIEF DECODE (≤3 min)

```
[ ] Mission description di-paste verbatim (NO paraphrase)
[ ] tools/01_brief_decoder.py executed
[ ] Output JSON parsed
[ ] MISSION TYPE selected (one of 12)
[ ] CORE VERB extracted verbatim
[ ] STRUCTURE TEMPLATE chosen from mission-type-templates.json
[ ] OPENER TYPE listed
[ ] CTA TYPE listed
[ ] DANGER FLAGS = NONE (or STOP)
[ ] Output displayed to user
```

## GATE 2 — DNA FETCH (5–15 min)

```
[ ] Address valid format (0x...)
[ ] Mission flag set if multi-mission campaign
[ ] tools/02_dna_fetcher_v2.py executed
[ ] submissions_enriched.json exists, valid JSON
[ ] Coverage HIGH ≥30% (or STOP & warn)
[ ] Winner ALL-MAX count ≥1 (or switch PROJECTED mode + disclose)
[ ] dna-winner.md generated
[ ] dna-nonwinner.md generated
[ ] dna-confidence.md displayed to user
```

## GATE 3 — WINNER MECHANISM MAP (≤5 min)

```
[ ] tools/03_winner_mechanism_map.py executed
[ ] winner-mechanism.json exists
[ ] WINNER-MECHANISM.md displayed to user
[ ] TOP-3 mechanism identified with n-count
[ ] Sample quote per mechanism captured
[ ] User informed: kedua kandidat WAJIB embed ≥1 mechanism
```

## GATE 4 — DRAFT CANDIDATE A (≤15 min)

```
[ ] Mission-type structure followed
[ ] Mechanism #1 dari Gate 3 embedded (quoteable)
[ ] Specificity ≥4 concrete details
[ ] Behavioral ≥1 observable verb
[ ] CTA matches mission-type pattern
[ ] Char count within campaign limit
[ ] NO kill-phrase dari LEXICON-DATA.md §EP-KILL
[ ] Saved to drafts/A.txt
```

## GATE 5 — DRAFT CANDIDATE B (≤15 min)

```
[ ] Different opener type from A
[ ] Different mechanism from A (top-2 or top-3 dari Gate 3)
[ ] Different argument arc
[ ] Different voice register
[ ] Different CTA shape
[ ] ≥3 axis berbeda dari A
[ ] Saved to drafts/B.txt
[ ] FAST-PATH check: timer >75% → skip Gate 5, jump to Gate 6 dengan A only
```

## GATE 6 — KILL-PATTERN SCAN (≤5 min)

```
For each candidate (A then B):
[ ] tools/05_kill_pattern_scanner.py → exit 0
[ ] tools/06_loser_semantic_scan.py → exit 0
[ ] tools/07_cta_formula_check.py → exit 0
[ ] Any exit 1 → regenerate candidate, max 3 attempts
[ ] If both candidates fail 3x → STOP, back to Gate 3
```

## GATE 7 — CHAMPION DELTA SCORE (≤5 min)

```
For each candidate:
[ ] tools/04_champion_delta_score.py executed
[ ] CDS report generated
[ ] ≥4 axis di atas pool top-5 median
[ ] 0 axis di bawah pool median
[ ] Any candidate FAIL → reject, regenerate
```

## GATE 8 — JUDGE ENSEMBLE (≤10 min)

```
For each candidate:
[ ] tools/08_judge_ensemble.py --mode adversarial-hard
[ ] 5 persona × locked-JSON output
[ ] Worst-credible aggregation computed
[ ] 0 deterministic unresolved
[ ] 0 precedented unresolved
[ ] 0 plausible-recurring (≥2 persona) unresolved
[ ] Worst-credible verdict = all-MAX (or note risk per gate)
```

## GATE 9 — A/B PICK (≤1 min)

```
[ ] tools/09_ab_picker.py executed
[ ] AB-decision.json generated
[ ] Picked candidate file copied to konten/<slug>/<slug>-CONTENT.txt
[ ] User informed which picked + why (one sentence)
```

## GATE 10 — QnA + ADVERSARIAL (≤15 min)

Skip if RQ weight = 0%.

```
[ ] 20 Q-COPY/A-COPY blocks generated
[ ] QnA rules followed:
    [ ] Q-first (Q before A)
    [ ] No 2 reply mulai dengan word sama
    [ ] ≥4 voice persona
    [ ] Canonical detail block synced to final content
    [ ] No anti-AI signature phrases
    [ ] Q-A semantic match
[ ] tools/10_qna_adversarial.py → PASS
[ ] Combined file written: <slug>-CONTENT-PLUS-20QNA-RQ5.md
```

### QnA RULES DETAIL:
```
ANTI-AI SIGNATURE BAN LIST:
- great point!
- love this!
- this resonates
- 100%
- this is everything
- couldn't agree more
- spot on
- nail on the head
- this hits different
- exactly this

VOICE PERSONA TARGET (minimum 4 dari 8 berikut, distributed):
1. Skeptical-tester ("kalau aku coba X, apakah Y?")
2. Builder-curious ("bagaimana implementasinya di Z?")
3. New-to-crypto ("aku baru di sini, jadi X itu...")
4. Veteran-disagree ("aku setuju 70%, tapi Y...")
5. Concrete-asker ("kasih contoh konkret X")
6. Personal-share ("aku pernah X, dan Y")
7. Extension-thinker ("ini juga berlaku untuk Z")
8. Counter-data ("data X menunjukkan Y, gimana?")

OPENER WORD DIVERSITY:
- track first word of each reply
- if same word appears ≥2x → rewrite one
```

## GATE 11 — FINAL INTEGRITY (≤1 min)

```
[ ] tools/11_final_integrity.py executed
[ ] Combined file mengandung exact CONTENT.txt
[ ] No bad unicode chars
[ ] No stale report files
[ ] CTA verb present
[ ] QnA count ≥20 (if RQ weight >0)
[ ] Exit 0 → proceed
[ ] Exit 1 → STOP, do not output to user
```

## GATE 12 — OUTPUT + LEDGER (≤2 min)

```
[ ] Final file path: konten/<slug>/<slug>-CONTENT-PLUS-20QNA-RQ5.md
[ ] LEDGER displayed in PERSIS format SKILL.md §14
[ ] All 12 gate statuses listed
[ ] Probability estimates as RANGE (not point)
[ ] Residual risks listed
[ ] Post-mortem instruction included
[ ] Timer stopped, total elapsed reported
```

---

## FAST-PATH MODE (auto-trigger jika timer >75% = >3h)

```
[ ] Skip Gate 5 (no candidate B)
[ ] Gate 8 reduce to 3 persona (Literal, EP-Harsh, OAA-Similarity)
[ ] Gate 10 reduce to 10 QnA jika RQ weight <30%
[ ] LEDGER label: "FAST-PATH, residual risk MEDIUM"
[ ] Estimate ranges shifted -10% per gate
```

---

## EMERGENCY ABORT (auto-trigger)

```
- Any gate fails 3 retries → STOP, report to user, do NOT output partial
- Timer 100% → output BEST-AVAILABLE candidate that passed Gate 6, label "TIME-PRESSED"
- User interrupts → save state to konten/<slug>/_PARTIAL/, allow resume
```

---

**END OF RUNTIME-CHECKLIST.md V8.0**
