---
name: rally-content-engine
version: V8.0.0
codename: "Deterministic-Champion"
locked: true
lock-date: 2026-06-26
supersedes: V7.7
description: |
  Rally Content Engine V8.0 — deterministic 12-gate pipeline. Goal: maximize the
  mathematical probability of all-MAX scoring via mission-scoped DNA, mechanism
  mining, dual-candidate A/B, hard-mechanical kill-pattern scanner, quantified
  Champion Delta Score, adversarial dual-judge ensemble, and full calibration
  loop from real verdicts. NEVER claims guarantee — claims rigor.
triggers:
  - /rally
  - /rally <address>
  - /rally info | list | subs | help
  - buat konten rally | rally content | konten rally
  - rally.fun | rally campaign | rally submission
default_skill_for: ["rally", "rally.fun", "Rally on-chain campaign"]
---

# RALLY CONTENT ENGINE V8.0 — SKILL UTAMA (Single Source of Truth)

> **JANGAN TAMBAH FILE BARU DI /skills/ TANPA PERSETUJUAN USER.**
> V7.7 gagal karena 16 file MD + 17 PY. V8.0 sengaja ramping: 3 file aktif + 13 tool.

---

## 0. PERNYATAAN JUJUR (WAJIB DI-OUTPUT KE USER SETIAP RUN)

```
⚠️ RALLY V8.0 — DISCLAIMER MUTLAK
- Juri Rally adalah LLM-based judge → STOKASTIK, BUKAN deterministik.
- Base-rate all-MAX di pool real = 1–3% (data calibration nyata).
- V8.0 MEMAKSIMALKAN probabilitas all-MAX. V8.0 TIDAK MENJAMIN.
- Setiap klaim "PASS" di tool = pre-submit prediction, BUKAN actual verdict.
- Floor V8.0: EP≥4 (jika 12 gate semua PASS). Ceiling: P(all-MAX) ≥35–50% per run.
```

Setiap run WAJIB output disclaimer ini sebelum gate 0. Tidak boleh diskip.

---

## 1. ARSITEKTUR (PETA AKTIF)

```
skills/
├── SKILL.md                    ← FILE INI (single source of truth)
├── RUNTIME-CHECKLIST.md        ← per-step mekanis, dibaca tiap gate
├── LEXICON-DATA.md             ← data terpisah (kill/win phrases, vocab)
├── tools/
│   ├── 01_brief_decoder.py
│   ├── 02_dna_fetcher_v2.py
│   ├── 03_winner_mechanism_map.py
│   ├── 04_champion_delta_score.py
│   ├── 05_kill_pattern_scanner.py    ← scan KONTEN, bukan vonis
│   ├── 06_loser_semantic_scan.py
│   ├── 07_cta_formula_check.py
│   ├── 08_judge_ensemble.py          ← adversarial 5-persona hard mode
│   ├── 09_ab_picker.py
│   ├── 10_qna_adversarial.py
│   ├── 11_final_integrity.py
│   ├── 12_postmortem_ingest.py       ← real verdict → calibration loop
│   └── 13_timer.py
├── data/
│   ├── lexicon-ep-kill.json
│   ├── lexicon-win-mechanism.json
│   ├── mission-type-templates.json
│   ├── confidence-priors.json
│   └── calibration-memory.json
└── archive/v7.7-frozen/        ← rollback emergency only
```

---

## 2. PIPELINE 12-GATE (URUT, TIDAK BISA DI-SKIP)

```
GATE 0  PREFLIGHT                   2 min
GATE 1  BRIEF DECODE                3 min   tools/01_brief_decoder.py
GATE 2  DNA FETCH MULTI-SOURCE    5–15 min  tools/02_dna_fetcher_v2.py
GATE 3  WINNER MECHANISM MAP        5 min   tools/03_winner_mechanism_map.py
GATE 4  DRAFT CANDIDATE A          15 min   (mission-default structure)
GATE 5  DRAFT CANDIDATE B          15 min   (contrarian / risk-rewarded)
GATE 6  KILL-PATTERN SCAN (kedua)   5 min   tools/05 + 06 + 07
GATE 7  CHAMPION DELTA SCORE        5 min   tools/04_champion_delta_score.py
GATE 8  JUDGE ENSEMBLE (5×2=10)    10 min   tools/08_judge_ensemble.py
GATE 9  A/B PICK                    1 min   tools/09_ab_picker.py
GATE 10 QNA + ADVERSARIAL          15 min   tools/10_qna_adversarial.py
GATE 11 FINAL INTEGRITY             1 min   tools/11_final_integrity.py
GATE 12 OUTPUT + LEDGER             2 min
                                  ─────────
                                   ~85 min normal · hard-cap 4 jam
```

**HARD STOPS:**
- Any gate `exit 1` → STOP, fix, rerun. Tidak boleh lanjut.
- Timer >75% budget → switch ke FAST-PATH (skip Gate 5 candidate B, gunakan A).
- Timer 100% → output WHATEVER lolos Gate 6 + label "TIME-PRESSED, residual risk HIGH".

---

## 3. GATE 0 — PREFLIGHT (deterministik, no narrative)

WAJIB output ke user PERSIS format ini sebelum tool call apapun:

```
═══ RALLY V8.0 PREFLIGHT ═══
[DISCLAIMER MUTLAK paste dari §0]

CHECKS:
[✓/✗] skills/SKILL.md exists
[✓/✗] skills/RUNTIME-CHECKLIST.md exists
[✓/✗] skills/LEXICON-DATA.md exists
[✓/✗] skills/tools/ all 13 files exist
[✓/✗] skills/data/ all 5 files exist
[✓/✗] /rally-data/learn/<addr>/ writable
[✓/✗] /konten/<campaign-slug>/ writable
[✓/✗] timer started: tools/13_timer.py start --budget 14400  (4 hr)

MEMORY LOADED:
  - LEXICON-DATA.md (active rules)
  - RUNTIME-CHECKLIST.md (mechanical steps)
  - data/calibration-memory.json (last N=X campaigns)
  - data/confidence-priors.json (per-gate hit rates)

NO ASSUMPTIONS FROM PRIOR RUN — pool-mode-defense BANNED (#0O carry-over from V7.7).
SELF-JUDGE MODE: adversarial-hard, locked-JSON output (no narrative spillage).

PROCEEDING TO GATE 1.
═════════════════════════════
```

Jika satupun ✗ → STOP, laporkan, JANGAN auto-recover diam-diam.

---

## 4. GATE 1 — BRIEF DECODE (tool-backed)

```bash
python3 skills/tools/01_brief_decoder.py \
  --brief "<paste mission description verbatim>" \
  --out skills/data/_run/brief-decoded.json
```

Output yang skill WAJIB tampilkan:
```
MISSION TYPE: <one of 12: EXPLAIN/IDENTIFY/PERSUADE/PREDICT/IMAGINE/REVIEW/COMPARE/HOT-TAKE/BUILD/MEME/STORY/META>
CORE VERB: <verbatim from brief>
STRUCTURE TEMPLATE: <from data/mission-type-templates.json>
OPENER TYPE: <suggested>
CTA TYPE: <suggested>
DANGER FLAGS: [list or NONE]
```

**STOP triggers:**
- danger-flag = "AMBIGUOUS_VERB" → minta user klarifikasi
- danger-flag = "MULTI_INTENT" → user pilih satu intent
- danger-flag = "FORMAT_CONFLICT" → user resolve format requirement

---

## 5. GATE 2 — DNA FETCH (mission-scoped, multi-source, confidence-tagged)

```bash
python3 skills/tools/02_dna_fetcher_v2.py \
  --address <addr> --mission <missionId> \
  --out rally-data/learn/<addr-mission>/
```

Output file:
- `submissions_enriched.json` (semua submission + confidence tag per row)
- `dna-winner.md` (HIGH confidence only)
- `dna-nonwinner.md` (HIGH+MEDIUM)
- `dna-confidence.md` (laporan coverage)

**STOP triggers:**
- Coverage HIGH <30% dari submission → STOP, peringatkan user data tipis
- Winner ALL-MAX count =0 → switch ke "PROJECTED MODE", disclose ke user

**HUKUM MUTLAK:** untuk campaign multi-mission, flag `--mission` WAJIB. Mix DNA antar-mission = invalid.

---

## 6. GATE 3 — WINNER MECHANISM MAP (bukan cuma surface)

```bash
python3 skills/tools/03_winner_mechanism_map.py \
  --submissions rally-data/learn/<addr-mission>/submissions_enriched.json \
  --out rally-data/learn/<addr-mission>/winner-mechanism.json \
  --out-md rally-data/learn/<addr-mission>/WINNER-MECHANISM.md
```

Tool ekstrak per winner ALL-MAX:
- **SURFACE**: opener type, CTA form, mention placement, paragraph rhythm
- **MECHANISM** (kontribusi unik V8.0):
  - `NAMED_CONCEPT` — winner menamai konsep baru (mis. "queue position", "judgment laundering")
  - `CONTRARIAN_VERDICT` — winner berdiri lawan konsensus
  - `MECHANISM_REVEAL` — winner buka cara kerja sesuatu yang biasanya tersembunyi
  - `RESOURCE_ROUTING` — winner kasih kerangka cara alokasi (waktu/uang/perhatian)
  - `VULNERABLE_SCENE` — winner cerita scene konkret dengan stake personal
  - `DATA_FRAME` — winner pakai angka/data sebagai tulang argumen
  - `CATEGORY_CREATION` — winner ciptakan kategori baru ("X is Y, not Z")

Output WAJIB di-quote di awal Gate 4 & 5:
```
TOP-3 MECHANISM DI MISSION INI:
1. NAMED_CONCEPT (n=8/12 winner) — examples: ...
2. CONTRARIAN_VERDICT (n=6/12) — examples: ...
3. RESOURCE_ROUTING (n=3/12) — examples: ...

KEDUA KANDIDAT WAJIB EMBED ≥1 MECHANISM DARI TOP-3 INI.
```

---

## 7. GATE 4 & 5 — DRAFT CANDIDATE A + B

### Aturan generation (berlaku untuk A & B):
1. Embed ≥1 mechanism dari Gate 3 (verifiable: harus bisa di-quote).
2. Specificity: ≥4 concrete details (name/number/place/tool/action).
3. Behavioral: ≥1 observable verb.
4. CTA: lihat data/mission-type-templates.json untuk pattern per mission-type.
5. NO kill-phrase dari LEXICON-DATA.md §EP-KILL.
6. NO loser semantic pattern dari LEXICON-DATA.md §LOSER-SEMANTIC.

### Beda A vs B (WAJIB beda di ≥3 dari 5 axis):
| Axis | Candidate A | Candidate B |
|---|---|---|
| Opener | mission-type default | risk-rewarded (contrarian / scene-cold-open) |
| Mechanism | top-1 mechanism dari Gate 3 | top-2 atau top-3 mechanism |
| Argument arc | safe (problem→solution→CTA) | contrarian (verdict→evidence→stake) |
| Voice register | authoritative-analytical | personal-vulnerable atau provocative |
| CTA shape | multiple-choice / this-or-that | resource-routing / personal-experience |

**Self-check sebelum lanjut ke Gate 6:**
```
□ Candidate A char count: ____ / within campaign limit
□ Candidate B char count: ____ / within campaign limit
□ A vs B berbeda di ≥3 axis: yes/no
□ Keduanya embed mechanism dari Gate 3: yes/no
```

---

## 8. GATE 6 — HARD MECHANICAL KILL-PATTERN SCAN

WAJIB untuk **kedua** kandidat, urut:

```bash
# A
python3 skills/tools/05_kill_pattern_scanner.py --content drafts/A.txt --out reports/A-kill.json
python3 skills/tools/06_loser_semantic_scan.py --content drafts/A.txt \
   --submissions rally-data/learn/<...>/submissions_enriched.json --out reports/A-loser.json
python3 skills/tools/07_cta_formula_check.py --content drafts/A.txt --out reports/A-cta.json

# B
python3 skills/tools/05_kill_pattern_scanner.py --content drafts/B.txt --out reports/B-kill.json
python3 skills/tools/06_loser_semantic_scan.py --content drafts/B.txt \
   --submissions rally-data/learn/<...>/submissions_enriched.json --out reports/B-loser.json
python3 skills/tools/07_cta_formula_check.py --content drafts/B.txt --out reports/B-cta.json
```

**HARD RULES:**
- Setiap tool exit 1 → kandidat tersebut REJECT, regenerate.
- Kalau kedua kandidat reject 3x berturut → STOP, kembali ke Gate 3 (mechanism salah).
- Setelah max 3 regenerate per kandidat tanpa PASS → angle salah, kembali ke Gate 1.

---

## 9. GATE 7 — CHAMPION DELTA SCORE (CDS) — QUANTITATIVE

```bash
python3 skills/tools/04_champion_delta_score.py \
  --content drafts/A.txt \
  --pool rally-data/learn/<...>/submissions_enriched.json \
  --out reports/A-cds.json

# (sama untuk B)
```

5 axis CDS (skala 0–100, percentile vs pool):
1. **Insight Density** (unique concept-noun per 100 char vs pool median)
2. **Specificity** (concrete-detail count vs pool top-5 median)
3. **Conversation Affordance** (reply path clarity 0–5)
4. **Hook Stop-Score** (top-3 word strength vs pool median)
5. **CTA Quality** (formula score 0–5)

**PASS THRESHOLD:**
- ≥4 axis di atas pool top-5 median (percentile ≥80)
- 0 axis di bawah pool median (percentile <50)

Kandidat yang tidak PASS CDS → REJECT, kembali ke Gate 4/5.

---

## 10. GATE 8 — ADVERSARIAL JUDGE ENSEMBLE (5 persona, hard-mode)

```bash
python3 skills/tools/08_judge_ensemble.py \
  --content drafts/A.txt --brief brief.txt \
  --pool rally-data/learn/<...>/submissions_enriched.json \
  --winner-mechanism rally-data/learn/<...>/winner-mechanism.json \
  --out reports/A-ensemble.json --mode adversarial-hard
```

**Adversarial-hard mode rules** (penting untuk single-model situation):
1. Tiap persona judge WAJIB tulis ≥3 kritik sebelum boleh tulis ≥1 pujian.
2. Output dikunci JSON schema:
   ```json
   {"persona": "...", "scores": {"EP":0-5,"OAA":0-5,"TQ":0-5,"IA":0-5,"CA":0-5,"CC":0-2},
    "criticisms": [{"gate":"EP","severity":"deterministic|precedented|plausible|style|hallucinated","quote":"..."}],
    "verdict_class": "<all-max|near-max|safe-mid|drop-risk>"}
   ```
3. **Worst-credible aggregation**: prediksi final = MIN per gate dari 5 persona (kecuali kritik diklasifikasi `hallucinated`/`style` tanpa preseden).
4. Recurrence rule: kritik yang muncul di ≥2 persona = real weakness, mandatory fix.

**PASS THRESHOLD:**
- Worst-credible verdict = all-MAX
- 0 deterministic unresolved
- 0 precedented unresolved
- 0 plausible-recurring (≥2 persona) unresolved

---

## 11. GATE 9 — A/B PICK

```bash
python3 skills/tools/09_ab_picker.py \
  --a-cds reports/A-cds.json --a-ensemble reports/A-ensemble.json \
  --b-cds reports/B-cds.json --b-ensemble reports/B-ensemble.json \
  --out reports/AB-decision.json
```

Decision matrix (urut prioritas):
1. Worst-credible verdict tertinggi (sum 5 gate weighted)
2. Jika tied → CDS sum tertinggi
3. Jika tied → kandidat dengan 0 residual risk di gate ber-weight tertinggi
4. Jika masih tied → Candidate A (default)

**HARD RULE:** Jika tidak ada kandidat lolos worst-credible all-MAX → tampilkan keduanya ke user dengan disclosure transparan, biarkan user pilih atau minta rewrite.

---

## 12. GATE 10 — QnA PACK + ADVERSARIAL AI-DETECT

Skip jika RQ weight = 0.

Generate 20 Q/A blocks dengan rules dari RUNTIME-CHECKLIST.md §QnA.

```bash
python3 skills/tools/10_qna_adversarial.py \
  --combined konten/<slug>/<slug>-CONTENT-PLUS-20QNA-RQ5.md \
  --out reports/qna-adversarial.json
```

Tool cek:
- Keragaman opener (no 2 reply mulai dengan word sama)
- Lexicon overlap antar reply (cosine ≤0.4)
- Voice persona ≥4
- Anti-AI signature: "great point!", "love this!", "this resonates", "100%", "this is everything"
- Q-A semantic mismatch (jawaban ngambang)

Hard fail jika ≥3 violation total.

---

## 13. GATE 11 — FINAL INTEGRITY

```bash
python3 skills/tools/11_final_integrity.py \
  --content konten/<slug>/<slug>-CONTENT.txt \
  --combined konten/<slug>/<slug>-CONTENT-PLUS-20QNA-RQ5.md \
  --reports-dir reports/ \
  --min-qna 20 --require-cta-verb
```

Tool cek:
- Combined file mengandung exact content (no drift)
- No bad unicode (— – " " ' ')
- Semua report file ada & decision=PASS
- Char count konsisten antar report
- QnA count ≥20

Exit 1 → DILARANG output ke user.

---

## 14. GATE 12 — OUTPUT + LEDGER

Output WAJIB satu file:
```
konten/<Campaign-Slug>/<Campaign-Slug>-CONTENT-PLUS-20QNA-RQ5.md
```

Plus LEDGER format wajib:
```
═══ RALLY V8.0 LEDGER — <campaign> — <date> ═══

DISCLAIMER MUTLAK paste

GATE STATUS:
  0  PREFLIGHT          PASS (t=2m)
  1  BRIEF DECODE       PASS — type=EXPLAIN, danger=NONE
  2  DNA FETCH          PASS — coverage HIGH=87%, winners=12
  3  MECHANISM MAP      PASS — top3=[NAMED_CONCEPT, CONTRARIAN, RESOURCE]
  4  DRAFT A            PASS — chars=274, mechanism=NAMED_CONCEPT
  5  DRAFT B            PASS — chars=259, mechanism=CONTRARIAN_VERDICT
  6  KILL-PATTERN A     PASS / B PASS
  7  CDS  A=4/5  B=5/5
  8  ENSEMBLE A=worst-credible all-MAX / B=worst-credible all-MAX
  9  PICKED: B (CDS lebih tinggi)
 10  QNA ADVERSARIAL    PASS — voices=4, AI-sig=0
 11  FINAL INTEGRITY    PASS
 12  OUTPUT

PROBABILITY ESTIMATES (calibrated from prior runs, RANGE not point):
  P(EP=5) :  0.65–0.80
  P(OAA=5):  0.70–0.85
  P(TQ=5) :  0.75–0.90
  P(IA=5) :  0.85–0.95
  P(CA=5) :  0.70–0.85
  P(all-MAX overall): 0.30–0.50  ← realistic, jujur

RESIDUAL RISKS:
  - <list any plausible criticism yang tidak ditolak>

POST-RUN ACTION:
  setelah Rally publish vonis, run:
  python3 skills/tools/12_postmortem_ingest.py --tweet <id> --verdict <json>
═════════════════════════════
```

---

## 15. POST-MORTEM LOOP (POST-SUBMIT)

```bash
python3 skills/tools/12_postmortem_ingest.py \
  --tweet <tweetId> --verdict reports/actual-verdict.json
```

Tool akan:
1. Diff prediksi vs aktual per gate
2. Tag per gate: HIT / OVER / UNDER
3. Append ke `data/calibration-memory.json`
4. Generate active lesson di `ADAPTIVE-RATCHET-LESSONS.md` (sub-file)
5. Setiap 5 entry baru → rebuild `data/confidence-priors.json`

Skill load `confidence-priors.json` di Gate 0 → estimasi probability di Ledger lebih akurat tiap run.

---

## 16. ANTI-SELF-DECEPTION GUARD RAILS (DARI V7.7, DIPERTAHANKAN)

DILARANG:
1. Edit `vonis.json` / report tool agar PASS.
2. Skip gate karena "campaign mirip".
3. Klaim "100% pass" / "guaranteed".
4. Output tanpa LEDGER lengkap.
5. Self-judge dengan vocab pujian sebelum kritik.

WAJIB:
1. Setiap PASS = disclose status self-validated.
2. Setiap probability = range, bukan titik.
3. Setiap miss-pattern = panen jadi lesson (post-mortem loop).

---

## 17. PRIORITY ORDER ATURAN (jika konflik)

```
1. Brief verbatim (Absolute Law dari V7.7 #0A — dipertahankan)
2. Mission-specific data (winner-mechanism, DNA)
3. SKILL.md ini
4. LEXICON-DATA.md
5. data/confidence-priors.json (calibration)
6. data/calibration-memory.json (historical)
7. archive/v7.7-frozen/* (reference saja, tidak overrides)
```

---

## 18. MIGRATION NOTES (V7.7 → V8.0)

| V7.7 file | V8.0 fate |
|---|---|
| `rally-content-engine-V7.7-SKILL.md` (5800 lines) | → `archive/v7.7-frozen/`, replaced by SKILL.md |
| STEP0-PREFLIGHT-RULES.md, MISSION-SOUL, RALLY-EXECUTION-CORE, GLOBAL-EP4-SYNCED, CTA-QUALITY-*, JUDGE-VARIANCE, LOSER-DNA, ADAPTIVE-*, EP-SEMANTIC, BLIND-JUDGE | digabung ke SKILL.md + RUNTIME-CHECKLIST.md, archive original |
| `rally-rules.py` | dipertahankan untuk vonis-scan compat, dipanggil opsional di Gate 8 secondary |
| `rally-compliance-gate.py` | dipertahankan, dipanggil di Gate 6 (mechanical) |
| `rally-dna-fetcher.py` | → `tools/02_dna_fetcher_v2.py` (extended, confidence-tagged) |
| `rally-cta-quality-check.py` | → `tools/07_cta_formula_check.py` (port) |
| `rally-loser-dna-scan.py` | → `tools/06_loser_semantic_scan.py` (semantic added) |
| `rally-final-integrity-check.py` | → `tools/11_final_integrity.py` (hardened) |
| `rally-winner-dna-map.py` | → `tools/03_winner_mechanism_map.py` (mechanism added) |
| `rally-ep-deduction-map.py` | merged into tools/05+06 |
| `rally-campaign-cartographer.py` | optional diagnostic, → archive |
| `rally-qna-engine.md` | rules merged ke RUNTIME-CHECKLIST.md §QnA |

---

**END OF SKILL.md V8.0**
