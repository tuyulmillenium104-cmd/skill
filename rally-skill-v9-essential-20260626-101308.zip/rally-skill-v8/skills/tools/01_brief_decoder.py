#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
01_brief_decoder.py — V8.0
Decode mission brief → mission-type, structure template, danger flags.
Closes V7.7 CELAH #6, #12.

Usage:
  python3 01_brief_decoder.py --brief "Explain what GenLayer is to a non-crypto..." --out brief-decoded.json
  python3 01_brief_decoder.py --brief-file brief.txt --out brief-decoded.json

Exit:
  0 = decoded, no danger
  1 = danger flag (user must resolve)
"""
import argparse, json, re, sys
from pathlib import Path

# 12 mission types with detection signals
MISSION_TYPES = {
    "EXPLAIN":  ["explain", "describe", "what is", "what's", "make it easy", "teach", "break down", "demystif"],
    "IDENTIFY": ["identify", "which projects", "which industries", "who needs", "name a", "pick a", "find"],
    "PERSUADE": ["argue", "make the case", "why is", "convince", "defend", "persuade", "make me believe"],
    "PREDICT":  ["predict", "what will happen", "by 2027", "next year", "future of", "forecast"],
    "IMAGINE":  ["imagine", "invent", "create", "what if", "design", "envision", "dream up"],
    "REVIEW":   ["review", "rate", "verdict", "your take on", "thoughts on", "tried"],
    "COMPARE":  ["vs", "versus", "compared", "which is better", "x or y", "pick between"],
    "HOT-TAKE": ["hot take", "unpopular", "controversial", "bold opinion", "spicy", "brutal", "roast", "bury"],
    "BUILD":    ["build", "ship", "demo", "show what you built", "share your project"],
    "MEME":     ["meme", "image", "visual", "shitpost", "make a meme"],
    "STORY":    ["story", "share an experience", "tell us about", "moment when", "your journey"],
    "META":     ["how you", "your process", "your workflow", "behind the scenes", "method"],
}

# brief signals → structure template
STRUCTURE_TEMPLATES = {
    "EXPLAIN":  "insight → mechanism → why it matters → CTA",
    "IDENTIFY": "named project → why breaks → specific fix → extend to category",
    "PERSUADE": "thesis → evidence chain → counter-acknowledge → conclusion → CTA",
    "PREDICT":  "prediction → reasoning → stakes → measurement window → CTA",
    "IMAGINE":  "premise → world-building → mechanism → user-action invite",
    "REVIEW":   "claim → use case → pros → cons → bottom line → CTA",
    "COMPARE":  "criteria → side-by-side → winner → caveat → CTA",
    "HOT-TAKE": "claim → 2-3 evidence → invite pushback",
    "BUILD":    "what built → mechanism → result → next step → CTA",
    "MEME":     "minimal text + native media + optional Q",
    "STORY":    "scene (time-place) → conflict → turn → lesson → CTA",
    "META":     "process reveal → rule → result → try-it CTA",
}

OPENER_SUGGESTIONS = {
    "EXPLAIN":  ['"X is Y, not Z."', '"Most people think X, but actually Y."'],
    "IDENTIFY": ['"Take <Project>. They..."', '"Look at <named project>."'],
    "PERSUADE": ['"Verdict: X."', '"I\'ll defend Y here."'],
    "PREDICT":  ['"By 2027, X."', '"The next 6 months: Y."'],
    "IMAGINE":  ['"Imagine if X..."', '"What if Y replaced Z?"'],
    "REVIEW":   ['"Used X for 3 weeks. Verdict: Y."'],
    "COMPARE":  ['"X vs Y. X wins because Z."'],
    "HOT-TAKE": ['"Unpopular: X is overrated."', '"Cooked: <target>."'],
    "BUILD":    ['"Shipped X today. Here\'s how it works."'],
    "MEME":     ['(native image + 1-line caption)'],
    "STORY":    ['"Last Tuesday at 3am..."', '"Two weeks ago I X."'],
    "META":     ['"How I write Rally content:"', '"My process for X:"'],
}

CTA_SUGGESTIONS = {
    "EXPLAIN":  '"Which part of X surprised you?" / "Where would you use this first?"',
    "IDENTIFY": '"Which project would you point to first?"',
    "PERSUADE": '"What evidence would change your mind?"',
    "PREDICT":  '"What would you bet against this?"',
    "IMAGINE":  '"What would you build first?"',
    "REVIEW":   '"What should I try next?"',
    "COMPARE":  '"Which matters more to you: A or B?"',
    "HOT-TAKE": '"Argue with me: where am I wrong?"',
    "BUILD":    '"What should I add next?"',
    "MEME":     '(optional engagement Q)',
    "STORY":    '"What\'s your version of this?"',
    "META":     '"Try this and tell me what broke."',
}

# Format/length constraints to extract
FORMAT_PATTERNS = {
    "one_line":      r"\b(one[- ]line|single line|one[- ]sentence|keep it tight|short and punchy)\b",
    "thread":        r"\b(thread|threads|multi[- ]tweet)\b",
    "max_chars":     r"\bmax(?:imum)?\s+(\d+)\s+char",
    "max_words":     r"\bmax(?:imum)?\s+(\d+)\s+word",
    "under_words":   r"\bunder\s+(\d+)\s+word",
    "require_url":   r"https?://\S+",
    "require_mention": r"(@\w+)",
    "require_hashtag": r"(#\w+)",
    "no_thread":     r"\b(no thread|single post|no multi[- ]post)\b",
}

# Danger flags
def detect_dangers(brief, scores, top_types):
    dangers = []
    # Multiple strong type candidates
    if len(top_types) >= 2 and (scores[top_types[0]] - scores[top_types[1]]) <= 1:
        dangers.append({
            "flag": "MULTI_INTENT",
            "detail": f"Brief equally matches: {top_types[0]} ({scores[top_types[0]]}) and {top_types[1]} ({scores[top_types[1]]})",
            "action": "User must clarify which is primary intent.",
        })
    # No clear type
    if scores[top_types[0]] == 0:
        dangers.append({
            "flag": "AMBIGUOUS_VERB",
            "detail": "No mission-type signal verb detected in brief.",
            "action": "User must specify mission type manually.",
        })
    # Format conflict
    if re.search(FORMAT_PATTERNS["one_line"], brief, re.I) and re.search(FORMAT_PATTERNS["thread"], brief, re.I):
        dangers.append({
            "flag": "FORMAT_CONFLICT",
            "detail": "Brief says both 'one line' AND 'thread'. Resolve before draft.",
            "action": "User clarifies format.",
        })
    # Length missing but mention required
    if re.search(FORMAT_PATTERNS["require_mention"], brief) and not (
        re.search(FORMAT_PATTERNS["max_chars"], brief, re.I) or
        re.search(FORMAT_PATTERNS["max_words"], brief, re.I)):
        dangers.append({
            "flag": "LENGTH_UNSPECIFIED",
            "detail": "Required mention but no length cap → assume X 280 default. Confirm with user.",
            "action": "Confirm default 280 chars OK.",
        })
    return dangers

def extract_format_rules(brief):
    rules = {}
    if re.search(FORMAT_PATTERNS["one_line"], brief, re.I): rules["format"] = "one_line"
    if re.search(FORMAT_PATTERNS["thread"], brief, re.I):   rules["format"] = "thread"
    if re.search(FORMAT_PATTERNS["no_thread"], brief, re.I): rules["format"] = "single_post"
    m = re.search(FORMAT_PATTERNS["max_chars"], brief, re.I)
    if m: rules["max_chars"] = int(m.group(1))
    m = re.search(FORMAT_PATTERNS["max_words"], brief, re.I)
    if m: rules["max_words"] = int(m.group(1))
    m = re.search(FORMAT_PATTERNS["under_words"], brief, re.I)
    if m: rules["under_words"] = int(m.group(1))
    mentions = re.findall(FORMAT_PATTERNS["require_mention"], brief)
    if mentions: rules["required_mentions"] = list(set(mentions))
    hashtags = re.findall(FORMAT_PATTERNS["require_hashtag"], brief)
    if hashtags: rules["required_hashtags"] = list(set(hashtags))
    urls = re.findall(FORMAT_PATTERNS["require_url"], brief)
    if urls: rules["required_urls"] = list(set(urls))
    return rules

def extract_core_verb(brief):
    """Extract first imperative verb in brief."""
    # naive: first verb-like word at start of a sentence
    sentences = re.split(r'(?<=[.!?])\s+', brief)
    for s in sentences:
        m = re.match(r'^(?:please\s+)?(\w+)', s.strip(), re.I)
        if m and m.group(1).lower() in [
            "explain", "describe", "identify", "argue", "predict", "imagine",
            "build", "ship", "review", "compare", "share", "tell", "show",
            "name", "pick", "choose", "make", "create", "write", "post",
            "bury", "defend", "roast", "rate"
        ]:
            return m.group(1).lower()
    return None

def classify(brief):
    bl = brief.lower()
    scores = {}
    for mtype, signals in MISSION_TYPES.items():
        scores[mtype] = sum(1 for s in signals if s in bl)
    sorted_types = sorted(scores.keys(), key=lambda k: -scores[k])
    return scores, sorted_types

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--brief", default=None, help="Brief text inline")
    ap.add_argument("--brief-file", default=None, help="Brief text from file")
    ap.add_argument("--out", required=True, help="Output JSON path")
    args = ap.parse_args()

    if args.brief:
        brief = args.brief
    elif args.brief_file:
        brief = Path(args.brief_file).read_text(encoding="utf-8")
    else:
        print("ERROR: --brief or --brief-file required", file=sys.stderr)
        sys.exit(2)

    brief = brief.strip()
    if len(brief) < 10:
        print("ERROR: brief too short (<10 chars)", file=sys.stderr)
        sys.exit(2)

    scores, top_types = classify(brief)
    primary = top_types[0]
    dangers = detect_dangers(brief, scores, top_types)
    format_rules = extract_format_rules(brief)
    core_verb = extract_core_verb(brief)

    result = {
        "tool": "01_brief_decoder.py",
        "version": "V8.0",
        "brief_verbatim": brief,
        "brief_chars": len(brief),
        "mission_type": primary,
        "mission_type_scores": scores,
        "alternative_types": top_types[1:3],
        "core_verb": core_verb,
        "structure_template": STRUCTURE_TEMPLATES[primary],
        "opener_suggestions": OPENER_SUGGESTIONS[primary],
        "cta_suggestion": CTA_SUGGESTIONS[primary],
        "format_rules": format_rules,
        "danger_flags": dangers,
        "decision": "PROCEED" if not dangers else "USER_RESOLVE_FIRST",
    }

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    # Human-readable print
    print("═══ BRIEF DECODE RESULT ═══")
    print(f"MISSION TYPE: {primary}  (scores: {scores})")
    print(f"CORE VERB: {core_verb or '(none detected)'}")
    print(f"STRUCTURE: {STRUCTURE_TEMPLATES[primary]}")
    print(f"OPENER SUGGESTIONS:")
    for o in OPENER_SUGGESTIONS[primary]:
        print(f"  - {o}")
    print(f"CTA SUGGESTION: {CTA_SUGGESTIONS[primary]}")
    print(f"FORMAT RULES: {format_rules}")
    if dangers:
        print(f"⚠️  DANGER FLAGS ({len(dangers)}):")
        for d in dangers:
            print(f"  - [{d['flag']}] {d['detail']}  → {d['action']}")
        print("DECISION: USER_RESOLVE_FIRST")
        sys.exit(1)
    else:
        print("DECISION: PROCEED")
        sys.exit(0)

if __name__ == "__main__":
    main()
