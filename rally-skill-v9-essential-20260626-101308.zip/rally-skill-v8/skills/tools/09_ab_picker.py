#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
09_ab_picker.py — V8.0
Pick winning candidate between A and B based on objective scoring.
Closes V7.7 CELAH #8 (no pre-submit A/B test).

Decision priority:
  1. Worst-credible verdict (sum 5 gate weighted)
  2. CDS sum tiebreaker
  3. 0 residual risk at high-weight gate
  4. Default to A
"""
import argparse, json, sys
from pathlib import Path

# Gate weights (default — override if campaign has explicit weights)
DEFAULT_WEIGHTS = {"EP": 0.30, "OAA": 0.20, "TQ": 0.15, "IA": 0.15, "CA": 0.15, "CC": 0.05}

def weighted_sum(scores, weights):
    return sum(scores.get(g, 0) * weights.get(g, 0) for g in weights)

def cds_sum(cds_report):
    return sum(v.get("content_value", 0) for v in cds_report.get("cds_per_axis", {}).values())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a-cds", required=True)
    ap.add_argument("--a-ensemble", required=True)
    ap.add_argument("--a-content", required=True)
    ap.add_argument("--b-cds", required=True)
    ap.add_argument("--b-ensemble", required=True)
    ap.add_argument("--b-content", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--final-out", required=True, help="Path to copy picked content to")
    ap.add_argument("--weights", default=None, help="JSON with gate weights")
    args = ap.parse_args()

    weights = json.load(open(args.weights)) if args.weights else DEFAULT_WEIGHTS

    a_cds = json.load(open(args.a_cds, encoding="utf-8"))
    a_ens = json.load(open(args.a_ensemble, encoding="utf-8"))
    b_cds = json.load(open(args.b_cds, encoding="utf-8"))
    b_ens = json.load(open(args.b_ensemble, encoding="utf-8"))

    a_worst = a_ens.get("worst_credible_scores", {})
    b_worst = b_ens.get("worst_credible_scores", {})

    a_wsum = weighted_sum(a_worst, weights)
    b_wsum = weighted_sum(b_worst, weights)

    a_cds_s = cds_sum(a_cds)
    b_cds_s = cds_sum(b_cds)

    # decision logic
    reasoning = []
    if a_wsum > b_wsum:
        picked = "A"; reasoning.append(f"Worst-credible weighted: A={a_wsum:.2f} > B={b_wsum:.2f}")
    elif b_wsum > a_wsum:
        picked = "B"; reasoning.append(f"Worst-credible weighted: B={b_wsum:.2f} > A={a_wsum:.2f}")
    else:
        reasoning.append(f"Worst-credible tied at {a_wsum:.2f}")
        if a_cds_s > b_cds_s:
            picked = "A"; reasoning.append(f"CDS sum A={a_cds_s:.2f} > B={b_cds_s:.2f}")
        elif b_cds_s > a_cds_s:
            picked = "B"; reasoning.append(f"CDS sum B={b_cds_s:.2f} > A={a_cds_s:.2f}")
        else:
            reasoning.append(f"CDS sum tied at {a_cds_s:.2f}")
            # residual at high-weight gate
            a_high = min(a_worst.get(g, 0) for g in ["EP","OAA"] if g in a_worst)
            b_high = min(b_worst.get(g, 0) for g in ["EP","OAA"] if g in b_worst)
            if a_high > b_high:
                picked = "A"; reasoning.append(f"High-weight floor A={a_high} > B={b_high}")
            elif b_high > a_high:
                picked = "B"; reasoning.append(f"High-weight floor B={b_high} > A={a_high}")
            else:
                picked = "A"; reasoning.append("Full tie → default A")

    # check if EITHER passed worst-credible all-MAX
    a_all_max = all(a_worst.get(g, 0) == (5 if g != "CC" else 2) for g in ["EP","OAA","TQ","IA","CA","CC"])
    b_all_max = all(b_worst.get(g, 0) == (5 if g != "CC" else 2) for g in ["EP","OAA","TQ","IA","CA","CC"])

    if not a_all_max and not b_all_max:
        warning = "WARNING: Neither candidate achieved worst-credible ALL-MAX. Consider rebuild from Gate 3 or 4."
    else:
        warning = None

    # Copy winning content
    src = args.a_content if picked == "A" else args.b_content
    src_text = Path(src).read_text(encoding="utf-8")
    Path(args.final_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.final_out).write_text(src_text, encoding="utf-8")

    result = {
        "tool": "09_ab_picker.py",
        "version": "V8.0",
        "weights": weights,
        "candidate_A": {"weighted_sum": a_wsum, "cds_sum": a_cds_s, "worst": a_worst, "all_max": a_all_max},
        "candidate_B": {"weighted_sum": b_wsum, "cds_sum": b_cds_s, "worst": b_worst, "all_max": b_all_max},
        "picked": picked,
        "reasoning": reasoning,
        "warning": warning,
        "final_path": args.final_out,
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"A/B PICK: {picked}")
    for r in reasoning: print(f"  · {r}")
    if warning: print(f"  ⚠️  {warning}")
    print(f"  → Final content written to {args.final_out}")
    sys.exit(0)

if __name__ == "__main__":
    main()
