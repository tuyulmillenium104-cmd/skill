#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
24_auto_rewriter.py — V8.5 AUTO-REWRITE GUIDED FIX
Takes a draft that REVISE-d, applies surgical fixes based on V8.4 sub-rubric failures,
outputs a rewrite plan + before/after structural guidance.

This is NOT an LLM call — it generates STRUCTURED INSTRUCTIONS that user can paste 
into any LLM (or follow manually) to rewrite the draft.

Usage:
  python3 24_auto_rewriter.py --content draft.txt --brief brief.txt --out rewrite_plan.md
"""
import argparse, json, re, sys, importlib.util
from pathlib import Path

# Load V8.4 + V8.5
spec84 = importlib.util.spec_from_file_location("v84", str(Path(__file__).parent / "21_judge_replica_v84.py"))
v84 = importlib.util.module_from_spec(spec84); spec84.loader.exec_module(v84)
spec85 = importlib.util.spec_from_file_location("v85", str(Path(__file__).parent / "23_judge_replica_v85.py"))
v85 = importlib.util.module_from_spec(spec85); spec85.loader.exec_module(v85)

# Specific fix templates per sub-rubric failure
SUBRUBRIC_FIXES = {
    ("Engagement Potential", "Hook Effectiveness", "slow opener"): {
        "diagnosis": "Opening word is 'So/Well/Honestly/Just thinking' = EP4 ceiling",
        "fix_template": "Replace first sentence with a declarative pattern:\n  - 'X is Y, not Z.'\n  - 'Most people think X. Actually Y.'\n  - 'Verdict: X.'\n  - 'My [thing] [did Y] for [time] because [reason].'\n  - 'The [thing] broke the moment [event].'",
        "examples_from_winners": [
            "Smart contracts can verify that something happened.",
            "Oracles broke the moment reality got subjective.",
            "Most people think the hardest part of a contract is enforcing it.",
            "My team once lost a game because the referee missed an offside call.",
        ],
    },
    ("Engagement Potential", "Hook Effectiveness", "first sentence"): {
        "diagnosis": "First sentence wrong length (too short <5 or too long >28 words)",
        "fix_template": "Target 9-18 words. Use declarative + strong concrete signal.",
        "examples_from_winners": [
            "(12w) Most people think the hardest part of a contract is enforcing it.",
            "(13w) The most expensive words in contracts are often the least precise.",
        ],
    },
    ("Engagement Potential", "Content Structure", "paragraphs"): {
        "diagnosis": "Paragraph count outside winner band 5-13",
        "fix_template": "Restructure to 6-13 stanza paragraphs.\nEach paragraph should be 1-3 sentences.\nUse double-newline between paragraphs.\nWinner pattern: short opener para → 2-3 body paras → CTA para",
    },
    ("Engagement Potential", "Conversation Potential", "no engagement trigger"): {
        "diagnosis": "Last 2 paragraphs lack ?, imperative verb, or URL",
        "fix_template": "Add ONE of these to last paragraph:\n  (A) Specific question: 'What's the X you Y?' / 'Which Z do you think W?'\n  (B) Imperative + specific: 'Name one X.' / 'Tell me your version.'\n  (C) URL + question: 'Visit app.rally.fun. What would you build?'",
    },
    ("Engagement Potential", "Conversation Potential", "generic CTA"): {
        "diagnosis": "Generic CTA detected ('thoughts?', 'agree?', 'drop yours')",
        "fix_template": "Replace with SPECIFIC personal-experience question:\n  - 'What's the [smallest/biggest/first/worst] [X] you [past_verb]?'\n  - 'Which [category] do you think [predict_verb]?'\n  - 'Tell me [the time] you [action].'",
        "examples_from_winners": [
            "What's the moment that changed how you read liquidity?",
            "Which industry do you think will be forced to adopt this first?",
            "What kind of agreement would be hardest for AI to enforce?",
        ],
    },
    ("Engagement Potential", "Value Delivery", "value signals"): {
        "diagnosis": "Lacks 2+ value signals from: named-concept, mechanism-reveal, scene-opener, contrarian+number, quoted-phrase",
        "fix_template": "Add ≥2 of these:\n  - NAMED CONCEPT: 'X is Y, not Z' (e.g., 'Founder mode is judgment laundering')\n  - MECHANISM REVEAL: 'The way X actually works: [specific process]'\n  - SCENE OPENER: 'Last Tuesday I [specific action]'\n  - CONTRARIAN+NUMBER: 'Most think X, but 73% of cases Y'\n  - QUOTED PHRASE: '\"X\" is the new Y'\n  - DEFINITIONAL: 'X is not always Y'\n  - Q-A RHYTHM: 'Did X happen? Did X count? Different questions.'",
    },
    ("Engagement Potential", "Call-to-Action Quality", "CTA missing"): {
        "diagnosis": "No question OR imperative in last 2 paragraphs (judge will write 'lacks CTA')",
        "fix_template": "Add explicit CTA. Must be SPECIFIC (not 'thoughts?'). Choose:\n  TYPE A — Direct imperative: 'Tell me your X' / 'Name one Y' / 'Drop a Z'\n  TYPE B — Specific personal Q: 'What's the X you Y?'\n  TYPE C — Choice Q: 'Would you rather X or Y?'",
    },
    ("Originality and Authenticity", "Language Authenticity", "hype phrases"): {
        "diagnosis": "Hype phrases detected (game changer, this is huge, to the moon, etc.)",
        "fix_template": "Remove ALL hype phrases. Replace with SPECIFIC mechanism explanations.\n  ❌ 'This is huge for crypto'\n  ✓ 'This changes the role of validators: from execute-rules to judge-context.'",
    },
    ("Originality and Authenticity", "Unique Perspective", "no unique angle"): {
        "diagnosis": "Lacks contrarian framing, named concept, or scene opener",
        "fix_template": "Add ONE of:\n  - Contrarian frame: 'Most think X. Actually Y.'\n  - Named concept: invent a 2-3 word label\n  - Scene from your experience: 'Last [time] I [specific action]'",
    },
    ("Information Accuracy", "Technical Accuracy", "unsupported earning"): {
        "diagnosis": "Earning/profit/guarantee claim — AUTO-FAIL IA",
        "fix_template": "REMOVE these phrases completely:\n  ❌ 'guaranteed', '100x', 'passive income', 'will make you', 'get rich', 'financial freedom'\n  ✓ Replace with bounded language: 'projected to', 'designed to', 'aims to', 'returns vary'",
    },
    ("Technical Quality", "Platform Optimization", "too long"): {
        "diagnosis": "Content >1700 chars — judge will say 'may reduce digestibility'",
        "fix_template": "Trim to 900-1500 char range. Cut:\n  - Redundant restatements\n  - Filler transitions ('It's worth noting', 'Furthermore')\n  - Long sentences (split into 2)",
    },
    ("Campaign Compliance", "Required Mention", "missing"): {
        "diagnosis": "Required @mention from brief is missing",
        "fix_template": "Add mention naturally MID-CONTENT (not appended at end as vocative).\n  ❌ '. @RallyOnChain' as standalone line\n  ✓ 'That's why @RallyOnChain matters for...' (integrated)",
    },
}

def find_fix(category, sub_rubric, reason):
    """Match reason to specific fix template."""
    reason_l = reason.lower()
    for (cat, sub, key), fix in SUBRUBRIC_FIXES.items():
        if cat == category and sub == sub_rubric and key in reason_l:
            return fix
    # Fallback: category-level generic
    return {
        "diagnosis": f"{category} / {sub_rubric}: {reason}",
        "fix_template": "Review the V8.4 reason above and apply targeted fix.",
        "examples_from_winners": [],
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--brief", default=None)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    text = Path(args.content).read_text(encoding="utf-8").strip()
    brief = Path(args.brief).read_text(encoding="utf-8") if args.brief and Path(args.brief).exists() else ""

    # Run V8.4 diagnosis
    scores, detail, features = v84.predict_scores(text, brief)
    missing = v84.diagnose(scores, detail)
    targets = v84.CATEGORY_MAX
    all_max_84 = all(scores[c] >= targets[c] for c in scores)

    # Run V8.5 score
    r85 = v85.predict(text, brief)

    # Build rewrite plan
    md = ["# RALLY AUTO-REWRITE PLAN\n",
          f"**Content:** {args.content} ({len(text)} chars)\n",
          f"**Brief:** {args.brief or 'none'}\n",
          f"**V8.4 sub-rubric decision:** {'PASS ALL' if all_max_84 else 'REVISE'}\n",
          f"**V8.5 weighted score:** {r85['weighted_score']:.2f} (threshold {r85['threshold']})\n",
          f"**Final decision:** {'SUBMIT (97% confidence)' if all_max_84 and r85['weighted_score']>=4.5 else 'REVISE'}\n\n"]
    
    if all_max_84 and r85['weighted_score'] >= 5.0:
        md.append("## ✅ NO FIXES NEEDED\n\nDraft predicted ALL-MAX with high confidence. Submit.\n\n")
    else:
        md.append("## 🔧 FIX LIST (prioritized by impact)\n\n")
        if not all_max_84:
            md.append("### Sub-rubric failures (must fix):\n\n")
            for i, m in enumerate(missing, 1):
                fix_info = find_fix(m['category'], m['sub_rubric'], m['reason'])
                md.append(f"#### Fix #{i}: [{m['category']}] {m['sub_rubric']}\n\n")
                md.append(f"**Current issue:** {m['reason']}\n\n")
                md.append(f"**Diagnosis:** {fix_info['diagnosis']}\n\n")
                md.append(f"**Fix template:**\n```\n{fix_info['fix_template']}\n```\n\n")
                if fix_info.get('examples_from_winners'):
                    md.append("**Examples from actual ALL-MAX winners:**\n")
                    for ex in fix_info['examples_from_winners']:
                        md.append(f"- `{ex}`\n")
                    md.append("\n")
        
        # Structural targets
        md.append("### Structural target adjustments:\n\n")
        md.append(f"- **Chars:** {features['chars']} → target **900-1500** (winner median 1220)\n")
        md.append(f"- **Paragraphs:** {features['paras']} → target **6-13** (winner median 9)\n")
        md.append(f"- **Sentences:** {features['sents']} → target **12-22** (winner median 17)\n")
        md.append(f"- **Avg sentence words:** {features['avg_sent_words']:.1f} → target **9-15** (winner median 12)\n")
        md.append(f"- **First sentence words:** {features['first_sent_words']} → target **9-18** (winner median 12)\n\n")

    # Add rewrite-with-LLM prompt
    md.append("---\n\n## 🤖 LLM PROMPT FOR REWRITE\n\n")
    md.append("Copy this into ChatGPT/Claude with your draft:\n\n")
    md.append("```\n")
    md.append("You are rewriting a Rally.fun campaign tweet for ALL-MAX score.\n\n")
    md.append("ORIGINAL DRAFT:\n")
    md.append(f"\"\"\"\n{text[:1500]}\n\"\"\"\n\n")
    if brief:
        md.append("CAMPAIGN BRIEF:\n")
        md.append(f"\"\"\"\n{brief[:800]}\n\"\"\"\n\n")
    md.append("EMPIRICAL WINNER PROFILE (must match):\n")
    md.append("- Length: 900-1500 characters\n")
    md.append("- Paragraphs: 6-13 (stanza style, double-newline separated)\n")
    md.append("- First sentence: 9-18 words, declarative, strong opener (NO 'So/Well/Honestly')\n")
    md.append("- Body: include ≥2 of: named-concept, mechanism-reveal, scene-opener, contrarian-frame, quoted-phrase, definitional-contrast\n")
    md.append("- CTA in last paragraph: explicit question OR imperative, MUST be specific (NOT 'thoughts?', 'agree?')\n")
    md.append("- Use @RallyOnChain naturally mid-content if required\n")
    md.append("- NO hype phrases (game changer, this is huge, to the moon)\n")
    md.append("- NO unsupported earning claims (guaranteed, 100x, passive income)\n")
    md.append("- NO AI-template phrases (delve into, let's unpack, in conclusion)\n\n")
    md.append("APPLY THESE FIXES:\n")
    for i, m in enumerate(missing, 1):
        md.append(f"{i}. [{m['category']} / {m['sub_rubric']}] {m['reason']}\n")
    md.append("\nOutput ONLY the rewritten tweet, nothing else.\n")
    md.append("```\n")

    Path(args.out).write_text("".join(md), encoding="utf-8")
    print(f"Rewrite plan saved: {args.out}")
    print(f"\nDecision: {'SUBMIT' if (all_max_84 and r85['weighted_score']>=5.0) else 'REVISE'}")
    print(f"V8.4 sub-rubric pass: {all_max_84}")
    print(f"V8.5 weighted: {r85['weighted_score']:.2f}")
    print(f"Missing sub-rubrics: {len(missing)}")
    sys.exit(0 if (all_max_84 and r85['weighted_score']>=5.0) else 1)

if __name__ == "__main__":
    main()
