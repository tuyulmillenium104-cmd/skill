#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
19_content_generator.py — V8.3
Content generator template that produces drafts matching ALL-MAX winner empirical profile.

This is NOT an LLM. This is a STRUCTURED TEMPLATE GENERATOR that:
  1. Takes brief + topic + 5-6 key facts
  2. Produces a draft matching winner statistical fingerprint:
     - 900-1500 chars
     - 6-13 stanza paragraphs  
     - 9-18 word first sentence with strong opener
     - Embedded value mechanism (named concept / contrarian / scene)
     - CTA: explicit imperative or specific personal question in last 2 paragraphs
     - Mention placement: natural, mid-content not appended
  3. Self-validates via 17_judge_replica.py
  4. If REVISE → suggests targeted refinements

Usage:
  python3 19_content_generator.py --brief brief.txt --topic "topic" \
    --facts "fact1" "fact2" "fact3" --mention "@RallyOnChain" --out drafts/

Output:
  drafts/template_<n>.txt    — generated drafts
  drafts/predictions/        — replica predictions for each
"""
import argparse, json, re, sys, importlib.util
from pathlib import Path

# Import replica
def load_replica():
    spec = importlib.util.spec_from_file_location("replica", str(Path(__file__).parent / "17_judge_replica.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m

# ============================================================
# TEMPLATE PATTERNS (empirical from 318 winners)
# ============================================================

OPENER_TEMPLATES = {
    "scene_pain": [
        "{thing} died in {timeframe}.",
        "For {timeframe} I {action} {thing}.",
        "Last {time_unit} I {action} {scene}.",
        "My {thing} {verb} for {timeframe} because {reason}.",
    ],
    "contrarian_verdict": [
        "{topic} is not {wrong_assumption}. It is {real_thing}.",
        "Most people think {assumption}. {topic} is actually {real}.",
        "{thing} broke the moment {event}.",
        "Everyone {action}. {real_thing} is {what}.",
    ],
    "definitional_contrast": [
        "{thing_a} can {action_a}. {thing_a} struggles to {action_b}.",
        "{thing_a} and {thing_b} are not always {same_thing}.",
        "{thing} is no longer about {old}. It is about {new}.",
    ],
    "qa_rhythm": [
        "{question_1}?",
        "{question_2}?",
        "{topic} answers a different question.",
    ],
    "named_concept": [
        "{Concept_Name}: when {when_clause}.",
        "I call this {concept}. It happens when {when_clause}.",
    ],
}

VALUE_BODY_TEMPLATES = {
    "mechanism_reveal": [
        "The way {thing} actually works:\n\n{mechanism_step_1}\n\n{mechanism_step_2}\n\n{mechanism_step_3}",
        "Here's what most people miss about {topic}:\n\n{insight_1}\n\n{insight_2}",
        "The hidden cost of {thing} is {cost}. Not {fake_cost}.",
    ],
    "definitional_explain": [
        "{thing_a} is great at {strength_a}. It cannot {weakness_a}.\n\nThat is where {brand} matters.\n\n{brand} {what_brand_does}.",
        "A {object} can {can_do}. It cannot {cannot_do}.\n\nNot because of {fake_reason}.\n\nBecause {real_reason}.",
    ],
    "scene_progression": [
        "{personal_scene}\n\n{what_broke}\n\n{realization}\n\n{turn}\n\n{brand} {role_in_turn}.",
    ],
}

CTA_TEMPLATES_SPECIFIC = [
    "What {specific_field} would you {action} {object}?",
    "Which {specific_category} do you think {predict_action} first?",
    "Tell me your version of {experience}.",
    "What's the {smallest|biggest|first|worst} {thing} you {past_verb}?",
    "Have you ever {experience}?",
    "Name one {category} that {breaks|works|matters}.",
    "What would you {action} if {hypothetical}?",
    "Would you rather {option_a} or {option_b}?",
    "If you had to choose: {choice_a}, {choice_b}, or {choice_c}?",
    "How do you {action} when {circumstance}?",
]

CTA_TEMPLATES_IMPERATIVE_URL = [
    "Visit {url} to {action}.\n\n{specific_question}",
    "Check {url} — {benefit}.\n\nWhat would you {action}?",
    "Go see how {brand} {does_what}: {url}.\n\n{specific_question}",
]

# ============================================================
# DRAFT BUILDER
# ============================================================

def build_draft(opener_type, value_type, cta_type, params):
    """Build a draft skeleton using templates + params (user fills in)."""
    opener = OPENER_TEMPLATES.get(opener_type, OPENER_TEMPLATES["contrarian_verdict"])[0]
    value = VALUE_BODY_TEMPLATES.get(value_type, VALUE_BODY_TEMPLATES["definitional_explain"])[0]
    cta = (CTA_TEMPLATES_SPECIFIC if cta_type=="question" else CTA_TEMPLATES_IMPERATIVE_URL)[0]
    
    template = f"""{opener}

{value}

{cta}"""
    
    # Variable substitution from params
    for k, v in params.items():
        template = template.replace("{"+k+"}", str(v))
    
    return template

# ============================================================
# AUTO-OPTIMIZE LOOP (use replica as oracle)
# ============================================================

def diagnose_and_suggest(replica_pred):
    """Given replica prediction, return list of structured suggestions for revision."""
    suggestions = []
    f = replica_pred.get('features', replica_pred.get('_features', {}))
    
    for m in replica_pred.get('missing_for_all_max', []):
        suggestions.append({
            'category': m['category'],
            'issue': m['issue'],
            'fix': m['fix'],
        })
    return suggestions

def revise_draft_suggestions(text, replica_pred):
    """Produce concrete revision suggestions text."""
    suggestions = diagnose_and_suggest(replica_pred)
    if not suggestions:
        return "No revisions needed — content predicts ALL-MAX."
    
    out = ["REVISION SUGGESTIONS:\n"]
    for s in suggestions:
        out.append(f"\n[{s['category']}] {s['issue']}")
        out.append(f"  → {s['fix']}")
    
    # Add concrete rewrite tips based on text analysis
    f = replica_pred.get('features', {})
    out.append("\n\nCONCRETE REWRITE TARGETS:")
    out.append(f"  Current: {f.get('chars', 0)} chars, {f.get('paras', 0)} paragraphs, {f.get('first_sent_words', 0)} word first sentence")
    out.append(f"  Target:  900-1500 chars, 6-13 paragraphs, 9-18 word first sentence")
    if not f.get('has_q_in_last2p_unquoted') and not f.get('has_imperative_in_last2p'):
        out.append("\n  CRITICAL: Add ? or imperative verb in LAST PARAGRAPH (winners: 80%)")
    if f.get('has_imperative_in_last2p') and not f.get('has_q_in_last2p_unquoted'):
        out.append("\n  TIP: Add a specific question alongside the imperative for max signal")
    
    return "\n".join(out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", help="Draft to evaluate & suggest revisions")
    ap.add_argument("--brief", default=None)
    ap.add_argument("--out-dir", default="drafts")
    ap.add_argument("--suggestions-out", default="revision-suggestions.md")
    ap.add_argument("--show-templates", action="store_true", help="Show empty templates as starter")
    args = ap.parse_args()
    
    Path(args.out_dir).mkdir(parents=True, exist_ok=True)
    
    if args.show_templates:
        print("═══ WINNER TEMPLATE BLUEPRINTS ═══\n")
        print("OPENER PATTERNS (pick 1):")
        for k, vs in OPENER_TEMPLATES.items():
            print(f"\n[{k}]")
            for v in vs:
                print(f"  - {v}")
        print("\n\nVALUE BODY PATTERNS (pick 1):")
        for k, vs in VALUE_BODY_TEMPLATES.items():
            print(f"\n[{k}]")
            for v in vs:
                print(f"  - {v}")
        print("\n\nCTA PATTERNS (use 1 specific question OR 1 imperative+URL+question):")
        print("\nSpecific question CTAs:")
        for c in CTA_TEMPLATES_SPECIFIC:
            print(f"  - {c}")
        print("\nImperative + URL CTAs:")
        for c in CTA_TEMPLATES_IMPERATIVE_URL:
            print(f"  - {c}")
        return
    
    if not args.content:
        print("Usage: --content draft.txt [--brief brief.txt]  OR  --show-templates")
        sys.exit(2)
    
    # Load draft, run replica, output suggestions
    replica = load_replica()
    text = Path(args.content).read_text(encoding="utf-8").strip()
    brief = Path(args.brief).read_text(encoding="utf-8") if args.brief and Path(args.brief).exists() else ""
    pred = replica.predict_scores(text, brief)
    
    # Diagnostic
    targets = {"Originality and Authenticity":2,"Content Alignment":2,"Information Accuracy":2,"Campaign Compliance":2,"Engagement Potential":5,"Technical Quality":5,"Reply Quality":5}
    all_max = all(pred[k] >= v for k,v in targets.items())
    
    print(f"\n═══ DRAFT EVALUATION ═══")
    print(f"Decision: {'SUBMIT' if all_max else 'REVISE'}")
    for k,v in pred.items():
        if k.startswith("_"): continue
        marker = "✓" if v >= targets[k] else "✗"
        print(f"  {marker} {k:35s} {v}/{targets[k]}")
    
    # Suggestions
    pred_dict_for_diag = {
        'features': pred['_features'],
        'missing_for_all_max': replica.diagnose_missing(pred, text, brief)
    }
    suggestions = revise_draft_suggestions(text, pred_dict_for_diag)
    print("\n" + suggestions)
    
    Path(args.suggestions_out).write_text(suggestions, encoding="utf-8")
    print(f"\nSuggestions saved to {args.suggestions_out}")
    sys.exit(0 if all_max else 1)

if __name__ == "__main__":
    main()
