#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
10_qna_adversarial.py — V8.0
Adversarial AI-detection scan for QnA replies. Closes V7.7 CELAH #13.

Checks:
  - Opener word diversity (no 2 reply mulai dengan word sama)
  - Lexicon overlap between replies (cosine ≤0.4 between any 2 replies)
  - Voice persona variety (≥4 distinct voice patterns)
  - Anti-AI signature ban
  - Q-A semantic mismatch
"""
import argparse, json, re, sys
from collections import Counter
from pathlib import Path

ANTI_AI_PHRASES = [
    "great point", "love this", "this resonates", "100%",
    "this is everything", "couldn't agree more", "spot on",
    "nail on the head", "this hits different", "exactly this",
    "absolutely this", "facts", "preach", "thread saved",
    "this deserves more likes",
]

VOICE_MARKERS = {
    "skeptical_tester":  [r"\bif i (try|test|use)\b", r"\bwhat happens when\b", r"\bdoes (it|this) actually\b"],
    "builder_curious":   [r"\bhow (do|did) you (build|implement|ship)\b", r"\b(in production|under the hood)\b"],
    "new_to_crypto":     [r"\bi[\'’]?m new (to|here)\b", r"\bnoob question\b", r"\bjust started\b"],
    "veteran_disagree":  [r"\bi (mostly )?agree,?\s+but\b", r"\b(70%|80%) agree\b", r"\bone (caveat|exception)\b"],
    "concrete_asker":    [r"\b(give|got) (me )?(a )?(concrete )?(example|case)\b", r"\bin practice\b"],
    "personal_share":    [r"\bi (once|tried|spent|built|lost)\b", r"\bmy (experience|case|setup)\b"],
    "extension_thinker": [r"\bthis (also )?(applies|works) (to|for)\b", r"\bsame thing in\b"],
    "counter_data":      [r"\b(data|stats?) shows?\b", r"\b\d+% of\b"],
}

def extract_replies(combined_text):
    """Extract Q-COPY/A-COPY pairs from combined file."""
    pairs = []
    # Find all A-COPY ```text ... ``` blocks
    blocks = re.findall(r"\*\*A-COPY\*\*\s*```text\s*(.+?)```", combined_text, re.S)
    for b in blocks:
        pairs.append(b.strip())
    return pairs

def extract_qa_pairs(combined_text):
    """Pull Q and A pairs in order."""
    # crude regex pull
    qs = re.findall(r"\*\*Q-COPY\*\*\s*```text\s*(.+?)```", combined_text, re.S)
    as_ = re.findall(r"\*\*A-COPY\*\*\s*```text\s*(.+?)```", combined_text, re.S)
    return list(zip(qs, as_))

def first_word(text):
    m = re.match(r"\W*(\w+)", text.strip())
    return m.group(1).lower() if m else ""

def tokenize(text):
    return re.findall(r"\w+", text.lower())

def cosine_sim(a_tokens, b_tokens):
    """Token bag cosine similarity."""
    ca, cb = Counter(a_tokens), Counter(b_tokens)
    common = set(ca) & set(cb)
    num = sum(ca[t] * cb[t] for t in common)
    da = (sum(v*v for v in ca.values())) ** 0.5
    db = (sum(v*v for v in cb.values())) ** 0.5
    return num / (da * db) if da and db else 0

def detect_voice(text):
    tl = text.lower()
    matched = []
    for vname, patterns in VOICE_MARKERS.items():
        for pat in patterns:
            if re.search(pat, tl):
                matched.append(vname)
                break
    return matched

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--combined", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--min-voices", type=int, default=4)
    ap.add_argument("--max-violations", type=int, default=2)
    args = ap.parse_args()

    text = Path(args.combined).read_text(encoding="utf-8")
    pairs = extract_qa_pairs(text)
    replies = [a for _, a in pairs]

    findings = {
        "n_pairs": len(pairs),
        "violations": [],
    }

    # 1. Opener word diversity
    openers = [first_word(r) for r in replies]
    opener_counts = Counter(openers)
    repeated_openers = [w for w, c in opener_counts.items() if c >= 2 and w]
    if repeated_openers:
        findings["violations"].append({
            "type": "opener_repeat",
            "detail": f"Repeated opener words: {repeated_openers}",
            "severity": "MEDIUM",
        })

    # 2. Cosine pair overlap >0.4
    high_sim_pairs = []
    for i in range(len(replies)):
        for j in range(i+1, len(replies)):
            sim = cosine_sim(tokenize(replies[i]), tokenize(replies[j]))
            if sim > 0.4:
                high_sim_pairs.append({"i": i, "j": j, "sim": round(sim, 2)})
    if high_sim_pairs:
        findings["violations"].append({
            "type": "high_lexicon_overlap",
            "detail": high_sim_pairs[:5],
            "severity": "HIGH" if len(high_sim_pairs) >= 3 else "MEDIUM",
        })

    # 3. Voice persona variety
    voices_detected = set()
    for r in replies:
        for v in detect_voice(r):
            voices_detected.add(v)
    if len(voices_detected) < args.min_voices:
        findings["violations"].append({
            "type": "voice_diversity_low",
            "detail": f"Only {len(voices_detected)} voice personas detected: {list(voices_detected)} (min {args.min_voices})",
            "severity": "HIGH",
        })

    # 4. Anti-AI signature
    ai_hits = []
    for i, r in enumerate(replies):
        rl = r.lower()
        for phrase in ANTI_AI_PHRASES:
            if phrase in rl:
                ai_hits.append({"reply_idx": i, "phrase": phrase})
    if ai_hits:
        findings["violations"].append({
            "type": "anti_ai_signature",
            "detail": ai_hits[:10],
            "severity": "HIGH",
        })

    # 5. Q-A semantic mismatch (Q vs A cosine <0.05 = totally disconnected)
    mismatches = []
    for i, (q, a) in enumerate(pairs):
        sim = cosine_sim(tokenize(q), tokenize(a))
        if sim < 0.05:
            mismatches.append({"pair_idx": i, "sim": round(sim, 3)})
    if mismatches:
        findings["violations"].append({
            "type": "qa_semantic_mismatch",
            "detail": mismatches[:5],
            "severity": "MEDIUM",
        })

    decision = "PASS" if len(findings["violations"]) <= args.max_violations and \
                       not any(v["severity"] == "HIGH" for v in findings["violations"]) else "FAIL"

    result = {
        "tool": "10_qna_adversarial.py",
        "version": "V8.0",
        "combined": args.combined,
        "voices_detected": sorted(voices_detected),
        "findings": findings,
        "decision": decision,
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"QNA ADVERSARIAL: {decision} — {len(findings['violations'])} violation(s)")
    for v in findings["violations"]:
        print(f"  [{v['severity']}] {v['type']}: {str(v['detail'])[:120]}")
    print(f"  Voices: {sorted(voices_detected)}")
    sys.exit(0 if decision == "PASS" else 1)

if __name__ == "__main__":
    main()
