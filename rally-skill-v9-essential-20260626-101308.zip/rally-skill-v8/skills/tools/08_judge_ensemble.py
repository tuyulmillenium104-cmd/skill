#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
08_judge_ensemble.py — V8.0
Adversarial-hard 5-persona judge ensemble with locked-JSON output.
Closes V7.7 CELAH #3 (self-judge bias).

Mode 1: --mode prompt-output
  Generates 5 persona judge PROMPTS that the user/agent must run separately
  (in a different model API call or new session). Returns JSON to user.

Mode 2: --mode score-verdicts
  Reads back the 5 verdict JSON files and computes worst-credible aggregate.

Mode 3: --mode adversarial-hard (full local heuristic ensemble — no LLM call)
  Runs 5 deterministic adversarial heuristic checks per persona. Useful as
  fallback when external judge unavailable. Bias-aware: optimistic-by-default
  bias is forced to zero by hard-mode rules (must produce ≥3 criticisms before
  any praise).

Usage:
  python3 08_judge_ensemble.py --content draft.txt --brief brief.txt \
    --pool submissions_enriched.json --winner-mechanism wm.json \
    --out reports/A-ensemble.json --mode adversarial-hard

Exit 0 = worst-credible all-MAX. Exit 1 = unresolved deterministic/precedented/recurring plausible.
"""
import argparse, json, re, sys
from collections import Counter
from pathlib import Path

# Persona definitions
PERSONAS = {
    "LITERAL_COMPLIANCE": {
        "focus": "brief word-by-word, format, length, mention, hashtag, raw URL, fourth-wall, banned symbols",
        "gates": ["CC", "CA"],
    },
    "IA_SKEPTIC": {
        "focus": "factual claims, implied claims, overspecified numbers, unsupported capabilities, causal overreach, omissions",
        "gates": ["IA"],
    },
    "OAA_SIMILARITY": {
        "focus": "structure/motif/opener/CTA pattern similarity to non-winner pool, formula-feeling, template-feeling",
        "gates": ["OAA"],
    },
    "EP_HARSH": {
        "focus": "hook strength, CTA quality, conversation path, value exceptional vs solid, stakes, bookmark value",
        "gates": ["EP"],
    },
    "TQ_NATIVE": {
        "focus": "rhythm, readability, density, punctuation, mention placement, native polish, raw URL, scanability",
        "gates": ["TQ"],
    },
}

# Adversarial-hard heuristic checks per persona
def check_literal_compliance(content, brief, format_rules):
    crits = []
    cl = content.lower()
    # length check
    if format_rules:
        mc = format_rules.get("max_chars")
        if mc and len(content) > mc:
            crits.append({"gate":"CC","severity":"deterministic","quote":f"Content {len(content)} chars exceeds brief max {mc}."})
        if format_rules.get("format") == "one_line" and "\n" in content.strip():
            crits.append({"gate":"CC","severity":"deterministic","quote":"Brief says 'one line' but content has newlines."})
        for m in format_rules.get("required_mentions", []):
            if m.lower() not in cl:
                crits.append({"gate":"CC","severity":"deterministic","quote":f"Required mention {m} missing."})
    # bad unicode
    for ch in ["—","–","“","”","‘","’"]:
        if ch in content:
            crits.append({"gate":"TQ","severity":"plausible","quote":f"Non-ASCII punctuation {repr(ch)} may break platform-native polish."})
            break
    # fourth-wall
    for fw in ["this tweet","this post","my submission","for this campaign"]:
        if fw in cl:
            crits.append({"gate":"OAA","severity":"plausible","quote":f"Fourth-wall phrase '{fw}' may reduce OAA."})
    return crits

def check_ia_skeptic(content, brief):
    crits = []
    cl = content.lower()
    # overspecified numbers
    nums = re.findall(r"\b\d+(?:\.\d+)?%?\b", content)
    if nums:
        # check if numbers appear in brief
        brief_l = (brief or "").lower()
        for n in nums:
            if n not in brief_l and not re.search(rf"\b{re.escape(n)}\b", brief_l):
                # number not in brief = unsourced claim
                if int(re.match(r"\d+", n).group()) > 1:
                    crits.append({"gate":"IA","severity":"plausible","quote":f"Number '{n}' has no source in brief or content."})
                    break
    # unsupported guarantee
    for phrase in ["guaranteed","will make","100x","huge roi","passive income"]:
        if phrase in cl:
            crits.append({"gate":"IA","severity":"deterministic","quote":f"Unsupported earning claim: '{phrase}'."})
    # causal overreach
    causal = re.findall(r"\b(\w+ ) (causes|always|never|only)\b", cl)
    if len(causal) >= 2:
        crits.append({"gate":"IA","severity":"plausible","quote":"Multiple absolute causal statements (always/never/only) — IA risk."})
    return crits

def check_oaa_similarity(content, pool):
    crits = []
    if not pool:
        return crits
    cl = content.lower()
    # opener match
    content_opener = " ".join(content.split()[:5]).lower()
    opener_match_count = 0
    for s in pool:
        sc = (s.get("content") or "").lower()
        s_opener = " ".join(sc.split()[:5])
        if content_opener and content_opener == s_opener:
            opener_match_count += 1
    if opener_match_count >= 2:
        crits.append({"gate":"OAA","severity":"precedented","quote":f"Opener matches {opener_match_count} pool entries verbatim."})
    # 5-gram overlap with non-winners
    def toks(t): return re.findall(r"\w+", t.lower())
    ct = toks(content)
    cgrams = set(" ".join(ct[i:i+5]) for i in range(len(ct)-4))
    nonwin = [s for s in pool if not (s.get("winner") or s.get("isWinner"))]
    for s in nonwin[:50]:  # limit for perf
        st = toks(s.get("content") or "")
        sgrams = set(" ".join(st[i:i+5]) for i in range(len(st)-4))
        overlap = cgrams & sgrams
        # filter mandatory phrases (brief vocab) — too hard here, just flag if ≥1 5-gram overlap
        if overlap:
            for o in list(overlap)[:1]:
                crits.append({"gate":"OAA","severity":"plausible","quote":f"5-gram overlap with non-winner: '{o}'"})
                break
            break
    return crits

def check_ep_harsh(content, winner_mechanism):
    crits = []
    cl = content.lower()
    # hook check
    first_sent = re.split(r"[.!?]", content.strip())[0]
    if len(first_sent.split()) > 18:
        crits.append({"gate":"EP","severity":"plausible","quote":f"First sentence {len(first_sent.split())} words — hook may be slow."})
    for slow in ["so,","well,","honestly,","just thinking","random thought"]:
        if cl.startswith(slow):
            crits.append({"gate":"EP","severity":"precedented","quote":f"Slow opener '{slow}' = hook-not-sharp pattern."})
    # CTA quality (need behavioral verb + object)
    behavioral_verbs = ["reply","tell me","choose","name","check","visit","pick","share","compare","spend","rate"]
    has_verb = any(v in cl for v in behavioral_verbs)
    has_qmark = "?" in content
    paras = [p for p in re.split(r"\n\s*\n", content.strip()) if p.strip()]
    tail = paras[-1] if paras else content
    if not has_verb and has_qmark:
        crits.append({"gate":"EP","severity":"precedented","quote":"Question mark without behavioral verb — Wingston pattern (EP4 risk on CTA Quality)."})
    elif not has_qmark and not has_verb:
        crits.append({"gate":"EP","severity":"deterministic","quote":"No CTA: no question mark, no behavioral verb."})
    # mechanism presence
    if winner_mechanism:
        top3 = [m["name"] for m in winner_mechanism.get("top_3_mechanisms", [])]
        # crude check: any heuristic that matches winner mechanism detected?
        from importlib import import_module
        # too complex to invoke here; just warn if no mechanism marker
        # (winner mechanism map should have run separately)
        if not any(marker in cl for marker in ["verdict","not","actually","first","spent","because","let me","tell me"]):
            crits.append({"gate":"EP","severity":"plausible","quote":"No obvious winner-mechanism marker detected in content."})
    # generic CTA
    for g in ["thoughts?","what do you think?","agree?","drop yours","let me know"]:
        if g in cl:
            crits.append({"gate":"EP","severity":"deterministic","quote":f"Generic CTA '{g}' = EP4 ceiling."})
    return crits

def check_tq_native(content):
    crits = []
    cl = content.lower()
    # dense paragraphs
    paras = [p for p in re.split(r"\n\s*\n", content.strip()) if p.strip()]
    for p in paras:
        sents = re.split(r"[.!?]\s+", p)
        long_count = sum(1 for s in sents if len(s.split()) > 22)
        if long_count >= 2:
            crits.append({"gate":"TQ","severity":"plausible","quote":f"Dense paragraph with {long_count} long sentences."})
            break
    # raw URL
    for m in re.finditer(r"https?://\S+", content):
        crits.append({"gate":"TQ","severity":"precedented","quote":f"Raw URL in body: {m.group(0)} (use native attachment or remove)."})
        break
    # vocative mention
    if re.search(r"\.\s+@\w+\s*\.", content):
        crits.append({"gate":"TQ","severity":"precedented","quote":"@mention as standalone vocative line — rhythm interruption (iPad verdict 0I-12)."})
    # 3+ em-dashes
    if content.count("—") >= 3:
        crits.append({"gate":"TQ","severity":"plausible","quote":"3+ em-dashes = punctuation drag."})
    return crits

PERSONA_FUNCS = {
    "LITERAL_COMPLIANCE": lambda c, b, p, wm, fr: check_literal_compliance(c, b, fr),
    "IA_SKEPTIC":         lambda c, b, p, wm, fr: check_ia_skeptic(c, b),
    "OAA_SIMILARITY":     lambda c, b, p, wm, fr: check_oaa_similarity(c, p),
    "EP_HARSH":           lambda c, b, p, wm, fr: check_ep_harsh(c, wm),
    "TQ_NATIVE":          lambda c, b, p, wm, fr: check_tq_native(c),
}

def score_from_criticisms(crits):
    """Given list of criticisms, infer per-gate score using worst-credible rule."""
    by_gate = {"EP":5,"OAA":5,"TQ":5,"IA":5,"CA":5,"CC":2}
    for cr in crits:
        gate = cr["gate"]
        sev = cr["severity"]
        if gate not in by_gate: continue
        if sev == "deterministic":
            by_gate[gate] = min(by_gate[gate], 3 if gate != "CC" else 0)
        elif sev == "precedented":
            by_gate[gate] = min(by_gate[gate], 4 if gate != "CC" else 1)
        elif sev == "plausible":
            by_gate[gate] = min(by_gate[gate], 4 if gate != "CC" else 1)
    return by_gate

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--brief", default=None)
    ap.add_argument("--pool", default=None)
    ap.add_argument("--winner-mechanism", default=None)
    ap.add_argument("--format-rules", default=None, help="JSON with brief format rules")
    ap.add_argument("--out", required=True)
    ap.add_argument("--mode", default="adversarial-hard",
                    choices=["adversarial-hard","prompt-output","score-verdicts"])
    ap.add_argument("--verdict-dir", default=None, help="Dir with verdict_<persona>.json files (for score-verdicts mode)")
    args = ap.parse_args()

    content = Path(args.content).read_text(encoding="utf-8").strip()
    brief = Path(args.brief).read_text(encoding="utf-8") if args.brief else ""
    pool = json.load(open(args.pool, encoding="utf-8")) if args.pool else []
    wm = json.load(open(args.winner_mechanism, encoding="utf-8")) if args.winner_mechanism else {}
    fr = json.load(open(args.format_rules, encoding="utf-8")) if args.format_rules else {}

    persona_results = {}

    if args.mode == "adversarial-hard":
        for pname in PERSONAS:
            crits = PERSONA_FUNCS[pname](content, brief, pool, wm, fr)
            scores = score_from_criticisms(crits)
            persona_results[pname] = {
                "focus": PERSONAS[pname]["focus"],
                "criticisms": crits,
                "scores": scores,
                "verdict_class": (
                    "all-max" if all(v == 5 or (k=="CC" and v==2) for k,v in scores.items())
                    else "near-max" if sum(scores.values()) >= 22
                    else "safe-mid"
                ),
            }
    elif args.mode == "prompt-output":
        # Generate prompts the user must run in separate sessions
        prompts = {}
        for pname, pdef in PERSONAS.items():
            prompts[pname] = build_judge_prompt(pname, pdef, content, brief)
        out = {"tool":"08_judge_ensemble.py","mode":"prompt-output","prompts":prompts,
               "instruction":"Run each prompt in a SEPARATE session (preferably different model). Save verdict to verdict_<persona>.json. Then re-run with --mode score-verdicts --verdict-dir <dir>."}
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"PROMPTS WRITTEN TO {args.out}")
        sys.exit(0)
    elif args.mode == "score-verdicts":
        if not args.verdict_dir:
            print("ERROR: --verdict-dir required for score-verdicts mode", file=sys.stderr); sys.exit(2)
        vd = Path(args.verdict_dir)
        for pname in PERSONAS:
            vf = vd / f"verdict_{pname}.json"
            if vf.exists():
                persona_results[pname] = json.load(open(vf, encoding="utf-8"))
            else:
                print(f"WARN: missing {vf}, defaulting to neutral.", file=sys.stderr)
                persona_results[pname] = {"criticisms":[],"scores":{"EP":5,"OAA":5,"TQ":5,"IA":5,"CA":5,"CC":2},"verdict_class":"all-max"}

    # Aggregate worst-credible
    gates = ["EP","OAA","TQ","IA","CA","CC"]
    worst = {g: 5 if g != "CC" else 2 for g in gates}
    all_crits = []
    for pname, pres in persona_results.items():
        for g in gates:
            sc = pres.get("scores",{}).get(g)
            if sc is not None: worst[g] = min(worst[g], sc)
        for cr in pres.get("criticisms", []):
            cr["persona"] = pname
            all_crits.append(cr)

    # Recurrence: same gate+severity in ≥2 persona = real weakness
    crit_keys = Counter((cr["gate"], cr["severity"]) for cr in all_crits)
    recurring = [(k,v) for k,v in crit_keys.items() if v >= 2]

    det_count = sum(1 for cr in all_crits if cr["severity"] == "deterministic")
    prec_count = sum(1 for cr in all_crits if cr["severity"] == "precedented")
    plaus_recur = sum(1 for k,v in recurring if k[1] == "plausible")

    all_max = all(worst[g] == (5 if g != "CC" else 2) for g in gates)
    decision = "PASS" if (all_max and det_count == 0 and prec_count == 0 and plaus_recur == 0) else "FAIL"

    reason_parts = []
    if not all_max: reason_parts.append(f"worst-credible not all-max: {worst}")
    if det_count: reason_parts.append(f"{det_count} deterministic")
    if prec_count: reason_parts.append(f"{prec_count} precedented")
    if plaus_recur: reason_parts.append(f"{plaus_recur} recurring plausible")
    reason = "; ".join(reason_parts) if reason_parts else "all clear"

    result = {
        "tool":"08_judge_ensemble.py",
        "version":"V8.0",
        "mode":args.mode,
        "content":args.content,
        "persona_results":persona_results,
        "worst_credible_scores":worst,
        "recurring_criticisms": [{"gate":k[0],"severity":k[1],"count":v} for k,v in recurring],
        "deterministic_unresolved": det_count,
        "precedented_unresolved": prec_count,
        "plausible_recurring_unresolved": plaus_recur,
        "decision": decision,
        "reason": reason,
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"JUDGE ENSEMBLE: {decision} — {reason}")
    print(f"  worst-credible: {worst}")
    for pname, pres in persona_results.items():
        ncrit = len(pres.get("criticisms",[]))
        vc = pres.get("verdict_class","?")
        print(f"  {pname:25s}  crit={ncrit}  verdict={vc}")
    sys.exit(0 if decision == "PASS" else 1)

def build_judge_prompt(pname, pdef, content, brief):
    return f"""You are RALLY {pname} judge. Focus: {pdef['focus']}.

RULES OF ENGAGEMENT (hard mode):
1. Write 3 criticisms BEFORE any praise.
2. Severity classes (use exact strings): deterministic, precedented, plausible, style, hallucinated.
3. Output ONLY this JSON, no commentary outside JSON:

{{
  "persona": "{pname}",
  "criticisms": [
    {{"gate": "EP|OAA|TQ|IA|CA|CC", "severity": "...", "quote": "..."}},
    ...
  ],
  "scores": {{"EP":0-5,"OAA":0-5,"TQ":0-5,"IA":0-5,"CA":0-5,"CC":0-2}},
  "verdict_class": "all-max|near-max|safe-mid|drop-risk"
}}

CAMPAIGN BRIEF:
\"\"\"
{brief}
\"\"\"

CONTENT TO JUDGE:
\"\"\"
{content}
\"\"\"

Produce ONLY the JSON.
"""

if __name__ == "__main__":
    main()
