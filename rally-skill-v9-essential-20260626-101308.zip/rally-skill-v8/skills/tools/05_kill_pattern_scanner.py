#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
05_kill_pattern_scanner.py — V8.0
Scan KONTEN (bukan vonis) terhadap 10 kelas EP-kill yang terbukti memotong skor.
Closes V7.7 CELAH #2 (top fatal celah).

Usage:
  python3 05_kill_pattern_scanner.py --content draft.txt --out reports/A-kill.json

Exit 0 = PASS (no kill pattern). Exit 1 = FAIL (regenerate).
"""
import argparse, json, re, sys
from pathlib import Path

# 10 kill-pattern classes (from LEXICON-DATA.md §EP-KILL)
KILL_PATTERNS = {
    "EP-KILL-1_generic_cta": {
        "phrases": [
            "thoughts?", "what do you think?", "agree?", "agree or disagree?",
            "drop yours below", "drop yours", "let me know", "share below",
            "share your thoughts", "lmk", "your take?", "what are your thoughts",
        ],
        "severity": "HIGH",
        "explanation": "Generic CTA = EP4 ceiling in CTA Quality. Use formula: behavioral verb + concrete object + choice.",
    },
    "EP-KILL-2_hype_phrases": {
        "phrases": [
            "game changer", "game-changer", "this is huge", "to the moon",
            "lfg", "this is everything", "this hits different", "mind blown",
            "chef's kiss", "absolute fire", "fire 🔥",
        ],
        "severity": "MEDIUM",
        "explanation": "Hype without substance = generic/formulaic deduction.",
    },
    "EP-KILL-3_brand_bridge_promo": {
        "regex": [
            r"that is why @\w+",
            r"this is exactly why @\w+",
            r"@\w+ solves this",
            r"makes sense to me, that[\'’]s why",
            r"shoutout to @\w+",
            r"big things coming from @\w+",
        ],
        "severity": "HIGH",
        "explanation": "Promotional brand bridge → IA/OAA risk. Story pain → mechanism, not campaign copy.",
    },
    "EP-KILL-4_unsupported_earning": {
        "phrases": [
            "guaranteed", "will make you", "passive income", "get rich",
            "financial freedom", "life changing money", "100x", "huge roi",
            "easy money", "free money",
        ],
        "severity": "HIGH",
        "explanation": "Unsupported earning claim → IA fail + CC violation.",
    },
    "EP-KILL-5_slow_opener": {
        "regex_start": [
            r"^so,?\s",
            r"^well,?\s",
            r"^honestly,?\s",
            r"^to be honest,?\s",
            r"^just thinking",
            r"^random thought",
            r"^been thinking about",
            r"^lately i[\'’]ve been",
            r"^let me share",
        ],
        "severity": "HIGH",
        "explanation": "Slow opener = hook-not-sharp. Open with verdict/number/scene/contrarian.",
    },
    "EP-KILL-6_ai_signature": {
        "phrases": [
            "in this fast-paced world", "in today's landscape", "it's worth noting",
            "delve into", "let's unpack", "moreover", "furthermore",
            "in summary", "to put it simply", "when it comes to",
            "navigate the", "embark on", "in the realm of",
        ],
        "severity": "HIGH",
        "explanation": "AI-signature phrasing = TQ/OAA fail (template-feeling).",
    },
    "EP-KILL-7_fourth_wall": {
        "phrases": [
            "this tweet", "this post", "reading this",
            "as i write this", "my thread", "tl;dr",
            "this submission", "for this campaign",
        ],
        "severity": "MEDIUM",
        "explanation": "Fourth-wall meta-commentary = CC violation if brief forbids, OAA risk otherwise.",
    },
    "EP-KILL-8_slogan_cadence": {
        "regex": [
            r"\b(fast|cheap|quick|simple)\.\s+(cheap|fast|simple|easy)\.\s+(decentralized|powerful|free|scalable)\.",
            r"\b(build|ship|iterate)\.\s+(ship|build|iterate)\.\s+(iterate|build|ship)\.",
        ],
        "severity": "MEDIUM",
        "explanation": "3-beat slogan cadence without specifics = OAA template / EP shallow.",
    },
    "EP-KILL-9_dual_cta_crowd": {
        "custom": "dual_cta_check",
        "severity": "MEDIUM",
        "explanation": "Dual CTA (multiple questions) crowds and dilutes engagement.",
    },
    "EP-KILL-10_vocative_mention": {
        "regex": [
            r"\.\s+@\w+\s*\.",      # mention as standalone sentence
            r",\s*@\w+,",            # vocative comma-flanked mid-sentence
        ],
        "severity": "MEDIUM",
        "explanation": "Vocative mid-sentence mention → TQ rhythm interruption.",
    },
}

def dual_cta_check(text):
    """Detect ≥2 question marks in final 2 sentences without choice structure."""
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    tail = " ".join(sentences[-2:]) if len(sentences) >= 2 else text
    qcount = tail.count("?")
    if qcount >= 2:
        # check if it's a single choice question (has "or" or list structure)
        if " or " not in tail.lower() and ":" not in tail:
            return True
    return False

def scan_phrases(text_lower, phrases):
    return [p for p in phrases if p in text_lower]

def scan_regex(text, patterns, flags=re.I):
    hits = []
    for pat in patterns:
        m = re.search(pat, text, flags)
        if m: hits.append({"pattern": pat, "matched": m.group(0)})
    return hits

def scan_regex_start(text, patterns):
    hits = []
    for pat in patterns:
        m = re.match(pat, text, re.I | re.M)
        if m: hits.append({"pattern": pat, "matched": m.group(0)})
    return hits

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--ignore", action="append", default=[], help="Kill pattern IDs to ignore (e.g. --ignore EP-KILL-7_fourth_wall)")
    args = ap.parse_args()

    text = Path(args.content).read_text(encoding="utf-8").strip()
    tl = text.lower()
    findings = {}
    severity_counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}

    for kid, kdef in KILL_PATTERNS.items():
        if kid in args.ignore:
            continue
        hits = []
        if "phrases" in kdef:
            hits.extend([{"phrase": h} for h in scan_phrases(tl, kdef["phrases"])])
        if "regex" in kdef:
            hits.extend(scan_regex(text, kdef["regex"]))
        if "regex_start" in kdef:
            hits.extend(scan_regex_start(text, kdef["regex_start"]))
        if kdef.get("custom") == "dual_cta_check":
            if dual_cta_check(text):
                hits.append({"custom": "dual_cta_check", "matched": "≥2 question marks in tail without choice marker"})
        if hits:
            findings[kid] = {
                "severity": kdef["severity"],
                "explanation": kdef["explanation"],
                "hits": hits,
                "hit_count": len(hits),
            }
            severity_counts[kdef["severity"]] += len(hits)

    decision = "PASS" if severity_counts["HIGH"] == 0 and severity_counts["MEDIUM"] <= 1 else "FAIL"
    if severity_counts["HIGH"] > 0:
        reason = f"{severity_counts['HIGH']} HIGH severity kill pattern(s) found"
    elif severity_counts["MEDIUM"] > 1:
        reason = f"{severity_counts['MEDIUM']} MEDIUM severity kill patterns (max 1 allowed)"
    else:
        reason = "No blocking kill patterns"

    result = {
        "tool": "05_kill_pattern_scanner.py",
        "version": "V8.0",
        "content": args.content,
        "content_chars": len(text),
        "severity_counts": severity_counts,
        "findings": findings,
        "decision": decision,
        "reason": reason,
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"KILL-PATTERN SCAN: {decision} — {reason}")
    if findings:
        for kid, info in findings.items():
            print(f"  [{info['severity']}] {kid}: {info['hit_count']} hit(s)")
            for h in info["hits"][:3]:
                print(f"     · {h}")
    sys.exit(0 if decision == "PASS" else 1)

if __name__ == "__main__":
    main()
