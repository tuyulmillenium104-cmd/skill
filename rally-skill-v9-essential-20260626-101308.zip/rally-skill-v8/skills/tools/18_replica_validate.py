#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
18_replica_validate.py — V8.1
Validate replica accuracy: predict scores for known winners and non-winners,
compare to actual judge verdicts.

This is the CRITICAL convergence test. If replica accuracy <95%, we iterate.
"""
import argparse, json, sys, importlib.util
from pathlib import Path

# Import replica module
spec = importlib.util.spec_from_file_location("replica", "skills/tools/17_judge_replica.py")
replica = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replica)

CATS = ["Originality and Authenticity","Content Alignment","Information Accuracy","Campaign Compliance","Engagement Potential","Technical Quality","Reply Quality"]
TARGETS = {"Originality and Authenticity":2,"Content Alignment":2,"Information Accuracy":2,"Campaign Compliance":2,"Engagement Potential":5,"Technical Quality":5,"Reply Quality":5}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--winners", default="jfr-data/winners_with_text.json")
    ap.add_argument("--raw-dir", default="jfr-data/raw")
    ap.add_argument("--out", default="jfr-data/replica_validation.json")
    ap.add_argument("--max-samples", type=int, default=2000)
    args = ap.parse_args()

    # Test on ALL-MAX winners (must predict all-max)
    winners = json.load(open(args.winners, encoding="utf-8"))
    winners = [w for w in winners if w.get("text") and "[FRAGMENT" not in w.get("text","")]
    # Exclude truncated tweets (text < 500 chars usually means t.co attachment cut off)
    # Use raw judge to detect — verdicts that say "longform" + tweet text < 500 chars = truncation
    truncated = []
    full = []
    for w in winners:
        if len(w["text"]) < 500:
            # likely truncated — Rally winners are typically 800+ char longform
            truncated.append(w)
        else:
            full.append(w)
    print(f"Testing on {len(full)} ALL-MAX winners with full text (excluded {len(truncated)} likely-truncated)…")
    winners = full

    correct_all_max = 0
    per_cat_correct = {c:0 for c in CATS}
    per_cat_predicted = {c:[] for c in CATS}
    failure_cases = []

    for w in winners:
        text = w["text"]
        # Get brief from raw
        brief = ""
        raw_path = Path(args.raw_dir)/f"{w['campaign_address']}.json"
        if raw_path.exists():
            subs = json.load(open(raw_path,encoding="utf-8"))
            mission = next((s.get("mission") for s in subs if s.get("mission",{}).get("id")==w.get("mission_id")), None)
            if mission: brief = (mission.get("description","") + "\n\nRULES:\n" + mission.get("rules","")).strip()

        pred = replica.predict_scores(text, brief)
        actual = w["scores"]

        match_count = 0
        for c in CATS:
            if c not in actual: continue
            pv = pred[c]
            av = actual[c]
            per_cat_predicted[c].append(pv)
            if pv >= TARGETS[c] and av >= TARGETS[c]:  # both MAX
                per_cat_correct[c] += 1
                match_count += 1
            elif pv < TARGETS[c] and av < TARGETS[c]:  # both not max
                per_cat_correct[c] += 1
                match_count += 1
            # else mismatch

        is_pred_all_max = all(pred[c] >= TARGETS[c] for c in CATS if c in actual)
        is_actual_all_max = all(actual[c] >= TARGETS[c] for c in CATS if c in actual)
        if is_pred_all_max == is_actual_all_max:
            correct_all_max += 1
        else:
            failure_cases.append({
                "author": w["author"], "campaign": w["campaign"],
                "actual": actual, "predicted": pred,
                "text_preview": text[:200],
            })

    # Test on LOW EP (must predict not max)
    print(f"\nTesting on EP_LOW (must predict EP<5)…")
    low_path = Path("jfr-data/per-category/Engagement_Potential_LOW.jsonl")
    low_correct = 0; low_total = 0
    if low_path.exists():
        # need tweet text — try syndication for first N
        import urllib.request
        rows = []
        with open(low_path) as f:
            for line in f:
                rows.append(json.loads(line))
                if len(rows) >= 50: break
        for r in rows:
            tid = r["tweet_id"]
            try:
                req = urllib.request.Request(f"https://cdn.syndication.twimg.com/tweet-result?id={tid}&token=a", headers={"User-Agent":"Mozilla/5.0"})
                d = json.load(urllib.request.urlopen(req, timeout=8))
                txt = d.get("text") or d.get("full_text") or ""
                if not txt: continue
            except Exception:
                continue
            pred = replica.predict_scores(txt, r.get("brief",""))
            low_total += 1
            if pred["Engagement Potential"] < 5:
                low_correct += 1

    # Summary
    n = len([w for w in winners if w.get("text")])
    pct_all_max = correct_all_max / max(1,n) * 100
    per_cat_acc = {c: per_cat_correct[c]/max(1,n)*100 for c in CATS}

    result = {
        "tool": "18_replica_validate.py",
        "tested_on": {"all_max_winners": n, "ep_low_samples": low_total},
        "all_max_accuracy": round(pct_all_max,2),
        "per_category_accuracy": {c:round(v,2) for c,v in per_cat_acc.items()},
        "ep_low_correct_rejected": low_correct,
        "ep_low_total_tested": low_total,
        "ep_low_accuracy": round(low_correct/max(1,low_total)*100,2),
        "n_failure_cases": len(failure_cases),
        "failure_cases": failure_cases[:20],
    }
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"\n═══ REPLICA VALIDATION ═══")
    print(f"ALL-MAX winners tested: {n}")
    print(f"  Correctly predicted ALL-MAX: {correct_all_max} ({pct_all_max:.1f}%)")
    print(f"\nPer-category accuracy:")
    for c, acc in per_cat_acc.items():
        marker = "✓" if acc >= 95 else ("·" if acc >= 80 else "✗")
        print(f"  {marker} {c:35s} {acc:.1f}%")
    print(f"\nEP<5 samples correctly rejected: {low_correct}/{low_total} ({result['ep_low_accuracy']:.1f}%)")
    print(f"\nFailure cases (predicted not-ALL-MAX but actually ALL-MAX): {len(failure_cases)}")

if __name__ == "__main__":
    main()
