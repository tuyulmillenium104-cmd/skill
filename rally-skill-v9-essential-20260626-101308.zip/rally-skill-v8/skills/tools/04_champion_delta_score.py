#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
04_champion_delta_score.py — V8.0
Quantitative Champion Delta Score (CDS) — content vs pool top performers.
Closes V7.7 CELAH #5 (subjective "superior/parity/inferior" → numeric).

5 axis CDS (0-100 percentile vs pool):
  1. Insight Density (unique concept-nouns per 100 char)
  2. Specificity (concrete details: name/number/place/tool)
  3. Conversation Affordance (reply path clarity 0-5)
  4. Hook Stop-Score (top-3 word strength)
  5. CTA Quality (formula score 0-5)

Usage:
  python3 04_champion_delta_score.py --content draft.txt --pool submissions_enriched.json --out cds.json

PASS: ≥4 axis above pool top-5 median (percentile ≥80), 0 axis below pool median.
"""
import argparse, json, re, sys
from pathlib import Path

# --- Metric extractors ---

CONCRETE_DETAIL_REGEX = [
    r"@\w+",                          # mentions
    r"#\w+",                          # hashtags
    r"\b\d+(?:\.\d+)?\s*(?:%|x|k|m|b)?\b",  # numbers
    r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2}\b",  # named entities (capitalized 1-3 word)
    r"\$\w+",                         # tickers
    r"https?://\S+",                  # urls
    r"\b\d+(?:am|pm|AM|PM)\b",        # times
    r"\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", # weekdays
]

CONCEPT_NOUN_REGEX = r"\b[a-z]{4,}(?:tion|ment|ity|ness|ship|ism|hood)\b"

HOOK_STRONG_WORDS = set([
    "verdict", "cooked", "mid", "genius", "actually", "unpopular", "wrong",
    "broken", "fake", "real", "truth", "lie", "stop", "ban", "kill",
    "won", "lost", "shipped", "built", "burned", "saved",
    "most", "every", "no one", "everyone", "nobody",
    "1", "2", "3", "5", "10", "100", "1000",
] + [str(n) for n in range(2026, 2031)])

HOOK_WEAK_WORDS = set([
    "so", "well", "honestly", "just", "maybe", "perhaps", "kind of",
    "it's", "there's", "you know", "i think", "in my opinion",
])

BEHAVIORAL_VERBS = [
    "reply", "comment", "tell me", "choose", "name", "check", "visit",
    "learn", "join", "mint", "compare", "pick", "show me", "share",
    "test", "spend", "route", "rate", "drop", "post",
]

CHOICE_MARKERS = [" or ", "either", "which", "rather", " vs ", " versus "]

def count_concrete_details(text):
    total = 0
    for rx in CONCRETE_DETAIL_REGEX:
        total += len(re.findall(rx, text))
    return total

def count_concept_nouns(text):
    return len(set(re.findall(CONCEPT_NOUN_REGEX, text.lower())))

def insight_density(text):
    """Unique concept-nouns per 100 chars."""
    chars = max(1, len(text))
    cn = count_concept_nouns(text)
    return round(cn / chars * 100, 2)

def specificity_score(text):
    return count_concrete_details(text)

def conversation_affordance(text):
    """0-5 scale: question mark + verb + object + low-friction + reply path."""
    score = 0
    tl = text.lower()
    if "?" in text: score += 1
    if any(v in tl for v in BEHAVIORAL_VERBS): score += 1
    if any(m in tl for m in CHOICE_MARKERS): score += 1
    # concrete object near CTA: last paragraph has 1+ concrete detail
    paras = [p for p in re.split(r"\n\s*\n", text.strip()) if p.strip()]
    last = paras[-1] if paras else text
    if count_concrete_details(last) >= 1: score += 1
    # reply-path friction low: question length <= 20 words
    last_q = re.search(r"[^.!?]*\?", last)
    if last_q and len(last_q.group(0).split()) <= 20: score += 1
    return score

def hook_stop_score(text):
    """Score 0-100 based on first 10 words strength."""
    first10 = " ".join(text.split()[:10]).lower()
    words = re.findall(r"\b\w+\b", first10)
    strong = sum(1 for w in words if w in HOOK_STRONG_WORDS)
    weak = sum(1 for w in words if w in HOOK_WEAK_WORDS)
    # base 50, add 10 per strong, subtract 15 per weak
    score = 50 + (strong * 10) - (weak * 15)
    # length penalty: first sentence >18 words → -10
    first_sent = re.split(r"[.!?]", text.strip())[0]
    if len(first_sent.split()) > 18:
        score -= 15
    return max(0, min(100, score))

def cta_formula_score(text):
    """0-5 formula: behavioral verb + concrete object + native choice + low friction + thesis integrated."""
    paras = [p for p in re.split(r"\n\s*\n", text.strip()) if p.strip()]
    cta = "\n".join(paras[-2:]) if len(paras) >= 2 else text
    cl = cta.lower()
    score = 0
    if any(v in cl for v in BEHAVIORAL_VERBS): score += 1
    if count_concrete_details(cta) >= 1: score += 1
    if any(m in cl for m in CHOICE_MARKERS) or "?" in cta: score += 1
    # low friction: question <= 20 words
    last_q = re.search(r"[^.!?]*\?", cta)
    if last_q and len(last_q.group(0).split()) <= 20: score += 1
    # thesis integrated: at least 1 concept noun shared between body and CTA
    body = "\n".join(paras[:-1]) if len(paras) > 1 else ""
    body_concepts = set(re.findall(CONCEPT_NOUN_REGEX, body.lower()))
    cta_concepts = set(re.findall(CONCEPT_NOUN_REGEX, cta.lower()))
    if body_concepts & cta_concepts: score += 1
    return score

# --- Pool stats ---

def percentile(value, sorted_pool):
    """Return percentile (0-100) of value vs sorted pool."""
    if not sorted_pool: return 50
    below = sum(1 for v in sorted_pool if v < value)
    return int(below / len(sorted_pool) * 100)

def pool_stats(pool_values):
    if not pool_values: return {"median": 0, "top5_median": 0, "max": 0}
    sv = sorted(pool_values)
    median = sv[len(sv)//2]
    top5 = sv[-5:] if len(sv) >= 5 else sv
    top5_median = sorted(top5)[len(top5)//2]
    return {"median": median, "top5_median": top5_median, "max": max(sv), "sorted": sv}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--pool", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--winners-only", action="store_true", help="Compare only vs winner pool")
    args = ap.parse_args()

    text = Path(args.content).read_text(encoding="utf-8").strip()
    pool = json.load(open(args.pool, encoding="utf-8"))
    if not isinstance(pool, list):
        print("ERROR: pool must be JSON list", file=sys.stderr); sys.exit(2)

    if args.winners_only:
        pool = [s for s in pool if s.get("winner") or s.get("isWinner")]
    pool = [s for s in pool if (s.get("content") or "").strip()]

    # compute metrics for content
    metrics = {
        "insight_density":          insight_density(text),
        "specificity":              specificity_score(text),
        "conversation_affordance": conversation_affordance(text),
        "hook_stop_score":          hook_stop_score(text),
        "cta_formula":              cta_formula_score(text),
    }

    # compute pool distributions
    pool_dist = {axis: [] for axis in metrics}
    for s in pool:
        c = s.get("content") or ""
        pool_dist["insight_density"].append(insight_density(c))
        pool_dist["specificity"].append(specificity_score(c))
        pool_dist["conversation_affordance"].append(conversation_affordance(c))
        pool_dist["hook_stop_score"].append(hook_stop_score(c))
        pool_dist["cta_formula"].append(cta_formula_score(c))

    # compute CDS per axis
    cds = {}
    for axis, value in metrics.items():
        stats = pool_stats(pool_dist[axis])
        pct = percentile(value, stats.get("sorted", []))
        cds[axis] = {
            "content_value": value,
            "pool_median": stats["median"],
            "pool_top5_median": stats["top5_median"],
            "pool_max": stats["max"],
            "percentile": pct,
            "vs_median": "ABOVE" if value > stats["median"] else ("EQUAL" if value == stats["median"] else "BELOW"),
            "vs_top5": "ABOVE" if value >= stats["top5_median"] else "BELOW",
        }

    above_top5 = sum(1 for v in cds.values() if v["percentile"] >= 80)
    below_median = sum(1 for v in cds.values() if v["percentile"] < 50)

    decision = "PASS" if above_top5 >= 4 and below_median == 0 else "FAIL"
    reason = (f"{above_top5}/5 axis ≥80th percentile; "
              f"{below_median}/5 axis below median (need ≥4 and 0)")

    result = {
        "tool": "04_champion_delta_score.py",
        "version": "V8.0",
        "content": args.content,
        "content_chars": len(text),
        "pool_size": len(pool),
        "winners_only": args.winners_only,
        "cds_per_axis": cds,
        "summary": {
            "axes_above_top5_median": above_top5,
            "axes_below_median": below_median,
        },
        "decision": decision,
        "reason": reason,
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"CHAMPION DELTA SCORE: {decision} — {reason}")
    for axis, info in cds.items():
        marker = "✓" if info["percentile"] >= 80 else ("·" if info["percentile"] >= 50 else "✗")
        print(f"  {marker} {axis:30s} value={info['content_value']:>6}  pct={info['percentile']:>3}  (median={info['pool_median']}, top5med={info['pool_top5_median']})")
    sys.exit(0 if decision == "PASS" else 1)

if __name__ == "__main__":
    main()
