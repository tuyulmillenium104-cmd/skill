#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
27_certainty_pipeline.py — V9.0 CERTAINTY PIPELINE
The "kepastian" mode — combines ALL evidence streams:

1. STATISTICAL MODEL (logistic regression on 1146 samples)
2. SUB-RUBRIC SCORER (35 sub-rubrics from V8.4)  
3. POOL OVERLAP (real-time 5-gram check vs winners/non-winners)
4. KILL-PATTERN HARD GATE (deterministic eliminators)
5. STRUCTURAL CONFORMANCE (chars/paras/sents within winner band)

DECISION:
- "CERTAIN_SUBMIT" — ALL 5 streams agree positive (estimated >95% confidence)
- "LIKELY_SUBMIT" — 4/5 streams agree (estimated 80-90% confidence)
- "BORDERLINE" — 3/5 streams agree (50-70% confidence)
- "REVISE" — <3/5 streams agree

Plus iterate-until-pass loop for unlimited-submission campaigns.

Usage:
  python3 27_certainty_pipeline.py --content draft.txt --brief brief.txt \
    --campaign-address 0xADDR --out cert.json
"""
import argparse, json, re, sys, urllib.request, time, importlib.util, statistics, math
from pathlib import Path

API_BASE = "https://app.rally.fun/api"
MODEL_PATH = Path(__file__).parent.parent.parent / "jfr-data-full" / "logistic_model.json"

# --- Stream 1: Statistical Model ---
def stream1_statistical(text, model):
    def extract(t):
        tl = t.lower()
        sents = re.split(r'(?<=[.!?])\s+', t.strip())
        paras = re.split(r'\n\s*\n', t.strip())
        last_2 = "\n\n".join(t.strip().split("\n\n")[-2:])
        last_2_unq = re.sub(r'"[^"]*"', '', last_2)
        last_2_unq = re.sub(r"[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]", '', last_2_unq)
        last_1 = t.strip().split("\n\n")[-1] if t.strip() else ""
        first = sents[0] if sents else ""
        return {
            'chars': len(t),
            'sents': len(sents),
            'paras': len(paras),
            'last_para_words': len(last_1.split()),
            'qmark_unq_last2p': last_2_unq.count('?'),
            'qmark_total': t.count('?'),
            'quoted': int(bool(re.search(r'"[^"]+"', t)) or bool(re.search(r'[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]', t))),
            'qa_rhythm_count': len(re.findall(r"\b(Did|Does|Is|Are|What|How|Why|When|Where|Can|Could|Should|Would)\b[^?]{1,80}\?", t)),
            'contrarian': int(bool(re.search(r'\b(actually|verdict|wrong|most people|everyone says|but actually|the truth|unpopular|broken|cooked|mid|fake|struggle|hardest|not just)\b', tl))),
            'personal_specific': int(bool(re.search(r"\bi (was|spent|tried|built|saw|watched|remember|used|did|lost|won|hired|bought|wrote|posted|sent|paid|started)\b", tl))),
            'mechanism_reveal': int(bool(re.search(r"\b(the way|how it works|the trick|the secret|what no one|under the hood|the moment|the difference|the gap|the hidden|matters because|the problem is|here[\u2019']s how)\b", tl))),
            'declarative_anchor_count': len(re.findall(r"\b(That is|This is|It is|There is|That[\u2019']s|It[\u2019']s) (the |a |an |where |when |why |how |what |not )", t, re.I)),
            'generic_cta': int(any(g in last_2.lower() for g in ['thoughts?', 'agree?', 'what do you think', 'drop yours', 'let me know.', 'lmk', 'your take?'])),
            'unsupported_earning': int(any(p in tl for p in ['guaranteed', 'passive income', 'get rich', '100x', 'will make you', 'financial freedom'])),
            'has_hype': int(any(p in tl for p in ['game changer', 'this is huge', 'to the moon', 'lfg', 'this is everything'])),
            'slow_opener': int(any(first.lower().startswith(w) for w in ['so ','so,','well,','well ','honestly','just thinking','random thought','been thinking','lately ',"i've been"])),
            'starts_at_or_hash': int(t.strip().startswith(('@', '#'))),
            'ai_signature': int(any(re.search(r"\b" + re.escape(p) + r"\b(?!\w)", tl) for p in ['delve into', 'let\'s unpack', 'in this fast-paced', 'embark on', 'in the realm of', 'in conclusion'])),
        }
    f = extract(text)
    norm = [(f[n] - model['means'][n]) / model['stds'][n] for n in model['feature_names']]
    z = model['bias'] + sum(model['weights'][i] * norm[i] for i in range(len(model['weights'])))
    p = 1/(1+math.exp(-z)) if abs(z)<30 else (1 if z>0 else 0)
    return p

# --- Stream 2: Structural Conformance ---
def stream2_structural(text):
    sents = re.split(r'(?<=[.!?])\s+', text.strip())
    paras = re.split(r'\n\s*\n', text.strip())
    chars = len(text)
    if not sents: return 0.0
    avg = sum(len(s.split()) for s in sents) / len(sents)
    
    score = 0
    # Winner empirical bands
    if 900 <= chars <= 1700: score += 1
    elif 700 <= chars <= 1900: score += 0.6
    
    if 6 <= len(paras) <= 13: score += 1
    elif 4 <= len(paras) <= 15: score += 0.6
    
    if 12 <= len(sents) <= 22: score += 1
    elif 8 <= len(sents) <= 28: score += 0.6
    
    if 9 <= avg <= 15: score += 1
    elif 7 <= avg <= 18: score += 0.6
    
    # First sentence
    first_words = len(sents[0].split())
    if 9 <= first_words <= 18: score += 1
    elif 5 <= first_words <= 25: score += 0.6
    
    return score / 5.0  # 0-1 range

# --- Stream 3: Kill-Pattern Hard Gate ---
def stream3_kill_check(text):
    tl = text.lower()
    last_2_l = "\n\n".join(text.strip().split("\n\n")[-2:]).lower()
    sents = re.split(r'(?<=[.!?])\s+', text.strip())
    first = sents[0].lower() if sents else ""
    
    kills = []
    if any(p in tl for p in ['guaranteed','passive income','get rich','100x','will make you','financial freedom']):
        kills.append("unsupported_earning_claim")
    if any(p in tl for p in ['game changer','this is huge','to the moon','lfg','this is everything']):
        kills.append("hype_phrase")
    if any(g in last_2_l for g in ['thoughts?','agree?','what do you think','drop yours','let me know.','lmk','your take?']):
        kills.append("generic_cta")
    if any(first.startswith(w) for w in ['so ','so,','well,','well ','honestly','just thinking','random thought','been thinking','lately ',"i've been"]):
        kills.append("slow_opener")
    if text.strip().startswith(('@','#')):
        kills.append("starts_at_or_hash")
    if any(re.search(r"\b"+re.escape(p)+r"\b(?!\w)", tl) for p in ['delve into',"let's unpack",'in this fast-paced','embark on','in the realm of','in conclusion']):
        kills.append("ai_signature")
    return len(kills) == 0, kills

# --- Stream 4: Sub-rubric (V8.4 lite) ---
def stream4_subrubric(text, brief=""):
    # Simplified — only check critical sub-rubrics
    tl = text.lower()
    last_2 = "\n\n".join(text.strip().split("\n\n")[-2:])
    paras = re.split(r'\n\s*\n', text.strip())
    
    passes = 0; total = 5
    # CTA quality
    has_q = "?" in last_2
    has_imp = bool(re.search(r"\b(tell me|reply|comment|share|drop|pick|choose|name|visit|check|mint|join|claim|stake|go (?:check|see|stake|visit)|start here|see how|find out)\b", last_2.lower()))
    has_generic = any(g in last_2.lower() for g in ['thoughts?','agree?','what do you think','drop yours','let me know.','lmk','your take?'])
    if (has_q or has_imp) and not has_generic: passes += 1
    
    # Hook
    sents = re.split(r'(?<=[.!?])\s+', text.strip())
    if sents and not any(sents[0].lower().startswith(w) for w in ['so ','so,','well,','honestly']): passes += 1
    
    # Structure
    if 4 <= len(paras) <= 15 and 500 <= len(text) <= 1700: passes += 1
    
    # Value (any signal)
    value_signals = sum([
        bool(re.search(r'\b(actually|wrong|most people|but actually|hardest|not just)\b', tl)),
        bool(re.search(r"\bi (spent|tried|built|saw|watched|did|lost|won|bought|wrote|posted)\b", tl)),
        bool(re.search(r"\b(the way|how it works|the trick|the moment|the difference|the gap|matters because)\b", tl)),
        bool(re.search(r'"[^"]+"', text)),
    ])
    if value_signals >= 2: passes += 1
    
    # Mention compliance
    required = re.findall(r'@\w+', brief) if brief else []
    if not required or all(m.lower() in text.lower() for m in required): passes += 1
    
    return passes / total

# --- Stream 5: Pool overlap (optional, requires campaign address) ---
def fetch_pool(addr):
    try:
        req = urllib.request.Request(f"{API_BASE}/submissions?campaignAddress={addr}", headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.load(r)
    except: return []

def is_winner_in_pool(sub):
    targets = {"Engagement Potential":5,"Technical Quality":5,"Reply Quality":5,
               "Originality and Authenticity":2,"Content Alignment":2,
               "Information Accuracy":2,"Campaign Compliance":2}
    for cat, mx in targets.items():
        m = next((a for a in sub.get("analysis",[]) if a.get("category")==cat), None)
        if not m: continue
        try:
            s = int(int(m.get("atto_score","0"))/10**18)
            if s < mx: return False
        except: return False
    return True

def fetch_tweet(tid):
    try:
        req = urllib.request.Request(f"https://api.fxtwitter.com/x/status/{tid}", headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.read().decode()
    except: return ""

def stream5_pool_overlap(text, campaign_address, max_fetch=50):
    if not campaign_address:
        return None, {"skipped": "no campaign_address"}
    subs = fetch_pool(campaign_address)
    if not subs: return None, {"error": "no submissions fetched"}
    
    winners_subs = [s for s in subs if is_winner_in_pool(s) and not s.get("disqualifiedAt")]
    nonwinners_subs = [s for s in subs if not is_winner_in_pool(s) and not s.get("disqualifiedAt")]
    
    # Fetch some texts
    winner_texts = []
    for w in winners_subs[:20]:
        td = fetch_tweet(w["tweetId"])
        if td:
            try: 
                d = json.loads(td)
                t = d.get('tweet',{}).get('text','')
                if t: winner_texts.append(t)
            except: pass
        time.sleep(0.03)
    
    nonwinner_texts = []
    for nw in nonwinners_subs[:max_fetch]:
        td = fetch_tweet(nw["tweetId"])
        if td:
            try:
                d = json.loads(td)
                t = d.get('tweet',{}).get('text','')
                if t: nonwinner_texts.append(t)
            except: pass
        time.sleep(0.03)
    
    def toks(t): return re.findall(r"\w+", t.lower())
    def grams(ts, n): return set(" ".join(ts[i:i+n]) for i in range(max(0, len(ts)-n+1)))
    
    ct = toks(text)
    cg5 = grams(ct, 5)
    cg7 = grams(ct, 7)
    
    w_overlap = sum(len(cg5 & grams(toks(t), 5)) for t in winner_texts)
    nw_overlap = sum(len(cg5 & grams(toks(t), 5)) for t in nonwinner_texts)
    nw_overlap_7 = sum(len(cg7 & grams(toks(t), 7)) for t in nonwinner_texts)
    
    # Score: low non-winner overlap = good
    if nw_overlap_7 >= 3: score = 0.0
    elif nw_overlap > 20: score = 0.3
    elif nw_overlap > 10: score = 0.6
    else: score = 1.0
    
    return score, {
        "pool_winners_compared": len(winner_texts),
        "pool_nonwinners_compared": len(nonwinner_texts),
        "winner_5gram_overlap": w_overlap,
        "nonwinner_5gram_overlap": nw_overlap,
        "nonwinner_7gram_overlap": nw_overlap_7,
    }

# --- Main pipeline ---
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--brief", default=None)
    ap.add_argument("--campaign-address", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model-path", default=str(MODEL_PATH))
    args = ap.parse_args()
    
    text = Path(args.content).read_text(encoding="utf-8").strip()
    brief = Path(args.brief).read_text(encoding="utf-8") if args.brief and Path(args.brief).exists() else ""
    model = json.load(open(args.model_path))
    
    print("Running 5-stream certainty pipeline...")
    
    # Run all streams
    s1_prob = stream1_statistical(text, model)
    s1_pass = s1_prob >= 0.55
    print(f"  [1] Statistical model: prob={s1_prob:.3f}  {'✓ PASS' if s1_pass else '✗ FAIL'}")
    
    s2_score = stream2_structural(text)
    s2_pass = s2_score >= 0.7
    print(f"  [2] Structural conformance: {s2_score:.2f}  {'✓ PASS' if s2_pass else '✗ FAIL'}")
    
    s3_pass, kills = stream3_kill_check(text)
    print(f"  [3] Kill-pattern check: {len(kills)} kills  {'✓ PASS' if s3_pass else '✗ FAIL — '+','.join(kills)}")
    
    s4_score = stream4_subrubric(text, brief)
    s4_pass = s4_score >= 0.8
    print(f"  [4] Sub-rubric (5 checks): {s4_score:.1%}  {'✓ PASS' if s4_pass else '✗ FAIL'}")
    
    s5_score, s5_info = stream5_pool_overlap(text, args.campaign_address)
    if s5_score is None:
        s5_pass = None
        print(f"  [5] Pool overlap: SKIPPED ({s5_info.get('skipped','error')})")
    else:
        s5_pass = s5_score >= 0.7
        print(f"  [5] Pool overlap: {s5_score:.2f}  {'✓ PASS' if s5_pass else '✗ FAIL — high contamination'}  ({s5_info.get('nonwinner_5gram_overlap',0)} 5-gram hits)")
    
    # Count passes (skip s5 if None)
    streams = [s1_pass, s2_pass, s3_pass, s4_pass]
    if s5_pass is not None:
        streams.append(s5_pass)
    n_pass = sum(1 for s in streams if s)
    n_total = len(streams)
    
    # Decision
    if n_pass == n_total:
        decision = "CERTAIN_SUBMIT"
        confidence = ">90%"
    elif n_pass == n_total - 1:
        decision = "LIKELY_SUBMIT"
        confidence = "75-90%"
    elif n_pass >= n_total - 2:
        decision = "BORDERLINE"
        confidence = "50-75%"
    else:
        decision = "REVISE"
        confidence = "<50%"
    
    print(f"\n{'='*50}")
    print(f"DECISION: {decision}")
    print(f"Streams passed: {n_pass}/{n_total}")
    print(f"Estimated confidence: {confidence}")
    print(f"{'='*50}")
    
    result = {
        "tool": "27_certainty_pipeline.py V9.0",
        "content_chars": len(text),
        "stream_results": {
            "statistical_model_probability": s1_prob,
            "structural_conformance": s2_score,
            "kill_patterns_found": kills,
            "subrubric_pass_rate": s4_score,
            "pool_overlap_score": s5_score,
            "pool_overlap_info": s5_info,
        },
        "streams_passed": n_pass,
        "streams_total": n_total,
        "decision": decision,
        "estimated_confidence": confidence,
        "fixes": [],
    }
    
    if decision != "CERTAIN_SUBMIT":
        fixes = []
        if not s1_pass:
            fixes.append("Statistical model gives <55% probability — review feature contributions")
        if not s2_pass:
            chars = len(text)
            paras = len(re.split(r'\n\s*\n', text.strip()))
            sents = len(re.split(r'(?<=[.!?])\s+', text.strip()))
            avg = sum(len(s.split()) for s in re.split(r'(?<=[.!?])\s+', text.strip()))/max(1,sents)
            if chars < 900: fixes.append(f"Expand to 900-1500 chars (current {chars})")
            if chars > 1700: fixes.append(f"Trim to <1700 chars (current {chars})")
            if paras < 6: fixes.append(f"Add paragraph breaks (current {paras}, target 7-13)")
            if avg > 18: fixes.append(f"Shorten sentences (avg {avg:.0f} words, target 9-15)")
        if not s3_pass:
            for k in kills:
                fix_map = {
                    "unsupported_earning_claim": "REMOVE earning claims (guaranteed/100x/passive income)",
                    "hype_phrase": "Remove hype (game changer/this is huge/to the moon)",
                    "generic_cta": "Replace generic CTA with specific question",
                    "slow_opener": "Rewrite opener (avoid So/Well/Honestly)",
                    "starts_at_or_hash": "Don't start with @ or #",
                    "ai_signature": "Remove AI template phrases (delve into/in conclusion)",
                }
                fixes.append(fix_map.get(k, f"Fix: {k}"))
        if not s4_pass:
            fixes.append("Strengthen sub-rubrics: add value signals, fix CTA, check hook")
        if s5_pass is False:
            fixes.append("High pool overlap — rewrite phrases that appear in non-winners")
        result["fixes"] = fixes
        print(f"\n💡 FIXES NEEDED:")
        for i, f in enumerate(fixes, 1):
            print(f"  {i}. {f}")
    else:
        print(f"\n✅ ALL STREAMS PASS — SUBMIT WITH HIGH CONFIDENCE")
    
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    sys.exit(0 if decision == "CERTAIN_SUBMIT" else 1)

if __name__ == "__main__":
    main()
