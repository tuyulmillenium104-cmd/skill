#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
03_winner_mechanism_map.py — V8.0
Extract MECHANISM (not just surface) from winner submissions.
Closes V7.7 CELAH #4 (winner-mining surface only).

Mechanism classes:
  NAMED_CONCEPT, CONTRARIAN_VERDICT, MECHANISM_REVEAL,
  RESOURCE_ROUTING, VULNERABLE_SCENE, DATA_FRAME, CATEGORY_CREATION

Usage:
  python3 03_winner_mechanism_map.py \
    --submissions rally-data/learn/<addr>/submissions_enriched.json \
    --out winner-mechanism.json \
    --out-md WINNER-MECHANISM.md

Output: top-3 mechanism wajib-pakai untuk mission ini.
"""
import argparse, json, re, sys
from collections import Counter
from pathlib import Path

# Detection heuristics per mechanism
def detect_named_concept(text):
    """Look for noun-phrase labels: 'X is Y, not Z' OR quoted/emphasized 2-4 word concept."""
    hits = []
    # X is Y, not Z pattern
    for m in re.finditer(r'\b(\w[\w\s-]{2,30})\s+is\s+(\w[\w\s-]{2,30}),?\s+not\s+(\w[\w\s-]{2,30})', text, re.I):
        hits.append({"type": "X-is-Y-not-Z", "match": m.group(0)[:80]})
    # quoted concept
    for m in re.finditer(r'"([^"]{4,40})"', text):
        if len(m.group(1).split()) <= 5:
            hits.append({"type": "quoted-concept", "match": m.group(1)})
    return hits

def detect_contrarian_verdict(text):
    hits = []
    patterns = [
        r"\b(verdict|hot take|unpopular opinion|truth is|actually false|the real)\b",
        r"\b(everyone says|everyone thinks|popular opinion|conventional wisdom)\b.{0,40}\b(but|however|actually|wrong)\b",
        r"\b(not\s+\w+,?\s+but\s+\w+)\b",
        r"\b(cooked|mid|genius|overrated|underrated)\b",
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, re.I):
            hits.append({"pattern": pat, "match": m.group(0)[:80]})
    return hits

def detect_mechanism_reveal(text):
    hits = []
    patterns = [
        r"\b(the way .{1,20} actually works?)\b",
        r"\b(what no one explains?)\b",
        r"\b(the hidden|the trick is|the secret is|here[\'’]s how)\b",
        r"\b(under the hood|behind the scenes)\b",
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, re.I):
            hits.append({"pattern": pat, "match": m.group(0)[:80]})
    return hits

def detect_resource_routing(text):
    hits = []
    patterns = [
        r"\b(what would you spend|where would you put|how would you allocate)\b",
        r"\b(first .{1,15}, then .{1,15})\b",
        r"\b(\d+%\s*\w+,?\s*\d+%)\b",  # 70/20/10 split
        r"\b(prioriti[sz]e|allocate|budget|split)\b.{0,30}\b(time|money|attention|rlp|points)\b",
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, re.I):
            hits.append({"pattern": pat, "match": m.group(0)[:80]})
    return hits

def detect_vulnerable_scene(text):
    hits = []
    # first-person past + specific time-place
    patterns = [
        r"\b(last\s+(tuesday|monday|week|month|night)|two weeks ago|yesterday|3am|2am|midnight)\b",
        r"\b(i\s+(refreshed|checked|called|texted|sat|stared|felt|cried|laughed))\b",
        r"\b(my\s+(partner|wife|husband|friend|kid|dad|mom|boss|teammate))\b",
    ]
    scene_hits = 0
    for pat in patterns:
        for m in re.finditer(pat, text, re.I):
            hits.append({"pattern": pat, "match": m.group(0)[:80]})
            scene_hits += 1
    # need at least 2 of these for it to be a "vulnerable scene"
    return hits if scene_hits >= 2 else []

def detect_data_frame(text):
    hits = []
    # numbers with units or comparison
    patterns = [
        r"\b(\d+)\s*(submissions|winners|%|x more|x less|users|subs)\b",
        r"\b(\d+(?:\.\d+)?\s*%)\b",
        r"\b(\d+x\s+(more|less|faster|cheaper))\b",
    ]
    n_hits = 0
    for pat in patterns:
        for m in re.finditer(pat, text, re.I):
            hits.append({"pattern": pat, "match": m.group(0)[:80]})
            n_hits += 1
    return hits if n_hits >= 2 else []

def detect_category_creation(text):
    hits = []
    patterns = [
        r"\bthere are (two|three|2|3|four|4) (types|kinds|modes|categories)\b",
        r"\b(\w+)\s+has\s+(\d+|two|three)\s+(modes|kinds|types|levels)\b",
        r"\bi split\s+\w+\s+into\b",
    ]
    for pat in patterns:
        for m in re.finditer(pat, text, re.I):
            hits.append({"pattern": pat, "match": m.group(0)[:80]})
    return hits

MECHANISMS = {
    "NAMED_CONCEPT":     detect_named_concept,
    "CONTRARIAN_VERDICT": detect_contrarian_verdict,
    "MECHANISM_REVEAL":  detect_mechanism_reveal,
    "RESOURCE_ROUTING":  detect_resource_routing,
    "VULNERABLE_SCENE":  detect_vulnerable_scene,
    "DATA_FRAME":        detect_data_frame,
    "CATEGORY_CREATION": detect_category_creation,
}

def is_all_max(sub):
    """Detect ALL-MAX winner from scores or judge praise."""
    scores = sub.get("scores") or sub.get("gateScores") or {}
    if scores:
        # check if all major gates are max (5 or 2 depending on rubric)
        max_count = 0; total = 0
        for k, v in scores.items():
            if isinstance(v, (int, float)):
                total += 1
                if v >= 5 or v >= 2:  # handle both 0-5 and 0-2 scales
                    max_count += 1
        return total > 0 and max_count == total
    # fallback: winner flag + judge praise vocab
    if sub.get("winner") or sub.get("isWinner"):
        analysis = (sub.get("analysis") or "").lower()
        praise = ["exceptional", "exemplary", "masterful", "outstanding", "flawless", "perfect"]
        return any(p in analysis for p in praise)
    return False

def is_winner(sub):
    return bool(sub.get("winner") or sub.get("isWinner") or is_all_max(sub))

def extract_mechanisms(text):
    found = {}
    for mname, fn in MECHANISMS.items():
        hits = fn(text)
        if hits:
            found[mname] = hits[:3]  # keep top 3 hits per mechanism
    return found

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--submissions", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--out-md", default=None)
    ap.add_argument("--require-all-max", action="store_true", default=False,
                    help="Only analyze ALL-MAX winners (default: all winners)")
    args = ap.parse_args()

    subs = json.load(open(args.submissions, encoding="utf-8"))
    if not isinstance(subs, list):
        print("ERROR: submissions must be a JSON list", file=sys.stderr)
        sys.exit(2)

    if args.require_all_max:
        target = [s for s in subs if is_all_max(s)]
        target_label = "ALL-MAX winners"
    else:
        target = [s for s in subs if is_winner(s)]
        target_label = "winners (any)"

    if not target:
        # fallback to top-scoring 10
        scored = [(s, sum((v if isinstance(v, (int, float)) else 0)
                          for v in (s.get("scores") or {}).values())) for s in subs]
        scored.sort(key=lambda x: -x[1])
        target = [s for s, _ in scored[:10]]
        target_label = "top-10 by score sum (fallback)"

    mechanism_counter = Counter()
    per_winner = []
    for w in target:
        content = w.get("content") or ""
        if not content.strip():
            continue
        found = extract_mechanisms(content)
        per_winner.append({
            "author": w.get("xUsername") or w.get("author"),
            "tweetId": w.get("tweetId"),
            "scores": w.get("scores") or w.get("gateScores"),
            "mechanisms": list(found.keys()),
            "samples": {m: hits[0] for m, hits in found.items()},
        })
        for m in found:
            mechanism_counter[m] += 1

    top3 = mechanism_counter.most_common(3)
    n_target = len(per_winner)

    result = {
        "tool": "03_winner_mechanism_map.py",
        "version": "V8.0",
        "target_label": target_label,
        "n_winners_analyzed": n_target,
        "mechanism_distribution": dict(mechanism_counter),
        "top_3_mechanisms": [
            {
                "rank": i+1,
                "name": m,
                "count": c,
                "ratio": round(c / max(1, n_target), 2),
                "examples": [pw["samples"].get(m) for pw in per_winner if m in pw["samples"]][:3],
            }
            for i, (m, c) in enumerate(top3)
        ],
        "per_winner_breakdown": per_winner,
        "instruction_for_drafts": (
            f"Both Candidate A and Candidate B MUST embed at least 1 mechanism from the top-3. "
            f"Verifiable: the embed must be quoteable in 1 sentence from the draft."
        ),
    }

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    if args.out_md:
        md = f"""# WINNER MECHANISM MAP — V8.0

**Target analyzed:** {target_label} (n={n_target})

## Top-3 Mechanism (use ≥1 in both drafts)

"""
        for entry in result["top_3_mechanisms"]:
            md += f"### {entry['rank']}. {entry['name']}  (n={entry['count']}, ratio={entry['ratio']})\n\n"
            for ex in entry["examples"]:
                if ex:
                    md += f"- `{ex.get('match', ex)}`\n"
            md += "\n"
        md += "## Distribution\n```json\n"
        md += json.dumps(result["mechanism_distribution"], indent=2)
        md += "\n```\n\n## Instruction\n" + result["instruction_for_drafts"] + "\n"
        Path(args.out_md).write_text(md, encoding="utf-8")

    print(f"WINNER MECHANISM MAP: analyzed {n_target} {target_label}")
    print("TOP-3 MECHANISM:")
    for entry in result["top_3_mechanisms"]:
        print(f"  {entry['rank']}. {entry['name']}  n={entry['count']}  ratio={entry['ratio']}")
    print(f"INSTRUCTION: {result['instruction_for_drafts']}")
    sys.exit(0)

if __name__ == "__main__":
    main()
