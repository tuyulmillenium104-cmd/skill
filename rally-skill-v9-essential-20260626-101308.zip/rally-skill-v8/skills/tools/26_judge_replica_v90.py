#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
26_judge_replica_v90.py — V9.0 LOGISTIC REGRESSION TRAINED MODEL

Trained on 1,146 labeled samples (461 EP=5 winners + 685 EP=4/LOW non-winners).
Uses 18 empirically-validated features with learned weights.

Threshold modes:
  - STRICT (0.85): 100% PRECISION (validated on held-out test set)
                   ~4% recall — only catches strongest winners
                   Use when "kepastian" is mandatory
  - HIGH (0.80):   87% precision, 6% recall
  - BALANCED (0.50): 72% precision, 61% recall
  - LENIENT (0.40): 68% precision, 73% recall

Usage:
  python3 26_judge_replica_v90.py --content draft.txt --threshold strict --out pred.json
"""
import argparse, json, re, sys, statistics, math
from pathlib import Path

MODEL_PATH = Path(__file__).parent.parent.parent / "jfr-data-full" / "logistic_model.json"

# Threshold modes
THRESHOLDS = {
    "strict": (0.85, "100% PRECISION on validation — RECOMMENDED for kepastian"),
    "high":   (0.80, "87% precision — high confidence"),
    "balanced": (0.50, "72% precision, balanced"),
    "lenient":(0.40, "68% precision — catches more winners"),
}

def extract_features(text):
    tl = text.lower()
    sents = re.split(r'(?<=[.!?])\s+', text.strip())
    paras = re.split(r'\n\s*\n', text.strip())
    last_2 = "\n\n".join(text.strip().split("\n\n")[-2:])
    last_2_unq = re.sub(r'"[^"]*"', '', last_2)
    last_2_unq = re.sub(r"[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]", '', last_2_unq)
    last_1 = text.strip().split("\n\n")[-1] if text.strip() else ""
    first_sent = sents[0] if sents else ""
    
    return {
        'chars': len(text),
        'sents': len(sents),
        'paras': len(paras),
        'last_para_words': len(last_1.split()),
        'qmark_unq_last2p': last_2_unq.count('?'),
        'qmark_total': text.count('?'),
        'quoted': int(bool(re.search(r'"[^"]+"', text)) or bool(re.search(r'[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]', text))),
        'qa_rhythm_count': len(re.findall(r"\b(Did|Does|Is|Are|What|How|Why|When|Where|Can|Could|Should|Would)\b[^?]{1,80}\?", text)),
        'contrarian': int(bool(re.search(r'\b(actually|verdict|wrong|most people|everyone says|but actually|the truth|unpopular|broken|cooked|mid|fake|struggle|hardest|not just)\b', tl))),
        'personal_specific': int(bool(re.search(r"\bi (was|spent|tried|built|saw|watched|remember|used|did|lost|won|hired|bought|wrote|posted|sent|paid|started)\b", tl))),
        'mechanism_reveal': int(bool(re.search(r"\b(the way|how it works|the trick|the secret|what no one|under the hood|the moment|the difference|the gap|the hidden|matters because|the problem is|here[\u2019']s how)\b", tl))),
        'declarative_anchor_count': len(re.findall(r"\b(That is|This is|It is|There is|That[\u2019']s|It[\u2019']s) (the |a |an |where |when |why |how |what |not )", text, re.I)),
        'generic_cta': int(any(g in last_2.lower() for g in ['thoughts?', 'agree?', 'what do you think', 'drop yours', 'let me know.', 'lmk', 'your take?'])),
        'unsupported_earning': int(any(p in tl for p in ['guaranteed', 'passive income', 'get rich', '100x', 'will make you', 'financial freedom'])),
        'has_hype': int(any(p in tl for p in ['game changer', 'this is huge', 'to the moon', 'lfg', 'this is everything'])),
        'slow_opener': int(any(first_sent.lower().startswith(w) for w in ['so ','so,','well,','well ','honestly','just thinking','random thought','been thinking','lately ',"i've been"])),
        'starts_at_or_hash': int(text.strip().startswith(('@', '#'))),
        'ai_signature': int(any(re.search(r"\b" + re.escape(p) + r"\b(?!\w)", tl) for p in ['delve into', 'let\'s unpack', 'in this fast-paced', 'embark on', 'in the realm of', 'in conclusion'])),
    }

def sigmoid(z):
    if z > 30: return 1.0
    if z < -30: return 0.0
    return 1/(1+math.exp(-z))

def predict_probability(text, model):
    f = extract_features(text)
    norm = [(f[name] - model['means'][name]) / model['stds'][name] for name in model['feature_names']]
    z = model['bias'] + sum(model['weights'][i] * norm[i] for i in range(len(model['weights'])))
    return sigmoid(z), f

def diagnose_low_score(f, model):
    """Return list of features pulling score down."""
    issues = []
    norm_contrib = []
    for i, name in enumerate(model['feature_names']):
        normed = (f[name] - model['means'][name]) / model['stds'][name]
        contrib = model['weights'][i] * normed
        norm_contrib.append((name, contrib, f[name]))
    # negative contributions = need fixing
    norm_contrib.sort(key=lambda x: x[1])
    return norm_contrib

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--brief", default=None)
    ap.add_argument("--threshold", default="strict", choices=list(THRESHOLDS.keys()))
    ap.add_argument("--out", required=True)
    ap.add_argument("--model-path", default=str(MODEL_PATH))
    args = ap.parse_args()
    
    model = json.load(open(args.model_path))
    text = Path(args.content).read_text(encoding="utf-8").strip()
    
    prob, features = predict_probability(text, model)
    thr_value, thr_desc = THRESHOLDS[args.threshold]
    decision = "SUBMIT" if prob >= thr_value else "REVISE"
    
    contributions = diagnose_low_score(features, model)
    
    result = {
        "tool": "26_judge_replica_v90.py V9.0",
        "content_chars": len(text),
        "probability_all_max": round(prob, 4),
        "threshold_mode": args.threshold,
        "threshold_value": thr_value,
        "threshold_description": thr_desc,
        "decision": decision,
        "features": features,
        "top_negative_contributors": [{"feature":n, "contribution":round(c,3), "value":v} for n,c,v in contributions[:8]],
        "top_positive_contributors": [{"feature":n, "contribution":round(c,3), "value":v} for n,c,v in contributions[-8:][::-1]],
    }
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    
    print(f"\n═══ JUDGE REPLICA V9.0 — {decision} ═══")
    print(f"Probability ALL-MAX: {prob*100:.1f}%")
    print(f"Threshold: {args.threshold} ({thr_value:.2f}) — {thr_desc}")
    print(f"\nTop POSITIVE contributors (good):")
    for c in result['top_positive_contributors']:
        if c['contribution'] > 0:
            print(f"  + {c['contribution']:+.3f}  {c['feature']:30s} value={c['value']}")
    print(f"\nTop NEGATIVE contributors (need fixing):")
    for c in result['top_negative_contributors']:
        if c['contribution'] < 0:
            print(f"  - {c['contribution']:+.3f}  {c['feature']:30s} value={c['value']}")
    
    if decision == "REVISE":
        print(f"\n💡 RECOMMENDATIONS:")
        # specific fixes based on top negatives
        for c in result['top_negative_contributors'][:5]:
            if c['contribution'] >= 0: continue
            name = c['feature']
            v = c['value']
            if name == 'qmark_unq_last2p' and v == 0:
                print(f"  - Add a SPECIFIC question (?) in last 2 paragraphs")
            elif name == 'paras' and v < 6:
                print(f"  - Break into more paragraphs (current {v}, target 8-13)")
            elif name == 'sents' and v < 12:
                print(f"  - Expand content (current {v} sentences, target 14-22)")
            elif name == 'chars' and v < 800:
                print(f"  - Expand to long-form (current {v} chars, winner avg 1051)")
            elif name == 'last_para_words' and v > 25:
                print(f"  - Shorten last paragraph (current {v} words, winner avg 17)")
            elif name == 'generic_cta' and v == 1:
                print(f"  - Remove generic CTA (thoughts?/agree?/drop yours)")
            elif name == 'has_hype' and v == 1:
                print(f"  - Remove hype phrases (game changer/this is huge)")
            elif name == 'unsupported_earning' and v == 1:
                print(f"  - REMOVE earning claims (guaranteed/100x/passive income)")
            elif name == 'slow_opener' and v == 1:
                print(f"  - Rewrite opener (avoid So/Well/Honestly start)")
            elif name == 'starts_at_or_hash' and v == 1:
                print(f"  - Don't start with @ or #")
    
    sys.exit(0 if decision == "SUBMIT" else 1)

if __name__ == "__main__":
    main()
