#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
22_full_pipeline.py — V8.4 ALL-IN-ONE
Full end-to-end pipeline:
  1. Fetch campaign pool (if address given)
  2. Pool overlap analysis vs winners/non-winners
  3. Sub-rubric replica V8.4 prediction
  4. Auto-revision suggestions with concrete fixes

Usage:
  python3 22_full_pipeline.py --content draft.txt --brief brief.txt --campaign-address 0xADDR
  python3 22_full_pipeline.py --content draft.txt --brief brief.txt  (skip pool fetch)

Exit 0 = predicted ALL-MAX, safe to submit (97% precision)
Exit 1 = REVISE — specific conditions listed
"""
import argparse, json, re, sys, urllib.request, time, importlib.util
from pathlib import Path

API_BASE = "https://app.rally.fun/api"

def fetch_submissions(addr):
    try:
        req = urllib.request.Request(f"{API_BASE}/submissions?campaignAddress={addr}", headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as r:
            d = json.load(r)
        return d if isinstance(d, list) else d.get("submissions", [])
    except Exception as e:
        print(f"[!] Fetch error: {e}", file=sys.stderr)
        return []

def fetch_tweet(tid):
    try:
        req = urllib.request.Request(f"https://api.fxtwitter.com/x/status/{tid}", headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=6) as r:
            return json.load(r).get("tweet",{}).get("text","")
    except: return ""

def is_winner(sub):
    """Detect if submission is ALL-MAX winner."""
    if sub.get("disqualifiedAt"): return False
    targets = {"Engagement Potential":5,"Technical Quality":5,"Reply Quality":5,
               "Originality and Authenticity":2,"Content Alignment":2,
               "Information Accuracy":2,"Campaign Compliance":2}
    for cat, mx in targets.items():
        match = next((a for a in sub.get("analysis",[]) if a.get("category")==cat), None)
        if not match: return False
        try:
            s = int(int(match.get("atto_score","0"))/10**18)
            if s < mx: return False
        except: return False
    return True

def compute_pool_overlap(text, winner_texts, nonwinner_texts):
    def toks(t): return re.findall(r"\w+", t.lower())
    def grams(ts, n): return set(" ".join(ts[i:i+n]) for i in range(max(0, len(ts)-n+1)))
    ct = toks(text)
    out = {}
    for n in [5, 6, 7]:
        cg = grams(ct, n)
        w_hits = []
        nw_hits = []
        for wt in winner_texts:
            for ph in (cg & grams(toks(wt), n)): w_hits.append(ph)
        for nwt in nonwinner_texts:
            for ph in (cg & grams(toks(nwt), n)): nw_hits.append(ph)
        unique_w = set(w_hits)
        unique_nw = set(nw_hits)
        loser_only = sorted(unique_nw - unique_w)
        out[f"{n}gram"] = {
            "winner_hits": len(w_hits),
            "nonwinner_hits": len(nw_hits),
            "loser_only_phrases": loser_only,
        }
    # Aggregate
    total_loser = len(out["5gram"]["loser_only_phrases"]) + len(out["6gram"]["loser_only_phrases"]) + len(out["7gram"]["loser_only_phrases"])
    total_nw_hits = sum(out[f"{n}gram"]["nonwinner_hits"] for n in [5,6,7])
    if total_loser >= 5 or total_nw_hits > 25:
        decision = "HIGH_CONTAMINATION"
    elif total_loser >= 3 or total_nw_hits > 15:
        decision = "MODERATE_CONTAMINATION"
    else:
        decision = "CLEAN"
    return {"per_ngram": out, "total_loser_phrases": total_loser, "total_nw_hits": total_nw_hits, "decision": decision}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--brief", default=None)
    ap.add_argument("--campaign-address", default=None)
    ap.add_argument("--max-pool-fetch", type=int, default=80, help="Max tweets to fetch from pool")
    ap.add_argument("--out", default="full_pipeline_report.json")
    args = ap.parse_args()
    
    text = Path(args.content).read_text(encoding="utf-8").strip()
    brief = Path(args.brief).read_text(encoding="utf-8") if args.brief and Path(args.brief).exists() else ""
    
    print(f"═══ RALLY V8.4 FULL PIPELINE ═══")
    print(f"Content: {args.content} ({len(text)} chars)")
    print(f"Brief: {args.brief or '(none)'}")
    print()
    
    # === STEP 1: Pool overlap ===
    pool_overlap_obj = None
    pool_overlap_for_replica = None
    if args.campaign_address:
        print(f"[1] Fetching pool for {args.campaign_address[:14]}…")
        subs = fetch_submissions(args.campaign_address)
        winners_subs = [s for s in subs if is_winner(s)]
        nonwinners_subs = [s for s in subs if not is_winner(s) and not s.get("disqualifiedAt")]
        print(f"    Pool: {len(subs)} total, {len(winners_subs)} winners, {len(nonwinners_subs)} non-winners")
        
        print(f"    Fetching texts (cap {args.max_pool_fetch})…")
        winner_texts = []
        for w in winners_subs[:30]:
            t = fetch_tweet(w["tweetId"])
            if t and len(t) > 100: winner_texts.append(t)
            time.sleep(0.05)
        nonwinner_texts = []
        for nw in nonwinners_subs[:args.max_pool_fetch]:
            t = fetch_tweet(nw["tweetId"])
            if t and len(t) > 100: nonwinner_texts.append(t)
            time.sleep(0.05)
        print(f"    Fetched {len(winner_texts)} winner + {len(nonwinner_texts)} non-winner texts")
        
        if nonwinner_texts:
            pool_overlap_obj = compute_pool_overlap(text, winner_texts, nonwinner_texts)
            pool_overlap_for_replica = {"nonwinner_overlap_5gram": pool_overlap_obj["total_loser_phrases"]}
            print(f"    Overlap: {pool_overlap_obj['decision']} ({pool_overlap_obj['total_loser_phrases']} loser-only phrases)")
    else:
        print("[1] Pool overlap skipped (no --campaign-address)")
    
    # === STEP 2: Replica V8.4 ===
    print(f"\n[2] Running judge replica V8.4…")
    spec = importlib.util.spec_from_file_location("r", str(Path(__file__).parent / "21_judge_replica_v84.py"))
    r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
    
    scores, detail, features = r.predict_scores(text, brief, pool_overlap_for_replica)
    missing = r.diagnose(scores, detail)
    targets = r.CATEGORY_MAX
    all_max = all(scores[c] >= targets[c] for c in scores)
    
    # === STEP 3: Output ===
    print(f"\n═══ SCORES ═══")
    for cat, sc in scores.items():
        mx = targets[cat]
        passed = detail[cat]["sub_passed"]
        marker = "✓" if sc >= mx else "✗"
        print(f"  {marker} {cat:35s} {sc}/{mx}  (sub-rubrics: {passed}/5)")
    
    decision = "SUBMIT" if all_max else "REVISE"
    print(f"\n═══ DECISION: {decision} ═══")
    
    if all_max:
        print("\n✅ ALL 35 sub-rubrics passed at MAX threshold")
        print("   Empirical confidence: 97% precision (3% inherent judge ambiguity)")
        if pool_overlap_obj and pool_overlap_obj["decision"] != "CLEAN":
            print(f"\n⚠️  Pool overlap warning: {pool_overlap_obj['decision']}")
            print(f"   Consider rewriting these loser-DNA phrases:")
            for p in pool_overlap_obj["per_ngram"]["5gram"]["loser_only_phrases"][:8]:
                print(f"     - '{p}'")
    else:
        print(f"\n⚠️  {len(missing)} SUB-RUBRIC(S) FAILING:")
        for m in missing:
            print(f"  · [{m['category']}] {m['sub_rubric']}")
            print(f"      → {m['reason']}")
        
        # Provide concrete fixes
        print(f"\n=== CONCRETE FIX SUGGESTIONS ===")
        fixes = []
        feats = features
        if feats["chars"] < 700:
            fixes.append(f"Expand content from {feats['chars']} to 700-1500 chars (winner range)")
        if feats["chars"] > 1700:
            fixes.append(f"Trim from {feats['chars']} to <1700 chars (>1700 triggers 'reduces digestibility')")
        if feats["paras"] < 4:
            fixes.append(f"Add paragraph breaks: from {feats['paras']} to 5-12 paragraphs")
        if feats["paras"] > 15:
            fixes.append(f"Consolidate: from {feats['paras']} to 5-12 paragraphs")
        if feats["has_slow_opener"]:
            fixes.append("Replace slow opener (So/Well/Honestly) with declarative statement")
        if feats["has_generic_cta"]:
            fixes.append("Replace generic CTA (thoughts?/agree?/drop yours) with specific question")
        if not feats["has_q_in_last2p"] and not feats["has_imperative_in_last2p"]:
            fixes.append("Add ? or imperative verb in last 2 paragraphs (mandatory)")
        if feats["has_q_in_last2p"] and not feats["has_specific_cta"]:
            fixes.append("Make question SPECIFIC: 'What X would you Y?' / 'Which X do you think Y?'")
        if not feats["has_contrarian"] and not feats["has_named_concept"] and not feats["has_mechanism_reveal"]:
            fixes.append("Add value signal: contrarian framing OR named concept OR mechanism reveal")
        if feats["has_unsupported_earning"]:
            fixes.append("REMOVE earning claims (guaranteed/100x/passive income) — auto IA fail")
        if feats["has_hype"]:
            fixes.append("Replace hype phrases (game changer/this is huge) with specific value")
        if feats["ai_signature"]:
            fixes.append("Remove AI-template phrases (delve into/let's unpack/in conclusion)")
        
        for i, fix in enumerate(fixes, 1):
            print(f"  {i}. {fix}")
    
    # Save full report
    report = {
        "tool": "22_full_pipeline.py V8.4",
        "content_chars": len(text),
        "scores": scores,
        "category_detail": detail,
        "missing_sub_rubrics": missing,
        "pool_overlap": pool_overlap_obj,
        "decision": decision,
        "all_max_predicted": all_max,
        "precision_confidence": 0.97 if all_max else None,
    }
    Path(args.out).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nFull report saved: {args.out}")
    sys.exit(0 if all_max else 1)

if __name__ == "__main__":
    main()
