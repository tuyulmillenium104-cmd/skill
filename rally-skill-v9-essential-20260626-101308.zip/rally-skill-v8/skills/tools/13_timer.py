#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
13_timer.py — V8.0
Wall-clock budget tracker. Closes V7.7 CELAH #11.

Usage:
  python3 13_timer.py start --budget 14400 --state-file .timer.json
  python3 13_timer.py status --state-file .timer.json
  python3 13_timer.py stop --state-file .timer.json
"""
import argparse, json, sys, time
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["start","status","stop"])
    ap.add_argument("--budget", type=int, default=14400, help="Budget seconds (default 4h)")
    ap.add_argument("--state-file", default=".rally-timer.json")
    args = ap.parse_args()

    sf = Path(args.state_file)
    now = time.time()

    if args.action == "start":
        sf.write_text(json.dumps({"start": now, "budget_sec": args.budget}), encoding="utf-8")
        print(f"TIMER STARTED — budget {args.budget}s ({args.budget/3600:.1f}h)")
        sys.exit(0)

    if not sf.exists():
        print("ERROR: timer not started.", file=sys.stderr); sys.exit(2)
    state = json.loads(sf.read_text(encoding="utf-8"))
    elapsed = now - state["start"]
    remaining = state["budget_sec"] - elapsed
    pct = elapsed / state["budget_sec"] * 100

    if args.action == "status":
        mode = "NORMAL"
        if pct >= 100: mode = "OVER_BUDGET"
        elif pct >= 75: mode = "FAST_PATH"
        elif pct >= 50: mode = "WATCH"
        print(f"TIMER: elapsed={elapsed:.0f}s ({pct:.1f}%), remaining={remaining:.0f}s, mode={mode}")
        sys.exit(0)

    if args.action == "stop":
        print(f"TIMER STOPPED — total elapsed {elapsed:.0f}s ({elapsed/60:.1f} min)")
        sf.unlink()
        sys.exit(0)

if __name__ == "__main__":
    main()
