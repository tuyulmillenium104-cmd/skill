#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
14_judge_harvester.py — V8.1
Real Rally API mining: fetch ALL submissions across active campaigns and
extract per-sub-rubric MAX vs non-MAX verdict verbatim.

Goal: build judge-function dataset for replica training.

Categories (qualitative, judged by LLM):
  - Originality and Authenticity  (max 2)
  - Content Alignment             (max 2)
  - Information Accuracy          (max 2)
  - Campaign Compliance           (max 2)
  - Engagement Potential          (max 5)
  - Technical Quality             (max 5)
  - Reply Quality                 (max 5)

Output:
  jfr-data/raw/<campaign_addr>.json              full enriched
  jfr-data/per-category/<category>_MAX.jsonl     one row per MAX verdict (qualitative cats only)
  jfr-data/per-category/<category>_NEAR.jsonl    score = max-1
  jfr-data/per-category/<category>_LOW.jsonl     score <= max-2
  jfr-data/summary.json                          stats

Usage:
  python3 14_judge_harvester.py --out-dir jfr-data --max-campaigns 50 --max-pages 10
"""
import argparse, json, os, sys, time, urllib.request, urllib.parse
from pathlib import Path

API_BASE = "https://app.rally.fun/api"
QUAL_CATS = {
    "Originality and Authenticity": 2,
    "Content Alignment":            2,
    "Information Accuracy":         2,
    "Campaign Compliance":          2,
    "Engagement Potential":         5,
    "Technical Quality":            5,
    "Reply Quality":                5,
}
WEI = 10**18

def fetch_json(url, timeout=20, retries=3):
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent":"rally-jfr/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.load(r)
        except Exception as e:
            if attempt == retries-1: raise
            time.sleep(1 + attempt)
    return None

def fetch_all_campaigns(max_pages=30):
    out = []
    for page in range(1, max_pages+1):
        url = f"{API_BASE}/campaigns?page={page}&limit=10"
        try:
            d = fetch_json(url)
        except Exception as e:
            print(f"  campaigns page {page} error: {e}", file=sys.stderr)
            break
        camps = d.get("campaigns", []) if isinstance(d, dict) else d
        if not camps: break
        out.extend(camps)
        if isinstance(d, dict) and not d.get("pagination",{}).get("hasNext"):
            break
    return out

def fetch_submissions(campaign_address):
    url = f"{API_BASE}/submissions?campaignAddress={urllib.parse.quote(campaign_address)}"
    try:
        d = fetch_json(url, timeout=30)
        if isinstance(d, list): return d
        if isinstance(d, dict): return d.get("submissions", [])
    except Exception as e:
        print(f"  submissions {campaign_address[:10]} error: {e}", file=sys.stderr)
    return []

def fetch_tweet_text(tweet_id, timeout=15):
    """Try syndication API for tweet content."""
    url = f"https://cdn.syndication.twimg.com/tweet-result?id={tweet_id}&token=a"
    try:
        d = fetch_json(url, timeout=timeout, retries=2)
        if isinstance(d, dict):
            return d.get("text") or d.get("full_text")
    except Exception:
        pass
    return None

def normalize_score(atto):
    """Convert wei-scaled score to int. Returns int or None."""
    try:
        return int(int(atto) / WEI)
    except (ValueError, TypeError):
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default="jfr-data")
    ap.add_argument("--max-campaigns", type=int, default=50)
    ap.add_argument("--max-pages", type=int, default=30)
    ap.add_argument("--fetch-tweet-text", action="store_true",
                    help="Slow: fetch full tweet text via syndication (best-effort)")
    ap.add_argument("--campaigns-cache", default=None,
                    help="Pre-fetched campaigns.json (skip API)")
    args = ap.parse_args()

    od = Path(args.out_dir)
    (od/"raw").mkdir(parents=True, exist_ok=True)
    (od/"per-category").mkdir(parents=True, exist_ok=True)

    print(f"[1/3] Fetching campaigns (max {args.max_pages} pages)…")
    if args.campaigns_cache and Path(args.campaigns_cache).exists():
        camps = json.load(open(args.campaigns_cache))
    else:
        camps = fetch_all_campaigns(args.max_pages)
        Path(od/"campaigns.json").write_text(json.dumps(camps, indent=2), encoding="utf-8")
    print(f"      {len(camps)} campaigns found.")

    camps = camps[:args.max_campaigns]
    print(f"[2/3] Fetching submissions for {len(camps)} campaigns…")

    # Open per-category JSONL writers
    writers = {}
    for cat in QUAL_CATS:
        for tier in ["MAX","NEAR","LOW"]:
            key = (cat, tier)
            slug = cat.replace(" ","_") + "_" + tier
            writers[key] = open(od/"per-category"/f"{slug}.jsonl", "w", encoding="utf-8")

    total_subs = 0
    total_verdicts = 0
    per_cat_counts = {cat:{"MAX":0,"NEAR":0,"LOW":0} for cat in QUAL_CATS}
    all_max_winners = []

    for i, c in enumerate(camps, 1):
        addr = c.get("intelligentContractAddress") or c.get("address")
        title = c.get("title","?")
        if not addr: continue
        print(f"  [{i:>3}/{len(camps)}] {title[:50]:50s} {addr[:10]}…", end="", flush=True)
        subs = fetch_submissions(addr)
        if not subs:
            print(" 0 subs")
            continue
        total_subs += len(subs)

        # Save raw
        Path(od/"raw"/f"{addr}.json").write_text(json.dumps(subs, indent=2), encoding="utf-8")

        n_all_max = 0
        # Get mission descriptions
        missions = {}
        for s in subs:
            m = s.get("mission")
            if isinstance(m, dict) and m.get("id"):
                missions[m["id"]] = m

        for s in subs:
            if s.get("disqualifiedAt") or s.get("invalidatedAt"): continue
            analysis = s.get("analysis")
            if not isinstance(analysis, list): continue

            mission_id = s.get("missionId","?")
            mission = missions.get(mission_id, {})
            brief = (mission.get("description","") + "\n\nRULES:\n" + mission.get("rules","")).strip()

            qual_scores = {}
            for entry in analysis:
                cat = entry.get("category")
                if cat not in QUAL_CATS: continue
                sc = normalize_score(entry.get("atto_score"))
                mx = normalize_score(entry.get("atto_max_score"))
                expected_max = QUAL_CATS[cat]
                if mx is None: mx = expected_max
                if sc is None: continue
                qual_scores[cat] = (sc, mx)
                verdict_text = entry.get("analysis","").strip()

                # tier classification
                if sc >= expected_max:
                    tier = "MAX"
                elif sc >= expected_max - 1:
                    tier = "NEAR"
                else:
                    tier = "LOW"

                row = {
                    "campaign": title,
                    "campaign_address": addr,
                    "mission_id": mission_id,
                    "brief": brief[:2000],
                    "author": s.get("xUsername"),
                    "tweet_id": s.get("tweetId"),
                    "category": cat,
                    "score": sc,
                    "max_score": expected_max,
                    "tier": tier,
                    "verdict": verdict_text,
                }
                writers[(cat, tier)].write(json.dumps(row, ensure_ascii=False) + "\n")
                per_cat_counts[cat][tier] += 1
                total_verdicts += 1

            # check ALL-MAX (all qualitative categories present and max)
            all_present = all(c in qual_scores for c in QUAL_CATS if c != "Reply Quality")
            if all_present:
                # RQ is optional (only if user replied to comments)
                is_max = all(qual_scores[c][0] >= QUAL_CATS[c] for c in qual_scores)
                if is_max:
                    n_all_max += 1
                    all_max_winners.append({
                        "campaign": title,
                        "campaign_address": addr,
                        "mission_id": mission_id,
                        "author": s.get("xUsername"),
                        "tweet_id": s.get("tweetId"),
                        "scores": {c: qual_scores[c][0] for c in qual_scores},
                    })

        print(f" {len(subs)} subs, {n_all_max} ALL-MAX")

    for w in writers.values(): w.close()

    Path(od/"all_max_winners.json").write_text(json.dumps(all_max_winners, indent=2, ensure_ascii=False), encoding="utf-8")
    summary = {
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "campaigns_mined": len(camps),
        "total_submissions": total_subs,
        "total_verdicts_extracted": total_verdicts,
        "all_max_winners": len(all_max_winners),
        "per_category": per_cat_counts,
    }
    Path(od/"summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print()
    print(f"[3/3] DONE.")
    print(f"  Campaigns mined:    {len(camps)}")
    print(f"  Total submissions:  {total_subs}")
    print(f"  Verdicts extracted: {total_verdicts}")
    print(f"  ALL-MAX winners:    {len(all_max_winners)}")
    print(f"  Per-category:")
    for cat, tiers in per_cat_counts.items():
        print(f"    {cat:35s}  MAX={tiers['MAX']:>5}  NEAR={tiers['NEAR']:>5}  LOW={tiers['LOW']:>5}")

if __name__ == "__main__":
    main()
