#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
16_fetch_winner_texts.py — V8.1
Fetch actual tweet text for ALL-MAX winners via syndication API.
Required for replica training (content → verdict mapping).
"""
import argparse, json, sys, time, urllib.request
from pathlib import Path

def fetch_text(tweet_id, timeout=10):
    url = f"https://cdn.syndication.twimg.com/tweet-result?id={tweet_id}&token=a"
    try:
        req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.load(r)
        return d.get("text") or d.get("full_text") or ""
    except Exception:
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--winners-file", default="jfr-data/all_max_winners.json")
    ap.add_argument("--raw-dir", default="jfr-data/raw")
    ap.add_argument("--out", default="jfr-data/winners_with_text.json")
    ap.add_argument("--sleep", type=float, default=0.2)
    args = ap.parse_args()

    winners = json.load(open(args.winners_file, encoding="utf-8"))
    print(f"Fetching text for {len(winners)} ALL-MAX winners…")

    out = []
    ok = 0; fail = 0
    for i, w in enumerate(winners, 1):
        tid = w.get("tweet_id")
        text = fetch_text(tid) if tid else None
        if text:
            w["text"] = text
            ok += 1
        else:
            # Fallback: pull verdict-quoted fragments from raw enriched
            addr = w.get("campaign_address")
            raw_path = Path(args.raw_dir) / f"{addr}.json"
            if raw_path.exists():
                subs = json.load(open(raw_path, encoding="utf-8"))
                match = next((s for s in subs if str(s.get("tweetId")) == str(tid)), None)
                if match and match.get("analysis"):
                    # crude: concatenate all judge analyses; will be longer than tweet but contains quotes
                    full = "\n".join(a.get("analysis","") for a in match["analysis"] if isinstance(a,dict))
                    w["text"] = "[FRAGMENT-FROM-VERDICT] " + full[:1500]
                    w["text_source"] = "verdict-fragment"
            if not w.get("text"):
                w["text"] = None
                fail += 1
        if not w.get("text_source"):
            w["text_source"] = "syndication"
        out.append(w)
        if i % 20 == 0:
            print(f"  {i}/{len(winners)}  ok={ok}  fail={fail}")
        time.sleep(args.sleep)

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"DONE. ok={ok}, fragment-fallback or null={fail}, total={len(out)}")
    print(f"Output: {args.out}")

if __name__ == "__main__":
    main()
