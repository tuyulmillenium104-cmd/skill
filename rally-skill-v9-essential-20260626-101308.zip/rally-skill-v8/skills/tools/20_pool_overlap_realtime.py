#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
20_pool_overlap_realtime.py — V8.4
Real-time fetch of campaign's existing submissions + n-gram overlap analysis.
For OAA precision boost: detect content that mirrors existing pool.

Usage:
  python3 20_pool_overlap_realtime.py \
    --content draft.txt \
    --campaign-address 0xCAMPAIGN \
    --out overlap.json
"""
import argparse, json, re, sys, urllib.request
from collections import Counter
from pathlib import Path

API_BASE = "https://app.rally.fun/api"

def fetch_submissions(addr):
    try:
        req = urllib.request.Request(f"{API_BASE}/submissions?campaignAddress={addr}", headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as r:
            d = json.load(r)
        return d if isinstance(d, list) else d.get("submissions", [])
    except Exception as e:
        print(f"ERROR fetching: {e}", file=sys.stderr)
        return []

def fetch_tweet_text(tid):
    try:
        req = urllib.request.Request(f"https://api.fxtwitter.com/x/status/{tid}", headers={"User-Agent":"Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=8) as r:
            d = json.load(r)
        return d.get("tweet",{}).get("text","")
    except: return ""

def toks(t): return re.findall(r"\w+", t.lower())
def grams(ts, n): return set(" ".join(ts[i:i+n]) for i in range(max(0,len(ts)-n+1)))

# Detect MAX winners in pool — by score sum
def is_all_max(sub):
    scores = {}
    for a in sub.get("analysis", []):
        cat = a.get("category")
        if cat in ["Originality and Authenticity","Content Alignment","Information Accuracy","Campaign Compliance","Engagement Potential","Technical Quality","Reply Quality"]:
            try:
                s = int(int(a.get("atto_score","0"))/10**18)
                mx = {"Originality and Authenticity":2,"Content Alignment":2,"Information Accuracy":2,"Campaign Compliance":2,"Engagement Potential":5,"Technical Quality":5,"Reply Quality":5}[cat]
                scores[cat] = s >= mx
            except: pass
    return scores and all(scores.values())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--campaign-address", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-pool", type=int, default=200, help="Max pool tweets to compare")
    args = ap.parse_args()
    
    text = Path(args.content).read_text(encoding="utf-8").strip()
    print(f"Fetching pool for {args.campaign_address[:12]}...")
    subs = fetch_submissions(args.campaign_address)
    print(f"  Got {len(subs)} submissions")
    
    if not subs:
        result = {"tool":"20","error":"no submissions","decision":"NEUTRAL"}
        Path(args.out).write_text(json.dumps(result,indent=2),encoding="utf-8")
        sys.exit(0)
    
    # Classify submissions as winner / non-winner
    winners = [s for s in subs if is_all_max(s) and not s.get("disqualifiedAt")]
    nonwinners = [s for s in subs if not is_all_max(s) and not s.get("disqualifiedAt")]
    
    print(f"  Winners: {len(winners)}  Non-winners: {len(nonwinners)}")
    print(f"Fetching tweet texts (max {args.max_pool})...")
    
    # Fetch texts (limit to perf)
    import time
    winner_texts = []
    for w in winners[:50]:
        t = fetch_tweet_text(w["tweetId"])
        if t and len(t) > 100:
            winner_texts.append(t)
        time.sleep(0.1)
    
    nonwinner_texts = []
    for nw in nonwinners[:args.max_pool]:
        t = fetch_tweet_text(nw["tweetId"])
        if t and len(t) > 100:
            nonwinner_texts.append(t)
        time.sleep(0.1)
    
    print(f"  Fetched: {len(winner_texts)} winners, {len(nonwinner_texts)} non-winners")
    
    # 5-gram overlap analysis
    ct = toks(text)
    findings = {}
    for n in [4, 5, 6, 7, 8]:
        cg = grams(ct, n)
        w_hits = []
        nw_hits = []
        for wt in winner_texts:
            inter = cg & grams(toks(wt), n)
            for ph in inter:
                w_hits.append(ph)
        for nwt in nonwinner_texts:
            inter = cg & grams(toks(nwt), n)
            for ph in inter:
                nw_hits.append(ph)
        # Unique phrases hit
        unique_w = set(w_hits)
        unique_nw = set(nw_hits)
        # Phrases that ONLY appear in non-winner (= loser-DNA signal)
        loser_dna = unique_nw - unique_w
        # Phrases that appear in both (mandatory campaign vocab — OK)
        common = unique_w & unique_nw
        findings[f"{n}gram"] = {
            "winner_hits": len(w_hits),
            "nonwinner_hits": len(nw_hits),
            "unique_winner_phrases": len(unique_w),
            "unique_nonwinner_phrases": len(unique_nw),
            "loser_dna_only_phrases": sorted(loser_dna)[:20],
            "common_phrases": sorted(common)[:10],
        }
    
    # Decision rules:
    # - 5-gram+ phrases that appear ONLY in non-winners = REWRITE candidates
    # - More winner overlap than non-winner overlap = good
    # - Total non-winner 5-gram hits > 25 = high contamination = OAA risk
    fivegram_loser_count = len(findings["5gram"]["loser_dna_only_phrases"])
    sevengram_loser_count = len(findings["7gram"]["loser_dna_only_phrases"])
    total_nw_overlap = sum(findings[f"{n}gram"]["nonwinner_hits"] for n in [5,6,7,8])
    
    if sevengram_loser_count >= 3 or total_nw_overlap > 40:
        decision = "HIGH_CONTAMINATION"
        oaa_penalty = -1
    elif fivegram_loser_count >= 5 or total_nw_overlap > 20:
        decision = "MODERATE_CONTAMINATION"
        oaa_penalty = -0.5
    else:
        decision = "CLEAN"
        oaa_penalty = 0
    
    result = {
        "tool": "20_pool_overlap_realtime.py V8.4",
        "campaign": args.campaign_address,
        "pool_winners": len(winner_texts),
        "pool_nonwinners": len(nonwinner_texts),
        "findings": findings,
        "decision": decision,
        "oaa_penalty": oaa_penalty,
        "summary": f"{decision}: 5gram_loser_only={fivegram_loser_count}, total_nw_overlap={total_nw_overlap}",
        "rewrite_targets": findings["5gram"]["loser_dna_only_phrases"][:15],
    }
    Path(args.out).write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    
    print(f"\n═══ POOL OVERLAP ANALYSIS ═══")
    print(f"Decision: {decision}")
    print(f"OAA penalty: {oaa_penalty}")
    for n in [5,6,7,8]:
        f=findings[f"{n}gram"]
        print(f"  {n}-gram: winner_hits={f['winner_hits']}  non_hits={f['nonwinner_hits']}  loser-only={len(f['loser_dna_only_phrases'])}")
    if result["rewrite_targets"]:
        print(f"\nREWRITE these 5-gram phrases (appear only in non-winners):")
        for p in result["rewrite_targets"][:10]:
            print(f"  - '{p}'")
    sys.exit(0)

if __name__ == "__main__":
    main()
