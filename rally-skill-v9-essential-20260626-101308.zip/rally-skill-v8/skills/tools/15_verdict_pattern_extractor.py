#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
15_verdict_pattern_extractor.py — V8.1
Statistical pattern extraction from Rally judge verdicts.

For each category (EP, OAA, TQ, IA, CA, CC, RQ):
  1. Identify sub-rubric headings the judge uses (e.g. "Hook Effectiveness", "CTA Quality")
  2. Per sub-rubric, extract MAX vs non-MAX phrase patterns
  3. Compute log-odds-ratio between MAX and NEAR/LOW verdicts
  4. Output: decision_boundary_<CAT>.json with weighted phrases

This is the actual reverse-engineering: which phrases predict MAX?

Output:
  jfr-data/boundaries/<CAT>_subrubrics.json   sub-rubric labels detected
  jfr-data/boundaries/<CAT>_phrases.json      phrase weights (positive = MAX, negative = non-MAX)
  jfr-data/boundaries/<CAT>_report.md         human-readable

Usage:
  python3 15_verdict_pattern_extractor.py --in-dir jfr-data/per-category --out-dir jfr-data/boundaries
"""
import argparse, json, math, re, sys
from collections import Counter, defaultdict
from pathlib import Path

CATS = [
    "Originality_and_Authenticity",
    "Content_Alignment",
    "Information_Accuracy",
    "Campaign_Compliance",
    "Engagement_Potential",
    "Technical_Quality",
    "Reply_Quality",
]

# Known Rally sub-rubric headings (extracted by inspection)
KNOWN_SUBRUBRICS = {
    "Engagement_Potential": [
        "Hook Effectiveness",
        "Call-to-Action Quality", "CTA Quality", "Call to Action",
        "Content Structure",
        "Conversation Potential",
        "Value Delivery",
    ],
    "Technical_Quality": [
        "Language Mechanics",
        "Formatting",
        "Media Integration",
        "Platform-Native",
        "Readability",
    ],
    "Originality_and_Authenticity": [
        "originality", "authentic", "distinctive", "voice",
    ],
    "Content_Alignment": [
        "alignment", "brief", "campaign mission",
    ],
    "Information_Accuracy": [
        "factual", "claim", "verifiable",
    ],
    "Campaign_Compliance": [
        "required", "format", "mention", "rules",
    ],
    "Reply_Quality": [
        "reply", "thread", "conversation", "engagement",
    ],
}

# Stopwords
STOP = set("""a an the and or but of in to for with on at by from as is are was were be been being 
this that these those it its their there here which who whom whose what when where why how
content tweet post submission author user creator i my we you me her him his them they
campaign mission rally rallyonchain category atto score""".split())

def tokenize(text):
    # phrase-level: keep n-grams up to 4
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s\-']", " ", text)
    tokens = [t for t in text.split() if t and t not in STOP and len(t) > 2]
    return tokens

def ngrams(tokens, n):
    return [" ".join(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

def load_jsonl(path):
    out = []
    if not Path(path).exists(): return out
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try: out.append(json.loads(line))
                except: pass
    return out

def detect_subrubrics(verdicts, known_subs):
    """Find which sub-rubric headings the judge actually uses, count freq."""
    counter = Counter()
    for v in verdicts:
        text = v.get("verdict","")
        for s in known_subs:
            # case-insensitive whole-phrase match
            if re.search(r"\b" + re.escape(s) + r"\b", text, re.I):
                counter[s] += 1
    return counter

def split_by_subrubric(verdicts, subrubrics):
    """Split each verdict into sub-rubric sentences."""
    # Build regex: split on known sub-rubric headers
    out = defaultdict(list)
    sorted_subs = sorted(subrubrics, key=lambda x: -len(x))  # longest first
    for v in verdicts:
        text = v.get("verdict","")
        # find positions
        markers = []
        for s in sorted_subs:
            for m in re.finditer(r"\b" + re.escape(s) + r"\b", text, re.I):
                markers.append((m.start(), s))
        if not markers:
            out["_global"].append({"verdict": text, "row": v})
            continue
        markers.sort()
        for i, (pos, sub) in enumerate(markers):
            end = markers[i+1][0] if i+1 < len(markers) else len(text)
            chunk = text[pos:end].strip()
            out[sub].append({"verdict": chunk, "row": v})
    return out

def phrase_log_odds(max_chunks, nonmax_chunks, n_range=(2,3,4), min_freq=5):
    """Compute log-odds-ratio per n-gram between MAX and non-MAX."""
    max_text = " ".join(c["verdict"] for c in max_chunks)
    non_text = " ".join(c["verdict"] for c in nonmax_chunks)
    if not max_text or not non_text: return []

    max_grams = Counter()
    non_grams = Counter()
    for n in n_range:
        for g in ngrams(tokenize(max_text), n):
            max_grams[g] += 1
        for g in ngrams(tokenize(non_text), n):
            non_grams[g] += 1

    total_max = sum(max_grams.values()) or 1
    total_non = sum(non_grams.values()) or 1
    out = []
    for g in set(max_grams) | set(non_grams):
        a = max_grams[g]
        b = non_grams[g]
        if a + b < min_freq: continue
        # smoothed log-odds
        p_max = (a + 0.5) / (total_max + 0.5)
        p_non = (b + 0.5) / (total_non + 0.5)
        lor = math.log(p_max / p_non)
        out.append({
            "phrase": g,
            "max_freq": a,
            "non_freq": b,
            "log_odds": round(lor, 3),
            "total_freq": a + b,
        })
    out.sort(key=lambda x: -abs(x["log_odds"]))
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-dir", default="jfr-data/per-category")
    ap.add_argument("--out-dir", default="jfr-data/boundaries")
    ap.add_argument("--min-freq", type=int, default=8,
                    help="Minimum total frequency to include a phrase in log-odds")
    ap.add_argument("--top-k", type=int, default=80,
                    help="Top K phrases to report per sub-rubric per direction")
    args = ap.parse_args()

    od = Path(args.out_dir)
    od.mkdir(parents=True, exist_ok=True)

    for cat in CATS:
        max_v   = load_jsonl(Path(args.in_dir)/f"{cat}_MAX.jsonl")
        near_v  = load_jsonl(Path(args.in_dir)/f"{cat}_NEAR.jsonl")
        low_v   = load_jsonl(Path(args.in_dir)/f"{cat}_LOW.jsonl")
        non_v   = near_v + low_v

        print(f"\n=== {cat}  (MAX={len(max_v)}  NEAR={len(near_v)}  LOW={len(low_v)}) ===")
        if not max_v or not non_v:
            print("  insufficient data, skip")
            continue

        # 1. Sub-rubric detection
        known = KNOWN_SUBRUBRICS.get(cat, [])
        sub_counter = detect_subrubrics(max_v + non_v, known) if known else Counter()
        # Pick sub-rubrics seen in at least 10% of verdicts
        total_v = len(max_v) + len(non_v)
        good_subs = [s for s,c in sub_counter.items() if c >= max(10, total_v*0.05)]
        print(f"  Sub-rubrics detected (≥5% verdicts): {good_subs}")

        # 2. Split + log-odds per sub-rubric
        per_sub_result = {}
        if good_subs:
            max_split = split_by_subrubric(max_v, good_subs)
            non_split = split_by_subrubric(non_v, good_subs)
            for sub in good_subs:
                lo = phrase_log_odds(max_split.get(sub,[]), non_split.get(sub,[]), min_freq=args.min_freq)
                pos = [p for p in lo if p["log_odds"] > 0][:args.top_k]
                neg = [p for p in lo if p["log_odds"] < 0][:args.top_k]
                per_sub_result[sub] = {
                    "n_max_chunks": len(max_split.get(sub,[])),
                    "n_non_chunks": len(non_split.get(sub,[])),
                    "max_indicating_phrases": pos,
                    "non_max_indicating_phrases": neg,
                }
                print(f"    {sub:35s} max_chunks={len(max_split.get(sub,[])):>5}  non_chunks={len(non_split.get(sub,[])):>5}  pos_phrases={len(pos)}  neg_phrases={len(neg)}")

        # 3. Global log-odds (across all verdict text)
        global_lo = phrase_log_odds(
            [{"verdict": v.get("verdict","")} for v in max_v],
            [{"verdict": v.get("verdict","")} for v in non_v],
            min_freq=args.min_freq
        )
        global_pos = [p for p in global_lo if p["log_odds"] > 0][:args.top_k]
        global_neg = [p for p in global_lo if p["log_odds"] < 0][:args.top_k]

        # Save
        out = {
            "category": cat,
            "n_max_verdicts": len(max_v),
            "n_near_verdicts": len(near_v),
            "n_low_verdicts": len(low_v),
            "sub_rubrics": good_subs,
            "sub_rubric_freq": dict(sub_counter),
            "per_sub_rubric": per_sub_result,
            "global_max_phrases": global_pos,
            "global_non_max_phrases": global_neg,
        }
        Path(od/f"{cat}_boundary.json").write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")

        # Human-readable
        md = f"# {cat} — Decision Boundary\n\n"
        md += f"MAX verdicts: {len(max_v)} | NEAR: {len(near_v)} | LOW: {len(low_v)}\n\n"
        md += f"## Sub-rubrics Detected\n\n"
        for s in good_subs:
            md += f"- **{s}** ({sub_counter[s]} mentions)\n"
        md += "\n## Top MAX-Indicating Phrases (global)\n\n| Phrase | MAX freq | non-MAX freq | log-odds |\n|---|---|---|---|\n"
        for p in global_pos[:30]:
            md += f"| `{p['phrase']}` | {p['max_freq']} | {p['non_freq']} | {p['log_odds']:+.2f} |\n"
        md += "\n## Top NON-MAX-Indicating Phrases (deduction triggers)\n\n| Phrase | MAX freq | non-MAX freq | log-odds |\n|---|---|---|---|\n"
        for p in global_neg[:30]:
            md += f"| `{p['phrase']}` | {p['max_freq']} | {p['non_freq']} | {p['log_odds']:+.2f} |\n"

        if per_sub_result:
            md += "\n## Per Sub-Rubric Patterns\n"
            for sub, data in per_sub_result.items():
                md += f"\n### {sub}\n\n**MAX phrases:**\n\n"
                for p in data["max_indicating_phrases"][:15]:
                    md += f"- `{p['phrase']}` (max={p['max_freq']}, non={p['non_freq']}, log-odds={p['log_odds']:+.2f})\n"
                md += f"\n**NON-MAX phrases (deduction triggers):**\n\n"
                for p in data["non_max_indicating_phrases"][:15]:
                    md += f"- `{p['phrase']}` (max={p['max_freq']}, non={p['non_freq']}, log-odds={p['log_odds']:+.2f})\n"

        Path(od/f"{cat}_boundary.md").write_text(md, encoding="utf-8")

    print("\nDONE. See jfr-data/boundaries/")

if __name__ == "__main__":
    main()
