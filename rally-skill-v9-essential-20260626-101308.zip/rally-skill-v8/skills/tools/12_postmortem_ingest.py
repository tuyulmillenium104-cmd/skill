#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
12_postmortem_ingest.py — V8.0
Ingest real Rally verdict and update calibration. Closes V7.7 CELAH #10.

Usage:
  python3 12_postmortem_ingest.py \
    --tweet <tweetId> \
    --predicted reports/A-ensemble.json \
    --actual actual-verdict.json \
    --campaign <addr> --mission <id> \
    --calibration-file ../data/calibration-memory.json \
    --priors-out ../data/confidence-priors.json

actual-verdict.json format:
  {"EP":5,"OAA":5,"TQ":5,"IA":5,"CA":5,"CC":2,"RQ":5,"raw_judge":"..."}
"""
import argparse, json, sys
from datetime import datetime
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tweet", required=True)
    ap.add_argument("--predicted", required=True, help="Path to ensemble JSON (with worst_credible_scores)")
    ap.add_argument("--actual", required=True, help="Path to actual verdict JSON")
    ap.add_argument("--campaign", required=True)
    ap.add_argument("--mission", default=None)
    ap.add_argument("--calibration-file", required=True)
    ap.add_argument("--priors-out", default=None)
    ap.add_argument("--lessons-file", default=None, help="Append active lesson to this file")
    args = ap.parse_args()

    pred_json = json.load(open(args.predicted, encoding="utf-8"))
    predicted = pred_json.get("worst_credible_scores", {})
    actual = json.load(open(args.actual, encoding="utf-8"))

    # diff per gate
    diff = {}
    for g in ["EP","OAA","TQ","IA","CA","CC","RQ"]:
        p = predicted.get(g)
        a = actual.get(g)
        if a is None: continue
        if p is None:
            diff[g] = {"predicted": None, "actual": a, "verdict": "NO_PREDICTION"}
        elif p == a:
            diff[g] = {"predicted": p, "actual": a, "verdict": "HIT"}
        elif p < a:
            diff[g] = {"predicted": p, "actual": a, "verdict": "UNDER"}
        else:
            diff[g] = {"predicted": p, "actual": a, "verdict": "OVER"}

    entry = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "campaign": args.campaign,
        "mission": args.mission,
        "tweet": args.tweet,
        "predicted_worst_credible": predicted,
        "actual_verdict": actual,
        "diff": diff,
        "raw_judge_snippet": actual.get("raw_judge", "")[:500],
    }

    cf = Path(args.calibration_file)
    if cf.exists():
        cal = json.load(open(cf, encoding="utf-8"))
    else:
        cal = {"version": "V8.0", "campaignLearnings": []}
    cal.setdefault("campaignLearnings", []).append(entry)
    cf.parent.mkdir(parents=True, exist_ok=True)
    cf.write_text(json.dumps(cal, indent=2, ensure_ascii=False), encoding="utf-8")

    # rebuild priors: per-gate hit rate
    if args.priors_out:
        per_gate = {}
        for e in cal["campaignLearnings"]:
            for g, d in e.get("diff", {}).items():
                per_gate.setdefault(g, {"hit":0,"over":0,"under":0,"total":0})
                v = d.get("verdict")
                if v in ("HIT","OVER","UNDER"):
                    per_gate[g][v.lower()] += 1
                    per_gate[g]["total"] += 1
        priors = {g: {
            "hit_rate": (s["hit"]/s["total"]) if s["total"] else None,
            "over_rate": (s["over"]/s["total"]) if s["total"] else None,
            "under_rate": (s["under"]/s["total"]) if s["total"] else None,
            "n": s["total"],
        } for g, s in per_gate.items()}
        Path(args.priors_out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.priors_out).write_text(json.dumps(priors, indent=2, ensure_ascii=False), encoding="utf-8")

    # generate active lesson if any UNDER (we predicted too high → real weakness)
    if args.lessons_file:
        unders = [(g,d) for g,d in diff.items() if d["verdict"]=="UNDER"]
        if unders:
            lesson_md = f"\n## {entry['date']} — {args.campaign[:10]}... — {args.mission or 'single'} — UNDER predictions\n\nTYPE: DEDUCTION\nSOURCE: Real Rally verdict\nEVIDENCE:\n"
            for g,d in unders:
                lesson_md += f"- {g}: predicted {d['predicted']}, actual {d['actual']}\n"
            snip = actual.get("raw_judge", "")[:300]
            if snip:
                lesson_md += f'\nJudge quote: "{snip}"\n'
            lesson_md += "\nACTIVE RULE:\n- Audit V8.0 pipeline for this gate; re-check kill-pattern/loser-semantic scanners.\n\n"
            with open(args.lessons_file, "a", encoding="utf-8") as f:
                f.write(lesson_md)

    print(f"POSTMORTEM INGESTED: tweet={args.tweet}")
    for g, d in diff.items():
        print(f"  {g}: pred={d['predicted']} actual={d['actual']} → {d['verdict']}")
    sys.exit(0)

if __name__ == "__main__":
    main()
