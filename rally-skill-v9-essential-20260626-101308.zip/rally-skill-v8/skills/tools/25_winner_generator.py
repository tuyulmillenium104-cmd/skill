#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
25_winner_generator.py — V8.5 STRUCTURED WINNER BLUEPRINT
Given brief + topic + key facts, generates STRUCTURED INSTRUCTIONS for drafting
content that matches winner empirical profile.

NOT an LLM call — produces a strict template the user (or LLM) fills in.

Output sections:
  1. Mission decode (from brief)
  2. Winner profile target (chars/paras/etc)
  3. Opener candidates (5 patterns)
  4. Body skeleton (with value-signal slots)
  5. CTA candidates (5 specific patterns)
  6. Self-check checklist
  7. LLM prompt template (paste-and-go)

Usage:
  python3 25_winner_generator.py --brief brief.txt --topic "GenLayer judgment layer" \
    --facts "validators read context" "AI consensus" "intelligent contracts" \
    --mention "@RallyOnChain" --out winner_blueprint.md
"""
import argparse, json, re, sys
from pathlib import Path

WINNER_PROFILE = {
    "chars_target": "900-1500 (median 1220)",
    "paras_target": "6-13 (median 9)",
    "sents_target": "12-22 (median 17)",
    "avg_sent_target": "9-15 words (median 12)",
    "first_sent_target": "9-18 words (median 12)",
}

OPENER_PATTERNS = [
    {"name": "Contrarian Declaration", "template": "{X} is not {wrong_belief}. It is {real_thing}.",
     "examples": ["Smart contracts can verify that something happened.", "Founder mode is not about execution. It is about removing the emotional safety layer."]},
    {"name": "Mechanism Reveal", "template": "The way {X} actually works is {surprise}.",
     "examples": ["The way Rally judges content actually works is decentralized AI consensus, not a single moderator."]},
    {"name": "Scene Opener", "template": "{Time period} I {specific action} because {reason}.",
     "examples": ["For a year I bought carbon offsets to protect a forest that was never going to be cut down.", "Last Tuesday I deleted a draft I'd been writing for three weeks."]},
    {"name": "Verdict Frame", "template": "Verdict: {target} is {assessment}.",
     "examples": ["Verdict: KOL marketing as credibility = cooked.", "My verdict on AI agent economy trend: Mid."]},
    {"name": "Definitional Contrast", "template": "{A} can {do_a}. {A} struggles to {do_b}.",
     "examples": ["Code is very good at asking: Did X happen? The world keeps asking: Did X count?", "A smart contract can confirm the machine stopped spinning. It cannot answer who's at fault."]},
    {"name": "Personal Stake", "template": "{Time} ago I {action} {amount} of {thing} because {reason}.",
     "examples": ["For a year I bought carbon offsets...", "My team once lost a game because the referee missed an offside call."]},
]

VALUE_SIGNALS = [
    {"name": "Named Concept (invent label)", "template": "I call this '{coined_term}': when {condition} happens, {result}.",
     "examples": ["judgment laundering", "queue position", "creator access budget", "correlation cosplay"]},
    {"name": "Mechanism Reveal", "template": "Here's the mechanism: {step_1}. Then {step_2}. The trick is {key_insight}.",
     "guidance": "Reveal HOW something works that's normally hidden"},
    {"name": "Definitional Contrast", "template": "{Thing} is no longer about {old_definition}. It is about {new_definition}.",
     "guidance": "Reframe what something means"},
    {"name": "Q-A Rhythm", "template": "Did {X}? Did {Y}? Did {Z}? Those are different questions.",
     "guidance": "Use 2-3 declarative questions in body"},
    {"name": "Personal Scene + Mechanism", "template": "When {personal action}, I learned {insight}. Most people miss {what}.",
     "guidance": "Combine specific personal moment with universal insight"},
    {"name": "Quoted Phrase", "template": "What {target_audience} call '{label}' is really {definition}.",
     "guidance": "Coin a quoted phrase that captures the insight"},
    {"name": "Specific Numbers + Contrarian", "template": "{N1}% of {X} do {Y}. But the {N2}% who don't are the ones who {Z}.",
     "guidance": "Use concrete numbers to anchor a contrarian point"},
]

CTA_PATTERNS = [
    {"name": "Specific Personal Experience Q", "template": "What's the {qualifier} {thing} you {past_verb}?",
     "examples": ["What's the smallest contract dispute you've seen that code alone couldn't solve?",
                  "What's the moment that changed how you read liquidity?",
                  "What's a draft caption you never sent because the app died first?"]},
    {"name": "Which-Choice Q", "template": "Which {category} do you think {predict_action} first?",
     "examples": ["Which industry do you think faces the first crisis when AI agents disagree?",
                  "Which platform do you think has most to lose if quality vs engagement gap stays?"]},
    {"name": "Direct Imperative", "template": "Name one {thing} that {qualifier}.",
     "examples": ["Name one project that broke because of a missing review.", "Tell me your version of this."]},
    {"name": "Would-Rather Choice", "template": "Would you rather {option_a} or {option_b}?",
     "examples": ["Would you rather buy access, or prove you showed up early enough to earn it?"]},
    {"name": "URL + Specific Q (action campaigns)", "template": "Visit {url}. {specific_question}",
     "examples": ["Go check Rally yourself: app.rally.fun. What's the worst random rejection on other platforms?"]},
]

ANTI_PATTERNS = [
    "❌ 'So I've been thinking...' / 'Well, honestly...' (slow opener)",
    "❌ 'This is huge' / 'Game changer' / 'To the moon' (hype)",
    "❌ 'Guaranteed' / 'Passive income' / '100x' (auto-IA-fail)",
    "❌ 'Thoughts?' / 'Agree?' / 'Drop yours' / 'Let me know' (generic CTA = EP4)",
    "❌ 'Delve into' / 'Let's unpack' / 'In conclusion' (AI signature)",
    "❌ Referral link + question (CTA split = EP4)",
    "❌ Starting with @ or # (CC violation)",
    "❌ Mention as standalone vocative line (TQ deduction)",
    "❌ >1900 chars (digestibility penalty)",
    "❌ <500 chars (too short for longform expectations)",
]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--brief", default=None, help="Path to brief.txt OR inline string")
    ap.add_argument("--brief-text", default=None, help="Brief text inline")
    ap.add_argument("--topic", required=True, help="Main topic of the tweet")
    ap.add_argument("--facts", nargs="+", default=[], help="3-6 key facts to include")
    ap.add_argument("--mention", default="@RallyOnChain", help="Required mention")
    ap.add_argument("--mission-type", default="explain", choices=["explain","identify","persuade","predict","story","review","hot_take"])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    
    brief = ""
    if args.brief and Path(args.brief).exists():
        brief = Path(args.brief).read_text(encoding="utf-8")
    elif args.brief_text:
        brief = args.brief_text
    
    md = [f"# WINNER BLUEPRINT — {args.topic}\n\n"]
    md.append(f"**Mission type:** {args.mission_type}\n")
    md.append(f"**Required mention:** {args.mention}\n")
    md.append(f"**Brief:** {brief[:400] + '...' if len(brief)>400 else brief}\n\n")
    
    md.append("## 1. WINNER TARGET PROFILE\n\n")
    for k, v in WINNER_PROFILE.items():
        md.append(f"- **{k.replace('_target','')}:** {v}\n")
    md.append("\n")
    
    md.append("## 2. OPENER — PICK ONE (write your version)\n\n")
    for i, op in enumerate(OPENER_PATTERNS, 1):
        md.append(f"### Option {chr(64+i)}: {op['name']}\n")
        md.append(f"Template: `{op['template']}`\n\n")
        md.append(f"Real winner examples:\n")
        for ex in op['examples']:
            md.append(f"- {ex}\n")
        md.append("\n**Your version for '{topic}':** [WRITE 9-18 words]\n\n".format(topic=args.topic))
    
    md.append("## 3. BODY SKELETON\n\n")
    md.append("Build 4-9 short paragraphs using ≥2 of these VALUE SIGNALS:\n\n")
    for i, vs in enumerate(VALUE_SIGNALS, 1):
        md.append(f"### Signal {chr(64+i)}: {vs['name']}\n")
        if 'template' in vs:
            md.append(f"Template: `{vs['template']}`\n")
        if 'guidance' in vs:
            md.append(f"Guidance: {vs['guidance']}\n")
        if 'examples' in vs:
            md.append(f"Real examples: {', '.join(vs['examples'])}\n")
        md.append("\n")
    
    md.append(f"### Key facts to weave in:\n")
    for f in args.facts:
        md.append(f"- {f}\n")
    md.append(f"\n### Mention integration:\n")
    md.append(f"Place {args.mention} naturally MID-CONTENT, e.g. 'That is where {args.mention} matters because...' — NOT as standalone vocative line.\n\n")
    
    md.append("## 4. CTA — PICK ONE (specific, not generic)\n\n")
    for i, cta in enumerate(CTA_PATTERNS, 1):
        md.append(f"### CTA Option {chr(64+i)}: {cta['name']}\n")
        md.append(f"Template: `{cta['template']}`\n")
        md.append(f"Examples:\n")
        for ex in cta['examples']:
            md.append(f"- {ex}\n")
        md.append("\n")
    
    md.append("## 5. ANTI-PATTERNS (AVOID)\n\n")
    for ap_ in ANTI_PATTERNS:
        md.append(f"{ap_}\n")
    md.append("\n")
    
    md.append("## 6. SELF-CHECK BEFORE SUBMIT\n\n")
    checks = [
        "Chars in 900-1500 range",
        "6-13 paragraphs (stanza style, double-newline)",
        "First sentence 9-18 words, declarative, no slow opener",
        f"Required mention ({args.mention}) integrated naturally mid-content",
        "≥2 value signals embedded (named-concept / mechanism / scene / contrarian / etc.)",
        "CTA in last paragraph: SPECIFIC question OR direct imperative",
        "Zero generic CTAs (thoughts?/agree?/drop yours)",
        "Zero hype phrases (game changer/this is huge)",
        "Zero unsupported earning claims (guaranteed/100x/passive income)",
        "Zero AI-template phrases (delve into/let's unpack)",
    ]
    for c in checks:
        md.append(f"- [ ] {c}\n")
    md.append("\nRun `python3 skills/tools/22_full_pipeline.py --content draft.txt --brief brief.txt` to verify.\n\n")
    
    md.append("## 7. PASTE-AND-GO LLM PROMPT\n\n")
    md.append("```\n")
    md.append(f"You are writing a Rally.fun campaign tweet for ALL-MAX score.\n\n")
    md.append(f"TOPIC: {args.topic}\n\n")
    md.append(f"BRIEF:\n{brief[:600]}\n\n")
    md.append(f"FACTS TO INCLUDE:\n")
    for f in args.facts:
        md.append(f"- {f}\n")
    md.append(f"\nREQUIRED MENTION: {args.mention}\n\n")
    md.append("WINNER PROFILE TO MATCH:\n")
    md.append("- Length: 900-1500 characters (LONG-FORM)\n")
    md.append("- 6-13 stanza paragraphs (double-newline separated)\n")
    md.append("- First sentence: 9-18 words, declarative\n")
    md.append("- NO slow openers (So/Well/Honestly)\n")
    md.append("- Body: include ≥2 of:\n")
    md.append("  • Named concept (coin a 2-3 word label)\n")
    md.append("  • Mechanism reveal (how X actually works)\n")
    md.append("  • Scene opener (specific personal moment)\n")
    md.append("  • Contrarian frame (most think X, actually Y)\n")
    md.append("  • Q-A rhythm (2-3 declarative questions)\n")
    md.append("  • Definitional contrast (X is no longer about Y)\n")
    md.append("- CTA in last paragraph (MANDATORY): specific question OR direct imperative\n")
    md.append("- Mention integrated mid-content, NOT as vocative end line\n\n")
    md.append("NEVER USE:\n")
    md.append("- Hype: 'game changer', 'this is huge', 'to the moon'\n")
    md.append("- Earning claims: 'guaranteed', '100x', 'passive income'\n")
    md.append("- Generic CTA: 'thoughts?', 'agree?', 'drop yours', 'let me know'\n")
    md.append("- AI template: 'delve into', 'let's unpack', 'in conclusion'\n\n")
    md.append("Output ONLY the tweet text, nothing else.\n")
    md.append("```\n")
    
    Path(args.out).write_text("".join(md), encoding="utf-8")
    print(f"Winner blueprint saved: {args.out}")
    print(f"Use the LLM prompt at section 7 to generate, then validate with:\n  python3 skills/tools/22_full_pipeline.py --content draft.txt --brief brief.txt")

if __name__ == "__main__":
    main()
