#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
17_judge_replica.py — V8.3 (re-trained on 318 ALL-MAX winners + 99k submissions)

EMPIRICAL CONSTANTS (data-driven from 236 campaigns, 99k subs, 677k verdicts):
  Winner chars: p25=892, median=1220, p75=1524    (LONG-FORM dominant)
  Winner paras: p25=6, median=9, p75=13            (stanza style)
  Winner avg sent: p25=10, median=12, p75=15       (punchy)
  Winner first sent words: p25=9, median=12, p75=18

  Winner feature %:
    has_qmark anywhere:    73.3%
    qmark in last 2 paras: 68.2%
    url in last 2 paras:   26.1%
    imperative verb in last 2 paras: 21.7%
    ANY engagement trigger in last 2p: 79.9%
    contrarian framing:    67.3%
    personal scene:        34.0%
    quoted phrase:         45.0%

KEY KILL PHRASES (log-odds from 5,937 EP_MAX vs 90,000 non-MAX):
  Non-MAX (never in EP=5):
    "potential limited" (1793), "moderate engagement" (1473), 
    "has moderate" (1250), "conversation potential limited" (1068),
    "does not ask" (829), "value delivery strongest" (597 — paradox!)
  EP=5-indicating:
    "demonstrates exceptional" (655), "exceptional engagement" (534),
    "across all engagement" (194), "potential maximized" (99)
"""
import argparse, json, re, sys, statistics
from pathlib import Path

# ============================================================
# CONTENT FEATURE EXTRACTORS
# ============================================================

def split_sentences(text):
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text.strip()) if s.strip()]

def split_paragraphs(text):
    return [p.strip() for p in re.split(r'\n\s*\n', text.strip()) if p.strip()]

def content_chars(text):
    return len(text.strip())

def extract_features(text):
    sents = split_sentences(text)
    paras = split_paragraphs(text)
    tl = text.lower()
    last_2paras = "\n\n".join(text.strip().split("\n\n")[-2:]) if text else ""
    last_2p_l = last_2paras.lower()
    # Strip quoted content for direct-question detection
    last2_unquoted = re.sub(r'"[^"]*"', '', last_2paras)
    last2_unquoted = re.sub(r"[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]", '', last2_unquoted)
    
    qa_pattern = len(re.findall(r"\b(Did|Does|Is|Are|What|How|Why|When|Where|Can|Could|Should|Would)\b[^?]{1,80}\?", text))
    declarative_anchors = len(re.findall(r"\b(That is|This is|It is|There is|That[\u2019']s|It[\u2019']s) (the |a |an |where |when |why |how |what |not |very |exactly |precisely |judgment|where it|why )", text, re.I))
    definitional = bool(re.search(r"\b(are not|is not|do not|does not) (always |necessarily |just |only |merely |the )", tl)) or \
                   bool(re.search(r"\b(no longer|not just) (a|an|the|about|the same)\b", tl)) or \
                   bool(re.search(r"\b\w+ is \w+,?\s+not\b", tl))
    
    scene_opener = False
    if sents:
        first2 = " ".join(sents[:2])
        if re.search(r"\b(in|at|on|for|when)\s+\w+\s+(\w+\s+){0,4}(\d+|\w+ ago|years?|months?|weeks?|days?|night|morning)\b", first2, re.I): scene_opener = True
        elif re.search(r"\b(my|our|the)\s+(cargo|package|wallet|account|client|team|company|partner|kid|dog|cat|house|order|invoice|warranty|paper|story|memory|moment|first|last|biggest|own)\b", first2, re.I): scene_opener = True
        elif re.search(r"\b(a|the)\s+\w+\s+(died|broke|failed|came|arrived|sat|stayed|stopped|lost|cost|paid|charged)\b", first2, re.I): scene_opener = True
        elif re.search(r"^\w+\s+(works|broke|fails|happens|matters|exists|begins|already know)", first2, re.I): scene_opener = True
    
    can_cannot_density = len(re.findall(r"\b(can|cannot|can\u2019t|can't|could|would|will|won\u2019t|won't)\b", tl))
    
    return {
        "chars": content_chars(text),
        "sents": len(sents),
        "paras": len(paras),
        "avg_sent_words": statistics.mean(len(s.split()) for s in sents) if sents else 0,
        "first_sent_words": len(sents[0].split()) if sents else 0,
        "first_words": " ".join(text.split()[:5]).lower(),
        "has_qmark": "?" in text,
        "qmark_count": text.count("?"),
        "has_mention": bool(re.search(r"@\w+", text)),
        "has_named_brand": bool(re.search(r"@(RallyOnChain|GenLayer|Wingston)", text, re.I)),
        # last 2-paragraph signals (most discriminative for EP=5)
        "last_2p": last_2paras,
        "last_2p_unquoted": last2_unquoted,
        "has_q_in_last2p_unquoted": "?" in last2_unquoted,
        "has_url_in_last2p": bool(re.search(r"https?://(?!t\.co|pic\.twitter)", last_2paras)),
        "has_imperative_in_last2p": bool(re.search(
            r"\b(tell me|reply|comment|share|drop|pick|choose|name|visit|check|mint|join|claim|test|compare|rate|defend|stake|"
            r"go (?:check|see|stake|visit|build|read|learn|find|grab)|start here|see how|find out|read more|learn more|"
            r"grab (?:your|yours|one)|come (?:see|earn|join|learn|test)|"
            r"explore|discover|try (?:it|this)|put (?:your|that))\b", last_2p_l)),
        # value / originality signals
        "has_contrarian": bool(re.search(r"\b(actually|verdict|wrong|most people|everyone|but actually|the truth|unpopular|broken|cooked|mid|fake|struggle|hardest|not just)\b", tl)),
        "has_personal": bool(re.search(r"\b(i (was|spent|tried|built|saw|watched|remember|used|did|lost|won|hired|bought|wrote|posted|sent|paid|started|grew|came|kept|stopped|deleted|opened|stared)|my (team|company|client|friend|partner|wife|husband|kid|story|first|career|cargo|wallet|biggest|own))\b", tl)),
        "has_quoted": bool(re.search(r'"[^"]+"', text)) or bool(re.search(r'[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]', text)),
        "has_named_concept": bool(re.search(r"\b\w+ is \w+,?\s+not\b", tl)),
        "has_mechanism_reveal": bool(re.search(r"\b(the way|how it works|the trick|the secret|what no one|under the hood|the moment|the difference|the gap|the hidden|matters because|the problem is|here[\u2019']s how|the catch)\b", tl)),
        "has_specific_number": bool(re.search(r"\b\d+\s*(rlp|k|m|%|x|hours?|days?|years?|times?|cents?|dollars?|people|trees|tweets|posts|followers|impressions|memories|months|weeks)\b", tl)) or bool(re.search(r"\b(188k|200k|#\d+|top \d+)\b", tl)),
        "has_qa_rhythm": qa_pattern >= 2,
        "has_declarative_anchor": declarative_anchors >= 1,
        "has_definitional": definitional,
        "has_scene_opener": scene_opener,
        "has_mechanism_density": can_cannot_density >= 4,
        # TQ
        "excessive_punct": text.count("!") > 4 or text.count("?") > 6,
        "ai_signature": any(re.search(r"\b" + re.escape(p) + r"\b(?!\w)", tl) for p in [
            "delve into", "delving into", "let's unpack", "in this fast-paced world",
            "embark on", "embarking on", "in the realm of", "in conclusion",
            "to summarize", "to put it simply", "it is worth noting", "in today's landscape",
        ]),
        "generic_cta": any(g in last_2p_l for g in [
            "thoughts?", "agree?", "what do you think", "drop yours", "drop your thoughts",
            "drop them below", "let me know.", "let me know in", "lmk", "your take?",
            "thoughts below", "comment below!", "what are your thoughts",
        ]),
    }

# ============================================================
# CTA SPECIFIC PATTERN (empirical from 318 winners)
# ============================================================
CTA_SPECIFIC_RE = re.compile(
    r"\b("
    r"your (first|own|worst|best|smallest|biggest|next|last|version|take|verdict|story|experience|case|wallet|belief|setup|play|story|message|memory)|"
    r"the (time|moment|day|first time|last time|year|night) (you|when|that)|"
    r"which (would|one|industry|do you|matters|version|of|project|platform|field|kind|sort|type|ai|agent|word|deal|use case|crypto|nft|company|chapter|piece)|"
    r"what (is|are|was|were|kind of|kinds of|sort of|sorts of|type of|types of|field of|deal|word|agreement|industry|moment|piece|version|use case|other|everyday|killed|made|breaks|happens|matters|changes|truth|story|memory)|"
    r"what (would|do|did|have|has|could) you|"
    r"what[\u2019']s (a|an|the|one|your|been)|"
    r"name (one|a|the|me)|"
    r"tell me (your|about|one|the|how|what)|"
    r"how (do|did|would|have|has|much) you|"
    r"why (do|did|does|would) you|"
    r"have you (ever|seen|tried|noticed|been|had)|"
    r"would you rather|"
    r"if you (had to (choose|pick|decide)|could|were|are (building|using|joining|earning|trying))|"
    r"are you (building|using|joining|earning|trying|still|the kind)|"
    r" or [a-z]+\?|"
    r"share (your|how|what|the|one)"
    r")", re.I
)

def has_cta_specific(text_lower):
    return bool(CTA_SPECIFIC_RE.search(text_lower))

# ============================================================
# OAA POOL OVERLAP SCAN (new in V8.3) — closes celah lama
# ============================================================
def compute_pool_overlap(text, winner_corpus=None, nonwinner_corpus=None, n=5):
    """Returns 5-gram overlap counts vs corpora. High non-winner overlap = OAA penalty."""
    if not winner_corpus and not nonwinner_corpus:
        return {"winner_overlap":0, "nonwinner_overlap":0, "novelty_score":1.0}
    def toks(t): return re.findall(r"\w+", t.lower())
    def grams(ts, n): return set(" ".join(ts[i:i+n]) for i in range(max(0,len(ts)-n+1)))
    cg = grams(toks(text), n)
    if not cg: return {"winner_overlap":0, "nonwinner_overlap":0, "novelty_score":1.0}
    w_hits = 0; nw_hits = 0
    if winner_corpus:
        for w in winner_corpus[:500]:
            w_hits += len(cg & grams(toks(w), n))
    if nonwinner_corpus:
        for nw in nonwinner_corpus[:500]:
            nw_hits += len(cg & grams(toks(nw), n))
    # novelty = inverse of overlap (high overlap = low novelty)
    total = w_hits + nw_hits
    novelty = 1.0 / (1.0 + total * 0.05)
    return {"winner_overlap": w_hits, "nonwinner_overlap": nw_hits, "novelty_score": round(novelty, 3)}

# ============================================================
# SCORING — EMPIRICAL THRESHOLDS
# ============================================================

def predict_engagement_potential(f):
    """EP score 1-5 based on data-driven thresholds from 5,937 EP_MAX verdicts."""
    deductions = []
    points = 0  # max 5

    # === 1) HOOK (1 pt) — first sentence 5-25 words, not weak opener ===
    weak_starts = ("so ","so,","well,","well ","honestly","just thinking","random thought","been thinking","lately ","i've been","let me share","i want to share")
    if f["first_sent_words"] >= 5 and f["first_sent_words"] <= 28 and not any(f["first_words"].startswith(w) for w in weak_starts):
        first_strong = (
            f["has_scene_opener"] or f["has_contrarian"] or f["has_specific_number"] or
            f["has_qa_rhythm"] or f["has_declarative_anchor"] or
            bool(re.search(r"^[A-Z]\w+\s+(is|are|was|were|broke|died|fail|works|matters|exists|already|never|always)", f.get("last_2p","")[:100] or ""))
        )
        points += 1 if first_strong else 0.6
        if not first_strong: deductions.append("hook_decent_not_sharp")
    else:
        deductions.append("hook_weak")

    # === 2) STRUCTURE (1 pt) — winners: paras 4-15, sent 8-18 words ===
    if 4 <= f["paras"] <= 15 and 8 <= f["avg_sent_words"] <= 18:
        points += 1
    elif 3 <= f["paras"] <= 20 and 7 <= f["avg_sent_words"] <= 22:
        points += 0.7
    elif f["paras"] >= 2:
        points += 0.4
    else:
        deductions.append("structure_dense")

    # === 3) VALUE DELIVERY (1 pt) — empirical multi-path ===
    value_signals = sum([
        f["has_named_concept"], f["has_mechanism_reveal"], f["has_definitional"],
        f["has_qa_rhythm"], f["has_scene_opener"], f["has_mechanism_density"],
        f["has_personal"] and f["has_contrarian"],
        f["has_specific_number"] and (f["has_contrarian"] or f["has_personal"]),
        f["has_quoted"] and f["has_contrarian"],  # quote alone is weak; quote+contrarian = strong
    ])
    if value_signals >= 2: points += 1
    elif value_signals == 1: points += 0.6
    else:
        deductions.append("value_moderate")

    # === 4) CTA QUALITY (1 pt) — the EP=4 vs EP=5 boundary ===
    has_q = f["has_q_in_last2p_unquoted"]
    has_imp = f["has_imperative_in_last2p"]
    has_url = f["has_url_in_last2p"]
    has_generic = f["generic_cta"]
    has_specific = has_cta_specific(f["last_2p_unquoted"].lower())
    
    if (has_q or has_imp) and has_specific and not has_generic:
        points += 1  # EP=5 path
    elif has_url and has_q and has_specific:
        points += 1
    elif (has_q or has_imp) and not has_generic:
        points += 0.55
        deductions.append("cta_not_specific")
    elif has_url and (has_q or has_imp):
        points += 0.45
        deductions.append("cta_url_no_specific")
    elif has_q and not has_generic:
        points += 0.35
        deductions.append("cta_rhetorical_only")
    elif has_url:
        points += 0.25
        deductions.append("cta_url_only")
    elif has_imp:
        points += 0.25
        deductions.append("cta_imperative_no_q")
    elif has_generic:
        points -= 0.3
        deductions.append("cta_generic")
    else:
        deductions.append("cta_missing")

    # === 5) CONVERSATION (1 pt) ===
    if has_q and has_specific and not has_generic:
        points += 1
    elif has_q and not has_generic:
        points += 0.7
    elif has_imp and has_specific:
        points += 0.7
    elif has_url and (has_q or has_imp):
        points += 0.5
    elif has_q:
        points += 0.3
    elif has_imp or has_url:
        points += 0.3
    else:
        deductions.append("conversation_limited")

    # === Modifiers ===
    if f["chars"] > 1900: points -= 0.7; deductions.append("too_long")
    elif f["chars"] > 1700: points -= 0.3; deductions.append("long_borderline")
    elif f["chars"] < 400: points -= 0.4; deductions.append("too_short")
    if f["avg_sent_words"] > 18 and f["chars"] > 1300: points -= 0.3; deductions.append("dense_long")
    if f["ai_signature"]: points -= 0.5; deductions.append("ai_signature")

    # === HARD GATE: EP=5 requires explicit engagement trigger ===
    has_engagement_trigger = has_q or has_imp or has_url
    
    if points >= 4.2 and has_engagement_trigger and not has_generic:
        ep = 5
    elif points >= 4.2 and not has_engagement_trigger:
        ep = 4; deductions.append("EP5_BLOCKED_no_engagement_trigger")
    elif points >= 3.3: ep = 4
    elif points >= 2.3: ep = 3
    elif points >= 1.3: ep = 2
    else: ep = 1
    return ep, deductions

def predict_technical_quality(f):
    deductions = []
    points = 5
    if f["excessive_punct"]: points -= 0.5; deductions.append("excessive_punct")
    if f["paras"] < 2 and f["chars"] > 500: points -= 1; deductions.append("wall_of_text")
    if f["avg_sent_words"] > 28: points -= 1; deductions.append("dense_sentences")
    if f["ai_signature"]: points -= 1; deductions.append("ai_signature")
    return int(round(max(1, points))), deductions

def predict_originality(f, pool_overlap=None):
    """OAA score 0-2 — multi-path + pool overlap penalty (V8.3 new)."""
    strong = sum([
        f["has_contrarian"], f["has_named_concept"], f["has_mechanism_reveal"],
        f["has_scene_opener"], f["has_mechanism_density"], f["has_qa_rhythm"],
    ])
    weak = sum([f["has_personal"], f["has_quoted"], f["has_definitional"], f["has_declarative_anchor"]])
    base = 0
    if strong >= 1: base = 2
    elif weak >= 2: base = 2
    elif weak >= 1: base = 1
    if f["ai_signature"]: base = max(0, base - 1)
    # Pool overlap penalty
    if pool_overlap and pool_overlap.get("nonwinner_overlap", 0) > 15:
        base = max(0, base - 1)
    return base

def predict_information_accuracy(f, text):
    tl = text.lower()
    if any(p in tl for p in ["guaranteed","100x","passive income","get rich","will make you","financial freedom"]):
        return 0
    return 2

def predict_compliance(text, brief):
    if not brief: return 2
    score = 2
    bl = brief.lower()
    for m in re.findall(r"@\w+", brief):
        if m.lower() not in text.lower():
            score -= 2; break
    if "one line" in bl and "\n" in text.strip(): score -= 1
    mm = re.search(r"max(?:imum)?\s+(\d+)\s+char", bl)
    if mm and content_chars(text) > int(mm.group(1)): score -= 1
    return max(0, score)

def predict_alignment(text, brief):
    if not brief: return 2
    bl = brief.lower(); tl = text.lower()
    brief_nouns = set(re.findall(r"\b[a-z]{5,}\b", bl)) - set(["tweet","post","content","share","write","create","make","include","please","rules","keep","with","this","that","your","these","mission","campaign","entry","original","author","language","creative","quality","matters","values","based","entries","format","brief","explain","describe","reply","comment","follow","style","example"])
    text_words = set(re.findall(r"\b[a-z]{4,}\b", tl))
    overlap = brief_nouns & text_words
    if len(brief_nouns) >= 5 and len(overlap) < 2: return 1
    return 2

def predict_reply_quality(f):
    if f["has_q_in_last2p_unquoted"] and not f["generic_cta"]: return 5
    if f["has_imperative_in_last2p"] and has_cta_specific(f["last_2p_unquoted"].lower()): return 5
    return 4

def predict_scores(text, brief="", pool_overlap=None):
    f = extract_features(text)
    ep, ep_d = predict_engagement_potential(f)
    tq, tq_d = predict_technical_quality(f)
    oaa = predict_originality(f, pool_overlap)
    ia = predict_information_accuracy(f, text)
    cc = predict_compliance(text, brief)
    ca = predict_alignment(text, brief)
    rq = predict_reply_quality(f)
    return {
        "Originality and Authenticity": oaa,
        "Content Alignment": ca,
        "Information Accuracy": ia,
        "Campaign Compliance": cc,
        "Engagement Potential": ep,
        "Technical Quality": tq,
        "Reply Quality": rq,
        "_features": f,
        "_ep_deductions": ep_d,
        "_tq_deductions": tq_d,
        "_pool_overlap": pool_overlap or {},
    }

def diagnose_missing(pred, text, brief):
    missing = []
    f = pred["_features"]
    targets = {"Originality and Authenticity":2,"Content Alignment":2,"Information Accuracy":2,"Campaign Compliance":2,"Engagement Potential":5,"Technical Quality":5,"Reply Quality":5}
    
    if pred["Engagement Potential"] < 5:
        for d in pred["_ep_deductions"]:
            fix = {
                "hook_weak": f"Rewrite opening sentence (current {f['first_sent_words']} words). Target: 9-18 words declarative, avoid 'so/well/honestly/just thinking'.",
                "hook_decent_not_sharp": "Add stronger first-sentence signal: scene opener, contrarian word ('actually/most people/the truth'), specific number, or 'X is Y, not Z' frame.",
                "structure_dense": f"Restructure to 4-13 stanza paragraphs (current {f['paras']}). Aim for avg sentence 8-18 words (current {f['avg_sent_words']:.0f}).",
                "value_moderate": "Add ≥1 of: NAMED concept ('X is Y'), mechanism reveal ('the way it works'), scene opener with personal stake, definitional contrast ('X is not always Y'), Q-A rhythm.",
                "cta_not_specific": "Replace generic question with specific personal/experience prompt: 'What's the X you Y?', 'Which would you Z?', 'Tell me about the time you...'.",
                "cta_url_no_specific": "URL is present but needs specific reply prompt too.",
                "cta_rhetorical_only": "Add either specific reply prompt or explicit imperative (visit/check/share/name).",
                "cta_url_only": "Add a specific question OR explicit imperative alongside the URL.",
                "cta_imperative_no_q": "Add a specific personal/experience question alongside the imperative.",
                "cta_generic": "Generic CTA ('thoughts?/agree?/drop yours/let me know') = EP4 ceiling. Use specific prompt instead.",
                "cta_missing": "Add explicit CTA — direct question OR imperative verb in last paragraph.",
                "conversation_limited": "Add specific reply path: 'Which/What/How would you...'.",
                "too_long": f"Current {f['chars']} chars > 1900. Cut to 900-1700 range.",
                "long_borderline": f"Current {f['chars']} chars. Trim to <1700 for safety.",
                "too_short": f"Current {f['chars']} chars < 400. Expand mechanism/scene/value to 900+.",
                "dense_long": "Long content with dense sentences — break into shorter paragraphs.",
                "ai_signature": "Remove AI-template phrases (delve into, let's unpack, in conclusion, navigate the).",
                "EP5_BLOCKED_no_engagement_trigger": "No ?, imperative, or URL in last 2 paragraphs → judge will write 'lacks CTA'. Add one.",
            }.get(d, d)
            missing.append({"category":"Engagement Potential","issue":d,"fix":fix})
    
    if pred["Technical Quality"] < 5:
        for d in pred["_tq_deductions"]:
            fix = {"excessive_punct":"Limit ! to ≤4 and ? to ≤6","wall_of_text":"Break into 4+ paragraphs","dense_sentences":"Cut sentences — winners avg 12 words","ai_signature":"Remove AI template phrases"}.get(d, d)
            missing.append({"category":"Technical Quality","issue":d,"fix":fix})
    
    if pred["Originality and Authenticity"] < 2:
        po = pred.get("_pool_overlap", {})
        if po.get("nonwinner_overlap", 0) > 15:
            missing.append({"category":"Originality and Authenticity","issue":"high_pool_overlap","fix":f"Content has {po['nonwinner_overlap']} 5-gram overlaps with non-winner pool. Rewrite key phrases."})
        else:
            missing.append({"category":"Originality and Authenticity","issue":"low_originality","fix":"Add contrarian frame OR named concept OR personal scene with specific verb."})
    if pred["Reply Quality"] < 5:
        missing.append({"category":"Reply Quality","issue":"reply_path","fix":"Need ? + non-generic in last 2 paragraphs OR imperative + specific prompt. Then submit + reply to comments adversarially."})
    if pred["Content Alignment"] < 2:
        missing.append({"category":"Content Alignment","issue":"brief_overlap_low","fix":"Include 2+ key topic words from brief verbatim."})
    if pred["Campaign Compliance"] < 2:
        missing.append({"category":"Campaign Compliance","issue":"format_or_mention","fix":"Verify required @mention, character limit, format rules."})
    return missing

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--brief", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--pool", default=None, help="Optional pool JSON for OAA overlap scan")
    args = ap.parse_args()
    text = Path(args.content).read_text(encoding="utf-8").strip()
    brief = Path(args.brief).read_text(encoding="utf-8") if args.brief and Path(args.brief).exists() else ""
    
    pool_overlap = None
    if args.pool and Path(args.pool).exists():
        pool = json.load(open(args.pool, encoding="utf-8"))
        winners = [s.get("content") or s.get("text") or "" for s in pool if s.get("isWinner") or s.get("winner")]
        nonwinners = [s.get("content") or s.get("text") or "" for s in pool if not (s.get("isWinner") or s.get("winner"))]
        pool_overlap = compute_pool_overlap(text, winners, nonwinners)
    
    pred = predict_scores(text, brief, pool_overlap)
    missing = diagnose_missing(pred, text, brief)
    targets = {"Originality and Authenticity":2,"Content Alignment":2,"Information Accuracy":2,"Campaign Compliance":2,"Engagement Potential":5,"Technical Quality":5,"Reply Quality":5}
    all_max = all(pred[k] >= v for k,v in targets.items())
    
    result = {
        "tool":"17_judge_replica.py V8.3",
        "predicted_scores": {k:v for k,v in pred.items() if not k.startswith("_")},
        "features": {k:v for k,v in pred["_features"].items() if not isinstance(v, str) or len(str(v))<200},
        "ep_deductions": pred["_ep_deductions"],
        "tq_deductions": pred["_tq_deductions"],
        "pool_overlap": pred["_pool_overlap"],
        "all_max_predicted": all_max,
        "missing_for_all_max": missing,
        "decision": "SUBMIT" if all_max else "REVISE",
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"\n═══ JUDGE REPLICA V8.3 — {result['decision']} ═══")
    for k,v in result["predicted_scores"].items():
        marker = "✓" if v >= targets[k] else "✗"
        print(f"  {marker} {k:35s} {v}/{targets[k]}")
    if missing:
        print(f"\n⚠️  {len(missing)} CONDITION(S) MISSING:")
        for m in missing:
            print(f"  · {m['category']:30s}: {m['issue']}")
            print(f"      FIX: {m['fix']}")
    else:
        print("\n✅ ALL CONDITIONS MET — predicted ALL-MAX.")
    sys.exit(0 if all_max else 1)

if __name__ == "__main__":
    main()
