#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
21_judge_replica_v84.py — V8.4 — SUB-RUBRIC AWARE

Reverse-engineered the COMPLETE Rally rubric from 677k verdicts:
  Engagement Potential (5/5) = 5 sub-rubrics, each 1/5 weight:
    1. Hook Effectiveness
    2. Content Structure
    3. Conversation Potential
    4. Value Delivery
    5. Call-to-Action Quality
  Technical Quality (5/5) = 5 sub-rubrics:
    1. Platform Optimization
    2. Language Mechanics
    3. Formatting
    4. Media Integration
    5. Thread Composition
  Originality and Authenticity (2/2) = 5 sub-rubrics:
    1. Unique Perspective
    2. Content Distinctiveness
    3. Language Authenticity
    4. Creative Expression
    5. Personal Voice
  Content Alignment (2/2) = 5 sub-rubrics:
    1. Message Accuracy
    2. Value Proposition
    3. Brand Consistency
    4. Terminology Usage
    5. Target Audience Alignment
  Information Accuracy (2/2) = 5 sub-rubrics:
    1. Technical Accuracy
    2. Documentation Alignment
    3. Claims Verification
    4. Context Accuracy
    5. Statistics
  Campaign Compliance (2/2) = 5 sub-rubrics:
    1. Required Mention
    2. Required Elements
    3. Format Compliance
    4. Guideline Adherence
    5. Content Restrictions
  Reply Quality (5/5) = 5 sub-rubrics:
    1. Subject-Matter Engagement
    2. Constructiveness
    3. Authenticity
    4. Civility
    5. Information Value

Each sub-rubric scored 0/1 → category MAX requires ALL sub-rubrics = 1.
"""
import argparse, json, re, sys, statistics, urllib.request
from pathlib import Path

# ============================================================
# CONTENT FEATURE EXTRACTORS (re-used from V8.3)
# ============================================================
def split_sentences(text):
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text.strip()) if s.strip()]
def split_paragraphs(text):
    return [p.strip() for p in re.split(r'\n\s*\n', text.strip()) if p.strip()]

def extract_features(text, brief=""):
    sents = split_sentences(text)
    paras = split_paragraphs(text)
    tl = text.lower()
    bl = brief.lower() if brief else ""
    last_2 = "\n\n".join(text.strip().split("\n\n")[-2:]) if text else ""
    last_2_l = last_2.lower()
    last_2_unq = re.sub(r'"[^"]*"', '', last_2)
    last_2_unq = re.sub(r"[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]", '', last_2_unq)
    
    return {
        "text": text, "brief": brief,
        "chars": len(text), "sents": len(sents), "paras": len(paras),
        "avg_sent_words": statistics.mean(len(s.split()) for s in sents) if sents else 0,
        "first_sent": sents[0] if sents else "",
        "first_sent_words": len(sents[0].split()) if sents else 0,
        "first_words": " ".join(text.split()[:5]).lower(),
        "last_2p": last_2,
        "last_2p_l": last_2_l,
        "last_2p_unq": last_2_unq,
        "has_qmark": "?" in text,
        "has_q_in_last2p": "?" in last_2_unq,
        "has_url_in_last2p": bool(re.search(r"https?://(?!t\.co|pic\.twitter)", last_2)),
        "has_mention": bool(re.search(r"@\w+", text)),
        "has_mention_in_brief": bool(re.search(r"@\w+", brief)),
        "required_mentions": re.findall(r"@\w+", brief),
        "required_hashtags": re.findall(r"#\w+", brief),
        # Hook signals
        "first_strong": any([
            re.search(r"\b(actually|verdict|wrong|most people|everyone|not just|broken|cooked)\b", (sents[0].lower() if sents else "")),
            re.search(r"^\d+", (sents[0] if sents else "")),
            re.search(r"\b(my|the|a)\s+\w+\s+(died|broke|failed|sat|stayed)\b", (sents[0].lower() if sents else "")),
        ]),
        # Generic CTA
        "has_generic_cta": any(g in last_2_l for g in [
            "thoughts?", "agree?", "what do you think", "drop yours", "drop your thoughts",
            "let me know.", "let me know in", "lmk", "your take?", "comment below!",
        ]),
        # Specific CTA pattern
        "has_specific_cta": _has_specific_cta(last_2_l),
        # Imperative
        "has_imperative_in_last2p": bool(re.search(
            r"\b(tell me|reply|comment|share|drop|pick|choose|name|visit|check|mint|join|claim|test|compare|rate|"
            r"go (?:check|see|stake|visit|build|read|learn|find|grab)|start here|see how|find out|read more|learn more|"
            r"explore|discover|try (?:it|this))\b", last_2_l)),
        # AI signature
        "ai_signature": any(re.search(r"\b" + re.escape(p) + r"\b(?!\w)", tl) for p in [
            "delve into", "let's unpack", "in this fast-paced world",
            "embark on", "in the realm of", "in conclusion",
            "to summarize", "to put it simply", "in today's landscape",
        ]),
        # Bad unicode
        "has_bad_unicode": False,  # disabled — winners use smart quotes
        # Excessive punct
        "has_excessive_punct": text.count("!") > 4 or text.count("?") > 6,
        # Raw URL (excluding pic/media)
        "has_url_anywhere": bool(re.search(r"https?://(?!t\.co|pic\.twitter)", text)),
        # Hashtag opening
        "starts_with_hashtag": text.strip().startswith("#"),
        "starts_with_mention": text.strip().startswith("@"),
        # Mention placement
        "mention_at_end": bool(re.search(r"@\w+\s*$", text.strip())),
        "mention_vocative": bool(re.search(r"\.\s+@\w+\s*\.", text)),
        # Scene/personal markers
        "has_scene_opener": _detect_scene(sents),
        "has_personal_voice": bool(re.search(r"\b(i|me|my|we|our|us)\b", tl)),
        "has_personal_specific": bool(re.search(r"\bi (was|spent|tried|built|saw|watched|remember|used|did|lost|won|hired|bought|wrote|posted|sent|paid|started)\b", tl)),
        "has_first_person": bool(re.search(r"\b(i|me|my|we)\b", tl)),
        # Content signals
        "has_contrarian": bool(re.search(r"\b(actually|verdict|wrong|most people|everyone says|but actually|the truth|unpopular|broken|cooked|mid|fake|hardest|not just|do not|cannot|won\u2019t|paradox)\b", tl)),
        "has_quoted": bool(re.search(r'"[^"]+"', text)) or bool(re.search(r'[\u201c\u201d][^\u201c\u201d]*[\u201c\u201d]', text)),
        "has_named_concept": bool(re.search(r"\b\w+ is \w+,?\s+not\b", tl)),
        "has_mechanism_reveal": bool(re.search(r"\b(the way|how it works|the trick|the secret|what no one|under the hood|the moment|the difference|the gap|the hidden|matters because|the problem is|here[\u2019']s how|the catch)\b", tl)),
        "has_specific_number": bool(re.search(r"\b\d+\s*(rlp|k|m|%|x|hours?|days?|years?|times?|cents?|dollars?|people|trees|tweets|posts|followers|impressions|memories|months|weeks)\b", tl)),
        "has_definitional": bool(re.search(r"\b(are not|is not|do not|does not) (always |necessarily |just |only |merely |the )", tl)),
        "has_qa_rhythm": len(re.findall(r"\b(Did|Does|Is|Are|What|How|Why|When|Where|Can|Could|Should|Would)\b[^?]{1,80}\?", text)) >= 2,
        "has_declarative_anchor": bool(re.search(r"\b(That is|This is|It is|There is|That[\u2019']s|It[\u2019']s) (the |a |an |where |when |why |how |what |not )", text, re.I)),
        # Hype phrases (kill)
        "has_hype": any(p in tl for p in ["game changer","this is huge","to the moon","lfg","this is everything","this hits different","mind blown"]),
        "has_unsupported_earning": any(p in tl for p in ["guaranteed","passive income","get rich","100x","will make you","financial freedom"]),
        # Slow opener
        "has_slow_opener": any((sents[0] if sents else "").lower().startswith(w) for w in ["so ","so,","well,","well ","honestly","just thinking","random thought","been thinking","lately ","i've been"]),
        # Brand promo bridge
        "has_brand_promo_bridge": any(re.search(rf"\b{p}\s+@\w+", tl) for p in ["that is why","this is exactly why","this is why"]),
        # Promotional density (≥2 brand mentions in <500 chars)
        "promo_density_high": len(re.findall(r"@\w+", text)) >= 3 and len(text) < 500,
        # Brief overlap
        "brief_words": _brief_topic_words(bl),
        "brief_overlap": _brief_overlap_count(tl, bl),
        # Media presence
        "has_media": bool(re.search(r"https?://(?:t\.co|pic\.twitter)", text)),
    }

def _has_specific_cta(last_l):
    return bool(re.search(
        r"\b("
        r"your (first|own|worst|best|smallest|biggest|next|last|version|take|verdict|story|experience|case|wallet|belief|setup|play|message|memory)|"
        r"the (time|moment|day|first time|last time|year|night) (you|when|that)|"
        r"which (would|one|industry|do you|matters|version|of|project|platform|field|kind|sort|type|ai|agent|word|deal|use case|crypto|nft|company|chapter|piece)|"
        r"what (is|are|was|were|kind of|kinds of|sort of|sorts of|type of|types of|field of|deal|word|agreement|industry|moment|piece|version|use case|other|everyday|killed|made|breaks|happens|matters|changes|truth|story|memory)|"
        r"what (would|do|did|have|has|could) you|"
        r"what[\u2019']s (a|an|the|one|your|been)|"
        r"name (one|a|the|me)|"
        r"tell me (your|about|one|the|how|what)|"
        r"how (do|did|would|have|has|much) you|"
        r"why (do|did|does|would) you|"
        r"have you (ever|seen|tried|noticed|been|had)|"
        r"would you rather|"
        r"if you (had to (choose|pick|decide)|could|were|are (building|using|joining|earning|trying))|"
        r"are you (building|using|joining|earning|trying|still|the kind)|"
        r" or [a-z]+\?|"
        r"share (your|how|what|the|one)"
        r")", last_l))

def _detect_scene(sents):
    if not sents: return False
    first2 = " ".join(sents[:2]).lower()
    return any([
        bool(re.search(r"\b(in|at|on|for|when)\s+\w+\s+(\w+\s+){0,4}(\d+|\w+ ago|years?|months?|weeks?|days?|night|morning)\b", first2)),
        bool(re.search(r"\b(my|our|the)\s+(cargo|package|wallet|account|client|team|company|partner|kid|dog|cat|house|order|invoice|warranty|paper|story|memory|moment|first|last|biggest|own)\b", first2)),
        bool(re.search(r"\b(a|the)\s+\w+\s+(died|broke|failed|came|arrived|sat|stayed|stopped|lost|cost|paid|charged)\b", first2)),
    ])

def _brief_topic_words(bl):
    return set(re.findall(r"\b[a-z]{5,}\b", bl)) - set(["tweet","post","content","share","write","create","make","include","please","rules","keep","with","this","that","your","these","mission","campaign","entry","original","author","language","creative","quality","matters","values","based","entries","format","brief","explain","describe","reply","comment","follow","style","example","others"])

def _brief_overlap_count(tl, bl):
    if not bl: return 99
    bws = _brief_topic_words(bl)
    text_words = set(re.findall(r"\b[a-z]{4,}\b", tl))
    return len(bws & text_words)

# ============================================================
# SUB-RUBRIC SCORERS (each returns 0/1 with reason)
# ============================================================

# === ENGAGEMENT POTENTIAL (5 sub-rubrics) ===
def score_hook_effectiveness(f):
    """Empirical: winner hooks are wildly varied. Only KILL slow openers."""
    if f["has_slow_opener"]: return (0, "slow opener (so/well/honestly/just thinking)")
    if f["first_sent_words"] < 3 or f["first_sent_words"] > 30: return (0, f"first sentence {f['first_sent_words']} words outside 3-30")
    if f["has_hype"]: 
        # Check if hype is IN the first sentence
        first_l = f["first_sent"].lower()
        if any(p in first_l for p in ["game changer","this is huge","to the moon"]):
            return (0, "hype phrase in hook")
    # Default: pass (winners use very wide variety of hook patterns)
    return (1, "hook acceptable")

def score_content_structure(f):
    """Length must be within winner band — too long causes 'may reduce digestibility' EP4."""
    if f["paras"] < 4 or f["paras"] > 15: return (0, f"paragraphs={f['paras']} outside 4-15")
    if f["avg_sent_words"] < 7 or f["avg_sent_words"] > 20: return (0, f"avg sentence {f['avg_sent_words']:.1f} outside 7-20")
    if f["chars"] < 500: return (0, f"chars={f['chars']} below 500")
    if f["chars"] > 1700: return (0, f"chars={f['chars']} above 1700 (judge will say 'reduces digestibility')")
    return (1, "structure within winner band")

def score_conversation_potential(f):
    if f["has_generic_cta"]: return (0, "generic CTA (thoughts/agree/drop yours)")
    if not f["has_q_in_last2p"] and not f["has_imperative_in_last2p"] and not f["has_url_in_last2p"]:
        return (0, "no engagement trigger in last 2 paragraphs")
    if f["has_q_in_last2p"] and f["has_specific_cta"]: return (1, "specific question CTA")
    if f["has_q_in_last2p"]: return (1, "question CTA")
    if f["has_imperative_in_last2p"] and (f["has_url_in_last2p"] or f["has_specific_cta"]): return (1, "imperative + URL/specific")
    return (0, "weak conversation path")

def score_value_delivery(f):
    """Empirical: winners deliver value via many signals. Any 1 strong = OK."""
    signals = sum([
        f["has_named_concept"], f["has_mechanism_reveal"], f["has_definitional"],
        f["has_qa_rhythm"], f["has_scene_opener"], f["has_quoted"],
        f["has_contrarian"], f["has_personal_specific"],
        f["has_specific_number"], f["has_declarative_anchor"],
    ])
    # Need at least 3 STRONG signals OR 2 + long-form depth
    if signals >= 3: return (1, f"value signals ≥3 ({signals})")
    if f["chars"] >= 900 and f["paras"] >= 5 and signals >= 2: return (1, f"long-form structured, {signals} value signals")
    if signals >= 2: return (0, f"only {signals} value signals, no long-form depth")
    if signals == 1 and f["chars"] >= 1000: return (0, "1 signal even with long-form — borderline")
    return (0, "insufficient value signals — judge will say 'moderate'")

def score_cta_quality(f):
    """V8.4.1 — EMPIRICAL: 1413 EP=4 verdicts say 'lacks call to action' / 'lacks direct'.
    
    EP=5 CTAs are DIRECT-IMPERATIVE-DRIVEN, not rhetorical-question-driven.
    Pattern matches:
      ✓ "Name one X" / "Tell me X" / "Reply with X" = direct
      ✓ "What's the X you Y?" = specific personal question (Y=did/found/built)
      ✓ Imperative-verb + URL + specific personal question
      ✗ "What kind of X do you think Y will Z?" = philosophical = EP4
      ✗ "Would you rather X or Y?" alone with no body anchor = EP4
      ✗ Question + referral URL = "CTA split" = EP4
    """
    import re
    if f["has_generic_cta"]: return (0, "generic CTA = EP4 ceiling")
    
    last_l = f["last_2p_l"]
    
    # KILL: Referral link in last 2p WITH question = "CTA split"
    has_referral = bool(re.search(r"\?ref=|/joinme/|/r/", f["last_2p"]))
    if has_referral and f["has_q_in_last2p"]:
        return (0, "referral link + question = 'CTA split between click and answer' (EP4 pattern)")
    if has_referral and not f["has_specific_cta"]:
        return (0, "referral link without specific CTA = promotional EP4")
    
    # KILL: Pure rhetorical philosophical Q ("What kind of X do you think will...")
    philosophical_q = bool(re.search(r"\bwhat (kind|sort|type) of \w+ (?:do you think|will|would|could|might)", last_l))
    if philosophical_q and not f["has_imperative_in_last2p"]:
        # rhetorical philosophical = "could be more direct" EP4
        if not bool(re.search(r"\b(name|tell|share|reply|comment|drop|pick|choose|visit)\b", last_l)):
            return (0, "philosophical 'what kind do you think' = EP4 ('lacks direct')")
    
    # DIRECT IMPERATIVE CTA = strongest pattern
    direct_imperative = bool(re.search(
        r"\b(name (?:one|a|the)|tell me (?:your|the|one)|reply with|drop (?:a|your|the)|share (?:the|your|one)|pick (?:one|your))\b",
        last_l))
    if direct_imperative:
        return (1, "direct imperative CTA")
    
    # SPECIFIC personal-experience Q: "What's the X you did?" / "What is the most X you Y?"
    personal_exp_q = bool(re.search(
        r"\b(what['\u2019]s the (?:one|first|last|smallest|biggest|worst|best)|"
        r"what is the (?:one|first|last|smallest|biggest|worst|most) [\w\s]{1,30} you (?:did|made|built|found|saw|fixed|won|lost|tried|spent|chose|wrote))\b",
        last_l))
    if personal_exp_q:
        return (1, "specific personal-experience question")
    
    # SPECIFIC + question with named target
    if f["has_q_in_last2p"] and f["has_specific_cta"]:
        # require body must have strong signals to support the question
        body_signals = sum([f["has_scene_opener"], f["has_personal_specific"], 
                            f["has_named_concept"], f["has_mechanism_reveal"],
                            f["has_definitional"], f["has_qa_rhythm"]])
        if body_signals >= 2:
            return (1, "specific Q + strong body content")
        return (0, "specific Q but body lacks 2+ strong signals — judge may say 'lacks direct'")
    
    # URL + question with specific (action-driven)
    if f["has_url_in_last2p"] and f["has_q_in_last2p"] and f["has_specific_cta"]:
        return (1, "URL + specific question")
    
    # Open question alone — strictest: need MULTIPLE body anchors
    if f["has_q_in_last2p"]:
        body_signals = sum([f["has_scene_opener"], f["has_personal_specific"], 
                            f["has_named_concept"], f["has_mechanism_reveal"],
                            f["has_contrarian"]])
        if body_signals >= 3:
            return (1, f"open Q + {body_signals} body anchors")
        return (0, f"open Q without sufficient body anchors ({body_signals})")
    
    if f["has_imperative_in_last2p"] and f["has_url_in_last2p"]:
        return (1, "imperative + URL CTA")
    
    if f["has_imperative_in_last2p"]:
        return (0, "imperative without question/URL — partial")
    
    return (0, "CTA missing/implicit")

# === TECHNICAL QUALITY (5 sub-rubrics) ===
def score_platform_optimization(f):
    if f["chars"] > 1900: return (0, "too long for platform")
    if f["has_excessive_punct"]: return (0, "excessive punctuation")
    if f["starts_with_hashtag"] or f["starts_with_mention"]: return (0, "starts with @/# (X platform rule violation)")
    return (1, "platform-optimized")

def score_language_mechanics(f):
    if f["ai_signature"]: return (0, "AI-template phrasing")
    return (1, "language mechanics clean")

def score_formatting(f):
    if f["paras"] < 2 and f["chars"] > 500: return (0, "wall of text")
    if f["avg_sent_words"] > 25: return (0, "sentences too long")
    return (1, "formatting OK")

def score_media_integration(f):
    # If no media, judge usually OK; if media present, check it's via t.co (native)
    if f["has_url_anywhere"] and not f["has_media"]:
        # raw URL in body not via t.co — neutral, often OK in Rally
        return (1, "URL handled OK")
    return (1, "media integration OK")

def score_thread_composition(f):
    # Single-tweet content — generally pass unless brief required thread
    if f["chars"] > 280 and "thread" in f["brief"].lower():
        return (1, "thread permitted by brief")
    return (1, "single post composition")

# === ORIGINALITY & AUTHENTICITY (5 sub-rubrics) ===
def score_unique_perspective(f, pool_overlap=None):
    if not (f["has_contrarian"] or f["has_named_concept"] or f["has_mechanism_reveal"] or f["has_scene_opener"]):
        return (0, "no unique angle")
    if pool_overlap and pool_overlap.get("nonwinner_overlap_5gram", 0) > 5:
        return (0, "high non-winner pool overlap (not unique)")
    return (1, "unique perspective")

def score_content_distinctiveness(f, pool_overlap=None):
    if pool_overlap:
        if pool_overlap.get("nonwinner_overlap_5gram", 0) > 8:
            return (0, "overlaps heavily with non-winner pool")
    if f["ai_signature"]: return (0, "AI-template feeling")
    # Multiple referral URLs = formulaic referral spam (kills distinctiveness)
    import re
    ref_count = len(re.findall(r"\?ref=", f["text"]))
    if ref_count >= 1 and "join" in f["last_2p_l"] and "invite" in f["text"].lower():
        return (0, "referral spam pattern (ref link + join/invite)")
    return (1, "distinctive")

def score_language_authenticity(f):
    if f["ai_signature"]: return (0, "AI-template language")
    if f["has_hype"]: return (0, "hype phrases (game changer etc)")
    return (1, "natural/authentic language")

def score_creative_expression(f):
    """Winners are very varied. Pass if ANY creative device present."""
    if f["has_quoted"] or f["has_named_concept"] or f["has_scene_opener"]: return (1, "named/quoted/scene")
    if f["has_definitional"] or f["has_qa_rhythm"] or f["has_mechanism_reveal"]: return (1, "definitional/QA/mechanism")
    if f["has_contrarian"]: return (1, "contrarian frame")
    if f["chars"] >= 800 and f["paras"] >= 5: return (1, "long-form structured (creative depth)")
    return (0, "lacks creative device")

def score_personal_voice(f):
    """Winners use personal voice broadly — include first-person OR conversational tone OR contrarian opinion."""
    if f["has_personal_specific"] or f["has_personal_voice"]: return (1, "personal voice present")
    if f["has_contrarian"]: return (1, "opinionated voice")
    if f["chars"] >= 600: return (1, "voice present in long-form")
    return (0, "voice generic/impersonal")

# === CONTENT ALIGNMENT (5 sub-rubrics) ===
def score_message_accuracy(f):
    if not f["brief"]: return (1, "no brief to check")
    if f["brief_overlap"] < 2: return (0, "low brief topic overlap")
    return (1, "message aligned with brief")

def score_value_proposition(f):
    if not f["brief"]: return (1, "no brief")
    return (1, "value prop present")  # usually passes unless very generic

def score_brand_consistency(f):
    if f["has_brand_promo_bridge"]: return (0, "promotional bridge feels forced")
    if f["has_mention_in_brief"]:
        for m in f["required_mentions"]:
            if m.lower() in f["text"].lower():
                return (1, f"brand {m} mentioned naturally")
        return (0, f"required mention {f['required_mentions']} missing")
    return (1, "brand consistency OK")

def score_terminology_usage(f):
    if f["brief"] and f["brief_overlap"] >= 2: return (1, "terminology aligned")
    return (1, "terminology OK")

def score_target_audience_alignment(f):
    return (1, "audience targeted via brief topic")

# === INFORMATION ACCURACY (5 sub-rubrics) ===
def score_technical_accuracy(f):
    if f["has_unsupported_earning"]: return (0, "unsupported earning claim")
    return (1, "technical accuracy OK")

def score_documentation_alignment(f):
    return (1, "doc alignment OK")  # hard to check without brief docs

def score_claims_verification(f):
    if f["has_unsupported_earning"]: return (0, "guarantee/profit claim unsupported")
    return (1, "claims verifiable")

def score_context_accuracy(f):
    return (1, "context OK")

def score_statistics(f):
    return (1, "statistics OK")

# === CAMPAIGN COMPLIANCE (5 sub-rubrics) ===
def score_required_mention(f):
    if not f["required_mentions"]: return (1, "no required mention in brief")
    for m in f["required_mentions"]:
        if m.lower() not in f["text"].lower(): return (0, f"missing {m}")
    return (1, "all required mentions present")

def score_required_elements(f):
    for h in f["required_hashtags"]:
        if h.lower() not in f["text"].lower(): return (0, f"missing hashtag {h}")
    return (1, "elements present")

def score_format_compliance(f):
    bl = f["brief"].lower() if f["brief"] else ""
    if "one line" in bl and "\n" in f["text"].strip(): return (0, "brief requires one line")
    if "no thread" in bl and f["chars"] > 280: return (0, "brief forbids thread")
    mm = re.search(r"max(?:imum)?\s+(\d+)\s+char", bl)
    if mm and f["chars"] > int(mm.group(1)): return (0, f"exceeds {mm.group(1)} chars")
    return (1, "format OK")

def score_guideline_adherence(f):
    if f["starts_with_hashtag"] or f["starts_with_mention"]:
        return (0, "starts with @/#")
    return (1, "guidelines followed")

def score_content_restrictions(f):
    if f["has_unsupported_earning"]: return (0, "unsupported earning = content restriction violation")
    return (1, "content restrictions OK")

# === REPLY QUALITY (5 sub-rubrics) — note: RQ depends on actual replies, here we estimate INVITATIONAL ===
def score_subject_engagement(f):
    if f["has_q_in_last2p"] and not f["has_generic_cta"]: return (1, "invites subject engagement")
    if f["has_specific_cta"]: return (1, "specific reply prompt")
    return (0, "weak reply invitation")
def score_constructiveness(f): return (1, "estimated constructive")
def score_authenticity_rq(f):
    if f["has_personal_specific"] or f["has_contrarian"]: return (1, "authentic invite")
    return (1, "authentic")
def score_civility(f): return (1, "civil")
def score_information_value_rq(f):
    """RQ info value — broad pass for any substantive content."""
    if f["has_named_concept"] or f["has_mechanism_reveal"] or f["has_qa_rhythm"] or f["has_definitional"]: return (1, "high info value")
    if f["has_contrarian"] or f["has_scene_opener"] or f["has_specific_number"]: return (1, "substantive content")
    if f["chars"] >= 800: return (1, "long-form depth")
    return (0, "info value moderate")

# ============================================================
# MAPPER: sub-rubric scores → category scores
# ============================================================

SUB_RUBRIC_CATEGORIES = {
    "Engagement Potential": [
        ("Hook Effectiveness", score_hook_effectiveness),
        ("Content Structure", score_content_structure),
        ("Conversation Potential", score_conversation_potential),
        ("Value Delivery", score_value_delivery),
        ("Call-to-Action Quality", score_cta_quality),
    ],
    "Technical Quality": [
        ("Platform Optimization", score_platform_optimization),
        ("Language Mechanics", score_language_mechanics),
        ("Formatting", score_formatting),
        ("Media Integration", score_media_integration),
        ("Thread Composition", score_thread_composition),
    ],
    "Originality and Authenticity": [
        ("Unique Perspective", score_unique_perspective),
        ("Content Distinctiveness", score_content_distinctiveness),
        ("Language Authenticity", score_language_authenticity),
        ("Creative Expression", score_creative_expression),
        ("Personal Voice", score_personal_voice),
    ],
    "Content Alignment": [
        ("Message Accuracy", score_message_accuracy),
        ("Value Proposition", score_value_proposition),
        ("Brand Consistency", score_brand_consistency),
        ("Terminology Usage", score_terminology_usage),
        ("Target Audience Alignment", score_target_audience_alignment),
    ],
    "Information Accuracy": [
        ("Technical Accuracy", score_technical_accuracy),
        ("Documentation Alignment", score_documentation_alignment),
        ("Claims Verification", score_claims_verification),
        ("Context Accuracy", score_context_accuracy),
        ("Statistics", score_statistics),
    ],
    "Campaign Compliance": [
        ("Required Mention", score_required_mention),
        ("Required Elements", score_required_elements),
        ("Format Compliance", score_format_compliance),
        ("Guideline Adherence", score_guideline_adherence),
        ("Content Restrictions", score_content_restrictions),
    ],
    "Reply Quality": [
        ("Subject-Matter Engagement", score_subject_engagement),
        ("Constructiveness", score_constructiveness),
        ("Authenticity", score_authenticity_rq),
        ("Civility", score_civility),
        ("Information Value", score_information_value_rq),
    ],
}

CATEGORY_MAX = {
    "Engagement Potential": 5, "Technical Quality": 5, "Reply Quality": 5,
    "Originality and Authenticity": 2, "Content Alignment": 2,
    "Information Accuracy": 2, "Campaign Compliance": 2,
}

def predict_scores(text, brief="", pool_overlap=None):
    f = extract_features(text, brief)
    out = {}
    detail = {}
    for cat, subs in SUB_RUBRIC_CATEGORIES.items():
        results = []
        for name, fn in subs:
            # Some scorers accept pool_overlap
            if name in ["Unique Perspective", "Content Distinctiveness"]:
                s, reason = fn(f, pool_overlap)
            else:
                s, reason = fn(f)
            results.append({"sub":name, "score":s, "reason":reason})
        passed = sum(r["score"] for r in results)
        # Map sub-rubric pass rate to category score
        # For max=5: need ALL 5 sub-rubrics passed → 5; else fewer
        # For max=2: need ALL 5 passed → 2; 4 → 1; <4 → 0 (CC/CA/IA are usually easy)
        mx = CATEGORY_MAX[cat]
        if mx == 5:
            # For 5-max (EP/TQ/RQ): 5 subs passed = 5, 4 = 4, 3 = 3, etc.
            # Each sub contributes ~1 point, but CTA Quality has 2x weight for EP empirically.
            cat_score = passed
        else:
            # For 2-max (OAA/CA/IA/CC): need 4+ subs for MAX (relaxed from 5)
            if passed >= 4: cat_score = 2
            elif passed >= 3: cat_score = 1
            else: cat_score = 0
        out[cat] = cat_score
        detail[cat] = {"score": cat_score, "max": mx, "sub_passed": passed, "sub_results": results}
    return out, detail, f

def diagnose(out, detail):
    missing = []
    for cat, info in detail.items():
        mx = info["max"]
        if info["score"] < mx:
            failing = [r for r in info["sub_results"] if r["score"] == 0]
            for r in failing:
                missing.append({"category":cat, "sub_rubric":r["sub"], "reason":r["reason"]})
    return missing

# ============================================================
# MAIN
# ============================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--brief", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--pool-overlap", default=None, help="Path to pool overlap report from tool 20")
    args = ap.parse_args()
    
    text = Path(args.content).read_text(encoding="utf-8").strip()
    brief = Path(args.brief).read_text(encoding="utf-8") if args.brief and Path(args.brief).exists() else ""
    pool_overlap = None
    if args.pool_overlap and Path(args.pool_overlap).exists():
        po = json.load(open(args.pool_overlap, encoding="utf-8"))
        # extract 5gram nonwinner-only count
        five = po.get("findings", {}).get("5gram", {})
        pool_overlap = {"nonwinner_overlap_5gram": len(five.get("loser_dna_only_phrases", []))}
    
    scores, detail, features = predict_scores(text, brief, pool_overlap)
    missing = diagnose(scores, detail)
    all_max = all(scores[c] >= CATEGORY_MAX[c] for c in scores)
    
    result = {
        "tool": "21_judge_replica_v84.py V8.4",
        "predicted_scores": scores,
        "category_detail": detail,
        "missing": missing,
        "all_max_predicted": all_max,
        "decision": "SUBMIT" if all_max else "REVISE",
        "features_summary": {
            k:v for k,v in features.items()
            if not k.startswith(("text","brief","last_2p","first_sent","first_words")) and not isinstance(v, (set, list))
        }
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    
    print(f"\n═══ JUDGE REPLICA V8.4 — {result['decision']} ═══")
    for cat, sc in scores.items():
        mx = CATEGORY_MAX[cat]
        marker = "✓" if sc >= mx else "✗"
        sub_p = detail[cat]["sub_passed"]
        print(f"  {marker} {cat:35s} {sc}/{mx}   (sub-rubrics: {sub_p}/5 passed)")
    if missing:
        print(f"\n⚠️  {len(missing)} SUB-RUBRIC(S) FAILING:")
        for m in missing:
            print(f"  · [{m['category']}] {m['sub_rubric']}: {m['reason']}")
    else:
        print("\n✅ ALL 35 SUB-RUBRICS PASSED — predicted ALL-MAX.")
    sys.exit(0 if all_max else 1)

if __name__ == "__main__":
    main()
