# RALLY SKILL V7.7 → V8.0 — ANALISIS MENDALAM & BLUEPRINT PERBAIKAN
**Tanggal analisis:** 2026-06-26 Asia/Jakarta
**Status:** Draft untuk persetujuan user sebelum eksekusi rewrite

---

## ⚠️ PERNYATAAN JUJUR DI DEPAN (WAJIB BACA)

**Tidak ada skill yang dapat MENJAMIN 100% all-MAX dari juri Rally.** Alasan struktural:

1. **Juri Rally = LLM-based, stokastik.** Konten yang sama dijuri ulang bisa berbeda 0.5–1 poin per gate. Sumber: terdokumentasi di `JUDGE-VARIANCE-HARDENING-PROTOCOL.md` skill Anda sendiri ("juri LLM tidak deterministik").
2. **Base rate ALL-MAX di Rally rendah.** Calibration memory Anda mencatat campaign GenLayer: 1505 submission → 24 winner ALL-MAX = **1.6%**. Bahkan eksekusi sempurna pun probabilistic, bukan deterministic.
3. **Skill V7.7 sendiri akui** di `STEP0-PREFLIGHT-RULES.md` §0.7: *"DILARANG klaim 100% pass"*.

**Yang BISA dijamin oleh V8.0 (target realistis & jujur):**

| Metrik | V7.7 sekarang (estimasi) | V8.0 target |
|---|---|---|
| P(EP ≥ 4) | ~75% | ≥ 95% (floor protection) |
| P(EP = 5) | ~30–40% | ≥ 65–75% |
| P(ALL-MAX run) | ~10–15% | ≥ 35–50% |
| Konsistensi run-to-run (σ skor) | besar (judge variance + skill drift) | kecil (deterministic pre-flight, scanner mandatory) |
| Akar penyebab miss yang ditutup | 60% | ≥ 95% |

**V8.0 tidak menjual "garansi all-MAX". V8.0 menjual: "setiap konten yang lolos pipeline ini punya probabilitas all-MAX yang dimaksimalkan secara matematis dan tidak akan kalah di kelas EP<4 / kill-pattern manapun."**

---

## BAGIAN 1 — 14 CELAH FATAL DI SKILL V7.7

### CELAH #1 — Skill files TERLALU BANYAK & TUMPANG TINDIH
**Bukti:** 16 file `.md` di `/skills/` (5800 baris file utama saja) + 17 `.py`. README sendiri mengakui *"Dokumen ini 5.800 baris; TIDAK ADA manusia/LLM yang mengeksekusi semuanya per run."*
**Dampak:** LLM eksekutor (Claude/GPT/Gemini) lupa aturan saat run, fallback ke "feeling", skip step. Ini bug No.1 yang berulang.
**Fix V8:** Konsolidasi ke **3 file aktif**: `SKILL.md` (single source of truth, ≤800 baris), `RUNTIME-CHECKLIST.md` (≤200 baris, dibaca tiap step), `LEXICON-DATA.md` (data terpisah). Semua file lain → folder `archive/`.

### CELAH #2 — Tidak ada Hard-Gate Mekanis untuk Top-5 EP Kill-Pattern
**Bukti:** `rally-rules.py` hanya scan **vonis simulasi** (jadi: scanner menilai TEBAKAN Anda terhadap vonis, bukan konten). `rally-compliance-gate.py` hanya cek format mekanis (mention, char count, period). **Tidak ada tool yang scan KONTEN langsung untuk EP4 killers** (lemah CTA, generic hype, hook lemah, brand bridge promo).
**Dampak:** Konten lolos semua scanner namun kena EP4 di juri asli karena CTA generic — kasus yang persis terjadi di Wingston mission-0 (didokumentasikan di `CTA-QUALITY-SEPARATION-PROTOCOL.md`).
**Fix V8:** Tambah `rally-kill-pattern-scanner.py` yang scan **KONTEN langsung** terhadap 10 top kill-pattern global (sudah ada datanya di `GLOBAL-EP4-PLAYBOOK.json`: cta.other=9508, hook.not_sharp=8273, media.raw=6760, conversation.other=6424, value.other=4049, structure.formatting=4011, specificity.missing=3186, generic.formulaic=2835, structure.dense=2789, cta.no_direct_prompt=2353).

### CELAH #3 — Self-Judge tetap Self-Judge, Disclaimer ≠ Mitigasi
**Bukti:** STEP0 §0.5 — disclosure 4 mitigasi, tapi yang menulis vonis = yang menulis konten = sesi yang sama = bias konfirmasi tetap 100% aktif. Disclaimer hanya jujur, tidak menyelesaikan.
**Dampak:** vonis.json yang dipakai scanner = optimistic, scanner PASS terus, juri asli SLAP.
**Fix V8:** Wajibkan **dual-model judge** — jalankan judge prompt di **API call terpisah** ke model berbeda (Claude → judge oleh GPT/Gemini, atau swap). Bila tidak available, **adversarial role-play hard mode**: judge persona DILARANG menulis kata positif sampai sudah menulis ≥3 kritik per gate. Output judge dikunci JSON-schema (tidak boleh ada kata bebas).

### CELAH #4 — Winner-DNA Extraction = Surface-Mining, BUKAN Mechanism-Mining
**Bukti:** `rally-winner-dna-map.py` ekstrak: opener types, CTA forms, mention placement, vocab. Semua surface. **Tidak ada extraction MECHANISM** ("kenapa winner ini menang? thesis apa yang dipikir juri saat memberi MAX?")
**Dampak:** Konten kita meniru SURFACE winner (struktur paragraf, kata kunci) tapi miss MECHANISM (insight density, contrarian angle, mechanism-naming). Hasilnya: kelihatan mirip winner, dapat EP4 karena "solid but not exceptional."
**Fix V8:** Tambah `rally-mechanism-extractor.py` yang untuk setiap winner ALL-MAX:
- Ekstrak **judge praise verbatim** dari vonis ("exceptional ___", "named ___", "fresh lens ___")
- Klasifikasi mechanism: NAMED_CONCEPT / CONTRARIAN_VERDICT / MECHANISM_REVEAL / RESOURCE_ROUTING / VULNERABLE_SCENE / DATA_FRAME
- Output: "winner ALL-MAX di mission ini punya 3 mechanism dominan: X (n=8), Y (n=6), Z (n=3). Konten kita WAJIB punya ≥1."

### CELAH #5 — Tidak ada Quantitative Champion Delta vs Pool
**Bukti:** `INTERNAL_DECISION_SUMMARY_TEMPLATE.md` minta "Champion Delta vs top-2 pool: SUPERIOR/PARITY/INFERIOR per axis." Tapi tidak ada angka, hanya label subjektif.
**Dampak:** Klaim "superior" hanya wishful thinking. Skill V7.7 sendiri akui (lock-reason): *"Top-1% mandate paritas diklaim superior"*.
**Fix V8:** **Champion Delta Score (CDS)** terkuantifikasi per axis:
- Insight Density Score (unique concept-noun per 100 char)
- Specificity Score (concrete details count: name/number/place/tool)
- Conversation Affordance Score (reply path clarity 0–5)
- Hook Stop-Score (top-3 word strength vs pool median)
- CTA Quality Score (formula 5/5)
Konten lolos hanya jika ≥4 axis CDS ≥ pool top-5 median.

### CELAH #6 — Mission-Type Playbook Hanya 5 Tipe, Underspecified
**Bukti:** `MISSION-SOUL-PROTOCOL.md` §3: EXPLAIN/IDENTIFY/PERSUADE/PREDICT/IMAGINE. Tidak cover: REVIEW/RANK, COMPARE, REACT/HOT-TAKE, BUILD/SHIP, MEME, STORY/EXPERIENCE.
**Dampak:** Mission ambigu → ditebak. Tebakan salah → struktur salah → rebuild biaya 1 jam.
**Fix V8:** Expand ke **12 mission-type** dengan struktur template + opener template + CTA template per tipe. Auto-classifier dari brief verbatim.

### CELAH #7 — DNA Fetcher Single Point of Failure
**Bukti:** `rally-dna-fetcher.py` README: "234/274 berhasil = 86%, 40 fragmen vonis (14%)." Untuk 14% tweet yang dihapus, DNA hanya fragmen — keputusan mission-critical dibuat dari data tidak lengkap.
**Dampak:** Winner pattern yang penting bisa di-miss karena ada di tweet yang dihapus.
**Fix V8:**
- Tambah fallback ke Wayback Machine snapshot
- Tambah Nitter mirror (jika up)
- Untuk tweet hilang: ekstrak **maximum quote** dari vonis judge (judge biasanya quote 1-3 kalimat penting)
- Tag confidence per-submission: HIGH (full text), MEDIUM (judge-quoted), LOW (fragment only)
- Skill harus tahu confidence level saat pakai data tersebut

### CELAH #8 — Tidak ada A/B Pre-Submit Test
**Bukti:** Pipeline V7.7 keluarkan 1 konten final. Tidak ada mekanisme bandingkan 2 kandidat dengan judge-ensemble dan pilih winner berdasarkan vote.
**Dampak:** Pilihan final = "single-best autonomous" tanpa empiris.
**Fix V8:** **Mandatory dual-candidate pipeline**:
1. Generate Candidate A (struktur mission-type default)
2. Generate Candidate B (struktur contrarian/risk-rewarded)
3. Jalankan 5-persona judge **dua-duanya**
4. Pilih yang worst-credible verdict-nya lebih tinggi
5. Jika tied → pilih yang Champion Delta Score lebih tinggi

### CELAH #9 — Loser-DNA Hanya n-gram Surface, Tidak Semantik
**Bukti:** `rally-loser-dna-scan.py` cek 4-8 gram exact match. Loser pattern semantik (mis. "self-implication CTA tanpa concrete object", "metaphor stack", "brand bridge tacked-on") tidak terdeteksi.
**Dampak:** Konten rewrite phrasing → lolos n-gram scan → tapi struktur loser pattern masih hidup → tetap EP4.
**Fix V8:** Tambah **semantic loser-pattern matcher** dengan 25 pattern terdefinisi (per gate: 5 EP / 5 OAA / 5 IA / 5 TQ / 5 CA), masing-masing dengan regex/heuristik + contoh negative.

### CELAH #10 — Tidak ada Calibration Loop yang Aktif
**Bukti:** `calibration-memory.json` hanya 1 entry (GenLayer mission-0, rallyResult="pending"). Tidak ada loop yang baca hasil real submit → update lexicon → adjust skill.
**Dampak:** Skill tidak belajar dari hasil real. Setiap miss diulang.
**Fix V8:** Tool `rally-postmortem-ingest.py`:
- Input: tweetId yang sudah disubmit + actual verdict dari Rally API
- Diff: prediksi internal vs vonis asli
- Auto-tagging: per gate, prediksi BENAR/OVER/UNDER
- Append ke `calibration-memory.json` + auto-generate active lesson ke `ADAPTIVE-RATCHET-LESSONS.md`
- Setiap 5 entry baru → rebuild `confidence-priors.json` (per-gate hit rate)

### CELAH #11 — Tidak ada Hard-Stop saat Time-Budget Habis
**Bukti:** STEP0 §0.8: "Deadline < 4 jam → STOP & tanya." Tapi tidak ada timer aktif, tidak ada budget per step.
**Dampak:** Run 5 jam → kena deadline → output buru-buru → low quality.
**Fix V8:** Budget per step (default 30 menit/step, max 4 jam total). Tool `rally-timer.py` track wall-clock. Saat 75% budget habis → switch ke "fast-path mode" (skip nice-to-have, fokus hard-gate).

### CELAH #12 — Brief Decoder Manual, Bukan Tool-Backed
**Bukti:** STEP 0.5 Mission-Soul Decode hanya prompt narasi. Tergantung agent ingat untuk run.
**Dampak:** 3/8 winner GenLayer salah-klasifikasi (didokumentasikan di MISSION-SOUL-PROTOCOL.md §1).
**Fix V8:** `rally-brief-decoder.py` — input: brief verbatim, output: mission-type classification + structure template + danger-flag (jika brief ambigu, agent dipaksa rebuild decode).

### CELAH #13 — QnA Engine RQ 5/5 Tidak Punya Adversarial Test
**Bukti:** `rally-qna-engine.md` produce 20 Q/A. Tapi tidak ada test "apakah QnA ini akan dilihat juri RQ sebagai 'organic friend reply' atau 'AI-generated batch'?"
**Dampak:** RQ 5/5 sangat jarang (skill bilang 4 dari 64 di pool = 6%). Banyak miss di RQ.
**Fix V8:** `rally-qna-adversarial.py`:
- Test: keragaman opener (no 2 reply mulai dengan kata sama)
- Test: lexicon overlap antar reply (cosine similarity max 0.4)
- Test: voice diversity (≥4 voice persona di 20 reply)
- Test: anti-AI signature (no "great point!", "love this!", "this resonates")
- Hard fail jika ≥3 reply punya pattern AI

### CELAH #14 — Tidak ada Versioning / Rollback Real
**Bukti:** Banyak file `.original-duplicated.md`, no git, no semver.
**Dampak:** Edit skill yang merusak tidak bisa di-rollback. Regresi terjadi (skill sendiri akui: "OAA 192→184, TQ 246→192").
**Fix V8:** Skill dipisah jadi semver `v8.0.0`. Setiap edit lexicon di-tag dengan tanggal + sumber vonis + regression test result. Folder `archive/v7.7-frozen/` untuk rollback emergency.

---

## BAGIAN 2 — ARSITEKTUR V8.0 (RAMPING & DETERMINISTIK)

```
skills/  (ACTIVE — load setiap /rally)
├── SKILL.md                          ← single source of truth, ≤800 baris
├── RUNTIME-CHECKLIST.md              ← per-step checklist mekanis ≤200 baris
├── LEXICON-DATA.md                   ← data terpisah (kill phrases, win phrases, vocab)
├── tools/
│   ├── 01_brief_decoder.py           ← brief → mission-type + structure (CELAH #6,#12)
│   ├── 02_dna_fetcher_v2.py          ← multi-source + confidence tagging (CELAH #7)
│   ├── 03_winner_mechanism_map.py    ← surface + MECHANISM extraction (CELAH #4)
│   ├── 04_champion_delta_score.py    ← quantitative CDS vs pool (CELAH #5)
│   ├── 05_kill_pattern_scanner.py    ← scan KONTEN, bukan vonis (CELAH #2)
│   ├── 06_loser_semantic_scan.py     ← 25 semantic patterns (CELAH #9)
│   ├── 07_cta_formula_check.py       ← (port dari v7.7, kept)
│   ├── 08_judge_ensemble.py          ← dual-model + locked-JSON judge (CELAH #3)
│   ├── 09_ab_picker.py               ← Candidate A vs B, pick winner (CELAH #8)
│   ├── 10_qna_adversarial.py         ← anti-AI signature (CELAH #13)
│   ├── 11_final_integrity.py         ← (port dari v7.7, hardened)
│   ├── 12_postmortem_ingest.py       ← real verdict → calibration loop (CELAH #10)
│   └── 13_timer.py                   ← time budget tracker (CELAH #11)
├── data/
│   ├── lexicon-ep-kill.json
│   ├── lexicon-ep-win.json
│   ├── lexicon-oaa.json
│   ├── lexicon-tq.json
│   ├── mission-type-templates.json   ← 12 mission types
│   ├── confidence-priors.json        ← auto-updated calibration
│   └── calibration-memory.json
└── archive/
    └── v7.7-frozen/                  ← old files untuk rollback
```

---

## BAGIAN 3 — PIPELINE EKSEKUSI V8.0 (12 GATE DETERMINISTIK)

```text
/rally <address>
│
├─ GATE 0  PREFLIGHT (2 min)
│  └─ skill files check, timer start, workspace ready
│
├─ GATE 1  BRIEF DECODE (3 min)
│  └─ tools/01_brief_decoder.py
│  └─ output: mission-type, structure template, danger-flag
│  └─ STOP jika danger-flag ON (brief ambigu)
│
├─ GATE 2  DNA FETCH MULTI-SOURCE (5–15 min)
│  └─ tools/02_dna_fetcher_v2.py --address X --mission Y
│  └─ output: dna.json + confidence per submission
│  └─ STOP jika confidence rata-rata <0.6
│
├─ GATE 3  WINNER MECHANISM MAP (5 min)
│  └─ tools/03_winner_mechanism_map.py
│  └─ output: top-3 mechanism wajib-pakai untuk mission ini
│
├─ GATE 4  DRAFT CANDIDATE A (15 min)
│  └─ Generate sesuai mission-type default structure
│  └─ Embed ≥1 mechanism dari Gate 3
│
├─ GATE 5  DRAFT CANDIDATE B (15 min)
│  └─ Generate dengan mechanism contrarian/risk-rewarded
│  └─ Beda struktur, beda opener type dari A
│
├─ GATE 6  HARD-MECHANICAL CHECK kedua kandidat (5 min)
│  └─ tools/05_kill_pattern_scanner.py (scan KONTEN)
│  └─ tools/07_cta_formula_check.py
│  └─ tools/06_loser_semantic_scan.py
│  └─ Kandidat dengan FAIL apapun → reject, regenerate
│
├─ GATE 7  CHAMPION DELTA SCORING kedua kandidat (5 min)
│  └─ tools/04_champion_delta_score.py vs pool top-5
│  └─ Kandidat dengan CDS <4 axis di atas median → reject
│
├─ GATE 8  DUAL-MODEL JUDGE ENSEMBLE kedua kandidat (10 min)
│  └─ tools/08_judge_ensemble.py
│  └─ 5 persona × 2 model API call terpisah = 10 verdict
│  └─ Output: worst-credible verdict per kandidat
│
├─ GATE 9  A/B PICK (1 min)
│  └─ tools/09_ab_picker.py → konten final
│
├─ GATE 10 QnA PACK + ADVERSARIAL (15 min)
│  └─ Generate 20 QnA
│  └─ tools/10_qna_adversarial.py → harus PASS
│
├─ GATE 11 FINAL INTEGRITY (1 min)
│  └─ tools/11_final_integrity.py
│  └─ Cek semua file sinkron, no stale
│
└─ GATE 12 OUTPUT + LEDGER + AWAITING POST-MORTEM
   └─ Output 1 file + LEDGER lengkap
   └─ User submit → tunggu vonis Rally → tools/12_postmortem_ingest.py
```

**Total wall-clock budget:** 80 menit normal, hard-cap 4 jam.

---

## BAGIAN 4 — APA YANG ANDA HARUS PUTUSKAN SEKARANG

Untuk saya mulai rewrite, saya butuh persetujuan/pilihan tentang **5 hal kunci**:

### Q1. SCOPE PEKERJAAN
Mana yang Anda mau:
- **(A) FULL REWRITE V8.0** — saya bangun semua dari awal sesuai blueprint di atas. ~estimasi: butuh 3-4 turn percakapan. Hasil: skill kompak, deterministik, semua celah ditutup, semua tool baru.
- **(B) SURGICAL FIX V7.7.1** — saya hanya tutup 5–7 celah paling fatal (CELAH #1, #2, #3, #5, #9), pertahankan struktur V7.7. ~1-2 turn. Hasil: V7.7 lebih stabil tapi struktur lama.
- **(C) HYBRID** — V8.0 minimal: SKILL.md baru + 5 tool baru (kill-pattern scanner, mechanism map, CDS, judge-ensemble, brief-decoder). Tool lama tetap. ~2 turn.

### Q2. LINGKUNGAN EKSEKUSI
- Apakah Anda jalankan `/rally` di workspace ini (Arena Agent Mode) atau di tempat lain (Claude Desktop, CLI lokal, dll)?
- Ini penting karena tool `08_judge_ensemble.py` butuh **API key model lain** (Anthropic/OpenAI/Google) untuk dual-model judge. Kalau Anda single-model only, saya akan implement "adversarial role-play hard mode" sebagai gantinya.

### Q3. SUMBER DATA POOL
- Apakah pipeline DNA fetcher V7.7 masih jalan (Rally API endpoint masih hidup)?
- Atau ada API/endpoint baru yang harus saya integrate?

### Q4. PRIORITAS TRADE-OFF
Skill yang ketat = lebih jarang lolos, tapi yang lolos lebih kuat. Skill yang longgar = lebih cepat output, tapi lebih sering kena EP4. Mana yang Anda mau:
- **(A) PRECISION-FIRST** — sering reject draft, hanya output yang almost-certainly all-MAX. (Saya rekomendasikan ini.)
- **(B) RECALL-FIRST** — output cepat, akui risiko EP4 di residual.

### Q5. TIMELINE & DELIVERABLE
- Anda mau saya kerjakan SEKARANG (langsung mulai rewrite di turn berikutnya), atau Anda mau review blueprint dulu dan kasih feedback?

---

## RINGKASAN UNTUK ANDA

Saya **TIDAK akan menjanjikan** "all-MAX guarantee" — itu kebohongan teknis.

Saya **AKAN menjanjikan**:
1. Setiap celah fatal yang saya identifikasi (14 buah) akan ditutup dengan tool/aturan konkret.
2. Skill V8.0 akan **dapat dieksekusi** (tidak seperti V7.7 yang 5800 baris dan sering di-skip).
3. Setiap keputusan di pipeline akan **terkuantifikasi** (CDS, kill-pattern score, judge ensemble worst-credible), bukan vibes.
4. Probabilitas all-MAX akan **dimaksimalkan secara matematis** sesuai data nyata Rally yang sudah Anda kumpulkan.

Mau saya mulai? Pilih jawaban Q1–Q5 di atas (atau jawab pakai opsi cepat di tombol berikut).
