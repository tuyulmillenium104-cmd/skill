# RALLY V8.0 — QUICK START

## INSTALL

```bash
# 1. backup V7.7 ke arsip
mv skills skills-v7.7-archive

# 2. salin V8.0 skill folder
cp -r rally-skill-v8/skills .

# 3. copy data lama yang reusable
cp skills-v7.7-archive/calibration-memory.json skills/data/
mkdir -p skills/archive/v7.7-frozen
cp skills-v7.7-archive/*.md skills/archive/v7.7-frozen/
cp skills-v7.7-archive/*.py skills/archive/v7.7-frozen/

# 4. verify
ls skills/                          # SKILL.md, RUNTIME-CHECKLIST.md, LEXICON-DATA.md
ls skills/tools/ | wc -l            # ≥10 files
ls skills/data/                     # calibration-memory.json
```

---

## ONE-RUN PIPELINE (manual orchestration)

```bash
# Setup
ADDR=0xCAMPAIGN_ADDRESS
MISSION=mission-0
SLUG=campaign-slug

mkdir -p rally-data/learn/$ADDR-$MISSION
mkdir -p konten/$SLUG/{drafts,reports}

# GATE 0 — timer start
python3 skills/tools/13_timer.py start --budget 14400

# GATE 1 — brief decode
echo "PASTE MISSION BRIEF HERE" > konten/$SLUG/brief.txt
python3 skills/tools/01_brief_decoder.py --brief-file konten/$SLUG/brief.txt --out konten/$SLUG/brief-decoded.json

# GATE 2 — DNA fetch (uses ported V7.7 tool)
python3 skills/tools/02_dna_fetcher_v2.py --address $ADDR --mission $MISSION

# GATE 3 — winner mechanism map
python3 skills/tools/03_winner_mechanism_map.py \
  --submissions rally-data/learn/$ADDR-$MISSION/submissions_enriched.json \
  --out konten/$SLUG/winner-mechanism.json \
  --out-md konten/$SLUG/WINNER-MECHANISM.md

# GATE 4 — DRAFT CANDIDATE A
# (LLM agent writes A based on mission-type default + mechanism #1)
# save to konten/$SLUG/drafts/A.txt

# GATE 5 — DRAFT CANDIDATE B
# (LLM agent writes B with different opener + mechanism #2)
# save to konten/$SLUG/drafts/B.txt

# GATE 6 — KILL PATTERN SCANS (both candidates)
for c in A B; do
  python3 skills/tools/05_kill_pattern_scanner.py --content konten/$SLUG/drafts/$c.txt --out konten/$SLUG/reports/$c-kill.json
  python3 skills/tools/06_loser_semantic_scan.py \
    --content konten/$SLUG/drafts/$c.txt \
    --submissions rally-data/learn/$ADDR-$MISSION/submissions_enriched.json \
    --out-json konten/$SLUG/reports/$c-loser.json \
    --out-md konten/$SLUG/reports/$c-loser.md \
    --motif "core motif phrase"
  python3 skills/tools/07_cta_formula_check.py --content konten/$SLUG/drafts/$c.txt --out-json konten/$SLUG/reports/$c-cta.json
done

# GATE 7 — CHAMPION DELTA SCORE
for c in A B; do
  python3 skills/tools/04_champion_delta_score.py \
    --content konten/$SLUG/drafts/$c.txt \
    --pool rally-data/learn/$ADDR-$MISSION/submissions_enriched.json \
    --out konten/$SLUG/reports/$c-cds.json
done

# GATE 8 — JUDGE ENSEMBLE
for c in A B; do
  python3 skills/tools/08_judge_ensemble.py \
    --content konten/$SLUG/drafts/$c.txt \
    --brief konten/$SLUG/brief.txt \
    --pool rally-data/learn/$ADDR-$MISSION/submissions_enriched.json \
    --winner-mechanism konten/$SLUG/winner-mechanism.json \
    --out konten/$SLUG/reports/$c-ens.json \
    --mode adversarial-hard
done

# GATE 9 — A/B PICK
python3 skills/tools/09_ab_picker.py \
  --a-cds konten/$SLUG/reports/A-cds.json \
  --a-ensemble konten/$SLUG/reports/A-ens.json \
  --a-content konten/$SLUG/drafts/A.txt \
  --b-cds konten/$SLUG/reports/B-cds.json \
  --b-ensemble konten/$SLUG/reports/B-ens.json \
  --b-content konten/$SLUG/drafts/B.txt \
  --out konten/$SLUG/reports/AB-decision.json \
  --final-out konten/$SLUG/$SLUG-CONTENT.txt

# GATE 10 — QnA + adversarial (after LLM generates 20 QnA into combined file)
python3 skills/tools/10_qna_adversarial.py \
  --combined konten/$SLUG/$SLUG-CONTENT-PLUS-20QNA-RQ5.md \
  --out konten/$SLUG/reports/qna-adv.json

# GATE 11 — FINAL INTEGRITY
python3 skills/tools/11_final_integrity.py \
  --content konten/$SLUG/$SLUG-CONTENT.txt \
  --combined konten/$SLUG/$SLUG-CONTENT-PLUS-20QNA-RQ5.md \
  --loser-report konten/$SLUG/reports/A-loser.json \
  --min-qna 20

# GATE 12 — TIMER STOP
python3 skills/tools/13_timer.py stop
```

---

## POST-SUBMIT CALIBRATION

```bash
# After Rally publishes verdict for your tweet
cat > actual-verdict.json << 'EOF'
{"EP":5,"OAA":5,"TQ":5,"IA":5,"CA":5,"CC":2,"RQ":5,"raw_judge":"<paste raw judge text>"}
EOF

python3 skills/tools/12_postmortem_ingest.py \
  --tweet 1234567890 \
  --predicted konten/$SLUG/reports/A-ens.json \
  --actual actual-verdict.json \
  --campaign $ADDR \
  --mission $MISSION \
  --calibration-file skills/data/calibration-memory.json \
  --priors-out skills/data/confidence-priors.json \
  --lessons-file skills/ADAPTIVE-RATCHET-LESSONS.md
```

Setiap 5 entry baru, `confidence-priors.json` auto-update dengan per-gate hit rate — skill jadi lebih akurat di run berikutnya.

---

## EXIT CODES

| Tool | exit 0 | exit 1 | exit 2 |
|---|---|---|---|
| 01_brief_decoder | PROCEED | USER_RESOLVE | bad args |
| 03_winner_mech | done | — | bad args |
| 04_cds | PASS | FAIL | bad args |
| 05_kill_scan | PASS | FAIL | — |
| 07_cta_check | PASS | FAIL | — |
| 08_ensemble | PASS | FAIL | — |
| 09_ab_pick | done | — | — |
| 10_qna_adv | PASS | FAIL | — |
| 11_integrity | PASS | FAIL | — |
| 13_timer | done | — | — |

**Pipeline rule:** Setiap tool exit 1 di gate wajib → STOP, fix, rerun.

---

## ANATOMY DARI SATU RUN YANG SUKSES (BENCHMARK)

Test internal V8.0 dengan sample content "good" (NAMED_CONCEPT + specific scene + CTA formula):

```
KILL-PATTERN SCAN:     PASS — 0 hits
CDS:                   3/5 axis ≥80th percentile (pool n=5 sample only)
JUDGE ENSEMBLE:        PASS — worst-credible all-MAX
  LITERAL_COMPLIANCE: 0 crit, all-max
  IA_SKEPTIC:         0 crit, all-max
  OAA_SIMILARITY:     0 crit, all-max
  EP_HARSH:           0 crit, all-max
  TQ_NATIVE:          0 crit, all-max
A/B PICK:              GOOD wins with weighted 4.85 vs 3.75
```

Sample "bad" (10 kill phrases) ditangkap:
```
KILL-PATTERN SCAN:     FAIL — 10 HIGH severity
JUDGE ENSEMBLE:        FAIL — EP=3, IA=3 worst-credible
  → 7 deterministic + 2 precedented criticisms
A/B PICK:              correctly chose GOOD over BAD
```

Inilah bukti pipeline V8.0 **mendiskriminasi** konten kuat vs lemah secara deterministik.
