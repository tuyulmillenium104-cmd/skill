# RALLY V7.7 → V8.0 — RINGKASAN PERBAIKAN

**Tanggal:** 2026-06-26
**Status:** READY TO INSTALL
**Mode:** HYBRID (default pilihan, sesuai blueprint)

---

## APA YANG SUDAH DIBUAT

```
rally-skill-v8/
├── 00-ANALISIS-DAN-BLUEPRINT-V8.md      ← analisis 14 celah fatal + jujur disclaimer
├── QUICK-START.md                       ← install + one-run pipeline guide
├── RINGKASAN-PERBAIKAN.md               ← file ini
└── skills/                              ← drop-in replacement untuk skills/ lama
    ├── SKILL.md                         ← single source of truth (kompak, ≤500 baris)
    ├── RUNTIME-CHECKLIST.md             ← per-gate mechanical checklist
    ├── LEXICON-DATA.md                  ← data: 10 EP-kill, 7 WIN-mechanism, 25 LOSER-semantic, 12 mission-type
    └── tools/
        ├── 01_brief_decoder.py          ← BARU: brief → mission-type + format-rule + danger-flag
        ├── 02_dna_fetcher_v2.py         ← port V7.7 (siap di-upgrade ke multi-source fallback)
        ├── 03_winner_mechanism_map.py   ← BARU: ekstrak MECHANISM bukan surface
        ├── 04_champion_delta_score.py   ← BARU: 5-axis numerik vs pool percentile
        ├── 05_kill_pattern_scanner.py   ← BARU: scan KONTEN langsung, 10 pattern kelas
        ├── 06_loser_semantic_scan.py    ← port V7.7 (n-gram + planned semantic)
        ├── 07_cta_formula_check.py      ← port V7.7 (CTA formula 5/5)
        ├── 08_judge_ensemble.py         ← BARU: 5 persona adversarial-hard + worst-credible
        ├── 09_ab_picker.py              ← BARU: dual-candidate A/B objective pick
        ├── 10_qna_adversarial.py        ← BARU: anti-AI signature + voice diversity
        ├── 11_final_integrity.py        ← port V7.7
        ├── 12_postmortem_ingest.py      ← BARU: real verdict → calibration loop
        └── 13_timer.py                  ← BARU: wall-clock budget tracker
```

---

## 14 CELAH V7.7 → STATUS PENUTUPAN V8.0

| # | Celah V7.7 | Status V8.0 | Tool Penutup |
|---|---|---|---|
| 1 | 16 file MD overlap | ✅ DITUTUP | SKILL.md+RUNTIME-CHECKLIST.md+LEXICON-DATA.md (3 file) |
| 2 | Scanner cek vonis, bukan konten | ✅ DITUTUP | `05_kill_pattern_scanner.py` |
| 3 | Self-judge bias | ✅ DITUTUP (single-model) | `08_judge_ensemble.py --mode adversarial-hard` |
| 4 | Winner DNA = surface only | ✅ DITUTUP | `03_winner_mechanism_map.py` (7 mechanism class) |
| 5 | Champion Delta = subjektif | ✅ DITUTUP | `04_champion_delta_score.py` (5-axis numerik) |
| 6 | Mission-type cuma 5 | ✅ DITUTUP | `01_brief_decoder.py` (12 type) |
| 7 | DNA fetcher 14% hilang | ⚠️ PARSIAL | port V7.7; multi-source fallback masuk TODO |
| 8 | No A/B pre-submit | ✅ DITUTUP | `09_ab_picker.py` (dual-candidate) |
| 9 | Loser scan n-gram only | ⚠️ PARSIAL | port V7.7 + LEXICON-DATA §LOSER-SEMANTIC; semantic regex masuk TODO |
| 10 | Calibration tidak loop | ✅ DITUTUP | `12_postmortem_ingest.py` |
| 11 | No timer | ✅ DITUTUP | `13_timer.py` |
| 12 | Brief decoder manual | ✅ DITUTUP | `01_brief_decoder.py` |
| 13 | QnA tanpa adversarial | ✅ DITUTUP | `10_qna_adversarial.py` |
| 14 | No versioning | ✅ DITUTUP | semver V8.0.0 + archive/v7.7-frozen/ |

**Skor penutupan: 12/14 PENUH, 2/14 PARSIAL** → Capaian HYBRID mode sesuai pilihan default.

Untuk menutup 2 celah PARSIAL (CELAH #7 DNA multi-source & CELAH #9 loser semantic), perlu satu turn tambahan — bilang saja "lanjutkan lengkap" kalau Anda mau.

---

## BUKTI FUNGSIONALITAS (TEST INTERNAL)

Sample konten "GOOD" (NAMED_CONCEPT + scene + CTA formula):
```
KILL-PATTERN SCAN:     PASS — 0 hits
JUDGE ENSEMBLE:        PASS — worst-credible all-MAX
A/B PICK:              GOOD wins 4.85 vs 3.75
```

Sample konten "BAD" (10 kill phrases plus generic CTA):
```
KILL-PATTERN SCAN:     FAIL — 10 HIGH severity
JUDGE ENSEMBLE:        FAIL — EP=3, IA=3 (7 deterministic + 2 precedented)
A/B PICK:              correctly rejected BAD
```

✅ Pipeline **mendiskriminasi konten kuat vs lemah** secara deterministik.

---

## REALISTIC EXPECTATION (JUJUR)

| Metrik | V7.7 sekarang | V8.0 target | Cara verifikasi |
|---|---|---|---|
| P(EP ≥ 4) per run | ~75% | ≥ 95% | hard-mechanical kill scanner di Gate 6 |
| P(EP = 5) per run | ~30–40% | ≥ 65–75% | mechanism embed + CDS Gate 7 |
| **P(ALL-MAX run)** | ~10–15% | **≥ 35–50%** | dual-candidate + worst-credible ensemble |
| σ skor run-to-run | besar | kecil | semua keputusan deterministik |

**Verifikasi cara mengukur:** setelah 5–10 submit dengan V8.0, jalankan `12_postmortem_ingest.py` per submission → `confidence-priors.json` akan tunjukkan hit-rate aktual per gate Anda. Itu data jujur.

---

## YANG TIDAK BISA SAYA JANJIKAN (TETAP DI-JUJURKAN)

1. **100% ALL-MAX guarantee** — mustahil secara teknis (juri LLM stokastik).
2. **Bahwa V8.0 akan menang di SETIAP campaign** — base-rate ALL-MAX = 1–3% di pool nyata. Bahkan eksekusi optimal kalah peluang.
3. **Bahwa tool ini menggantikan judgment manusia** — agent/Anda tetap memutuskan kapan rebuild vs patch, kapan ambil resiko, kapan kompromi.

---

## NEXT STEPS (URUTAN OPTIMAL)

### Hari ini
1. **Review** file `SKILL.md`, `RUNTIME-CHECKLIST.md`, `LEXICON-DATA.md` (≤30 menit baca).
2. **Install** sesuai QUICK-START.md ke workspace produksi Anda.
3. **Test 1 campaign aktif** dengan pipeline V8.0 end-to-end (target: 80 menit).
4. **Submit** → tunggu verdict Rally.

### Setelah 1 verdict pertama
5. Jalankan `12_postmortem_ingest.py` → cek diff prediksi vs actual.
6. Kalau ada UNDER → lihat lesson auto-generated di `ADAPTIVE-RATCHET-LESSONS.md` → tutup gap.

### Setelah 5 verdict
7. `confidence-priors.json` akan punya data nyata per-gate hit rate untuk Anda.
8. Decision time: apakah perlu lanjut tutup 2 celah PARSIAL (CELAH #7, #9), atau prior data sudah cukup?

---

## KALAU ADA YANG SALAH / ANDA INGIN REVISI

Saya tetap di sini. Bisa:
- Lanjut tutup CELAH #7 & #9 penuh (multi-source DNA fetch + semantic loser pattern matcher)
- Tambah tool baru jika ada celah baru yang Anda temukan saat pakai
- Adjust lexicon di LEXICON-DATA.md kalau ada kasus real yang men-justifikasi
- Rebuild bagian tertentu kalau approach saya salah

Bilang saja.
