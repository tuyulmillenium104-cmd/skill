# Content_Alignment — Decision Boundary

MAX verdicts: 11399 | NEAR: 1453 | LOW: 0

## Sub-rubrics Detected

- **alignment** (6681 mentions)
- **campaign mission** (801 mentions)
- **brief** (712 mentions)

## Top MAX-Indicating Phrases (global)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `gate disabled automatic` | 3882 | 0 | +7.44 |
| `gate disabled automatic pass` | 3882 | 0 | +7.44 |
| `disabled automatic` | 3882 | 0 | +7.44 |
| `gate disabled` | 3882 | 0 | +7.44 |
| `automatic pass` | 3882 | 0 | +7.44 |
| `disabled automatic pass` | 3882 | 0 | +7.44 |
| `automatic pass gate disabled` | 3877 | 0 | +7.44 |
| `pass gate disabled` | 3877 | 0 | +7.44 |
| `pass gate disabled automatic` | 3877 | 0 | +7.44 |
| `pass gate` | 3877 | 0 | +7.44 |
| `disabled automatic pass gate` | 3877 | 0 | +7.44 |
| `automatic pass gate` | 3877 | 0 | +7.44 |
| `all constraints` | 671 | 0 | +5.69 |
| `exceptional alignment campaign's goals` | 350 | 0 | +5.04 |
| `strictly met` | 298 | 0 | +4.88 |
| `constraints strictly` | 290 | 0 | +4.85 |
| `demonstrates exceptional alignment` | 1949 | 3 | +4.81 |
| `constraints strictly met` | 244 | 0 | +4.68 |
| `overall exceptional` | 241 | 0 | +4.66 |
| `minor limitation` | 227 | 0 | +4.60 |
| `demonstrates exceptional` | 1951 | 4 | +4.56 |
| `demonstrates exceptional alignment campaign's` | 628 | 1 | +4.52 |
| `all criteria` | 203 | 0 | +4.49 |
| `utility rolled` | 201 | 0 | +4.48 |
| `all constraints strictly` | 196 | 0 | +4.46 |
| `exceptional alignment across` | 190 | 0 | +4.43 |
| `first utility rolled` | 184 | 0 | +4.39 |
| `exceptional alignment across all` | 183 | 0 | +4.39 |
| `all technical constraints` | 182 | 0 | +4.38 |
| `demonstrates exceptional alignment across` | 179 | 0 | +4.37 |

## Top NON-MAX-Indicating Phrases (deduction triggers)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `however fails` | 0 | 134 | -7.11 |
| `overall acceptable` | 0 | 114 | -6.95 |
| `partial alignment` | 0 | 64 | -6.38 |
| `partially aligns` | 0 | 58 | -6.28 |
| `shows partial` | 0 | 51 | -6.15 |
| `meets several` | 0 | 42 | -5.96 |
| `shows partial alignment` | 0 | 42 | -5.96 |
| `alignment misses` | 0 | 41 | -5.94 |
| `meets basic` | 0 | 41 | -5.94 |
| `notable gaps` | 0 | 40 | -5.91 |
| `additionally while` | 0 | 39 | -5.89 |
| `however notable gaps` | 0 | 32 | -5.69 |
| `demonstrates acceptable` | 0 | 32 | -5.69 |
| `falls short exceptional alignment` | 0 | 32 | -5.69 |
| `overall acceptable not` | 0 | 32 | -5.69 |
| `however falls` | 1 | 95 | -5.67 |
| `not exceptional alignment` | 0 | 31 | -5.66 |
| `requirements lacks` | 0 | 31 | -5.66 |
| `overall alignment acceptable` | 0 | 30 | -5.63 |
| `moderately aligned` | 0 | 29 | -5.59 |
| `demonstrates acceptable alignment` | 0 | 29 | -5.59 |
| `however falls short` | 1 | 85 | -5.56 |
| `connect critique` | 0 | 28 | -5.56 |
| `acceptable not exceptional alignment` | 0 | 28 | -5.56 |
| `alignment misses several` | 0 | 26 | -5.49 |
| `several areas` | 0 | 26 | -5.49 |
| `missing cta` | 0 | 26 | -5.49 |
| `rather than exceptional` | 0 | 26 | -5.49 |
| `than exceptional` | 0 | 26 | -5.49 |
| `fails explicitly` | 0 | 25 | -5.45 |

## Per Sub-Rubric Patterns

### alignment

**MAX phrases:**

- `all constraints` (max=425, non=0, log-odds=+5.20)
- `strictly met` (max=281, non=0, log-odds=+4.79)
- `constraints strictly` (max=269, non=0, log-odds=+4.75)
- `constraints strictly met` (max=227, non=0, log-odds=+4.58)
- `all constraints strictly` (max=182, non=0, log-odds=+4.36)
- `adheres all` (max=181, non=0, log-odds=+4.35)
- `campaign's goals style requirements` (max=169, non=0, log-odds=+4.28)
- `minor limitation` (max=168, non=0, log-odds=+4.28)
- `constraints met` (max=165, non=0, log-odds=+4.26)
- `all constraints strictly met` (max=162, non=0, log-odds=+4.24)
- `all criteria` (max=161, non=0, log-odds=+4.24)
- `overall excellent fit` (max=141, non=0, log-odds=+4.10)
- `negative constraints` (max=136, non=0, log-odds=+4.07)
- `across all criteria` (max=131, non=0, log-odds=+4.03)
- `minor note` (max=128, non=0, log-odds=+4.01)

**NON-MAX phrases (deduction triggers):**

- `overall acceptable` (max=0, non=75, log-odds=-6.56)
- `acceptable not exceptional` (max=0, non=60, log-odds=-6.34)
- `however fails` (max=0, non=45, log-odds=-6.05)
- `acceptable not exceptional alignment` (max=0, non=42, log-odds=-5.99)
- `alignment misses` (max=0, non=39, log-odds=-5.91)
- `however falls` (max=0, non=26, log-odds=-5.51)
- `only partial` (max=0, non=25, log-odds=-5.47)
- `alignment misses several` (max=0, non=25, log-odds=-5.47)
- `alignment acceptable not exceptional` (max=0, non=25, log-odds=-5.47)
- `not strong` (max=0, non=23, log-odds=-5.39)
- `misses key` (max=0, non=23, log-odds=-5.39)
- `short exceptional alignment` (max=0, non=21, log-odds=-5.30)
- `rather than exceptional` (max=0, non=21, log-odds=-5.30)
- `than exceptional` (max=0, non=21, log-odds=-5.30)
- `falls short exceptional alignment` (max=0, non=19, log-odds=-5.21)

### campaign mission

**MAX phrases:**

- `requirements met` (max=74, non=0, log-odds=+2.86)
- `avoids generic` (max=74, non=0, log-odds=+2.86)
- `resonates target` (max=55, non=0, log-odds=+2.57)
- `daily rlp` (max=52, non=0, log-odds=+2.51)
- `whitelist link` (max=51, non=0, log-odds=+2.49)
- `resonates target audience` (max=49, non=0, log-odds=+2.45)
- `top 425 leaderboard follow` (max=49, non=0, log-odds=+2.45)
- `425 leaderboard follow` (max=49, non=0, log-odds=+2.45)
- `negative constraints` (max=49, non=0, log-odds=+2.45)
- `all negative` (max=47, non=0, log-odds=+2.41)
- `includes required` (max=47, non=0, log-odds=+2.41)
- `all negative constraints` (max=47, non=0, log-odds=+2.41)
- `campaigns top 425 leaderboard` (max=47, non=0, log-odds=+2.41)
- `all constraints` (max=46, non=0, log-odds=+2.39)
- `rlps daily` (max=46, non=0, log-odds=+2.39)

**NON-MAX phrases (deduction triggers):**

- `however doesn't` (max=3, non=10, log-odds=-3.24)
- `not fully` (max=4, non=11, log-odds=-3.08)
- `overall meets` (max=3, non=8, log-odds=-3.03)
- `doesn't mention` (max=3, non=7, log-odds=-2.90)
- `does not mention` (max=5, non=9, log-odds=-2.69)
- `analyze each dimension message` (max=5, non=6, log-odds=-2.31)
- `identifying needs genlayer` (max=5, non=5, log-odds=-2.14)
- `needs genlayer` (max=12, non=12, log-odds=-2.14)
- `requirements check` (max=8, non=8, log-odds=-2.14)
- `let analyze each dimension` (max=5, non=5, log-odds=-2.14)
- `analyze each dimension` (max=6, non=6, log-odds=-2.14)
- `dimension message accuracy` (max=7, non=6, log-odds=-2.00)
- `each dimension message accuracy` (max=7, non=6, log-odds=-2.00)
- `dimension message` (max=7, non=6, log-odds=-2.00)
- `each dimension message` (max=7, non=6, log-odds=-2.00)

### brief

**MAX phrases:**

- `only minor` (max=24, non=0, log-odds=+2.65)
- `waitlist gone` (max=24, non=0, log-odds=+2.65)
- `open everyone` (max=21, non=0, log-odds=+2.52)
- `clearly announces` (max=20, non=0, log-odds=+2.47)
- `sharp honest` (max=20, non=0, log-odds=+2.47)
- `avoids dashes` (max=18, non=0, log-odds=+2.37)
- `overall strong` (max=18, non=0, log-odds=+2.37)
- `matches knowledge base` (max=16, non=0, log-odds=+2.26)
- `matches knowledge` (max=16, non=0, log-odds=+2.26)
- `style avoids` (max=16, non=0, log-odds=+2.26)
- `than overly` (max=15, non=0, log-odds=+2.19)
- `tone sharp honest` (max=15, non=0, log-odds=+2.19)
- `proposition clearly` (max=15, non=0, log-odds=+2.19)
- `overall excellent` (max=15, non=0, log-odds=+2.19)
- `value proposition clearly` (max=15, non=0, log-odds=+2.19)

**NON-MAX phrases (deduction triggers):**

- `not exceptional` (max=1, non=14, log-odds=-3.51)
- `acceptable brief` (max=1, non=11, log-odds=-3.28)
- `doesn't fully` (max=1, non=9, log-odds=-3.09)
- `acceptable not` (max=2, non=11, log-odds=-2.77)
- `brief doesn't` (max=2, non=10, log-odds=-2.67)
- `does not clearly` (max=2, non=9, log-odds=-2.58)
- `exceptional brief` (max=5, non=20, log-odds=-2.56)
- `not clearly` (max=3, non=12, log-odds=-2.51)
- `more like` (max=4, non=15, log-odds=-2.48)
- `overall meets` (max=2, non=8, log-odds=-2.46)
- `reads more like` (max=3, non=8, log-odds=-2.13)
- `reads more` (max=3, non=8, log-odds=-2.13)
- `overall solid` (max=5, non=12, log-odds=-2.06)
- `only partially` (max=4, non=8, log-odds=-1.88)
- `staking vip access` (max=6, non=8, log-odds=-1.51)
