# Campaign_Compliance — Decision Boundary

MAX verdicts: 10322 | NEAR: 2530 | LOW: 0

## Sub-rubrics Detected

- **required** (9493 mentions)
- **format** (5833 mentions)
- **rules** (7299 mentions)
- **mention** (11686 mentions)

## Top MAX-Indicating Phrases (global)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `complies all requirements` | 954 | 0 | +6.47 |
| `gate disabled automatic` | 894 | 0 | +6.40 |
| `gate disabled automatic pass` | 894 | 0 | +6.40 |
| `disabled automatic` | 894 | 0 | +6.40 |
| `gate disabled` | 894 | 0 | +6.40 |
| `automatic pass` | 894 | 0 | +6.40 |
| `disabled automatic pass` | 894 | 0 | +6.40 |
| `automatic pass gate disabled` | 893 | 0 | +6.40 |
| `pass gate disabled` | 893 | 0 | +6.40 |
| `pass gate disabled automatic` | 893 | 0 | +6.40 |
| `pass gate` | 893 | 0 | +6.40 |
| `disabled automatic pass gate` | 893 | 0 | +6.40 |
| `automatic pass gate` | 893 | 0 | +6.40 |
| `fully complies all requirements` | 823 | 0 | +6.32 |
| `fully complies all` | 1351 | 1 | +5.72 |
| `demonstrates exceptional compliance` | 358 | 0 | +5.49 |
| `fully complies` | 1575 | 2 | +5.36 |
| `all requirements successfully` | 310 | 0 | +5.34 |
| `exceptional compliance all` | 301 | 0 | +5.32 |
| `highly compliant all` | 298 | 0 | +5.31 |
| `excellent compliance all` | 289 | 0 | +5.28 |
| `all requirements correctly` | 266 | 0 | +5.19 |
| `demonstrates exceptional compliance all` | 261 | 0 | +5.17 |
| `demonstrates full` | 260 | 0 | +5.17 |
| `demonstrates excellent compliance all` | 259 | 0 | +5.17 |
| `demonstrates full compliance` | 252 | 0 | +5.14 |
| `highly compliant all requirements` | 247 | 0 | +5.12 |
| `overall excellent` | 222 | 0 | +5.01 |
| `excellent compliance all requirements` | 216 | 0 | +4.99 |
| `full compliance all` | 216 | 0 | +4.99 |

## Top NON-MAX-Indicating Phrases (deduction triggers)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `not fully compliant` | 0 | 115 | -6.53 |
| `significant compliance` | 0 | 84 | -6.22 |
| `fails mandatory` | 0 | 81 | -6.18 |
| `however fails` | 1 | 206 | -6.01 |
| `requirements misses` | 0 | 63 | -5.93 |
| `prevents full` | 0 | 57 | -5.83 |
| `several core` | 0 | 55 | -5.80 |
| `prevents full compliance` | 0 | 55 | -5.80 |
| `not excellent` | 0 | 55 | -5.80 |
| `one explicit` | 0 | 54 | -5.78 |
| `prevents top` | 0 | 46 | -5.62 |
| `fails critical` | 0 | 46 | -5.62 |
| `compliant misses key` | 0 | 45 | -5.60 |
| `exceptional acceptable` | 0 | 44 | -5.58 |
| `lacks depth` | 0 | 44 | -5.58 |
| `partially compliant misses key` | 0 | 44 | -5.58 |
| `significant compliance failure` | 0 | 42 | -5.53 |
| `key violation` | 0 | 41 | -5.50 |
| `acceptable not fully compliant` | 0 | 41 | -5.50 |
| `however fails critical` | 0 | 40 | -5.48 |
| `warrants acceptable` | 0 | 40 | -5.48 |
| `summary satisfies most` | 0 | 38 | -5.43 |
| `overall compliance acceptable` | 0 | 38 | -5.43 |
| `however fails mandatory` | 0 | 38 | -5.43 |
| `fails mandatory requirement` | 0 | 37 | -5.40 |
| `several core requirements` | 0 | 37 | -5.40 |
| `misses key mandatory` | 0 | 36 | -5.38 |
| `violates mandatory` | 0 | 36 | -5.38 |
| `however explicitly requires` | 0 | 35 | -5.35 |
| `violation prevents` | 0 | 35 | -5.35 |

## Per Sub-Rubric Patterns

### required

**MAX phrases:**

- `checks confirm dashes` (max=129, non=0, log-odds=+4.67)
- `programmatic checks confirm dashes` (max=127, non=0, log-odds=+4.65)
- `only minor` (max=95, non=0, log-odds=+4.36)
- `confirm dashes used` (max=90, non=0, log-odds=+4.31)
- `checks confirm dashes used` (max=87, non=0, log-odds=+4.27)
- `required elements correctly mentions` (max=82, non=0, log-odds=+4.21)
- `elements correctly mentions` (max=82, non=0, log-odds=+4.21)
- `states reward` (max=70, non=0, log-odds=+4.06)
- `reward 'earn` (max=67, non=0, log-odds=+4.01)
- `reward 'earn rlps` (max=67, non=0, log-odds=+4.01)
- `reward 'earn rlps daily'` (max=62, non=0, log-odds=+3.94)
- `minor note` (max=57, non=0, log-odds=+3.85)
- `minor caveat` (max=56, non=0, log-odds=+3.83)
- `identifies specific` (max=54, non=0, log-odds=+3.80)
- `confirm dashes used does` (max=52, non=0, log-odds=+3.76)

**NON-MAX phrases (deduction triggers):**

- `acceptable compliance` (max=0, non=44, log-odds=-5.38)
- `not fully compliant` (max=0, non=41, log-odds=-5.31)
- `acceptable not exceptional` (max=0, non=36, log-odds=-5.18)
- `however fails` (max=0, non=33, log-odds=-5.10)
- `marks violated` (max=0, non=31, log-odds=-5.04)
- `app fun violated` (max=0, non=25, log-odds=-4.82)
- `overall acceptable` (max=0, non=25, log-odds=-4.82)
- `fun violated` (max=0, non=25, log-odds=-4.82)
- `check marks violated` (max=0, non=23, log-odds=-4.74)
- `programmatic check marks violated` (max=0, non=22, log-odds=-4.70)
- `not fully compliant required` (max=0, non=21, log-odds=-4.65)
- `full compliance required` (max=0, non=21, log-odds=-4.65)
- `fails mandatory` (max=0, non=20, log-odds=-4.61)
- `not fully` (max=1, non=59, log-odds=-4.57)
- `significant compliance` (max=0, non=19, log-odds=-4.55)

### format

**MAX phrases:**

- `confirm dashes` (max=103, non=0, log-odds=+4.35)
- `checks confirm dashes` (max=98, non=0, log-odds=+4.30)
- `programmatic checks confirm dashes` (max=95, non=0, log-odds=+4.27)
- `confirm dashes used` (max=80, non=0, log-odds=+4.10)
- `checks confirm dashes used` (max=75, non=0, log-odds=+4.03)
- `confirm dashes used does` (max=59, non=0, log-odds=+3.79)
- `start format does not` (max=52, non=0, log-odds=+3.67)
- `strong compliant` (max=47, non=0, log-odds=+3.57)
- `exceptional adherence` (max=46, non=0, log-odds=+3.55)
- `demonstrates exceptional` (max=42, non=0, log-odds=+3.46)
- `disclosure restrictions violated` (max=41, non=0, log-odds=+3.43)
- `all mandatory elements` (max=38, non=0, log-odds=+3.36)
- `timing disclosure restrictions violated` (max=37, non=0, log-odds=+3.33)
- `overall excellent` (max=35, non=0, log-odds=+3.28)
- `compliance programmatic checks` (max=33, non=0, log-odds=+3.22)

**NON-MAX phrases (deduction triggers):**

- `mandatory requirement` (max=0, non=12, log-odds=-4.20)
- `explicitly requires` (max=0, non=11, log-odds=-4.12)
- `not fully compliant` (max=0, non=11, log-odds=-4.12)
- `marks violated` (max=0, non=10, log-odds=-4.03)
- `not excellent` (max=0, non=10, log-odds=-4.03)
- `however explicitly` (max=0, non=10, log-odds=-4.03)
- `violation prevents` (max=0, non=10, log-odds=-4.03)
- `only partially` (max=1, non=24, log-odds=-3.78)
- `subtype char count 274` (max=1, non=23, log-odds=-3.74)
- `falls short` (max=1, non=21, log-odds=-3.65)
- `acceptable not exceptional` (max=1, non=12, log-odds=-3.10)
- `count 274` (max=4, non=34, log-odds=-3.02)
- `requirements quote` (max=1, non=11, log-odds=-3.02)
- `char count 274` (max=4, non=33, log-odds=-2.99)
- `does not fully` (max=1, non=10, log-odds=-2.93)

### rules

**MAX phrases:**

- `demonstrates excellent` (max=123, non=0, log-odds=+4.32)
- `overall demonstrates excellent` (max=93, non=0, log-odds=+4.04)
- `overall excellent` (max=91, non=0, log-odds=+4.01)
- `minor caveat` (max=89, non=0, log-odds=+3.99)
- `excellent adherence` (max=80, non=0, log-odds=+3.89)
- `all stated requirements` (max=79, non=0, log-odds=+3.87)
- `all stated` (max=234, non=1, log-odds=+3.86)
- `demonstrates exceptional` (max=73, non=0, log-odds=+3.80)
- `followed does` (max=65, non=0, log-odds=+3.68)
- `followed does not` (max=65, non=0, log-odds=+3.68)
- `demonstrates excellent adherence` (max=65, non=0, log-odds=+3.68)
- `rules strictly followed does` (max=61, non=0, log-odds=+3.62)
- `strictly followed does` (max=61, non=0, log-odds=+3.62)
- `strictly followed does not` (max=61, non=0, log-odds=+3.62)
- `all rules satisfied` (max=57, non=0, log-odds=+3.55)

**NON-MAX phrases (deduction triggers):**

- `acceptable compliance` (max=0, non=55, log-odds=-5.90)
- `overall acceptable` (max=0, non=27, log-odds=-5.20)
- `only partially` (max=0, non=27, log-odds=-5.20)
- `satisfies most` (max=0, non=24, log-odds=-5.09)
- `compliant true` (max=0, non=24, log-odds=-5.09)
- `acceptable compliance rules` (max=0, non=23, log-odds=-5.04)
- `acceptable not exceptional rules` (max=0, non=21, log-odds=-4.96)
- `acceptable rather than` (max=0, non=20, log-odds=-4.91)
- `not fully compliant` (max=0, non=20, log-odds=-4.91)
- `acceptable rather` (max=0, non=20, log-odds=-4.91)
- `not exceptional due` (max=0, non=20, log-odds=-4.91)
- `because core` (max=0, non=14, log-odds=-4.56)
- `however fails` (max=0, non=14, log-odds=-4.56)
- `only moderately` (max=0, non=13, log-odds=-4.49)
- `failure mandatory` (max=0, non=13, log-odds=-4.49)

### mention

**MAX phrases:**

- `character count 288` (max=119, non=0, log-odds=+4.42)
- `perfectly style` (max=118, non=0, log-odds=+4.41)
- `healthy engagement` (max=104, non=0, log-odds=+4.28)
- `avoiding generic ai-generated phrasing` (max=91, non=0, log-odds=+4.15)
- `engagement likes replies` (max=91, non=0, log-odds=+4.15)
- `avoids use` (max=89, non=0, log-odds=+4.13)
- `mention hashtag avoids use` (max=88, non=0, log-odds=+4.12)
- `hashtag avoids use` (max=88, non=0, log-odds=+4.12)
- `show healthy` (max=81, non=0, log-odds=+4.04)
- `ai-generated phrasing timing` (max=76, non=0, log-odds=+3.97)
- `generic ai-generated phrasing timing` (max=75, non=0, log-odds=+3.96)
- `demonstrates exceptional` (max=75, non=0, log-odds=+3.96)
- `healthy engagement likes` (max=75, non=0, log-odds=+3.96)
- `violations found` (max=73, non=0, log-odds=+3.93)
- `aligns perfectly style` (max=72, non=0, log-odds=+3.92)

**NON-MAX phrases (deduction triggers):**

- `explicitly requires` (max=0, non=111, log-odds=-6.47)
- `falls short` (max=0, non=77, log-odds=-6.10)
- `acceptable not exceptional mention` (max=0, non=49, log-odds=-5.65)
- `acceptable compliance mention` (max=0, non=48, log-odds=-5.63)
- `however fails` (max=1, non=139, log-odds=-5.59)
- `significant compliance` (max=0, non=45, log-odds=-5.57)
- `fails mandatory` (max=0, non=38, log-odds=-5.40)
- `explicitly requires mentioning` (max=0, non=37, log-odds=-5.38)
- `not fully compliant` (max=0, non=36, log-odds=-5.35)
- `empty mentions` (max=0, non=34, log-odds=-5.29)
- `critical mandatory` (max=0, non=34, log-odds=-5.29)
- `fails critical` (max=0, non=34, log-odds=-5.29)
- `prevents full` (max=0, non=33, log-odds=-5.26)
- `violates mandatory` (max=0, non=33, log-odds=-5.26)
- `prevents full compliance` (max=0, non=33, log-odds=-5.26)
