# Engagement_Potential — Decision Boundary

MAX verdicts: 1039 | NEAR: 5450 | LOW: 6363

## Sub-rubrics Detected

- **Conversation Potential** (9358 mentions)
- **Value Delivery** (7786 mentions)
- **Content Structure** (7454 mentions)
- **Hook Effectiveness** (3302 mentions)
- **Call-to-Action Quality** (2627 mentions)

## Top MAX-Indicating Phrases (global)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `engagement criteria hook highly` | 28 | 0 | +6.71 |
| `all engagement criteria hook` | 67 | 1 | +6.47 |
| `all engagement criteria` | 83 | 2 | +6.17 |
| `exceptional engagement potential across` | 149 | 4 | +6.17 |
| `excels multiple` | 15 | 0 | +6.10 |
| `across all engagement criteria` | 75 | 2 | +6.08 |
| `demonstrates exceptional engagement potential` | 188 | 6 | +6.03 |
| `excels across all engagement` | 72 | 2 | +6.03 |
| `excels multiple engagement` | 14 | 0 | +6.03 |
| `demonstrates exceptional engagement` | 188 | 6 | +6.03 |
| `delivers immense` | 13 | 0 | +5.96 |
| `delivers immense value` | 13 | 0 | +5.96 |
| `maximized through` | 12 | 0 | +5.89 |
| `potential maximized through` | 12 | 0 | +5.89 |
| `conversation potential maximized through` | 12 | 0 | +5.89 |
| `effectiveness outstanding` | 12 | 0 | +5.89 |
| `excels multiple engagement criteria` | 12 | 0 | +5.89 |
| `hook effectiveness outstanding` | 12 | 0 | +5.89 |
| `thread demonstrates exceptional engagement` | 11 | 0 | +5.80 |
| `include more explicit cta` | 10 | 0 | +5.71 |
| `while maximizing` | 10 | 0 | +5.71 |
| `excels across all` | 86 | 4 | +5.62 |
| `demonstrates exceptional` | 222 | 17 | +5.21 |
| `conversation potential maximized` | 42 | 3 | +5.16 |
| `excels across` | 86 | 7 | +5.11 |
| `exceptional engagement potential` | 194 | 18 | +5.02 |
| `engagement demonstrates exceptional` | 14 | 1 | +4.94 |
| `five criteria hook immediately` | 14 | 1 | +4.94 |
| `potential maximized` | 42 | 4 | +4.91 |
| `across all engagement` | 78 | 8 | +4.89 |

## Top NON-MAX-Indicating Phrases (deduction triggers)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `potential limited` | 0 | 1545 | -5.37 |
| `moderate engagement` | 0 | 1359 | -5.24 |
| `moderate engagement potential` | 0 | 1262 | -5.17 |
| `has moderate` | 0 | 1058 | -4.99 |
| `not especially` | 0 | 1017 | -4.95 |
| `has moderate engagement potential` | 0 | 991 | -4.92 |
| `has moderate engagement` | 0 | 991 | -4.92 |
| `however engagement potential` | 0 | 957 | -4.89 |
| `conversation potential limited` | 0 | 936 | -4.87 |
| `ask question` | 0 | 881 | -4.81 |
| `not explicitly` | 0 | 786 | -4.69 |
| `potential low` | 0 | 752 | -4.65 |
| `question invite` | 0 | 748 | -4.64 |
| `falls short` | 0 | 742 | -4.64 |
| `does not ask` | 0 | 741 | -4.63 |
| `not ask` | 0 | 741 | -4.63 |
| `has solid` | 0 | 734 | -4.62 |
| `lacks strong` | 0 | 730 | -4.62 |
| `does not explicitly` | 0 | 719 | -4.61 |
| `conversation potential low` | 0 | 710 | -4.59 |
| `delivery moderate` | 0 | 647 | -4.50 |
| `value delivery moderate` | 0 | 646 | -4.50 |
| `quality weak` | 0 | 640 | -4.49 |
| `solid engagement potential` | 0 | 601 | -4.43 |
| `value delivery strongest` | 0 | 559 | -4.35 |
| `delivery strongest` | 0 | 559 | -4.35 |
| `has solid engagement` | 0 | 549 | -4.33 |
| `explicitly invite` | 0 | 535 | -4.31 |
| `engagement potential limited` | 0 | 530 | -4.30 |
| `does not ask question` | 0 | 524 | -4.29 |

## Per Sub-Rubric Patterns

### Conversation Potential

**MAX phrases:**

- `maximized through` (max=12, non=0, log-odds=+6.06)
- `conversation potential maximized through` (max=12, non=0, log-odds=+6.06)
- `potential maximized through` (max=12, non=0, log-odds=+6.06)
- `conversation potential maximized` (max=42, non=3, log-odds=+5.33)
- `potential maximized` (max=42, non=3, log-odds=+5.33)
- `conversation potential maximized closing` (max=10, non=1, log-odds=+4.78)
- `maximized closing` (max=10, non=1, log-odds=+4.78)
- `potential maximized closing` (max=10, non=1, log-odds=+4.78)
- `very high due` (max=9, non=1, log-odds=+4.68)
- `conversation potential outstanding` (max=9, non=1, log-odds=+4.68)
- `potential outstanding` (max=9, non=1, log-odds=+4.68)
- `finally conversation` (max=13, non=2, log-odds=+4.52)
- `finally conversation potential` (max=13, non=2, log-odds=+4.52)
- `potential extremely high` (max=11, non=4, log-odds=+3.77)
- `conversation potential extremely high` (max=11, non=4, log-odds=+3.77)

**NON-MAX phrases (deduction triggers):**

- `potential limited` (max=0, non=986, log-odds=-4.75)
- `conversation potential limited` (max=0, non=936, log-odds=-4.70)
- `potential low` (max=0, non=720, log-odds=-4.44)
- `conversation potential low` (max=0, non=710, log-odds=-4.42)
- `ask question` (max=0, non=666, log-odds=-4.36)
- `does not ask` (max=0, non=512, log-odds=-4.09)
- `not ask` (max=0, non=512, log-odds=-4.09)
- `question invite` (max=0, non=473, log-odds=-4.02)
- `does not ask question` (max=0, non=398, log-odds=-3.84)
- `not ask question` (max=0, non=398, log-odds=-3.84)
- `not explicitly` (max=0, non=360, log-odds=-3.74)
- `does not explicitly` (max=0, non=347, log-odds=-3.71)
- `invite opinions` (max=0, non=334, log-odds=-3.67)
- `ask question invite` (max=0, non=327, log-odds=-3.65)
- `pose question` (max=0, non=277, log-odds=-3.48)

### Value Delivery

**MAX phrases:**

- `only minor drawback lack` (max=16, non=2, log-odds=+4.50)
- `drawback lack explicit` (max=9, non=1, log-odds=+4.46)
- `minor drawback lack explicit` (max=9, non=1, log-odds=+4.46)
- `adhering all` (max=10, non=2, log-odds=+4.05)
- `all constraints including` (max=21, non=5, log-odds=+3.98)
- `minor drawback lack` (max=17, non=4, log-odds=+3.97)
- `exceptional provides` (max=9, non=2, log-odds=+3.95)
- `delivery exceptional provides` (max=9, non=2, log-odds=+3.95)
- `value delivery exceptional provides` (max=9, non=2, log-odds=+3.95)
- `improvements could include more` (max=16, non=4, log-odds=+3.91)
- `could include more` (max=16, non=4, log-odds=+3.91)
- `complies all constraints` (max=12, non=3, log-odds=+3.89)
- `strictly adhering all` (max=8, non=2, log-odds=+3.84)
- `constraints while` (max=18, non=5, log-odds=+3.83)
- `value delivery exceptional offering` (max=14, non=4, log-odds=+3.78)

**NON-MAX phrases (deduction triggers):**

- `delivery moderate` (max=0, non=646, log-odds=-4.55)
- `value delivery moderate` (max=0, non=646, log-odds=-4.55)
- `delivery strongest` (max=0, non=559, log-odds=-4.41)
- `value delivery strongest` (max=0, non=559, log-odds=-4.41)
- `engagement ceiling` (max=0, non=358, log-odds=-3.96)
- `overall clear` (max=0, non=319, log-odds=-3.85)
- `strongest area` (max=0, non=305, log-odds=-3.80)
- `delivery strongest area` (max=0, non=302, log-odds=-3.79)
- `value delivery strongest area` (max=0, non=302, log-odds=-3.79)
- `overall solid` (max=0, non=280, log-odds=-3.72)
- `more like` (max=0, non=240, log-odds=-3.56)
- `delivery decent` (max=0, non=235, log-odds=-3.54)
- `value delivery decent` (max=0, non=235, log-odds=-3.54)
- `overall thoughtful` (max=0, non=232, log-odds=-3.53)
- `stronger hook` (max=0, non=207, log-odds=-3.42)

### Content Structure

**MAX phrases:**

- `reading utilizing` (max=9, non=1, log-odds=+4.19)
- `readability despite length structure` (max=9, non=2, log-odds=+3.68)
- `open-ended question directly` (max=8, non=2, log-odds=+3.57)
- `proven tactic` (max=8, non=2, log-odds=+3.57)
- `highly optimized social reading` (max=10, non=3, log-odds=+3.45)
- `structure expertly` (max=9, non=3, log-odds=+3.35)
- `high-quality replies` (max=8, non=3, log-odds=+3.23)
- `question directly` (max=15, non=6, log-odds=+3.22)
- `optimized social reading` (max=10, non=4, log-odds=+3.19)
- `well-organized using line breaks` (max=23, non=10, log-odds=+3.15)
- `well-organized using line` (max=23, non=10, log-odds=+3.15)
- `call-to-action highly effective` (max=7, non=3, log-odds=+3.11)
- `structure well-organized using line` (max=22, non=10, log-odds=+3.11)
- `specific open-ended question` (max=7, non=3, log-odds=+3.11)
- `highly optimized social` (max=13, non=6, log-odds=+3.08)

**NON-MAX phrases (deduction triggers):**

- `elements like` (max=0, non=410, log-odds=-4.36)
- `formatting elements like` (max=0, non=372, log-odds=-4.27)
- `structure decent` (max=0, non=252, log-odds=-3.88)
- `like line` (max=0, non=235, log-odds=-3.81)
- `like line breaks` (max=0, non=234, log-odds=-3.80)
- `formatting devices` (max=0, non=218, log-odds=-3.73)
- `however lacks` (max=0, non=214, log-odds=-3.71)
- `lacks formatting` (max=0, non=210, log-odds=-3.69)
- `however engagement` (max=0, non=193, log-odds=-3.61)
- `formatting elements like line` (max=0, non=189, log-odds=-3.59)
- `like bullet points` (max=0, non=189, log-odds=-3.59)
- `like bullet` (max=0, non=189, log-odds=-3.59)
- `elements like line` (max=0, non=189, log-odds=-3.59)
- `elements like line breaks` (max=0, non=189, log-odds=-3.59)
- `block text` (max=0, non=186, log-odds=-3.57)

### Hook Effectiveness

**MAX phrases:**

- `hook effectiveness outstanding` (max=12, non=0, log-odds=+6.39)
- `effectiveness outstanding` (max=12, non=0, log-odds=+6.39)
- `outstanding opening` (max=8, non=4, log-odds=+3.81)
- `status quo` (max=6, non=4, log-odds=+3.54)
- `short punchy` (max=7, non=5, log-odds=+3.48)
- `call-to-action strong` (max=9, non=7, log-odds=+3.41)
- `challenges conventional` (max=7, non=6, log-odds=+3.31)
- `opening immediately captures attention` (max=6, non=6, log-odds=+3.17)
- `instant curiosity` (max=6, non=6, log-odds=+3.17)
- `effectiveness opening immediately` (max=13, non=13, log-odds=+3.17)
- `relatable opening` (max=5, non=5, log-odds=+3.17)
- `creating strong` (max=8, non=8, log-odds=+3.17)
- `opening immediately captures` (max=6, non=6, log-odds=+3.17)
- `creating instant curiosity` (max=5, non=5, log-odds=+3.17)
- `hook effectiveness opening immediately` (max=13, non=13, log-odds=+3.17)

**NON-MAX phrases (deduction triggers):**

- `not especially` (max=0, non=571, log-odds=-3.87)
- `does not` (max=0, non=439, log-odds=-3.61)
- `hook effectiveness decent` (max=0, non=394, log-odds=-3.50)
- `effectiveness decent` (max=0, non=394, log-odds=-3.50)
- `may not` (max=0, non=388, log-odds=-3.48)
- `hook effectiveness moderate` (max=0, non=379, log-odds=-3.46)
- `effectiveness moderate` (max=0, non=379, log-odds=-3.46)
- `stop scrolling` (max=0, non=327, log-odds=-3.31)
- `moderate opening` (max=0, non=257, log-odds=-3.07)
- `hook effectiveness moderate opening` (max=0, non=257, log-odds=-3.07)
- `effectiveness moderate opening` (max=0, non=257, log-odds=-3.07)
- `however hook` (max=0, non=215, log-odds=-2.90)
- `wingston nft` (max=0, non=207, log-odds=-2.86)
- `not stop` (max=0, non=203, log-odds=-2.84)
- `may not stop` (max=0, non=203, log-odds=-2.84)

### Call-to-Action Quality

**MAX phrases:**

- `naturally prompts` (max=8, non=5, log-odds=+3.74)
- `question naturally` (max=11, non=7, log-odds=+3.73)
- `question highly` (max=6, non=4, log-odds=+3.67)
- `ending direct` (max=6, non=4, log-odds=+3.67)
- `quality excellent` (max=16, non=12, log-odds=+3.58)
- `call-to-action quality excellent` (max=16, non=12, log-odds=+3.58)
- `thought-provoking question` (max=8, non=6, log-odds=+3.57)
- `without feeling` (max=10, non=8, log-odds=+3.51)
- `feeling forced` (max=5, non=5, log-odds=+3.30)
- `quality concludes` (max=6, non=6, log-odds=+3.30)
- `call-to-action quality concludes` (max=6, non=6, log-odds=+3.30)
- `invites audience` (max=9, non=11, log-odds=+3.11)
- `quality features` (max=9, non=12, log-odds=+3.03)
- `call-to-action quality features` (max=9, non=12, log-odds=+3.03)
- `quality highly` (max=5, non=7, log-odds=+2.99)

**NON-MAX phrases (deduction triggers):**

- `does not` (max=0, non=799, log-odds=-4.08)
- `quality weak` (max=0, non=516, log-odds=-3.64)
- `call-to-action quality weak` (max=0, non=516, log-odds=-3.64)
- `explicit cta` (max=0, non=344, log-odds=-3.23)
- `readers reply share` (max=0, non=227, log-odds=-2.82)
- `invite replies` (max=0, non=212, log-odds=-2.75)
- `not explicitly` (max=0, non=202, log-odds=-2.70)
- `does not explicitly` (max=0, non=197, log-odds=-2.68)
- `weak explicit` (max=0, non=190, log-odds=-2.64)
- `potential call-to-action` (max=0, non=181, log-odds=-2.59)
- `potential call-to-action quality` (max=0, non=179, log-odds=-2.58)
- `next step` (max=0, non=165, log-odds=-2.50)
- `invitation readers` (max=0, non=162, log-odds=-2.48)
- `direct invitation` (max=0, non=159, log-odds=-2.46)
- `engagement potential` (max=0, non=158, log-odds=-2.46)
