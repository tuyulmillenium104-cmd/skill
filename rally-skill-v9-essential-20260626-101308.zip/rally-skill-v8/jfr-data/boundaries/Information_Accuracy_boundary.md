# Information_Accuracy — Decision Boundary

MAX verdicts: 11410 | NEAR: 1442 | LOW: 0

## Sub-rubrics Detected

- **factual** (4293 mentions)
- **verifiable** (2196 mentions)
- **claim** (3351 mentions)

## Top MAX-Indicating Phrases (global)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `gate disabled automatic` | 1893 | 0 | +6.72 |
| `gate disabled automatic pass` | 1893 | 0 | +6.72 |
| `disabled automatic` | 1893 | 0 | +6.72 |
| `gate disabled` | 1893 | 0 | +6.72 |
| `automatic pass` | 1893 | 0 | +6.72 |
| `disabled automatic pass` | 1893 | 0 | +6.72 |
| `automatic pass gate disabled` | 1887 | 0 | +6.71 |
| `pass gate disabled` | 1887 | 0 | +6.71 |
| `pass gate disabled automatic` | 1887 | 0 | +6.71 |
| `pass gate` | 1887 | 0 | +6.71 |
| `disabled automatic pass gate` | 1887 | 0 | +6.71 |
| `automatic pass gate` | 1887 | 0 | +6.71 |
| `demonstrates exceptional` | 892 | 0 | +5.96 |
| `all constraints` | 886 | 0 | +5.96 |
| `demonstrates exceptional factual` | 726 | 0 | +5.76 |
| `demonstrates exceptional factual accuracy` | 715 | 0 | +5.74 |
| `factual accuracy across all` | 493 | 0 | +5.37 |
| `all constraints including` | 483 | 0 | +5.35 |
| `accurate aligns perfectly` | 456 | 0 | +5.29 |
| `excellent factual` | 393 | 0 | +5.14 |
| `characters like` | 382 | 0 | +5.12 |
| `accurate aligns perfectly provided` | 379 | 0 | +5.11 |
| `characters like dashes` | 373 | 0 | +5.09 |
| `demonstrates excellent factual` | 370 | 0 | +5.08 |
| `accuracy strict` | 368 | 0 | +5.08 |
| `factual accuracy strict` | 359 | 0 | +5.05 |
| `excellent factual accuracy` | 331 | 0 | +4.97 |
| `highly accurate aligns perfectly` | 328 | 0 | +4.96 |
| `demonstrates excellent factual accuracy` | 321 | 0 | +4.94 |
| `including quoting` | 317 | 0 | +4.93 |

## Top NON-MAX-Indicating Phrases (deduction triggers)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `however fails` | 0 | 44 | -6.01 |
| `overall factually acceptable` | 0 | 33 | -5.73 |
| `could mislead readers` | 0 | 33 | -5.73 |
| `than exceptional` | 0 | 27 | -5.53 |
| `rather than exceptional` | 0 | 26 | -5.49 |
| `fails mention` | 0 | 25 | -5.46 |
| `some inaccuracies` | 0 | 25 | -5.46 |
| `acceptable rather than exceptional` | 0 | 24 | -5.42 |
| `could mislead` | 1 | 72 | -5.40 |
| `not supported knowledge` | 0 | 23 | -5.37 |
| `not supported knowledge base` | 0 | 23 | -5.37 |
| `fails include` | 0 | 21 | -5.28 |
| `lacks specificity` | 0 | 19 | -5.19 |
| `however two` | 0 | 19 | -5.19 |
| `could mislead readers about` | 0 | 18 | -5.13 |
| `perfect technical accuracy` | 0 | 18 | -5.13 |
| `while core` | 0 | 18 | -5.13 |
| `misses key` | 0 | 18 | -5.13 |
| `several accurate` | 0 | 17 | -5.08 |
| `contains several` | 1 | 49 | -5.02 |
| `prevent top` | 0 | 16 | -5.02 |
| `incomplete somewhat` | 0 | 16 | -5.02 |
| `could mislead users` | 0 | 16 | -5.02 |
| `acceptable not exceptional` | 1 | 47 | -4.98 |
| `acceptable factual` | 0 | 15 | -4.96 |
| `mislead followers` | 0 | 15 | -4.96 |
| `verification supported claims include` | 0 | 15 | -4.96 |
| `mostly accurate information` | 0 | 15 | -4.96 |
| `prevent perfect technical accuracy` | 0 | 15 | -4.96 |
| `significant omission` | 0 | 15 | -4.96 |

## Per Sub-Rubric Patterns

### factual

**MAX phrases:**

- `factual accuracy across all` (max=493, non=0, log-odds=+5.24)
- `accuracy across all` (max=493, non=0, log-odds=+5.24)
- `accuracy strict` (max=361, non=0, log-odds=+4.92)
- `factual accuracy strict` (max=359, non=0, log-odds=+4.92)
- `criteria technical` (max=327, non=0, log-odds=+4.83)
- `technically correctly` (max=207, non=0, log-odds=+4.37)
- `aligns perfectly` (max=198, non=0, log-odds=+4.33)
- `all constraints` (max=195, non=0, log-odds=+4.31)
- `strict alignment` (max=190, non=0, log-odds=+4.29)
- `accuracy strict alignment` (max=189, non=0, log-odds=+4.28)
- `factual accuracy strict alignment` (max=188, non=0, log-odds=+4.27)
- `all criteria` (max=180, non=0, log-odds=+4.23)
- `accuracy across all criteria` (max=176, non=0, log-odds=+4.21)
- `across all criteria` (max=176, non=0, log-odds=+4.21)
- `across all` (max=505, non=1, log-odds=+4.16)

**NON-MAX phrases (deduction triggers):**

- `acceptable not exceptional` (max=0, non=16, log-odds=-5.15)
- `rather than exceptional` (max=0, non=14, log-odds=-5.03)
- `accurate incomplete` (max=0, non=14, log-odds=-5.03)
- `than exceptional` (max=0, non=14, log-odds=-5.03)
- `not exceptional factual` (max=0, non=14, log-odds=-5.03)
- `acceptable rather than exceptional` (max=0, non=13, log-odds=-4.95)
- `acceptable accuracy` (max=0, non=13, log-odds=-4.95)
- `acceptable not exceptional factual` (max=0, non=12, log-odds=-4.88)
- `not strongly` (max=0, non=12, log-odds=-4.88)
- `could mislead` (max=0, non=12, log-odds=-4.88)
- `makes acceptable` (max=0, non=10, log-odds=-4.70)
- `because contains` (max=0, non=10, log-odds=-4.70)
- `acceptable rather than` (max=1, non=16, log-odds=-4.06)
- `acceptable rather` (max=1, non=16, log-odds=-4.06)
- `overall mostly` (max=2, non=25, log-odds=-3.98)

### verifiable

**MAX phrases:**

- `all constraints` (max=102, non=0, log-odds=+4.38)
- `adheres all` (max=67, non=0, log-odds=+3.96)
- `all claims` (max=64, non=0, log-odds=+3.92)
- `constraints including` (max=61, non=0, log-odds=+3.87)
- `highly accurate` (max=60, non=0, log-odds=+3.85)
- `materials verifiable against` (max=58, non=0, log-odds=+3.82)
- `avoids dashes` (max=57, non=0, log-odds=+3.80)
- `dashes does` (max=54, non=0, log-odds=+3.75)
- `dashes does not` (max=54, non=0, log-odds=+3.75)
- `strictly adheres` (max=53, non=0, log-odds=+3.73)
- `materials misleading false` (max=51, non=0, log-odds=+3.69)
- `present verifiable against` (max=51, non=0, log-odds=+3.69)
- `information present verifiable against` (max=49, non=0, log-odds=+3.65)
- `misleading information verifiable` (max=49, non=0, log-odds=+3.65)
- `materials misleading false information` (max=49, non=0, log-odds=+3.65)

**NON-MAX phrases (deduction triggers):**

- `overall acceptable` (max=0, non=15, log-odds=-4.38)
- `factually acceptable` (max=0, non=14, log-odds=-4.31)
- `top verifiable` (max=0, non=13, log-odds=-4.24)
- `acceptable verifiable` (max=0, non=12, log-odds=-4.16)
- `overall mostly accurate` (max=0, non=10, log-odds=-3.99)
- `overall factually acceptable` (max=0, non=10, log-odds=-3.99)
- `acceptable not` (max=1, non=14, log-odds=-3.21)
- `overall mostly` (max=1, non=13, log-odds=-3.14)
- `acceptable accuracy` (max=1, non=12, log-odds=-3.06)
- `context accuracy overall` (max=1, non=10, log-odds=-2.89)
- `fully precise` (max=1, non=10, log-odds=-2.89)
- `overall context` (max=1, non=10, log-odds=-2.89)
- `not exceptional` (max=1, non=9, log-odds=-2.79)
- `accuracy overall` (max=2, non=10, log-odds=-2.38)
- `not fully` (max=6, non=25, log-odds=-2.31)

### claim

**MAX phrases:**

- `all claims` (max=161, non=0, log-odds=+4.65)
- `false information present` (max=111, non=0, log-odds=+4.28)
- `misleading false information present` (max=110, non=0, log-odds=+4.27)
- `minor limitation` (max=103, non=0, log-odds=+4.20)
- `rolled out'` (max=91, non=0, log-odds=+4.08)
- `utility rolled out'` (max=91, non=0, log-odds=+4.08)
- `all constraints` (max=88, non=0, log-odds=+4.05)
- `minor caveat` (max=84, non=0, log-odds=+4.00)
- `all claims claim` (max=82, non=0, log-odds=+3.98)
- `all technical terms` (max=82, non=0, log-odds=+3.98)
- `first utility rolled` (max=75, non=0, log-odds=+3.89)
- `effects make` (max=73, non=0, log-odds=+3.86)
- `clear accurate` (max=73, non=0, log-odds=+3.86)
- `misleading false information` (max=198, non=1, log-odds=+3.76)
- `minor note` (max=63, non=0, log-odds=+3.71)

**NON-MAX phrases (deduction triggers):**

- `overall acceptable` (max=0, non=16, log-odds=-4.63)
- `could mislead readers` (max=0, non=14, log-odds=-4.50)
- `mostly consistent` (max=0, non=12, log-odds=-4.35)
- `overall factually acceptable` (max=0, non=12, log-odds=-4.35)
- `not supported knowledge base` (max=0, non=11, log-odds=-4.26)
- `readers about` (max=0, non=11, log-odds=-4.26)
- `not supported knowledge` (max=0, non=11, log-odds=-4.26)
- `anywhere provided` (max=0, non=11, log-odds=-4.26)
- `makes acceptable` (max=0, non=10, log-odds=-4.17)
- `could mislead` (max=1, non=27, log-odds=-4.04)
- `overall mostly` (max=2, non=41, log-odds=-3.94)
- `overall mostly accurate` (max=2, non=33, log-odds=-3.73)
- `goes beyond` (max=1, non=18, log-odds=-3.64)
- `required however` (max=1, non=17, log-odds=-3.59)
- `factually acceptable` (max=1, non=14, log-odds=-3.40)
