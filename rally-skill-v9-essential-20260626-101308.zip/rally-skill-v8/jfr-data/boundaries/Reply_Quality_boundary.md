# Reply_Quality — Decision Boundary

MAX verdicts: 670 | NEAR: 776 | LOW: 11489

## Sub-rubrics Detected

- **reply** (4487 mentions)
- **engagement** (6161 mentions)
- **conversation** (1439 mentions)
- **thread** (810 mentions)

## Top MAX-Indicating Phrases (global)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `replies demonstrate exceptional` | 87 | 1 | +6.31 |
| `exceptionally high` | 28 | 0 | +6.29 |
| `replies exceptionally` | 23 | 0 | +6.10 |
| `engagement authenticity instead` | 20 | 0 | +5.96 |
| `authenticity instead` | 20 | 0 | +5.96 |
| `subject-matter engagement authenticity instead` | 20 | 0 | +5.96 |
| `demonstrate exceptional` | 93 | 2 | +5.87 |
| `provided replies demonstrate exceptional` | 17 | 0 | +5.80 |
| `authenticity instead generic praise` | 16 | 0 | +5.74 |
| `engagement authenticity instead generic` | 16 | 0 | +5.74 |
| `each reply directly addresses` | 16 | 0 | +5.74 |
| `authenticity instead generic` | 16 | 0 | +5.74 |
| `replies constructive offering` | 15 | 0 | +5.68 |
| `exceptional relevance` | 15 | 0 | +5.68 |
| `submitted replies demonstrate exceptional` | 14 | 0 | +5.62 |
| `replies demonstrate exceptional subject-matter` | 42 | 1 | +5.59 |
| `exceptionally high-quality` | 13 | 0 | +5.54 |
| `warranting top` | 13 | 0 | +5.54 |
| `collectively demonstrate high subject-matter` | 13 | 0 | +5.54 |
| `demonstrate exceptional relevance` | 13 | 0 | +5.54 |
| `demonstrate exceptionally` | 13 | 0 | +5.54 |
| `exceptionally high quality` | 13 | 0 | +5.54 |
| `demonstrate high-quality authentic` | 12 | 0 | +5.47 |
| `exceptionally strong` | 12 | 0 | +5.47 |
| `replies demonstrate exceptional relevance` | 12 | 0 | +5.47 |
| `replies exceptionally high` | 12 | 0 | +5.47 |
| `exceptional subject-matter engagement authenticity` | 36 | 1 | +5.44 |
| `demonstrate high-quality` | 34 | 1 | +5.38 |
| `replies demonstrate exceptional quality` | 11 | 0 | +5.38 |
| `collectively demonstrate high-quality` | 11 | 0 | +5.38 |

## Top NON-MAX-Indicating Phrases (deduction triggers)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `replies analyze replies` | 0 | 5416 | -7.04 |
| `analyze replies` | 0 | 5417 | -7.04 |
| `replies analyze replies analyze` | 0 | 5118 | -6.99 |
| `analyze replies analyze` | 0 | 5118 | -6.99 |
| `analyze replies analyze replies` | 0 | 4593 | -6.88 |
| `replies analyze` | 1 | 6312 | -6.10 |
| `replies overwhelmingly` | 0 | 503 | -4.67 |
| `analyze reply` | 0 | 479 | -4.62 |
| `replies analyze reply` | 0 | 479 | -4.62 |
| `than genuine` | 0 | 453 | -4.56 |
| `rather than genuine` | 0 | 393 | -4.42 |
| `very low` | 0 | 385 | -4.40 |
| `shows some` | 0 | 354 | -4.32 |
| `than authentic` | 0 | 340 | -4.28 |
| `insight personal` | 0 | 317 | -4.21 |
| `analyze replies analyze reply` | 0 | 310 | -4.18 |
| `could apply` | 0 | 307 | -4.17 |
| `rather than authentic` | 0 | 302 | -4.16 |
| `any specific` | 0 | 267 | -4.04 |
| `without substance` | 0 | 257 | -4.00 |
| `new insight` | 0 | 242 | -3.94 |
| `replies extremely` | 0 | 230 | -3.89 |
| `any personal` | 0 | 229 | -3.88 |
| `few replies show` | 0 | 226 | -3.87 |
| `short generic` | 0 | 225 | -3.86 |
| `lack depth` | 0 | 223 | -3.85 |
| `not demonstrate` | 0 | 219 | -3.84 |
| `adding any` | 0 | 217 | -3.83 |
| `without adding any` | 0 | 214 | -3.81 |
| `while civil` | 0 | 208 | -3.79 |

## Per Sub-Rubric Patterns

### reply

**MAX phrases:**

- `information value high` (max=11, non=0, log-odds=+5.28)
- `free generic` (max=11, non=1, log-odds=+4.18)
- `value high` (max=11, non=1, log-odds=+4.18)
- `constructive offering` (max=12, non=2, log-odds=+3.75)
- `reply constructive offering` (max=10, non=2, log-odds=+3.58)
- `perfectly campaign's goal` (max=8, non=2, log-odds=+3.36)
- `demonstrates deep subject-matter reply` (max=9, non=3, log-odds=+3.14)
- `replies highly` (max=11, non=4, log-odds=+3.08)
- `showing deep` (max=13, non=5, log-odds=+3.04)
- `generic ai-like` (max=8, non=3, log-odds=+3.03)
- `strong subject-matter reply directly` (max=8, non=3, log-odds=+3.03)
- `each reply` (max=7, non=3, log-odds=+2.90)
- `offers distinct` (max=7, non=3, log-odds=+2.90)
- `praise instead` (max=7, non=3, log-odds=+2.90)
- `reply offers distinct` (max=7, non=3, log-odds=+2.90)

**NON-MAX phrases (deduction triggers):**

- `shows some` (max=0, non=203, log-odds=-3.87)
- `verbatim copy` (max=0, non=163, log-odds=-3.65)
- `reply verbatim` (max=0, non=151, log-odds=-3.57)
- `any specific` (max=0, non=127, log-odds=-3.40)
- `reply essentially` (max=0, non=114, log-odds=-3.29)
- `than genuine` (max=0, non=113, log-odds=-3.29)
- `very low` (max=0, non=111, log-odds=-3.27)
- `insight personal` (max=0, non=108, log-odds=-3.24)
- `could apply` (max=0, non=102, log-odds=-3.18)
- `lacks any` (max=0, non=101, log-odds=-3.17)
- `copy original` (max=0, non=98, log-odds=-3.14)
- `new insight` (max=0, non=93, log-odds=-3.09)
- `reply verbatim copy` (max=0, non=93, log-odds=-3.09)
- `any personal` (max=0, non=92, log-odds=-3.08)
- `reply just` (max=0, non=89, log-odds=-3.05)

### engagement

**MAX phrases:**

- `engagement authenticity instead` (max=20, non=0, log-odds=+5.88)
- `authenticity instead` (max=20, non=0, log-odds=+5.88)
- `authenticity instead generic praise` (max=16, non=0, log-odds=+5.66)
- `engagement authenticity instead generic` (max=16, non=0, log-odds=+5.66)
- `authenticity instead generic` (max=16, non=0, log-odds=+5.66)
- `replies constructive offering` (max=14, non=0, log-odds=+5.53)
- `responses users` (max=10, non=0, log-odds=+5.21)
- `engagement authenticity rather than` (max=25, non=1, log-odds=+5.00)
- `engagement authenticity rather` (max=25, non=1, log-odds=+5.00)
- `authenticity rather` (max=25, non=2, log-odds=+4.49)
- `authenticity rather than` (max=25, non=2, log-odds=+4.49)
- `praise each` (max=14, non=1, log-odds=+4.43)
- `generic praise each` (max=14, non=1, log-odds=+4.43)
- `constructive offering` (max=22, non=2, log-odds=+4.36)
- `authenticity rather than offering` (max=12, non=1, log-odds=+4.29)

**NON-MAX phrases (deduction triggers):**

- `without adding` (max=0, non=369, log-odds=-4.44)
- `none replies` (max=0, non=304, log-odds=-4.25)
- `than genuine` (max=0, non=284, log-odds=-4.18)
- `rather than genuine` (max=0, non=261, log-odds=-4.09)
- `than authentic` (max=0, non=246, log-odds=-4.03)
- `rather than authentic` (max=0, non=221, log-odds=-3.93)
- `engagement actual` (max=0, non=208, log-odds=-3.87)
- `very low` (max=0, non=190, log-odds=-3.78)
- `engagement constructiveness information value` (max=0, non=164, log-odds=-3.63)
- `engagement constructiveness information` (max=0, non=164, log-odds=-3.63)
- `without substance` (max=0, non=162, log-odds=-3.62)
- `per scoring` (max=0, non=145, log-odds=-3.51)
- `could apply` (max=0, non=145, log-odds=-3.51)
- `engagement-farm style` (max=0, non=142, log-odds=-3.49)
- `not demonstrate` (max=0, non=133, log-odds=-3.42)

### conversation

**MAX phrases:**

- `each conversation` (max=8, non=3, log-odds=+2.45)
- `language natural` (max=8, non=4, log-odds=+2.19)
- `natural phrasing` (max=6, non=4, log-odds=+1.93)
- `civility maintained` (max=7, non=5, log-odds=+1.87)
- `all replies` (max=7, non=5, log-odds=+1.87)
- `overall replies` (max=8, non=6, log-odds=+1.83)
- `some replies` (max=6, non=5, log-odds=+1.73)
- `goal highlighting` (max=5, non=5, log-odds=+1.56)
- `conversation around` (max=5, non=5, log-odds=+1.56)
- `spam hostility` (max=5, non=5, log-odds=+1.56)
- `rather than just` (max=7, non=8, log-odds=+1.43)
- `than just` (max=7, non=8, log-odds=+1.43)
- `campaign's goal` (max=17, non=20, log-odds=+1.40)
- `conversation rather than` (max=11, non=13, log-odds=+1.40)
- `conversation rather` (max=11, non=13, log-odds=+1.40)

**NON-MAX phrases (deduction triggers):**

- `per scoring` (max=0, non=32, log-odds=-2.62)
- `low conversation` (max=0, non=30, log-odds=-2.55)
- `scoring guidelines` (max=0, non=28, log-odds=-2.48)
- `low-effort conversation` (max=0, non=27, log-odds=-2.45)
- `generic agreement` (max=0, non=24, log-odds=-2.33)
- `without substance` (max=0, non=24, log-odds=-2.33)
- `than genuine` (max=0, non=23, log-odds=-2.29)
- `conversation lacks` (max=0, non=21, log-odds=-2.20)
- `rewordings original` (max=0, non=20, log-odds=-2.15)
- `per scoring guidelines` (max=0, non=20, log-odds=-2.15)
- `very low` (max=0, non=19, log-odds=-2.10)
- `lowest possible` (max=0, non=18, log-odds=-2.05)
- `rather than genuine` (max=0, non=18, log-odds=-2.05)
- `conversation per` (max=0, non=17, log-odds=-2.00)
- `authenticity information value` (max=0, non=16, log-odds=-1.94)

### thread

**MAX phrases:**

- `campaign's goal` (max=4, non=7, log-odds=+1.99)
- `generic praise` (max=6, non=12, log-odds=+1.85)
- `genuine human` (max=3, non=8, log-odds=+1.61)
- `advance thread` (max=4, non=12, log-odds=+1.48)
- `explaining genlayer` (max=2, non=8, log-odds=+1.28)
- `ai-sounding platitudes` (max=2, non=9, log-odds=+1.16)
- `thread demonstrates` (max=3, non=14, log-odds=+1.08)
- `shows genuine` (max=3, non=14, log-odds=+1.08)
- `vague positivity` (max=2, non=11, log-odds=+0.97)
- `value proposition` (max=2, non=13, log-odds=+0.81)
- `information value` (max=7, non=47, log-odds=+0.65)
- `thread original` (max=1, non=9, log-odds=+0.65)
- `genuinely engaged` (max=1, non=9, log-odds=+0.65)
- `authenticity thread` (max=1, non=10, log-odds=+0.55)
- `thread thread` (max=2, non=17, log-odds=+0.55)

**NON-MAX phrases (deduction triggers):**

- `personal perspective` (max=0, non=102, log-odds=-2.82)
- `original thought` (max=0, non=101, log-odds=-2.81)
- `thought personal` (max=0, non=77, log-odds=-2.54)
- `zero original` (max=0, non=75, log-odds=-2.52)
- `original thought personal` (max=0, non=75, log-odds=-2.52)
- `personal experience` (max=0, non=48, log-odds=-2.08)
- `zero original thought` (max=0, non=47, log-odds=-2.05)
- `thought personal perspective` (max=0, non=47, log-odds=-2.05)
- `original thought personal perspective` (max=0, non=45, log-odds=-2.01)
- `thread itself` (max=0, non=41, log-odds=-1.92)
- `thread lacks` (max=0, non=36, log-odds=-1.79)
- `zero original thought personal` (max=0, non=36, log-odds=-1.79)
- `thread adds` (max=0, non=34, log-odds=-1.74)
- `meaningful thread` (max=0, non=33, log-odds=-1.71)
- `thread contains` (max=0, non=31, log-odds=-1.64)
