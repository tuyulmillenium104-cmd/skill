# Technical_Quality — Decision Boundary

MAX verdicts: 5751 | NEAR: 5475 | LOW: 1626

## Sub-rubrics Detected

- **Language Mechanics** (11650 mentions)
- **Formatting** (9102 mentions)
- **Media Integration** (9558 mentions)
- **Readability** (7476 mentions)
- **Platform-Native** (834 mentions)

## Top MAX-Indicating Phrases (global)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `demonstrates exceptional technical` | 545 | 0 | +7.49 |
| `demonstrates exceptional` | 545 | 0 | +7.49 |
| `demonstrates exceptional technical execution` | 452 | 0 | +7.30 |
| `exceptional technical execution across` | 441 | 0 | +7.28 |
| `proficiency adheres all constraints` | 174 | 0 | +6.35 |
| `exceptional technical execution` | 456 | 1 | +6.21 |
| `exceptional technical` | 550 | 2 | +5.89 |
| `punctuation zero` | 93 | 0 | +5.72 |
| `punctuation zero spelling` | 86 | 0 | +5.65 |
| `punctuation zero spelling errors` | 85 | 0 | +5.63 |
| `excellent technical execution across` | 768 | 4 | +5.63 |
| `exceptional technical proficiency` | 84 | 0 | +5.62 |
| `demonstrates exceptional technical proficiency` | 83 | 0 | +5.61 |
| `language mechanics strong using` | 77 | 0 | +5.54 |
| `exceptional technical proficiency across` | 77 | 0 | +5.54 |
| `mechanics strong using` | 77 | 0 | +5.54 |
| `proficiency adheres all` | 214 | 1 | +5.46 |
| `technical proficiency adheres all` | 214 | 1 | +5.46 |
| `demonstrates excellent technical execution` | 1129 | 8 | +5.38 |
| `zero spelling errors structure` | 64 | 0 | +5.35 |
| `thread demonstrates exceptional` | 60 | 0 | +5.29 |
| `thread demonstrates exceptional technical` | 60 | 0 | +5.29 |
| `flawless utilizing` | 57 | 0 | +5.24 |
| `composition demonstrates excellent` | 55 | 0 | +5.20 |
| `composition demonstrates excellent technical` | 53 | 0 | +5.17 |
| `mechanics flawless utilizing` | 52 | 0 | +5.15 |
| `language mechanics flawless utilizing` | 52 | 0 | +5.15 |
| `excellent technical execution adherence` | 51 | 0 | +5.13 |
| `adherence requirements language mechanics` | 51 | 0 | +5.13 |
| `adherence requirements language` | 51 | 0 | +5.13 |

## Top NON-MAX-Indicating Phrases (deduction triggers)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `execution competent` | 0 | 335 | -6.01 |
| `technical execution competent` | 0 | 324 | -5.98 |
| `overall technical execution competent` | 0 | 321 | -5.97 |
| `optimization decent` | 0 | 189 | -5.44 |
| `platform optimization decent` | 0 | 189 | -5.44 |
| `tidak ada` | 0 | 184 | -5.42 |
| `however technical` | 0 | 180 | -5.39 |
| `several notable` | 0 | 179 | -5.39 |
| `however notable` | 0 | 156 | -5.25 |
| `notable strengths` | 0 | 156 | -5.25 |
| `inconsistent spacing` | 0 | 154 | -5.24 |
| `execution several notable` | 0 | 149 | -5.21 |
| `technical execution several notable` | 0 | 149 | -5.21 |
| `competent minor` | 0 | 144 | -5.17 |
| `has several` | 0 | 143 | -5.17 |
| `however technical execution` | 0 | 141 | -5.15 |
| `generally solid` | 0 | 141 | -5.15 |
| `optimization mixed` | 0 | 136 | -5.12 |
| `platform optimization mixed` | 0 | 136 | -5.12 |
| `issues prevent` | 0 | 131 | -5.08 |
| `strengths minor` | 0 | 129 | -5.06 |
| `notable issues` | 0 | 127 | -5.05 |
| `secara teknis` | 0 | 126 | -5.04 |
| `does not fully` | 0 | 125 | -5.03 |
| `solid technical execution overall` | 1 | 375 | -5.03 |
| `demonstrates competent` | 0 | 121 | -5.00 |
| `competent technical execution` | 0 | 120 | -4.99 |
| `demonstrates generally` | 0 | 117 | -4.97 |
| `moderate technical` | 0 | 115 | -4.95 |
| `issues reduce` | 0 | 109 | -4.89 |

## Per Sub-Rubric Patterns

### Language Mechanics

**MAX phrases:**

- `enhance language mechanics flawless` (max=103, non=0, log-odds=+5.75)
- `punctuation zero` (max=92, non=0, log-odds=+5.63)
- `punctuation zero spelling` (max=86, non=0, log-odds=+5.57)
- `punctuation zero spelling errors` (max=85, non=0, log-odds=+5.55)
- `language mechanics strong using` (max=77, non=0, log-odds=+5.46)
- `mechanics strong using` (max=77, non=0, log-odds=+5.46)
- `structure well-optimized` (max=68, non=0, log-odds=+5.33)
- `zero spelling errors structure` (max=64, non=0, log-odds=+5.27)
- `flawless utilizing` (max=57, non=0, log-odds=+5.16)
- `enhancing language mechanics flawless` (max=56, non=0, log-odds=+5.14)
- `enhances language mechanics flawless` (max=53, non=0, log-odds=+5.08)
- `mechanics flawless utilizing` (max=52, non=0, log-odds=+5.07)
- `language mechanics flawless utilizing` (max=52, non=0, log-odds=+5.07)
- `structure well-optimized language mechanics` (max=51, non=0, log-odds=+5.05)
- `structure well-optimized language` (max=51, non=0, log-odds=+5.05)

**NON-MAX phrases (deduction triggers):**

- `generally solid` (max=0, non=88, log-odds=-4.76)
- `reduce polish` (max=0, non=88, log-odds=-4.76)
- `mechanics issues` (max=0, non=87, log-odds=-4.75)
- `language mechanics issues` (max=0, non=85, log-odds=-4.73)
- `mechanics generally solid` (max=0, non=83, log-odds=-4.71)
- `language mechanics generally solid` (max=0, non=83, log-odds=-4.71)
- `missing punctuation` (max=0, non=76, log-odds=-4.62)
- `inconsistent capitalization` (max=0, non=73, log-odds=-4.58)
- `language mechanics grammar mostly` (max=0, non=71, log-odds=-4.55)
- `mechanics grammar mostly` (max=0, non=71, log-odds=-4.55)
- `mostly sound` (max=0, non=69, log-odds=-4.52)
- `mechanics mostly sound` (max=0, non=69, log-odds=-4.52)
- `language mechanics mostly sound` (max=0, non=69, log-odds=-4.52)
- `generally strong correct` (max=0, non=59, log-odds=-4.37)
- `mechanics generally strong correct` (max=0, non=59, log-odds=-4.37)

### Formatting

**MAX phrases:**

- `enhancing formatting highly` (max=48, non=0, log-odds=+5.40)
- `optimized formatting highly` (max=48, non=0, log-odds=+5.40)
- `formatting optimized formatting` (max=42, non=0, log-odds=+5.27)
- `highly optimized formatting highly` (max=38, non=0, log-odds=+5.17)
- `enhance formatting highly optimized` (max=36, non=0, log-odds=+5.12)
- `breaks enhance formatting highly` (max=36, non=0, log-odds=+5.12)
- `improve formatting highly` (max=35, non=0, log-odds=+5.09)
- `formatting highly optimized platform` (max=33, non=0, log-odds=+5.03)
- `optimized platform utilizing` (max=26, non=0, log-odds=+4.80)
- `highly optimized platform utilizing` (max=25, non=0, log-odds=+4.76)
- `enhancing formatting highly effective` (max=24, non=0, log-odds=+4.72)
- `optimized formatting highly effective` (max=23, non=0, log-odds=+4.68)
- `breaks formatting highly` (max=23, non=0, log-odds=+4.68)
- `improve formatting highly effective` (max=23, non=0, log-odds=+4.68)
- `optimized formatting highly optimized` (max=21, non=0, log-odds=+4.59)

**NON-MAX phrases (deduction triggers):**

- `slightly awkward` (max=0, non=95, log-odds=-4.42)
- `execution competent` (max=0, non=93, log-odds=-4.40)
- `technical execution competent` (max=0, non=90, log-odds=-4.37)
- `overall technical execution competent` (max=0, non=89, log-odds=-4.36)
- `missed opportunity` (max=0, non=88, log-odds=-4.35)
- `optimization decent` (max=0, non=87, log-odds=-4.33)
- `platform optimization decent` (max=0, non=87, log-odds=-4.33)
- `overall technically competent` (max=0, non=85, log-odds=-4.31)
- `opportunity discoverability` (max=0, non=73, log-odds=-4.16)
- `optimization adequate` (max=1, non=185, log-odds=-3.99)
- `platform optimization adequate` (max=1, non=185, log-odds=-3.99)
- `missed opportunity discoverability` (max=0, non=61, log-odds=-3.98)
- `inconsistent spacing` (max=0, non=59, log-odds=-3.95)
- `formatting inefficiencies` (max=0, non=59, log-odds=-3.95)
- `platform optimization mixed` (max=0, non=58, log-odds=-3.93)

### Media Integration

**MAX phrases:**

- `perfectly campaign's` (max=69, non=0, log-odds=+5.41)
- `aligns perfectly campaign's` (max=59, non=0, log-odds=+5.26)
- `although single` (max=36, non=0, log-odds=+4.77)
- `all negative` (max=34, non=0, log-odds=+4.71)
- `all negative constraints` (max=34, non=0, log-odds=+4.71)
- `perfectly aligned` (max=33, non=0, log-odds=+4.68)
- `met precisely` (max=33, non=0, log-odds=+4.68)
- `constraints while` (max=30, non=0, log-odds=+4.59)
- `fully optimized platform` (max=30, non=0, log-odds=+4.59)
- `although single-tweet` (max=30, non=0, log-odds=+4.59)
- `strictly met` (max=29, non=0, log-odds=+4.55)
- `composition polished constraint-compliant` (max=28, non=0, log-odds=+4.52)
- `resulting highly polished` (max=27, non=0, log-odds=+4.48)
- `all constraints met` (max=27, non=0, log-odds=+4.48)
- `furthermore strictly` (max=26, non=0, log-odds=+4.45)

**NON-MAX phrases (deduction triggers):**

- `execution competent` (max=0, non=189, log-odds=-5.46)
- `technical execution competent` (max=0, non=183, log-odds=-5.43)
- `overall technical execution competent` (max=0, non=182, log-odds=-5.42)
- `tidak ada` (max=0, non=116, log-odds=-4.97)
- `overall competent` (max=0, non=78, log-odds=-4.58)
- `competent minor` (max=0, non=77, log-odds=-4.57)
- `ada media` (max=0, non=64, log-odds=-4.38)
- `overall technically competent` (max=1, non=193, log-odds=-4.38)
- `tidak ada media` (max=0, non=62, log-odds=-4.35)
- `bukan thread` (max=0, non=56, log-odds=-4.25)
- `composition ini` (max=0, non=54, log-odds=-4.21)
- `ini bukan` (max=0, non=54, log-odds=-4.21)
- `thread composition ini` (max=0, non=54, log-odds=-4.21)
- `minor mechanical` (max=0, non=52, log-odds=-4.18)
- `rather than cleanly` (max=0, non=51, log-odds=-4.16)

### Readability

**MAX phrases:**

- `devices platform optimization strong` (max=27, non=0, log-odds=+4.21)
- `feeds platform optimization strong` (max=26, non=0, log-odds=+4.17)
- `without sacrificing` (max=25, non=0, log-odds=+4.13)
- `access whitelists` (max=25, non=0, log-odds=+4.13)
- `long-form feature effectively` (max=25, non=0, log-odds=+4.13)
- `'free mint' status` (max=22, non=0, log-odds=+4.01)
- `rather than purely promotional` (max=22, non=0, log-odds=+4.01)
- `devices platform optimization high` (max=22, non=0, log-odds=+4.01)
- `integrates all` (max=22, non=0, log-odds=+4.01)
- `mint' status` (max=22, non=0, log-odds=+4.01)
- `perfectly goal` (max=22, non=0, log-odds=+4.01)
- `than purely promotional` (max=22, non=0, log-odds=+4.01)
- `excellent adheres twitter's` (max=21, non=0, log-odds=+3.96)
- `followed negative constraint` (max=21, non=0, log-odds=+3.96)
- `optimization excellent adheres twitter's` (max=21, non=0, log-odds=+3.96)

**NON-MAX phrases (deduction triggers):**

- `optimization decent` (max=0, non=68, log-odds=-4.72)
- `platform optimization decent` (max=0, non=68, log-odds=-4.72)
- `platform optimization mixed` (max=0, non=66, log-odds=-4.69)
- `optimization mixed` (max=0, non=66, log-odds=-4.69)
- `platform optimization competent` (max=0, non=58, log-odds=-4.56)
- `optimization competent` (max=0, non=58, log-odds=-4.56)
- `more like` (max=0, non=49, log-odds=-4.39)
- `optimization adequate` (max=1, non=129, log-odds=-4.26)
- `platform optimization adequate` (max=1, non=129, log-odds=-4.26)
- `does not fully` (max=0, non=42, log-odds=-4.24)
- `however notable` (max=0, non=36, log-odds=-4.09)
- `execution competent` (max=0, non=36, log-odds=-4.09)
- `technical execution competent` (max=0, non=34, log-odds=-4.03)
- `overall technical execution competent` (max=0, non=34, log-odds=-4.03)
- `however minor` (max=0, non=34, log-odds=-4.03)

### Platform-Native

**MAX phrases:**

- `platform-native technically proficient` (max=23, non=0, log-odds=+4.57)
- `platform-native technically proficient platform-native` (max=22, non=0, log-odds=+4.52)
- `technically proficient platform-native` (max=22, non=0, log-odds=+4.52)
- `proficient platform-native` (max=22, non=0, log-odds=+4.52)
- `fully compliant` (max=20, non=0, log-odds=+4.43)
- `platform-native fully compliant` (max=20, non=0, log-odds=+4.43)
- `fully aligned` (max=13, non=0, log-odds=+4.01)
- `platform-native fully aligned` (max=13, non=0, log-odds=+4.01)
- `platform-native fully` (max=40, non=1, log-odds=+4.01)
- `platform-native technically` (max=37, non=1, log-odds=+3.93)
- `compliant all` (max=12, non=0, log-odds=+3.93)
- `fully compliant all` (max=11, non=0, log-odds=+3.85)
- `platform-native fully compliant all` (max=11, non=0, log-odds=+3.85)
- `composition platform-native composition` (max=11, non=0, log-odds=+3.85)
- `platform-native composition platform-native composition` (max=10, non=0, log-odds=+3.76)

**NON-MAX phrases (deduction triggers):**

- `such stronger` (max=0, non=12, log-odds=-2.50)
- `platform-native optimization` (max=1, non=24, log-odds=-2.08)
- `stronger hook` (max=1, non=13, log-odds=-1.48)
- `features such` (max=1, non=13, log-odds=-1.48)
- `elements such` (max=1, non=11, log-odds=-1.32)
- `platform-native optimization platform-native` (max=1, non=11, log-odds=-1.32)
- `platform-native engagement` (max=6, non=48, log-odds=-1.29)
- `perfect platform-native` (max=1, non=9, log-odds=-1.13)
- `platform-native impact platform-native` (max=2, non=14, log-odds=-1.04)
- `platform-native platform-native platform-native` (max=2, non=13, log-odds=-0.97)
- `optimization platform-native` (max=2, non=13, log-odds=-0.97)
- `platform optimization` (max=3, non=17, log-odds=-0.89)
- `platform-native technique` (max=2, non=12, log-odds=-0.89)
- `platform-native impact` (max=4, non=20, log-odds=-0.80)
- `mention hashtag` (max=3, non=15, log-odds=-0.77)
