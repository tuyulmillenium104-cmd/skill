# Originality_and_Authenticity — Decision Boundary

MAX verdicts: 3417 | NEAR: 6948 | LOW: 2487

## Sub-rubrics Detected

- **authentic** (7681 mentions)
- **distinctive** (4118 mentions)
- **voice** (11022 mentions)
- **originality** (7649 mentions)

## Top MAX-Indicating Phrases (global)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `demonstrates exceptional` | 558 | 0 | +8.20 |
| `demonstrates exceptional originality` | 537 | 0 | +8.16 |
| `demonstrates high degree originality` | 212 | 0 | +7.23 |
| `demonstrates exceptional originality authenticity` | 138 | 0 | +6.80 |
| `strong unique perspective framing` | 104 | 0 | +6.52 |
| `demonstrates highly` | 104 | 0 | +6.52 |
| `demonstrates exceptional originality authentic` | 103 | 0 | +6.51 |
| `demonstrates high level originality` | 99 | 0 | +6.47 |
| `strong originality authenticity` | 78 | 0 | +6.24 |
| `minor deductions` | 75 | 0 | +6.20 |
| `demonstrates strong originality authenticity` | 74 | 0 | +6.18 |
| `demonstrates high originality` | 72 | 0 | +6.16 |
| `high degree originality` | 217 | 1 | +6.16 |
| `exceptional originality authenticity across` | 70 | 0 | +6.13 |
| `high degree originality framing` | 62 | 0 | +6.01 |
| `overall highly original` | 61 | 0 | +5.99 |
| `demonstrates highly original` | 57 | 0 | +5.92 |
| `creative expression shines through` | 52 | 0 | +5.83 |
| `expression shines through` | 52 | 0 | +5.83 |
| `demonstrates exceptional originality framing` | 48 | 0 | +5.75 |
| `unlike similar tweets focus` | 48 | 0 | +5.75 |
| `exceptional originality framing` | 48 | 0 | +5.75 |
| `constraints while delivering` | 46 | 0 | +5.71 |
| `minor deduction` | 43 | 0 | +5.64 |
| `voice highly authentic` | 43 | 0 | +5.64 |
| `demonstrates high level` | 121 | 1 | +5.57 |
| `distinct similar tweets avoids` | 39 | 0 | +5.55 |
| `thread demonstrates exceptional` | 39 | 0 | +5.55 |
| `stands out highly original` | 37 | 0 | +5.50 |
| `rely repetitive` | 37 | 0 | +5.50 |

## Top NON-MAX-Indicating Phrases (deduction triggers)

| Phrase | MAX freq | non-MAX freq | log-odds |
|---|---|---|---|
| `overall acceptable` | 0 | 1301 | -6.68 |
| `not especially` | 0 | 1228 | -6.63 |
| `identical all` | 0 | 1037 | -6.46 |
| `than authentic` | 0 | 869 | -6.28 |
| `very close` | 0 | 729 | -6.11 |
| `not introduce` | 0 | 714 | -6.08 |
| `does not introduce` | 0 | 704 | -6.07 |
| `than original` | 0 | 668 | -6.02 |
| `highly derivative` | 0 | 656 | -6.00 |
| `rather than authentic` | 0 | 628 | -5.96 |
| `rather than original` | 0 | 607 | -5.92 |
| `acceptable not` | 0 | 583 | -5.88 |
| `moderately original` | 0 | 561 | -5.84 |
| `identical all five` | 0 | 547 | -5.82 |
| `natural enough` | 0 | 543 | -5.81 |
| `closely mirror` | 0 | 482 | -5.69 |
| `feels templated` | 0 | 482 | -5.69 |
| `expression limited` | 0 | 462 | -5.65 |
| `identical all five similar` | 0 | 461 | -5.65 |
| `creative expression limited` | 0 | 459 | -5.64 |
| `demonstrates acceptable` | 0 | 454 | -5.63 |
| `templated rather than` | 0 | 453 | -5.63 |
| `templated rather` | 0 | 453 | -5.63 |
| `more like polished` | 0 | 440 | -5.60 |
| `copy rather` | 0 | 399 | -5.50 |
| `copy rather than` | 0 | 399 | -5.50 |
| `demonstrates acceptable originality` | 0 | 394 | -5.49 |
| `originality limited` | 0 | 387 | -5.47 |
| `very similar` | 0 | 385 | -5.47 |
| `any personal` | 0 | 378 | -5.45 |

## Per Sub-Rubric Patterns

### authentic

**MAX phrases:**

- `aligns perfectly` (max=32, non=0, log-odds=+4.91)
- `minor deductions` (max=30, non=0, log-odds=+4.85)
- `highly distinct similar tweets` (max=26, non=0, log-odds=+4.71)
- `all constraints while` (max=26, non=0, log-odds=+4.71)
- `stands out significantly` (max=23, non=0, log-odds=+4.59)
- `shines through` (max=23, non=0, log-odds=+4.59)
- `speak while` (max=22, non=0, log-odds=+4.55)
- `creative expression shines through` (max=22, non=0, log-odds=+4.55)
- `while creative` (max=22, non=0, log-odds=+4.55)
- `expression shines through` (max=22, non=0, log-odds=+4.55)
- `high avoids common cliches` (max=21, non=0, log-odds=+4.50)
- `distinct similar tweets avoids` (max=21, non=0, log-odds=+4.50)
- `distinctiveness strong` (max=20, non=0, log-odds=+4.45)
- `while delivering` (max=20, non=0, log-odds=+4.45)
- `overall highly original` (max=20, non=0, log-odds=+4.45)

**NON-MAX phrases (deduction triggers):**

- `overall acceptable` (max=0, non=228, log-odds=-5.38)
- `authentic enough` (max=0, non=185, log-odds=-5.18)
- `not especially` (max=0, non=178, log-odds=-5.14)
- `not exceptional` (max=0, non=159, log-odds=-5.03)
- `very close` (max=0, non=112, log-odds=-4.68)
- `acceptable not` (max=0, non=98, log-odds=-4.54)
- `expression limited` (max=0, non=98, log-odds=-4.54)
- `creative expression limited` (max=0, non=97, log-odds=-4.53)
- `not introduce` (max=0, non=92, log-odds=-4.48)
- `does not introduce` (max=0, non=92, log-odds=-4.48)
- `natural enough` (max=0, non=87, log-odds=-4.42)
- `not exceptional authentic` (max=0, non=87, log-odds=-4.42)
- `authentic personal take` (max=0, non=86, log-odds=-4.41)
- `only moderately` (max=0, non=85, log-odds=-4.40)
- `not highly` (max=1, non=255, log-odds=-4.40)

### distinctive

**MAX phrases:**

- `free promotional` (max=20, non=0, log-odds=+5.04)
- `similar tweets avoiding` (max=17, non=0, log-odds=+4.88)
- `expression strong` (max=15, non=0, log-odds=+4.76)
- `creative expression strong` (max=15, non=0, log-odds=+4.76)
- `natural conversational free promotional` (max=14, non=0, log-odds=+4.70)
- `conversational free promotional` (max=14, non=0, log-odds=+4.70)
- `compared similar tweets avoiding` (max=14, non=0, log-odds=+4.70)
- `minor deductions` (max=12, non=0, log-odds=+4.55)
- `avoiding promotional` (max=11, non=0, log-odds=+4.47)
- `evident innovative` (max=11, non=0, log-odds=+4.47)
- `creative expression evident innovative` (max=11, non=0, log-odds=+4.47)
- `expression evident innovative` (max=11, non=0, log-odds=+4.47)
- `overall stands` (max=10, non=0, log-odds=+4.38)
- `organic rather than` (max=10, non=0, log-odds=+4.38)
- `expression shines` (max=10, non=0, log-odds=+4.38)

**NON-MAX phrases (deduction triggers):**

- `overall acceptable` (max=0, non=262, log-odds=-4.93)
- `acceptable distinctive` (max=0, non=155, log-odds=-4.41)
- `would make` (max=0, non=144, log-odds=-4.34)
- `not especially` (max=0, non=116, log-odds=-4.12)
- `like polished` (max=0, non=102, log-odds=-3.99)
- `not exceptional` (max=0, non=96, log-odds=-3.93)
- `some distinctive` (max=0, non=96, log-odds=-3.93)
- `natural enough` (max=0, non=90, log-odds=-3.87)
- `than distinctive` (max=0, non=88, log-odds=-3.85)
- `shows some` (max=0, non=86, log-odds=-3.82)
- `overlaps heavily` (max=0, non=84, log-odds=-3.80)
- `authenticity language` (max=0, non=81, log-odds=-3.76)
- `very close` (max=0, non=79, log-odds=-3.74)
- `language authenticity language` (max=0, non=78, log-odds=-3.73)
- `acceptable original` (max=0, non=78, log-odds=-3.73)

### voice

**MAX phrases:**

- `aligns perfectly` (max=88, non=0, log-odds=+6.31)
- `perfectly campaign's` (max=59, non=0, log-odds=+5.91)
- `while delivering` (max=53, non=0, log-odds=+5.80)
- `maintaining distinct` (max=43, non=0, log-odds=+5.60)
- `while maintaining distinct` (max=43, non=0, log-odds=+5.60)
- `aligns perfectly campaign's` (max=42, non=0, log-odds=+5.57)
- `constraints while delivering` (max=38, non=0, log-odds=+5.47)
- `overall highly original` (max=37, non=0, log-odds=+5.45)
- `stands out significantly` (max=31, non=0, log-odds=+5.27)
- `stands out highly` (max=30, non=0, log-odds=+5.24)
- `voice feels voice voice` (max=29, non=0, log-odds=+5.21)
- `minor deductions` (max=29, non=0, log-odds=+5.21)
- `all constraints while delivering` (max=28, non=0, log-odds=+5.17)
- `voice distinctly` (max=27, non=0, log-odds=+5.14)
- `completely avoids` (max=25, non=0, log-odds=+5.06)

**NON-MAX phrases (deduction triggers):**

- `overall acceptable` (max=0, non=650, log-odds=-6.04)
- `not especially` (max=0, non=557, log-odds=-5.89)
- `would make` (max=0, non=361, log-odds=-5.45)
- `natural enough` (max=0, non=340, log-odds=-5.39)
- `more like polished` (max=0, non=296, log-odds=-5.25)
- `expression limited` (max=0, non=274, log-odds=-5.18)
- `creative expression limited` (max=0, non=273, log-odds=-5.17)
- `feels templated` (max=0, non=272, log-odds=-5.17)
- `very close` (max=0, non=252, log-odds=-5.09)
- `experience opinion` (max=0, non=251, log-odds=-5.09)
- `not introduce` (max=0, non=250, log-odds=-5.09)
- `does not introduce` (max=0, non=248, log-odds=-5.08)
- `than original` (max=0, non=234, log-odds=-5.02)
- `templated rather than` (max=0, non=232, log-odds=-5.01)
- `templated rather` (max=0, non=232, log-odds=-5.01)

### originality

**MAX phrases:**

- `unlike similar tweets` (max=117, non=0, log-odds=+6.48)
- `unlike similar` (max=124, non=1, log-odds=+5.44)
- `immediately establishes` (max=38, non=0, log-odds=+5.37)
- `unlike provided similar` (max=35, non=0, log-odds=+5.28)
- `unlike provided` (max=35, non=0, log-odds=+5.28)
- `unlike similar tweets provided` (max=34, non=0, log-odds=+5.26)
- `unlike provided similar tweets` (max=33, non=0, log-odds=+5.23)
- `authenticity across all five` (max=29, non=0, log-odds=+5.10)
- `while other` (max=29, non=0, log-odds=+5.10)
- `originality grounding` (max=27, non=0, log-odds=+5.03)
- `originality moving` (max=26, non=0, log-odds=+4.99)
- `while similar tweets` (max=25, non=0, log-odds=+4.95)
- `tweets rely` (max=73, non=1, log-odds=+4.91)
- `originality moving beyond` (max=24, non=0, log-odds=+4.91)
- `unlike similar tweets rely` (max=22, non=0, log-odds=+4.83)

**NON-MAX phrases (deduction triggers):**

- `originality limited` (max=0, non=387, log-odds=-5.63)
- `closely mirrors` (max=0, non=336, log-odds=-5.49)
- `originality moderate` (max=0, non=261, log-odds=-5.24)
- `originality some` (max=0, non=251, log-odds=-5.20)
- `not exceptional` (max=0, non=246, log-odds=-5.18)
- `moderate rather than` (max=0, non=227, log-odds=-5.10)
- `moderate rather` (max=0, non=227, log-odds=-5.10)
- `originality moderate rather` (max=0, non=225, log-odds=-5.09)
- `originality moderate rather than` (max=0, non=225, log-odds=-5.09)
- `identical all` (max=0, non=182, log-odds=-4.88)
- `some originality` (max=0, non=174, log-odds=-4.83)
- `not especially` (max=0, non=169, log-odds=-4.80)
- `very close` (max=0, non=168, log-odds=-4.80)
- `than standout` (max=0, non=167, log-odds=-4.79)
- `rather than standout` (max=0, non=166, log-odds=-4.79)
