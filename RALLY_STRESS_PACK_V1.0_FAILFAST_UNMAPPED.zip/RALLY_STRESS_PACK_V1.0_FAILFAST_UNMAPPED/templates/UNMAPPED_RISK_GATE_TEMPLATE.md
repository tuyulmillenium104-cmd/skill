# UNMAPPED RISK GATE

Ignore the checklist for a moment. Assume mechanical gates might pass.

Review as:

1. Rally judge
2. casual target reader
3. skeptical participant
4. campaign owner
5. competitor-comparison judge
6. human-authenticity detector
7. domain-native reader
8. non-expert reader

Questions:

- What feels off even if all checkers pass?
- What risk is not covered by current gates?
- What is the nicest 4/5 sentence a judge could write?
- If this loses, why?
- Does the media/screenshot have to prove something the text depends on?
- Does it feel like a real human wrote it?

For each issue classify:

- HARD FAIL
- CREDIBLE DEDUCTION
- SOFT WATCH
- TASTE PREFERENCE
- FALSE POSITIVE

Do not rewrite the whole content. Give minimal surgical fix only.
