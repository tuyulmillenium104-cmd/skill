# MAIN CONTENT STRESS REPORT

Overall: PASS / REVISION NEEDED / STOP

Q&A approval: YES / NO

## Stage results

| Stage | Result | Notes |
|---|---|---|
| Intake validity |  |  |
| Hard compliance |  |  |
| Campaign/source/media fit |  |  |
| Creative viability |  |  |
| Unmapped Risk Gate |  |  |
| Known gate stress |  |  |

## Issues

| Severity | Evidence | Why Rally may cut | Minimal surgical fix |
|---|---|---|---|

## Decision

```text
If PASS: MAIN_CONTENT_STRESS_PASS - Q&A GENERATION APPROVED
If FAIL: STOP - Q&A NOT GENERATED
```
