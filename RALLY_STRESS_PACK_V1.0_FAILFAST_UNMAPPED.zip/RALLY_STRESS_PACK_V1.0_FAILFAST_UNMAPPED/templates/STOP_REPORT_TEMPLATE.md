# STRESS STOP REPORT

Overall: **STOP**

Q&A generated: **NO**

## Failed stage

- Stage:
- Severity: HARD FAIL / CREDIBLE DEDUCTION

## Evidence

```text
[paste exact line / rule / risk]
```

## Why Rally judge may cut

```text
[reason]
```

## Recommended action

- Regenerate new content: YES / NO
- Surgical rewrite possible: YES / NO

## Minimal fix direction

```text
[instruction for generate session]
```

## What not to change

- 
