# Q&A AFTER MAIN CONTENT PASS

Q&A may be generated only after:

```text
MAIN_CONTENT_STRESS_PASS
```

## Q&A rules

- Must answer or extend the actual CTA/mechanism.
- Must sound like different humans.
- Must not use repeated public shells.
- Must not reveal private checker/audit workflow.
- Must pass formula-shell caps:
  - myConcernStartPct <= 10%
  - myAnswerStartPct <= 10%
  - formulaStartPct <= 35%
  - mentionStartPct <= 25%

## Q&A status labels

Before audit:

```text
Q&A DRAFT - STRESS PENDING
```

After pass:

```text
Q&A LOCAL PASS - NOT EXTERNAL GUARANTEE
```
