# FINAL STRESS REPORT

## Status

- Main content stress: PASS / FAIL
- Q&A generated: YES / NO
- Q&A stress: PASS / FAIL / NOT RUN
- Final integrity: PASS / FAIL / NOT RUN

## Honest label

Allowed only if all relevant gates pass:

```text
Local strict PASS
Known-Gate Absolute local PASS
Controllable-side PASS
```

Forbidden:

```text
guaranteed all-max
guaranteed winner
guaranteed top 1%
guaranteed RQ5
```
