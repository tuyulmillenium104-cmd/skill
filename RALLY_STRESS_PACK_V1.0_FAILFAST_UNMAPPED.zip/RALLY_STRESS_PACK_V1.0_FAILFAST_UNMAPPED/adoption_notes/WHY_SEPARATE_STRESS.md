# Why this stress pack is separate

Separation protects creative quality.

Generate should create original human content. Stress should judge it.

The stress pack is allowed to fail fast. If main content fails, it must not waste time creating Q&A.
