# Example STOP report

Overall: STOP

Q&A generated: NO

Stage: Campaign/source/media fit
Severity: HARD FAIL

Evidence:

```text
Draft says homepage board, but screenshot plan says profile-only screenshot.
```

Why Rally may cut:

```text
The campaign requires real screenshot/proof. If the proof surface does not support the claim, the post can read as staged or mismatched.
```

Recommended action:

```text
Regenerate around profile/activity proof, or attach board screenshot.
```
