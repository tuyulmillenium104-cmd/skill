# RALLY STRESS PACK V1.0 - FAILFAST + UNMAPPED RISK

Purpose: evaluate generate-pack outputs. Do not write main content.

## Role

```text
Generate pack = Creator / Writer
Stress pack = Rally Stress Judge / Red Team
```

## Core rule

Main content is stress-tested first. Q&A is created only if main content passes.

```text
If main content fails -> STOP REPORT -> Q&A NOT GENERATED
If main content passes -> Q&A APPROVED -> generate/audit Q&A
```

## Stress philosophy

Known gates catch mapped risks. The Unmapped Risk Gate catches what tools do not measure.

## Read order

1. `STRESS_WORKFLOW.md`
2. `templates/MAIN_CONTENT_STRESS_REPORT_TEMPLATE.md`
3. `templates/STOP_REPORT_TEMPLATE.md`
4. `templates/UNMAPPED_RISK_GATE_TEMPLATE.md`
5. `templates/QNA_AFTER_PASS_TEMPLATE.md`
