# STRESS WORKFLOW - FAILFAST

## Phase A - Main content stress only

Run stages in order. Stop early on hard fail or major credible deduction.

### Stage 0 - Intake validity

Check:

- draft exists,
- campaign truth lock exists,
- mission clear,
- screenshot/media plan present if required.

### Stage 1 - Hard compliance

Check:

- required mention(s),
- required URL(s),
- required relation/source URL,
- screenshot/media plan,
- forbidden punctuation,
- forbidden claims.

Hard fail stops immediately.

### Stage 2 - Campaign/source/media fit

Check:

- content answers mission ask,
- product/KB claims are accurate,
- screenshot plan supports content,
- relation/media plan matches campaign.

### Stage 3 - Creative viability

Manual judge check:

- hook stop power,
- fresh surface,
- human voice,
- campaign-native value,
- CTA fit.

### Stage 4 - Unmapped Risk Gate

Free AI judgement to catch unknown risks. Structured severity only.

### Stage 5 - Known gate stress

Run mechanical/semantic gates:

- compliance,
- CTA,
- tactical value,
- compactness,
- loser-DNA,
- originality,
- TQ/OAA/IA,
- EP semantic,
- worst-positive,
- human-typed.

If main content fails, output STOP REPORT. Do not create Q&A.

## Phase B - Q&A only after main content pass

Only after `MAIN_CONTENT_STRESS_PASS`:

1. create/generate Q&A,
2. run RQ prompt-answer,
3. run RQ mechanics,
4. run naturalness,
5. run QNA gold,
6. run V3.1.4+ formula-shell policy,
7. run human-typed combined,
8. final integrity.

## Severity

- HARD FAIL: stop immediately.
- CREDIBLE DEDUCTION: stop if core angle/content is affected.
- SOFT WATCH: continue but record.
- TASTE PREFERENCE: do not stop.
- FALSE POSITIVE: ignore after documenting.
