# Universal Rally Campaign Safety Protocol

Purpose: make the Rally workflow safer across **all campaigns**, not only one campaign. This protocol exists because recent runs exposed failure modes that are campaign-agnostic: mission mix-ups, wrong handles, duplicated content across missions, public/internal file confusion, unnatural Q&A labels, stale files, and semantic pipeline errors.

## Core principle

```text
Same safety discipline. Campaign-specific creative output.
```

This protocol must run after every significant content/Q&A change and before packaging the final deliverable.

## 1. Mission Isolation Lock

Every mission is treated as a separate product.

Required per mission:

```text
mission-id/
  content.txt
  content_and_qna_final.md
  RUN_REPORT.md or audit summary
  reports/
  data/ or evidence pointer
```

Rules:

- Do not reuse the same content for multiple missions unless the user explicitly asks for it.
- Mission 0 and mission 1 must have different strategic intent, not only different folder names.
- Before finalization, compare content across missions.
- If two mission contents are identical or near-identical, rebuild at least one mission.

Universal check:

```text
content_mission_A != content_mission_B
similarity(content_mission_A, content_mission_B) <= allowed_threshold
```

Default allowed threshold:

```text
0.82
```

If higher than threshold, human review is required. If identical, hard FAIL.

## 2. Canonical Handle and URL Lock

Each campaign has canonical public entities:

- required handles,
- forbidden/old handles,
- quote/reply URL,
- campaign title,
- mission title,
- prohibited formatting.

Rules:

- The final handle must follow the latest campaign/user-corrected canonical handle.
- If the user corrects a handle, treat it as a canonical override.
- Replace all public occurrences of the old handle.
- Re-run compliance after replacement.
- Verify exact counts.

Required checks:

```text
required_handle_count == expected_count
forbidden_handle_count == 0
quote_or_reply_url == required_url, if mission requires it
```

If multiple handles are allowed, document which is used and why.

## 3. Public vs Internal Deliverable Separation

Default user deliverable must be one clean public final folder.

Public folder may contain:

```text
README.md
mission-x/content.txt
mission-x/content_and_qna_final.md
```

Public folder must not contain:

```text
Q-COPY
A-COPY
tier labels
Gold V3
qa_ranking
voicePersona
voiceMode
deployment
SIMULATED
internal metadata
checker names
private audit workflow
```

Internal folders/reports are allowed only when the user asks for audit evidence, or inside a clearly separate organized/audit folder.

Default naming:

```text
Campaign_Name_FINAL/
Campaign_Name_FINAL.zip
```

Avoid giving the user two competing final folders unless explicitly requested.

## 4. Semantic Process Order Audit

For any campaign explaining a process, pipeline, protocol, workflow, or stack, check temporal/causal order.

Common safe order for commerce/contract pipelines:

```text
agreement -> escrow/payment hold -> work/execution -> verification -> dispute -> release/settlement
```

Danger pattern:

```text
agreement -> settlement -> work
```

Why it is risky:

- “settlement” can mean final resolution.
- If placed before work, it can sound like the deal finalizes before performance.
- Use “escrow”, “funds held”, “payment hold”, or “value held” before work.

Universal rule:

```text
If settlement appears before work/execution in a process sequence, review and likely replace with escrow/payment hold.
```

Also check for other causal order problems:

- verdict before evidence,
- release before proof,
- dispute before agreement,
- verification before delivery,
- appeal before initial decision,
- final settlement before contested work is assessed.

## 5. Q&A Public Naturalness Lock

Q&A must read as public replies from humans, not as generated labels.

Risk patterns:

```text
Small doubt:
Real issue:
Hot take:
Wrong lesson:
Challenge:
Technical deep-dive:
Specific probe:
```

These may be acceptable in private ranking metadata, but they should not appear in public Q&A if they feel like labels.

Universal Q&A rules:

- No public parser labels.
- No private skill metadata.
- No repetitive opening shell.
- No colon-label opening unless it genuinely sounds human for the campaign.
- No semicolon-heavy artificial style.
- Q&A must match the final content, final CTA, and final handle.

Recommended checks:

```text
metadata_grep == clean
old_handle_grep == clean
Q/A count == expected
Q&A references current CTA concepts
no label-like colon openers
```

## 6. Final Synchronization Gate

After every content, handle, CTA, or Q&A change, update all final surfaces.

Required sync order:

```text
1. content.txt
2. content_and_qna_final.md
3. combined/internal file if used
4. contract/report if used
5. zip package
6. grep/sanity checks
7. present final file
```

Never say “updated” until the zip and public folder are actually rebuilt.

## 7. Controllable Truth Boundary

Universal claim allowed:

```text
No known controllable non-max reason remains in the local audit set.
```

Universal claims forbidden:

```text
Guaranteed all-max
Guaranteed EP 5/5
Guaranteed RQ 5/5
Guaranteed top 1%
Guaranteed winner
Guaranteed rewards
```

Always separate:

- controllable local gates,
- subjective local judgment,
- external Rally judge variance,
- real replies and engagement.

## 8. Universal Final Checklist

Before final delivery, answer all:

```text
[ ] Mission folders are isolated and not duplicated.
[ ] Required handle count is correct.
[ ] Forbidden/old handle count is zero.
[ ] Required URL is present where required.
[ ] Main content in content.txt equals main content in public MD.
[ ] Q&A count is correct.
[ ] Q&A aligns with final content and CTA.
[ ] Public folder has no internal metadata labels.
[ ] Semantic process order has no causal contradiction.
[ ] Zip was rebuilt after last edit.
[ ] External score guarantees are not claimed.
```

## 9. Tool Support

Use the universal checker:

```bash
python3 /home/user/konten/ACTIVE_ARCHITECTURE/tools/universal_campaign_sanity_check.py \
  --root /home/user/konten/Campaign_FINAL \
  --required-handle @CorrectHandle \
  --forbidden-handle @OldHandle \
  --require-distinct-content
```

This checker does not replace campaign-specific gates, EP semantic review, or human taste review. It catches universal workflow failures before delivery.

## 10. Real Judge 4/5 Cap Integration

The universal sanity checker can now run the real judge 4/5 cap gate for every mission in a final folder.

Recommended strict command:

```bash
python3 /home/user/konten/ACTIVE_ARCHITECTURE/tools/universal_campaign_sanity_check.py \
  --root /home/user/konten/Campaign_FINAL \
  --required-handle @CorrectHandle \
  --forbidden-handle @OldHandle \
  --require-distinct-content \
  --real-judge-4cap \
  --campaign-type explain
```

If this fails, the content/Q&A may still pass older local gates, but the new real-judge calibration says a credible 4/5 cap remains. Treat that as a rebuild/rewrite signal, not as a cosmetic warning.

## 11. Campaign Goal Alignment Integration

Universal final sanity is not enough if the draft is accurate but too narrow.

Every serious run should include either:

```text
CAMPAIGN_GOAL_ALIGNMENT.md
```

or:

```text
CAMPAIGN_GOAL_ALIGNMENT_CONTRACT.json
```

and should enforce it with:

```bash
python3 /home/user/konten/ACTIVE_ARCHITECTURE/tools/campaign_goal_alignment_enforcer.py \
  --contract CAMPAIGN_GOAL_ALIGNMENT_CONTRACT.json \
  --content content.txt
```

This gate prevents future content from delivering only a sub-feature when winners deliver the full campaign reason to exist.

## 12. Manual-First Tool Boundary

Universal safety checks must not become creative direction.

Required protocol:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/protocols/MANUAL_FIRST_RALLY_CREATIVE_PROTOCOL.md
```

Universal rule:

```text
Run manual adversarial audit before Python finalization.
Run Python only after the content is already strong by human/winner judgment.
```

If a script PASS conflicts with manual judgment, manual judgment wins.
If a script FAIL asks for unnatural language, manually rewrite the concept instead of patching the sentence.

Hard ban:

```text
No regex patch loop for public Q&A naturalness or RQ repair.
```

## 13. EP Surface Selection Integration

The universal workflow now recognizes the EP surface map as a selection system, not a checklist.

Required protocol:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/protocols/EP_SURFACE_SELECTION_PROTOCOL.md
```

A campaign can fail if the assistant forces irrelevant EP surfaces into it. A campaign can also fail if a critical surface is ignored.

Universal rule:

```text
Every EP surface must be considered.
Only campaign-relevant surfaces must be optimized.
Irrelevant surfaces must be scoped out with a reason.
```

## 14. Parallel Fast Strict Integration

Universal safety allows parallel execution only for independent branches.

Required protocol:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/protocols/PARALLEL_FAST_STRICT_WORKFLOW.md
```

Cache protocol:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/protocols/CAMPAIGN_CACHE_PROTOCOL.md
```

Parallelism must never skip:

- campaign-soul audit,
- winner comparison,
- manual adversarial review,
- Q&A public audit,
- mechanical final checks.

If speed conflicts with quality, quality wins.

## 15. Run Ledger Anti-Skip Integration

Universal safety now requires step evidence for serious runs.

Protocol:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/protocols/RUN_LEDGER_PROTOCOL.md
```

Validator:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/tools/run_completion_validator.py
```

Rule:

```text
No artifact, no step.
No valid ledger, no full strict claim.
```

## 16. Sub-Agent Panel Integration

For high-stakes runs, universal final safety expects a sub-agent panel artifact.

Protocol:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/protocols/SUB_AGENT_PANEL_PROTOCOL.md
```

Template:

```text
/home/user/konten/ACTIVE_ARCHITECTURE/templates/SUB_AGENT_PANEL_TEMPLATE.md
```

This does not have to be a long report. Compact proof is enough, but each sub-agent must provide evidence, a possible 4/5 sentence, and a decision.

---

## Adoption note

Adopted carefully from the user-supplied GitHub skill repository on 2026-07-18. Active only where compatible with current engine law: Campaign Ask x Rally Judge Desire, Data does not write, real-verdict ratchets, and no external score guarantee.
