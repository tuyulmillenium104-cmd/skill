# EP Surface Selection Protocol

Purpose: treat Engagement Potential surfaces as a **campaign-aware diagnostic map**, not as a rigid checklist. This prevents forcing every campaign into the same shape and avoids stiff, over-engineered content.

## Core principle

```text
Campaign first.
EP surfaces second.
Draft third.
Audit fourth.
Tools last.
```

The EP surface map is not a recipe. It is a question bank. Every surface must be considered, but not every surface should be forced into the content.

## Surface status system

Each EP surface gets one of four statuses per campaign:

```text
CRITICAL   = must be strong for this campaign type
SUPPORTING = useful but not the main driver
WATCH      = do not force, but check for risk
SCOPED OUT = not relevant or would damage the campaign if forced
```

A surface cannot be scoped out silently. It needs a reason.

## Universal EP surfaces

These are generally relevant to every Rally campaign. They do not always need to be equally dominant, but they must always be considered.

| # | Surface | Why universal | Typical fail sentence |
|---:|---|---|---|
| 1 | Campaign-soul fit | The post must deliver why the campaign exists, not only mention the topic. | Strong, but misses the bigger campaign point. |
| 2 | Literal mission compliance | If the post misses the mission action, quality cannot save it. | Good content, but not fully aligned with the mission ask. |
| 3 | Stop power | No one engages if the opening does not stop attention. | Clear, but the hook is not elite. |
| 4 | Payoff speed | The reader needs value quickly, especially on X. | Strong idea, but payoff arrives too late. |
| 5 | Read completion | EP depends on people finishing the post. | Insightful, but too dense for casual scrollers. |
| 6 | Concept clarity | Readers must understand the product/point. | Interesting, but the mechanism is not clear enough. |
| 7 | Value delivery | The post must give insight, explanation, utility, emotion, or stance. | Engaging, but value delivery is moderate. |
| 8 | Human voice / authenticity | Juries notice campaign-copy and AI-like polish. | Polished, but not fully organic. |
| 9 | Platform fit | X rewards scannability, compression, and native phrasing. | Good idea, but not optimized for the platform. |
| 10 | CTA / open-loop quality | Official EP includes CTA quality. It can be explicit or a natural open loop. | Conversation potential is limited by the ask. |
| 11 | Expected reply richness | A good CTA should invite substantive replies, not only option-picking. | The prompt is answerable, but may produce shallow replies. |
| 12 | Brand / project integration | Required mention must feel native and necessary. | Mention is present but feels inserted. |
| 13 | Originality versus pool | Juries compare against other submissions. | Accurate, but overlaps with common campaign narratives. |
| 14 | Claim boundary | Overclaiming can hurt IA and trust. | Strong, but phrasing implies more than the KB supports. |
| 15 | Judge preference versus winners | A final must compete with winners, not just avoid errors. | Strong, but not as compelling as top winners. |
| 16 | Friction to first response | If replying feels hard, EP drops. | CTA is thoughtful but may be too effortful. |
| 17 | Cognitive ease | Too many concepts reduce completion and sharing. | Accurate, but concept-heavy. |
| 18 | Memory hierarchy | The post needs one dominant takeaway, not five competing ideas. | Good points, but no single memorable center. |

## Conditional EP amplifiers

These are powerful only when the campaign type needs them. They should be selected, not forced.

| # | Surface | Critical when | Dangerous when forced |
|---:|---|---|---|
| 19 | Bookmarkability / save potential | explain, product, protocol, technical, educational | meme, pure culture, short punchline campaigns |
| 20 | Shareability / retweet incentive | launch, thought leadership, hot take, broad awareness | narrow how-to posts where utility matters more |
| 21 | Standalone thesis portability | launch, hot take, protocol, founder/product campaigns | personal story where subtlety matters more |
| 22 | Social currency | launch, infra, culture, hot take | sensitive/personal campaigns where posturing hurts |
| 23 | Public stance | hot take, launch, narrative/opinion | neutral explainers where overstatement risks accuracy |
| 24 | Debate surface | hot take, protocol tradeoff, culture | compliance-heavy or safety-sensitive campaigns |
| 25 | Why-now urgency | launch, milestone, market shift | evergreen explainers if urgency feels fake |
| 26 | Source-thread integration | quote/reply missions | standalone explain missions |
| 27 | Quote-tweet usefulness | quote/reply missions | non-quote missions |
| 28 | Audience breadth | broad campaigns, launch, mass-awareness | niche technical campaigns where expert precision matters |
| 29 | Expert respect | technical/protocol/builder campaigns | casual campaigns where jargon reduces reach |
| 30 | Non-expert bridge | broad explain, onboarding, public launch | expert-only campaigns where oversimplification annoys |
| 31 | Saveable rule/checklist | explain/product/protocol | emotional/personal campaigns where checklist kills feeling |
| 32 | Practical decision frame | product/protocol/tactical builder | pure hype/culture campaigns |
| 33 | Emotional / identity hook | personal story, culture, hot take | technical explainers if it feels manufactured |
| 34 | Meme/remixability | meme/culture/light campaigns | serious protocol/explain campaigns |
| 35 | Humor/punchline | humor/meme/persona | high-trust technical campaigns |
| 36 | Visual imagination | most narrative/explain campaigns | if it replaces product clarity |
| 37 | Analogy freshness | explain/product/protocol | if analogy becomes distant or confusing |
| 38 | Technical depth | builder/protocol campaigns | broad campaigns where depth becomes density |
| 39 | Longform depth | complex explain, winner pools that reward depth | mobile-scroller campaigns or dense pools |
| 40 | FOMO / temporal relevance | launch, time-limited events | evergreen education where urgency feels fake |
| 41 | Comparative advantage clarity | product/protocol campaigns | when it requires unsupported claims about competitors |
| 42 | Objection preemption | skeptical/protocol audiences | short emotional campaigns where it over-explains |

## Risk-only surfaces

These are usually not things to add. They are things to avoid or control.

| # | Surface | Risk |
|---:|---|---|
| 43 | Synthetic symmetry | Too perfectly structured can feel AI-generated. |
| 44 | Line-break dependency | Impact comes from formatting, not substance. |
| 45 | Abstract noun density | Too many concepts, not enough objects. |
| 46 | Metaphor burden | Metaphor requires too much interpretation or has bad connotations. |
| 47 | Thought-leadership cosplay | Smart-sounding but not lived or useful. |
| 48 | Specificity without livedness | Details feel invented only to satisfy specificity. |
| 49 | Analogy distance | Example is fresh but too niche or far from audience. |
| 50 | Underusing campaign language | Avoiding jargon so much that campaign specifics disappear. |
| 51 | Overusing campaign language | Copying KB/brand language until it feels promotional. |
| 52 | Product boundary blur | Product becomes too narrow or too broad. |
| 53 | Reply entropy collapse | Replies all reason in the same way. |
| 54 | Reply social unreality | Replies sound like audit notes, not public comments. |
| 55 | Reply-to-CTA drift | Replies discuss the writing instead of answering the prompt. |
| 56 | Coordination suspicion | Reply set is uniformly polished or coordinated. |
| 57 | Retweet friction | People may like it but not share it. |
| 58 | Quoteability gap | No line travels outside the post. |
| 59 | Memetic compression gap | No compact phrase captures the idea. |
| 60 | Scenario plausibility | Scenario feels constructed or unlikely. |
| 61 | Comment-bait smell | CTA feels like engagement farming. |
| 62 | Context dependency | Post only works if reader already knows the quoted thread. |
| 63 | Read-aloud unnaturalness | Sentence passes text checks but sounds odd aloud. |
| 64 | Score-chasing signature | Public wording reveals rubric optimization. |

## Newly added surfaces beyond the original 47

The following are additions discovered after further analysis:

| # | Surface | Why it matters |
|---:|---|---|
| 65 | Reader role clarity | The reader should know whether they are being addressed as builder, user, skeptic, creator, trader, etc. |
| 66 | Curiosity gap closure | The hook must pay off what it promises. |
| 67 | Action specificity after reading | Reader should know what to think, do, test, or reply after reading. |
| 68 | Disagreement safety | Controversy must invite discussion without making false or reckless claims. |
| 69 | Concept ownership | The post should have a mental model that feels distinct, not just campaign vocabulary. |
| 70 | Screenshot value | The post should still make sense and carry value if screenshotted or quoted out of context. |
| 71 | First-screen density | The first few visible lines should give enough reason to expand/read. |
| 72 | Friction to agree | The post should not make readers feel they are endorsing hype too blindly. |
| 73 | Cross-audience bridge | Strong posts often give non-experts access while preserving expert respect. |
| 74 | Stance calibration | Stance should be sharp enough to share but not so strong that it becomes inaccurate. |
| 75 | Category creation | For product/protocol campaigns, the post should sometimes name the category, not only the product. |
| 76 | Emotional stakes calibration | Stakes should feel meaningful but not melodramatic. |
| 77 | Proof of reading the source | Quote/reply missions should feel like the creator actually read the source thread. |
| 78 | Distribution compatibility | The post should work for the likely account/audience, not only for an ideal audience. |
| 79 | Attention after CTA | The final line should not weaken or blur the strongest takeaway. |
| 80 | Negative space | The post should know what not to explain. Over-explaining can cap EP. |

## Selection process

Before drafting:

1. Understand campaign and mission deeply.
2. Determine campaign type and value mode.
3. Mark each surface as CRITICAL, SUPPORTING, WATCH, or SCOPED OUT.
4. Explain why any surface is critical or scoped out.
5. Draft from campaign strategy, not from the list.

After drafting:

1. Audit critical surfaces with evidence lines.
2. Write credible 4/5 sentence for each weak surface.
3. If any credible controllable 4/5 sentence remains, rewrite or rebuild.

## The important warning

Do not force all surfaces into one post.

That creates:

- stiff writing,
- too many goals,
- checklist smell,
- weak campaign fit,
- poor human voice.

The correct question is not:

```text
Did we include all EP surfaces?
```

The correct question is:

```text
Did we select and dominate the EP surfaces that this campaign actually needs?
```

---

## Adoption note

Adopted carefully from the user-supplied GitHub skill repository on 2026-07-18. Active only where compatible with current engine law: Campaign Ask x Rally Judge Desire, Data does not write, real-verdict ratchets, and no external score guarantee.
