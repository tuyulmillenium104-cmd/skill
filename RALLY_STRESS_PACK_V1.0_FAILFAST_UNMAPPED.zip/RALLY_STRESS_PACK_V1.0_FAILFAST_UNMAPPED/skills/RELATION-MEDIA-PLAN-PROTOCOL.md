# Relation / Media Plan Protocol

Purpose: prevent quote/reply/original-post mistakes, screenshot/media misses, and campaign-goal relation spillover before drafting and before final submission.

## Authority

This protocol is subordinate to:

1. Literal campaign and mission brief.
2. `RALLY-FUNDAMENTAL-LAW.md` / Campaign Ask x Rally Judge Desire.
3. Real Rally verdict evidence.

It does not override the literal mission ask. It documents it.

## Required artifact

For each mission create:

```text
submission-plan.json
```

Minimum fields:

```json
{
  "relationType": "original | quote | reply",
  "sourceUrl": "https://... if quote/reply is required",
  "mediaUsed": true,
  "mediaDescription": "what screenshot/image/video proves",
  "postingSurface": "X post / quote / reply / thread",
  "manualExternalChecks": [
    "attach real screenshot before submit",
    "verify required URL expands correctly"
  ]
}
```

## Checks

Run after requirement provenance exists:

```bash
python3 skills/rally-relation-compliance.py \
  --provenance requirement-provenance.json \
  --plan submission-plan.json \
  --out-json relation.json \
  --out-md RELATION.md
```

## Known real-judge failure this prevents

A prior external verdict deducted Campaign Compliance because campaign-wide quote/reply language spilled into a mission where the local mission relation was treated as original. This protocol makes that tension visible as `CAMPAIGN_GOAL_RELATION_SPILLOVER`.

## Honest limit

This protocol verifies the plan and text artifacts. It cannot verify the actual X UI state after posting. If a screenshot or quote/reply is required, user must still attach/perform it manually.
