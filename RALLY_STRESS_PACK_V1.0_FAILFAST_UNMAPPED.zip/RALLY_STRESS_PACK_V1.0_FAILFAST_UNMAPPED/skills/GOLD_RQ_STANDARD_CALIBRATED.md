# RALLY RQ GOLD STANDARD V3 - EVIDENCE-CALIBRATED

**Version:** 3.1.3  
**Status:** ACTIVE / highest RQ-generation authority after the literal campaign brief  
**Evidence refresh:** 2026-07-13  
**Machine policy:** `skills/rq-gold-policy-v3.json`  
**Policy checker:** `skills/rally-rq-v3-policy-check.py`

## 0. Truth law

A pack may be called **RQ5-ready** only after every required gate passes. It may
never be called guaranteed RQ 5/5. External RQ still depends on organic replies,
response speed, posting account behavior, and Rally's external judge.

`PASS` means the controllable side is strong and evidence-calibrated. It is not a
score prediction, probability, winner promise, or external verdict.

## 1. Evidence hierarchy

Use evidence in this order:

1. Literal campaign and mission brief.
2. Current mission-scoped real RQ5 replies and judge verdicts.
3. User-supplied Gold Standard when compatible with real evidence.
4. Global RQ verdict corpus and field lessons.
5. Automated gates and heuristics.

Fresh real evidence outranks a generic template or old threshold. Any conflict must
be documented and resolved evidence-first.

## 2. Required pack

Default English pack:

- 20 Q-COPY/A-COPY pairs.
- Specific Probe: 4.
- Challenge: 5.
- Technical Deep-Dive: 5.
- Hot Take: 4.
- Real Experience: 2; mark AI-generated rows as `SIMULATED_ARCHETYPE` in heading/type metadata and `CONDITIONAL_ORGANIC_MATCH_ONLY` in ranking metadata. Do not place the warning label inside Q-COPY.
- Ranked strongest to weakest with Tier S=9, Tier A=7, Tier B=4, Tier C=0.
- AI-generated Real Experience may be Tier S only as `CONDITIONAL_ORGANIC_MATCH_ONLY`; its Q-COPY is not deployable as testimony.

Mission evidence may change distribution only with a written calibration report and
an exposed checker override. Do not silently force equal distribution.

## 3. Q-COPY construction

### 3.1 Every Q must

- Read like a real public reply, not an interview question.
- Carry a personal opinion, stake, decision, objection, or experience.
- Reference the final post, CTA, mechanism, timing, number, or exact phrase.
- Add a new angle rather than paraphrasing the post.
- Be 160-260 characters under the current hash-backed workflow.
- Avoid generic praise, FAQ language, and writing-craft commentary.
- Stay within factual boundaries; hypothetical scenarios must read as hypothetical.

### 3.2 Type rules

**Specific Probe**

- Quote an exact phrase from the final post.
- Probe a new consequence, edge case, or domain.
- Generic `What is X?` questions fail.

**Challenge**

- Include a claim plus mechanism/evidence/scenario plus a precise doubt.
- Flat disagreement fails.
- Unsupported market facts fail; phrase uncertainty as a hypothesis.

**Technical Deep-Dive**

- Reference a specific post mechanism.
- Ask a bounded technical question or state a concrete technical concern.
- Generic `How does X work?` fails.

**Hot Take**

- Make a bold claim and provide an alternative thesis.
- Generic opposition fails.

**Real Experience**

- Use a mini-story from the replier's perspective.
- AI-generated examples must carry `SIMULATED_ARCHETYPE` in non-copy metadata and `CONDITIONAL_ORGANIC_MATCH_ONLY` deployment metadata.
- The Q-COPY body must read naturally and must not contain internal warning labels.
- Never seed simulated testimony as fake organic engagement.

### 3.3 Pack-level Q controls

Default V3 thresholds:

- Decision-marker coverage >=75%, not 100%.
- Decision-word coverage >=50%; decision-marker coverage already carries the stronger 75% action/stake constraint.
- CTA-aligned Q >=40%.
- Specific Probe exact-source quote =100%.
- Q using `because` <=35%.
- Q using `I would` <=25%.
- Q using `my decision` <=20%.
- Q-length coefficient of variation >=9%.
- At least three sentence-count structures across the pack.
- Journalist framing =0.
- Generic FAQ =0.
- Exact duplicate Q =0.

Coverage targets prevent rigid per-pair formula. Distinct voices outrank cosmetic
uniformity.

### 3.4 Voice-diversity controls (V3.1)

- Explicit first-person Q <=75%.
- Decision-marker Q <=80% as well as >=75%.
- Casual/contraction voice >=35%.
- Anecdotal or applied-experience surface >=35%.
- Distinct first-two-word Q openers >=15.
- Same first Q word <=25%.
- Same first-two-word Q shell <=15%.
- First-person Q openings <=40% even though first-person may appear later in up to 75%.
- Direct-question Q =20-35%.
- Two-sentence shell <=50%.
- Semicolon usage <=15%.
- Formal/abstract register <=40%.
- At least ten distinct personas and five distinct voice modes.
- No adjacent rows may use the same persona.
- `qa_ranking.json` must store `voicePersona` and `voiceMode` for every row.
- Scaffold `EVIDENCE_PERSONA_*` / `EVIDENCE_VOICE_*` placeholders are planning markers only and are rejected in a final ranking.
- Personas must be derived from current mission evidence; prior-campaign legal/protocol roles cannot leak into unrelated missions.

Lexical uniqueness alone is insufficient. A pack fails if different words still carry
the same polished analytical voice.

## 4. A-COPY construction

For an English pack:

- 40-45 words when possible.
- Hard maximum 280 characters.
- One line per answer.
- Direct response plus a new insight, implication, or honest boundary.
- Writer presence must remain consistent with the main post.
- Include a decision/action word.
- Weave facts naturally; do not recite the knowledge base.
- Zero fabricated facts or fake experience.
- Vary openings and closings.

Question-ending coverage is 50-75%, not a per-pair law. Statement closes are valid
when mission-specific real RQ5 replies support them. Do not force every answer to
end as a question if that creates a template shell.

## 5. Human-voice controls

Across the 20 pairs:

- Use blunt, analytical, anecdotal, skeptical, technical, and witty voices.
- Avoid 3 adjacent pairs with the same opening or sentence architecture.
- Keep exact duplicate Q/A at zero.
- Keep repeated 5-gram shells below naturalness review thresholds.
- Include at least two controlled witty/CT-native rows when campaign tone permits.
- Prefer one concrete detail over dense terminology.
- Remove academic phrasing that a real reply would not naturally use.

## 6. RQ5 evidence patterns

Real high-scoring replies repeatedly show:

- specific use cases;
- direct statements instead of journalist framing;
- subject-matter reasoning;
- constructive skepticism;
- personal or applied consequences;
- distinct voices;
- no generic praise, platitudes, or low-effort replies.

A technically sophisticated Q can still be weak if it ignores the post's actual CTA
or sounds like a requirement document.

## 7. Ranking protocol

Rank strongest to weakest for response speed:

1. Honest, specific objections.
2. Deep mechanism questions tied to the post.
3. Concrete domain probes answering the CTA.
4. Alternative theses and controlled humor.
5. Simulated archetypes last and non-deployable.

Internal ranking scores are prioritization indices only. Never label them Rally scores
or RQ probabilities.

## 8. Anti-dilution law

Every pair must pass the single-quote test:

> If the judge quotes only this line, is there a clear positive concept such as
> specificity, authenticity, subject-matter engagement, constructiveness, anecdote,
> or distinct voice?

If not, rebuild or remove the pair. Do not retain filler to reach 20.

## 9. Mandatory gates

Run all five:

```bash
python3 skills/rally-rq-prompt-answer-check.py \
  --content content.txt --combined combined.md \
  --out-json rq-prompt-answer.json --out-md RQ-PROMPT-ANSWER.md

python3 skills/rally-rq-mechanics-calibration-check.py \
  --content content.txt --combined combined.md \
  --campaign campaign.json --mission <mission> \
  --out-json rq-mechanics.json --out-md RQ-MECHANICS.md

python3 skills/rally-naturalness-variance-check.py \
  --content content.txt --combined combined.md \
  --out-json naturalness.json --out-md NATURALNESS.md

python3 skills/rally-qna-gold-audit.py \
  --content content.txt --combined combined.md \
  --out-json qna-gold.json --out-md QNA-GOLD.md

python3 skills/rally-rq-v3-policy-check.py \
  --content content.txt --combined combined.md \
  --ranking-json qa_ranking.json \
  --out-json rq-gold-v3-policy.json --out-md RQ-GOLD-V3-POLICY.md
```

Required result:

- every checker PASS;
- every pair Q/A/Feel >=4;
- RQ prompt-answer pass 20/20;
- mechanics >=70%;
- decision >=75%;
- skeptic >=25%;
- no naturalness FAIL or unresolved review;
- V3 policy PASS.

## 10. Deployment law

- Q-COPY models likely incoming replies; do not post all Qs yourself.
- Select only the A-COPY matching a real organic reply.
- Prioritize real confession, serious skepticism, and technical questions.
- Reply quickly when possible, but never sacrifice substance for speed.
- Do not post fake experiences, fake community conversation, or synthetic testimony.
- Re-audit any edited answer before deployment.

## 11. Final status language

Allowed:

- `RQ5-ready`
- `Gold V3 PASS`
- `mission-calibrated RQ5 pressure`

Forbidden:

- `guaranteed RQ5`
- `will produce RQ 5/5`
- `certain winner`
- `external judge proof`
