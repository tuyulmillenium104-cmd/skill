# DATA AS JUDGE, NOT WRITER POLICY

Status: ACTIVE
Purpose: prevent the system from becoming a winner-example copier.

## Core law

Real Rally data is used to **judge and stress-test** content, not to write the content by copying winner examples.

```text
Data does not write.
Data judges.
```

## What data is allowed to do

Data may:

- reveal hidden deduction risks;
- reveal winner-pull mechanisms;
- benchmark hook strength, CTA strength, specificity, and mechanism clarity;
- show crowded motifs and loser patterns;
- challenge whether a draft is distinctive enough;
- provide evidence for manual no-cut review.

## What data must not do

Data must not:

- become a template;
- dictate a copied analogy;
- force reuse of winner phrasing;
- globally hard-code mission-specific tricks;
- make every campaign sound like the previous winning campaign;
- replace original thesis creation.

## Correct use of winner data

Bad:

```text
Winner used claim number, so use claim number.
```

Good:

```text
Winner used a mundane administrative object to explain shared context. Find a fresh object for this mission.
```

Bad:

```text
Winner used itinerary, so use itinerary.
```

Good:

```text
Winner made the workflow concrete through a familiar coordination object. Create a new object if the campaign allows it.
```

## Drafting order

Correct order:

1. Literal brief.
2. Human problem.
3. Original thesis.
4. Fresh concrete object.
5. Mechanism bridge.
6. CTA engine.
7. Winner/loser data as judge.
8. Python gates as safety net.

Wrong order:

1. Read winner.
2. Copy winner's surface pattern.
3. Patch until checker passes.

## Anti-copy test

Before drafting, answer:

- What winner expression are we avoiding copying?
- What underlying mechanism did that winner use?
- What fresh expression are we using instead?
- Why is our expression mission-true and not derivative?

If this cannot be answered, do not draft.
