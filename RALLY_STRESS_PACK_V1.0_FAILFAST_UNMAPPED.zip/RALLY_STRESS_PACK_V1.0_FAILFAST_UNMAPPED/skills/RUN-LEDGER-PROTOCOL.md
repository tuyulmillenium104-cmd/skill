# Run Ledger Protocol

Purpose: prevent skipped steps, false “full strict” claims, and AI self-certification. A step is not considered done unless it leaves evidence.

## Core rule

```text
No artifact, no step.
```

A final answer may not claim a step was completed unless the run ledger records:

- step id,
- step name,
- required input,
- output artifact path,
- dependency,
- acceptance criteria,
- decision,
- timestamp or run order,
- caveat if simulated or skipped.

## Why this exists

AI agents can unintentionally or intentionally overclaim:

```text
I ran full strict.
I did a blind audit.
I checked winners.
Q&A is RQ5 locked.
```

Those claims are invalid without artifacts.

## Required run structure

For serious Rally runs, use this structure:

```text
RUN/
  00_EVIDENCE/
  01_CAMPAIGN_GOAL/
  02_SATURATION/
  03_EP_SURFACES/
  04_WINNER_DUEL/
  05_DRAFTS/
  06_MANUAL_AUDIT/
  07_QNA/
  08_MECHANICAL_QA/
  09_FINAL/
  RUN_LEDGER.json
  RUN_LEDGER.md
```

If a different folder structure is used, the ledger must still point to every artifact.

## Required step classes

A full strict run should include, unless explicitly scoped out with reason:

1. Evidence fetch
2. Campaign goal alignment
3. Winner mechanism audit
4. Saturation strategy
5. EP surface selection
6. Creative direction cards
7. Direction duel
8. Draft creation
9. Manual adversarial content audit
10. Content revision or rebuild decision
11. Q&A creation after content stability
12. Manual Q&A human conversation audit
13. Mechanical content gates
14. Mechanical Q&A gates
15. Real judge 4/5 cap audit
16. Universal sanity check
17. Final packaging and sync
18. Final truth caveat

## Step status values

Allowed:

```text
DONE
PASS
FAIL
SKIPPED_WITH_REASON
BLOCKED
```

Not allowed:

```text
maybe
assumed
probably
should be okay
```

## Manual steps need evidence too

Manual reasoning steps must create artifacts such as:

```text
CAMPAIGN_GOAL_ALIGNMENT.md
WINNER_MECHANISM_AUDIT.md
EP_SURFACE_SELECTION.md
MANUAL_ADVERSARIAL_AUDIT.md
QNA_HUMAN_VARIANCE_AUDIT.md
AGGREGATOR_DECISION.md
```

A manual step is invalid if it only says “done” without:

- evidence line,
- risk sentence,
- decision,
- action.

## Negative proof requirement

Every audit step must include an attempted failure sentence.

Example:

```text
Credible 4/5 sentence tested:
Strong, but the example is too niche and the post lacks a broad share thesis.

Decision:
Not credible because the final contains [evidence line].
```

If no attempted failure sentence appears, the audit is incomplete.

## Dependency rule

Steps cannot be claimed out of order.

Examples:

```text
Q&A cannot be DONE before content stability.
Final report cannot be DONE before final content and Q&A are stable.
Packaging cannot be DONE before public final sync.
```

The ledger validator should fail if dependencies are missing or not done.

## Final response rule

Every final response for a serious run must include:

```text
Completed steps:
Failed steps:
Skipped/simulated steps:
Remaining caveats:
Final artifact path:
```

If a required step is skipped, it must be listed honestly.

## Anti-lie language

Do not say:

```text
true blind
independent judge
guaranteed all max
guaranteed EP 5
guaranteed RQ5
```

unless that exact claim is evidenced.

Allowed:

```text
simulated blind
manual adversarial audit
local mechanical pass
external score not guaranteed
```

## Completion validator

Use:

```bash
python3 /home/user/konten/ACTIVE_ARCHITECTURE/tools/run_completion_validator.py \
  --ledger RUN_LEDGER.json \
  --final-root /home/user/konten/Campaign_FINAL \
  --zip /home/user/konten/Campaign_FINAL.zip
```

The validator checks evidence existence and basic final sync. It does not replace manual judgment.

---

## Sub-Agent Panel Evidence Requirement

For full strict runs, the manual adversarial audit step must include sub-agent panel evidence.

Required artifact:

```text
SUB_AGENT_PANEL.md
```

or a clear sub-agent section inside:

```text
MANUAL_ADVERSARIAL_AUDIT.md
```

If no sub-agent artifact exists, do not claim a full manual adversarial audit.

---

## Adoption note

Adopted carefully from the user-supplied GitHub skill repository on 2026-07-18. Active only where compatible with current engine law: Campaign Ask x Rally Judge Desire, Data does not write, real-verdict ratchets, and no external score guarantee.
