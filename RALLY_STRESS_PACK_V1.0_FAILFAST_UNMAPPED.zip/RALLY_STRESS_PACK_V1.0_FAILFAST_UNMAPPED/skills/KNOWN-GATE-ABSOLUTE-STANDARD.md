# KNOWN-GATE ABSOLUTE STANDARD

Status: ACTIVE - highest honest certainty standard
Purpose: define the strongest claim we can honestly make before submitting to Rally.

## Core truth

External absolute guarantee is impossible from outside Rally.

Forbidden claims:

```text
guaranteed EP5
guaranteed all-max
guaranteed winner
guaranteed top 1%
```

Allowed highest claim:

```text
Known-Gate Absolute PASS
```

## Definition

Known-Gate Absolute means:

```text
All known controllable cut surfaces found in current evidence are closed.
```

It is absolute only with respect to:

- literal campaign/mission brief;
- source post / KB truth;
- current mission-scoped Rally verdict data;
- hidden-gate mining output;
- winner-pull mining output;
- manual no-cut review;
- Irreducible Apex review;
- human-typed public copy review;
- local Python gates;
- final integrity.

It is not absolute with respect to:

- unknown future hidden gates;
- Rally internal prompt changes;
- LLM judge variance;
- competitor pool;
- account behavior;
- timing;
- engagement metrics;
- organic replies.

## Required closure map

A final content package cannot be called Known-Gate Absolute unless every category is explicitly closed.

### 1. Campaign Ask closure

- mission ID correct;
- required quote/reply/link correct;
- required handles correct;
- forbidden formats avoided;
- campaign ask answered directly;
- no wrong-mission contamination.

### 2. Source Truth closure

- source post/brief/KB truth loaded;
- no fabricated claims;
- no unsupported guarantee;
- product mechanism stated accurately;
- relationship between brands/protocols accurate.

### 3. EP known deduction closure

Must close current known EP cut surfaces:

- `cta_weak`
- `conversation_limited`
- `value_not_exceptional`
- `structure_density`
- `hook_weak`
- `specificity_missing`
- `generic_formulaic`
- `brand_promotional`
- `too_niche_or_abstract`
- `mechanism_unclear`
- `media_format_issue`
- `authenticity_polish_tax`

### 4. Winner-pull closure

Must show evidence for likely judge praise:

- hook;
- concrete scenario;
- mechanism clarity;
- value payload;
- CTA/conversation;
- human voice;
- structure/read-through;
- brand/source integration;
- distinctiveness.

### 5. Human-typed closure

- no public skill leakage;
- no label-like shells that sound generated;
- no audit voice;
- main content feels human;
- Q/A feel like real public replies.

### 6. Irreducible closure

- every line has a function;
- no obvious stronger substitution remains;
- compression/expansion checked;
- hostile judge 10-attack has no credible unresolved cuts;
- non-expert retell passes;
- expert respect passes.

### 7. Local gate closure

Required PASS:

- compliance;
- CTA;
- tactical value;
- compactness;
- loser-DNA;
- originality;
- TQ;
- OAA;
- IA;
- EP semantic content-specific;
- worst-positive;
- Q&A gates if Q&A is included;
- final integrity.

## Unknown-risk statement

Every Known-Gate Absolute report must include:

```text
Remaining risk is limited to unknown/future judge gates, judge variance, external engagement, account/timing behavior, and organic reply quality.
```

## Decision rule

If any known cut surface remains open, status is:

```text
NOT ABSOLUTE - REBUILD / REPAIR REQUIRED
```

If all known cut surfaces are closed, status is:

```text
KNOWN-GATE ABSOLUTE PASS
```
