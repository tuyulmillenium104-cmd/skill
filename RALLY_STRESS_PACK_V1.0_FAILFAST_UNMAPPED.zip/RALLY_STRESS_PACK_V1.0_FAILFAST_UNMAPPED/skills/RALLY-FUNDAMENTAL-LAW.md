# RALLY FUNDAMENTAL LAW

Status: ACTIVE - highest operating principle after the literal campaign/mission brief.

## Core law

Winning Rally content is built from two truths:

```text
Campaign Ask x Rally Judge Desire
```

A draft is not valid unless it satisfies both.

## 1. Campaign Ask

Campaign Ask means the literal mission request:

- what the campaign asks the creator to do;
- what must be quoted/replied/mentioned/linked;
- what must be explained or argued;
- what must not be said;
- required tone or style;
- source post / knowledge base truth;
- exact mission-specific constraints.

If the draft does not answer the literal campaign ask, nothing else matters.

## 2. Rally Judge Desire

Rally Judge Desire means the qualities the real Rally AI judge rewards for the current mission.

This must be learned from:

1. current mission-scoped real submissions;
2. real Rally verdicts and scores;
3. winner and near-winner praise;
4. non-winner deductions;
5. campaign-family priors only when mission data is weak.

Typical judge desires include:

- strong hook;
- original angle;
- accurate campaign understanding;
- concrete detail;
- clear mechanism;
- useful value payload;
- natural brand/source integration;
- readable structure;
- strong reply path / CTA;
- human voice;
- no generic AI-looking content.

## 3. Rally Judge Rejection

Rally Judge Rejection means the patterns the real Rally AI judge cuts for this mission.

Examples:

- wrong mission or wrong handle;
- generic hype;
- weak CTA;
- abstract explanation without concrete example;
- unclear product mechanism;
- overclaiming;
- too dense or too long;
- promotional brand bridge;
- similarity to other submissions;
- AI-looking formula;
- only explaining when the mission asks for reaction;
- only hype when the mission asks for explanation.

## 4. All other frameworks are subordinate

The following are tools, not the foundation:

- Hidden Gate Mining;
- Winner Pull Mining;
- Original Thesis Engine;
- Memetic Insight Engine;
- Irreducible Apex;
- Human-Typed Standard;
- Python checkers;
- Q&A Gold.

They exist only to help satisfy:

```text
Campaign Ask x Rally Judge Desire
```

If any framework conflicts with the literal brief or real Rally judge evidence, the framework loses.

## 5. Four-question final test

Before finalizing any content, answer:

```text
1. Does this do exactly what the campaign asks?
2. What will the Rally judge praise?
3. What could the Rally judge fairly cut?
4. Would a real reader understand and want to reply?
```

If any answer is weak, rebuild.

## 6. Final output rule

Do not call content final because it sounds good or passes tools.

Call it final only when:

```text
Campaign Ask is satisfied.
Rally Judge Desire is intentionally built in.
Rally Judge Rejection is actively defended against.
Human reader path is clear.
```

## 7. Forbidden claim

Never claim guaranteed all-max, guaranteed winner, or guaranteed top 1%.

Allowed:

```text
highest controllable local standard achieved
local strict PASS
Irreducible Apex local PASS
Rally Judge Desire aligned
```
