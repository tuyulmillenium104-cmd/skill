# Real Judge 4/5 Cap Calibration Protocol

Purpose: convert real Rally judge 4/5 feedback into universal infrastructure so future campaigns do not repeat the same controllable mistakes.

This protocol is campaign-agnostic. It applies most strongly to explain, product, protocol, launch, quote-thread, technical-builder, and agent/infrastructure campaigns.

## Real verdict lesson

A real Rally judge gave strong but capped scores:

```text
Engagement Potential: 4/5
Technical Quality: 4/5
Reply Quality: 4/5
```

The verdict praised hook, scenario, structure, CTA, and topical relevance, but capped the submission for three controllable reasons:

1. Value delivery was memorable but not saveable enough.
2. Technical execution was clean but somewhat dense, abstract, and polished/corporate.
3. Replies were relevant but some sounded formulaic or campaign-optimized.

## New universal hard gates

### 1. Saveable Utility Gate

For explain/product/protocol/launch/technical campaigns, a strong narrative is not enough.

The content must give the reader at least one reusable rule, test, checklist, decision frame, or operational criterion.

Weak:

```text
This shows why disputes need a place to go.
```

Stronger:

```text
Before release, define what proves delivery, what pauses escrow, and what evidence survives appeal.
```

Required signals:

- rule
- test
- acceptance criteria
- proof standard
- release condition
- decision rule
- source log
- checklist
- before / after condition
- what counts as done

If the post is only a story or mental model, it can still be EP4 even with a strong hook.

### 2. Anti-Corporate Polish Gate

Clean writing is not enough for TQ 5/5 if the voice sounds like campaign copy.

Risk phrases include:

```text
missing layer
agent stack
agentic economy
proof bundle
validator process
shared trust layer
open trust layer
unlock
infrastructure
ecosystem
```

These are not banned. They become risky when clustered without concrete nouns, lived texture, or simple human phrasing.

Counterweights:

- specific object
- specific failure
- specific log/file/test
- named condition
- plain-language sentence
- less polished sentence that sounds typed by a person

Required rule:

```text
Every abstract mechanism phrase must be paid for by a concrete detail or practical rule.
```

### 3. Human Reply Variance Gate

Q&A/replies must not sound like one optimizer wearing 20 masks.

Risk shells:

```text
My concern is...
My answer is...
I would choose...
The risk is...
The line...
The phrase...
works because...
After I tried mapping...
```

These are allowed sparingly, but overuse creates RQ4 risk.

Hard limits for a 20-row public Q&A pack:

```text
"My concern is" <= 3
"My answer is" <= 3
quote-framing rows <= 4
"works because" <= 2
same A opening shell <= 3
label-like public openers = 0
```

Q&A must include varied public voice:

- casual replies,
- specific objections,
- applied examples,
- shorter direct replies,
- practical decisions,
- a few messy/human phrasings,
- not only rubric-friendly phrasing.

## Required workflow insertion

Add after EP rubric and before final packaging:

```text
Real Judge 4/5 Cap Kill Gate
```

It must answer:

```text
Could a real judge praise this and still write 4/5 because it is not saveable enough?
Could a real judge praise this and still write 4/5 because it is polished/corporate/dense?
Could a real judge praise the replies and still write 4/5 because they sound patterned?
```

If yes, rebuild or rewrite. Do not only patch wording.

## Required checker

Use:

```bash
python3 /home/user/konten/ACTIVE_ARCHITECTURE/tools/rally_real_judge_4cap_check.py \
  --content content.txt \
  --qna content_and_qna_final.md \
  --campaign-type explain \
  --out-json reports/real-judge-4cap.json \
  --out-md reports/REAL-JUDGE-4CAP.md
```

This checker is not a scoring guarantee. It blocks known 4/5 cap surfaces discovered from real Rally verdicts.

---

## Adoption note

Adopted carefully from the user-supplied GitHub skill repository on 2026-07-18. Active only where compatible with current engine law: Campaign Ask x Rally Judge Desire, Data does not write, real-verdict ratchets, and no external score guarantee.
