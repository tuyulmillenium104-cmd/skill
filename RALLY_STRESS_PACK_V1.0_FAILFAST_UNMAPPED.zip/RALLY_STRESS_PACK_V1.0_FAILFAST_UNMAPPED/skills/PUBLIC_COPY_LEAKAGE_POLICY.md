# Public Copy Privacy Rule - Prompt Mode

Status: ACTIVE addendum for Gold V3 Q/A generation.

## One prompt rule

```text
PUBLIC-COPY PRIVACY RULE:
Q-COPY and A-COPY must read as public replies from real people.
Do not include language that reveals our private skill files, checker workflow, audit process, internal metadata, or generation scaffolding.
Official Rally/campaign/community terms are allowed when they are natural in context.
If unsure, ask: would a normal Rally participant write this publicly without seeing our skill files? If no, rewrite it into plain public language.
```

## Operating note

Do not maintain a broad forbidden vocabulary for normal Rally, campaign, marketing, or creator language. Keep leakage control lightweight.

A tiny exact-match guardrail may catch obvious private scaffolding examples such as `5-gram`, `loser DNA`, `self-judge`, `qa_ranking`, `voicePersona`, or `SIMULATED_ARCHETYPE`, but the real rule is the prompt above, not a long blacklist.

Everything else is a writing/naturalness decision, not a hard leakage ban.
