# HUMAN-TYPED PUBLIC COPY STANDARD

Status: ACTIVE
Purpose: ensure final content, Q-COPY, and A-COPY read like public posts/replies written by real people, not like audit output, generated templates, or skill-compliance prose.

## Core law

Public copy must sound like something a real participant could type without seeing our skill files.

```text
Human public copy > perfect rubric prose.
```

This applies to:

- main content;
- Q-COPY;
- A-COPY;
- public-only exports.

It does not apply to internal reports, headings, ranking metadata, or audit files.

## Hard distinction

### Internal language

Belongs only in skill/checker/audit files:

- checker names;
- audit labels;
- metadata labels;
- scoring workflow;
- `qa_ranking`;
- `voicePersona`;
- `SIMULATED_ARCHETYPE`;
- `CONDITIONAL_ORGANIC_MATCH_ONLY`;
- private skill terms.

### Public language

Must sound like a normal public post or reply:

- direct observation;
- personal reaction;
- concrete example;
- natural doubt;
- practical question;
- lived experience;
- plain-language mechanism.

## Style rules

## 1. Avoid repeated labels

Label-colon shells such as `My concern:`, `My answer:`, `Hot take:`, and `Wrong lesson:` are especially likely to sound generated. Prefer natural sentence forms.

Do not overuse label-like openings:

```text
My concern is...
My answer is...
My decision is...
Hot take:
Wrong lesson:
The risk is...
```

These are allowed occasionally, but repeated use makes copy feel generated.

Rule of thumb:

- In a 20-Q pack, no single label shell should dominate.
- If 3 adjacent Qs or As feel like the same skeleton, rewrite.

## 2. Prefer natural reply shapes

Human replies often sound like:

```text
This is the part I don't buy yet...
Wait, who owns the updated note?
The analogy works, but...
Feels like the case file has to exist before the dispute.
I keep coming back to the same thing...
That line is doing more work than the product pitch.
```

Use these kinds of shapes instead of always using rubric language.

## 3. Keep one human intent per reply

Every Q-COPY should clearly be one of these:

- a real doubt;
- a specific question;
- a personal example;
- a challenge;
- a technical concern;
- a concrete extension;
- a useful alternative framing.

If the Q only exists to satisfy a category, rewrite.

## 4. Avoid audit voice in public copy

Public copy should not sound like:

```text
mechanism clarity is insufficient
CTA alignment is weak
this row needs stronger decision-marker coverage
semantic saturation risk
```

Translate to public language:

```text
I still don't see who owns the updated pickup note.
The question is easy to admire but hard to answer.
This sounds like a support ticket unless the case starts before the dispute.
```

## 5. Imperfect rhythm is okay

Do not make every sentence the same length.
Do not make every Q the same shape.
Do not over-polish every line.

Human copy can be:

- short;
- blunt;
- slightly conversational;
- specific;
- uneven in rhythm.

But it must remain clear and campaign-safe.

## 6. Preserve truth and precision

Human style does not mean sloppy claims.

Never trade accuracy for casual voice.
If a casual phrase overclaims, rewrite it.

## Manual human-typed test

Before finalizing, ask:

```text
Would a real person write this publicly without knowing our skill?
Can I imagine a specific person typing this?
Does it sound like a comment, not a rubric?
Does it add a real thought, not just satisfy a category?
```

If any answer is no, rewrite.

## Q&A pack additional checks

For 20-pair Q&A packs:

- Avoid repeated Q shells.
- Avoid repeated A openings.
- Use direct questions, statements, mini-stories, and concise challenges.
- Keep metadata out of Q/A bodies.
- Keep simulated Real Experience labels outside public copy.
- Let some answers close as statements if natural.

## Relationship to Gold V3

This standard complements Gold V3. If a line passes mechanical gates but fails human-typed review, rewrite it.

## Relationship to Irreducible Apex

Irreducible Apex content must also pass this human-typed standard.

A line can be functional and still too engineered. If it feels engineered, rewrite without losing function.
