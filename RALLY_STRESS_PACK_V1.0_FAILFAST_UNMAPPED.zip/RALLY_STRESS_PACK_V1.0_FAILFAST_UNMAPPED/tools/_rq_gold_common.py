#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, json, math, re, statistics, sys, time
from collections import Counter, defaultdict
from pathlib import Path

TYPE_NAMES = ["Specific Probe", "Challenge", "Technical Deep-Dive", "Hot Take", "Real Experience"]
EXPECTED_TYPES = {"Specific Probe":4, "Challenge":5, "Technical Deep-Dive":5, "Hot Take":4, "Real Experience":2}
DECISION_MARKERS = ['i would','my decision','i choose','i would choose','i would rather','i trust','i would pick','i like','my concern','my answer']
DECISION_WORDS = ['decision','decide','decided','forced','cut','stop','start','choose','chose','remove','protect','rewrite','change','cancel','publish','share','make','pick','trust','switch','wait','avoid','risk','use','try']
FIRST_PERSON_RE = re.compile(r"\b(i|me|my|mine|we|our|ours|i'm|i've|i'd|i’ll|i'll|we're|we've)\b", re.I)
CONTRACTIONS_RE = re.compile(r"\b(\w+'\w+|can't|won't|don't|doesn't|didn't|isn't|aren't|wasn't|weren't|i'm|i've|i'd|i'll|you're|that's|there's|it's)\b", re.I)
ANECDOTE_RE = re.compile(r"\b(i tried|i used|i saw|i had|i learned|last year|last month|last cycle|when i|after i|my team|my wallet|my first|we tried|we used|worked on|shipped|lost|joined|minted|staked|held)\b", re.I)
SKEPTIC_RE = re.compile(r"\b(my concern|concern|doubt|risk|skeptic|skeptical|worry|worried|but what|what happens|edge case|trade[- ]off|attack|failure|breaks|unclear|trust issue|not convinced)\b", re.I)
MECHANIC_RE = re.compile(r"\b(stake|staking|mint|leaderboard|ranking|rank|score|points|reward|rewards|yield|protocol|contract|wallet|custody|claim|airdrop|token|nft|eligibility|campaign|mission|reply|cta|mechanism|daily|epoch|allocation|supply|telegram|agent|bot|dashboard|context|notes?|brief|draft|filter|rally|judge|ask|story|breakdown|prompt|interface|workflow|handoff|escrow|verification|dispute|appeal|proof|evidence|delivery|release|verdict|case|receipt|source|log|itinerary|identity|negotiation|obligation|payment|funds|refund|internetcourt|genlayer)\b", re.I)
GENERIC_FAQ_RE = re.compile(r"^\s*(what is|how does .{0,40} work\??$|can you explain|tell me more|thoughts\??$|what do you think\??$|is this good\??$|have you used)\b", re.I)
JOURNALIST_RE = re.compile(r"\b(could you elaborate|can you elaborate|as a founder|what inspired|what are your thoughts|would you say|how would you describe|interview)\b", re.I)
FORMAL_RE = re.compile(r"\b(utilize|therefore|furthermore|moreover|consequently|paradigm|framework|holistic|synergy|leverage|aforementioned|optimize|methodology|implementation|stakeholder|robust|scalable|ecosystem)\b", re.I)
PUBLIC_COPY_PRIVACY_RULE = """Q-COPY and A-COPY must read as public replies from real people.
Do not include language that reveals private skill files, checker workflow, audit process,
internal metadata, or generation scaffolding. Official Rally/campaign/community terms are
allowed when natural in context. If unsure, ask: would a normal Rally participant write
this publicly without seeing our skill files? If no, rewrite it into plain public language.
"""
# Tiny exact-example guardrail only. Do not expand into a broad ban list for official
# Rally/campaign terms; use the privacy rule above plus naturalness review.
METADATA_RE = re.compile(r"\b(SIMULATED_ARCHETYPE|CONDITIONAL_ORGANIC_MATCH_ONLY|voicePersona|voiceMode|EVIDENCE_PERSONA_|EVIDENCE_VOICE_|5[- ]gram|loser[- ]DNA|Gold\s*V3|qa_ranking|self[- ]judge|meta[- ]judge|self[- ]validated)\b", re.I)
LOW_EFFORT_RE = re.compile(r"\b(agree|gm|nice|great post|love this|this hits|so true|based|wagmi|lfg)\b", re.I)


def read(path):
    return Path(path).read_text(encoding='utf-8', errors='ignore')


def extract_main_content(combined):
    m = re.search(r"##\s*MAIN CONTENT\s*```text\n(.*?)\n```", combined, re.S|re.I)
    return m.group(1).strip() if m else ''


def normalize_type(s):
    sl = (s or '').lower().replace('_',' ').replace('-',' ')
    if 'specific' in sl and 'probe' in sl: return 'Specific Probe'
    if 'technical' in sl or 'deep dive' in sl: return 'Technical Deep-Dive'
    if 'hot' in sl and 'take' in sl: return 'Hot Take'
    if 'real' in sl and 'experience' in sl: return 'Real Experience'
    if 'challenge' in sl or 'skeptic' in sl: return 'Challenge'
    return None


def parse_pairs(text):
    pat = re.compile(r"(?P<head>^#{2,4}[^\n]*?)\n\s*\*\*Q-COPY\*\*\s*```text\n(?P<q>.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(?P<a>.*?)\n```", re.S|re.M)
    rows=[]
    for i,m in enumerate(pat.finditer(text),1):
        head=m.group('head').strip()
        explicit=None
        for name in TYPE_NAMES:
            if name.lower() in head.lower(): explicit=name
        rows.append({'idx':i,'heading':head,'type':explicit,'q':m.group('q').strip(),'a':m.group('a').strip()})
    if not rows:
        # fallback old parser without heading
        for i,(q,a) in enumerate(re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```", text, flags=re.S),1):
            rows.append({'idx':i,'heading':'','type':None,'q':q.strip(),'a':a.strip()})
    return rows


def load_ranking(path):
    data=json.load(open(path,encoding='utf-8'))
    if isinstance(data, list): rows=data
    elif isinstance(data, dict): rows=data.get('rows') or data.get('ranking') or data.get('items') or []
    else: rows=[]
    by_idx={}
    for i,r in enumerate(rows,1):
        try: idx=int(r.get('idx') or r.get('row') or r.get('rank') or i)
        except Exception: idx=i
        by_idx[idx]=r
    return data, rows, by_idx


def q_words(q):
    return re.findall(r"[A-Za-z0-9']+", q.lower())


def first_word(q):
    w=q_words(q); return w[0] if w else ''


def first_two(q):
    w=q_words(q); return ' '.join(w[:2]) if len(w)>=2 else (w[0] if w else '')


def sentence_count(t):
    parts=[p for p in re.split(r"[.!?]+", t.strip()) if p.strip()]
    return max(1,len(parts)) if t.strip() else 0


def has_decision_marker(q):
    ql=q.lower()
    return any(m in ql for m in DECISION_MARKERS)


def has_decision_word(t):
    tl=t.lower()
    return any(re.search(r"\b"+re.escape(w)+r"\b", tl) for w in DECISION_WORDS)


def cta_terms(content):
    tail=' '.join([p.strip() for p in re.split(r"\n\s*\n+", content.strip()) if p.strip()][-3:]).lower()
    candidates = set(re.findall(r"\b(reply|comment|tell|choose|pick|share|mint|stake|join|claim|vote|rank|follow|post|build|try|use|compare|name|show|visit|learn|apply|answer|drop)\b", tail))
    # Add important repeated nouns from tail
    words=[w for w in re.findall(r"\b[a-z][a-z0-9-]{3,}\b", tail) if w not in {'that','this','with','from','your','what','when','where','will','have','they','them','about','into','more'}]
    for w,c in Counter(words).most_common(8): candidates.add(w)
    return candidates


def cta_aligned(q, content):
    terms=cta_terms(content)
    ql=q.lower()
    if not terms:
        return bool(MECHANIC_RE.search(q) or '?' in q)
    return any(re.search(r"\b"+re.escape(t)+r"\b", ql) for t in terms)


def quoted_fragments(q):
    return [x.strip() for x in re.findall(r"[\"'`](.{3,80}?)[\"'`]", q)]


def exact_quote_from_content(q, content):
    frags=quoted_fragments(q)
    cl=content.lower()
    return bool(frags) and any(f.lower() in cl for f in frags)


def infer_type(row):
    if row.get('type'): return row['type']
    h=row.get('heading','')
    typ=normalize_type(h)
    if typ: return typ
    q=row['q']
    if exact_quote_from_content(q, ''): return 'Specific Probe'
    if SKEPTIC_RE.search(q): return 'Challenge'
    if MECHANIC_RE.search(q) and '?' in q: return 'Technical Deep-Dive'
    if ANECDOTE_RE.search(q): return 'Real Experience'
    return None


def pct(n,d): return n/max(1,d)


def cv(vals):
    if not vals: return 0.0
    mean=sum(vals)/len(vals)
    return statistics.pstdev(vals)/mean if mean else 0.0


def write_report(out_json,out_md,result,title):
    Path(out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[f'# {title}\n\n', f"Decision: **{result['decision']}**\n\n"]
    for k,v in result.get('summary',{}).items():
        md.append(f'- {k}: {v}\n')
    md.append('\n## Reasons\n')
    md += [f"- {r}\n" for r in result.get('reasons',[])] or ['- clear\n']
    if result.get('failures'):
        md.append('\n## Failures\n')
        for f in result['failures'][:80]:
            md.append(f"- {f}\n")
    Path(out_md).write_text(''.join(md),encoding='utf-8')
