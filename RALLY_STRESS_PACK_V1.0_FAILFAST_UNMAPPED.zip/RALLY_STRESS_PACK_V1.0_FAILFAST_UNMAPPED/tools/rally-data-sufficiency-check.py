#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rally data sufficiency checker.

Determines how much to trust mission-specific winner/loser mining before drafting.
"""
import argparse, json, time, sys
from pathlib import Path
from collections import Counter


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--submissions', required=True)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    subs=json.load(open(args.submissions, encoding='utf-8'))
    total=len(subs)
    winners=[s for s in subs if s.get('winner')]
    nonw=[s for s in subs if not s.get('winner')]
    sources=Counter(s.get('contentSource') or 'missing' for s in subs)
    full=sum(1 for s in subs if (s.get('content') or '').strip() and (s.get('contentSource') or '') not in ['judge-quote-fragments','analysis-fragment'])
    content_any=sum(1 for s in subs if (s.get('content') or '').strip())
    coverage=content_any/max(1,total)
    full_cov=full/max(1,total)
    winner_count=len(winners)
    # Conservative mode thresholds
    if total>=80 and winner_count>=5 and coverage>=0.90:
        mode='HIGH_DATA'
        strategy='Mission-specific hidden gates and winner-pull are reliable anchors. Still avoid overfitting winner surface.'
    elif total>=40 and winner_count>=3 and coverage>=0.75:
        mode='MEDIUM_DATA'
        strategy='Use mission data strongly, but validate with campaign-family priors and manual no-cut review.'
    elif total>=15 and winner_count>=1:
        mode='LOW_DATA'
        strategy='Brief-first. Use mission data as watch signals only. Do not create hard mission-specific rules from sparse patterns.'
    else:
        mode='ZERO_OR_INSUFFICIENT_DATA'
        strategy='Brief-first + campaign-family/global priors. Do not rely on winner/loser mining.'
    reasons=[]
    if total<40: reasons.append(f'submissions {total} < 40')
    if winner_count<3: reasons.append(f'winners {winner_count} < 3')
    if coverage<0.75: reasons.append(f'content coverage {coverage:.0%} < 75%')
    result={'tool':'rally-data-sufficiency-check.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'totalSubmissions':total,'winnerCount':winner_count,'nonWinnerCount':len(nonw),'contentCoverage':round(coverage,3),'fullContentCoverage':round(full_cov,3),'contentSources':dict(sources),'mode':mode,'strategy':strategy,'reasons':reasons,'decision':'PASS'}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# DATA SUFFICIENCY CHECK\n\n',f'Decision: **PASS**\n\n',f'Mode: **{mode}**\n\n',f'- Submissions: {total}\n- Winners: {winner_count}\n- Non-winners: {len(nonw)}\n- Content coverage: {coverage:.1%}\n- Full content coverage: {full_cov:.1%}\n- Sources: {dict(sources)}\n\n', '## Strategy\n\n', strategy+'\n\n', '## Reasons / limitations\n']
    md += [f'- {r}\n' for r in reasons] or ['- sufficient for selected mode\n']
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'DATA SUFFICIENCY CHECK: {mode} [subs={total}, winners={winner_count}, coverage={coverage:.0%}]')

if __name__=='__main__': main()
