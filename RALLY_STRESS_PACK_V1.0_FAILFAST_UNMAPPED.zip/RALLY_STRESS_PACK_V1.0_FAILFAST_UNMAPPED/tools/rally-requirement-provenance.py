#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Requirement provenance and literal constraint extraction (V7.8.8)."""
import argparse,json,re,time
from pathlib import Path
from rally_common import sha256_file

def lines(t):return [x.strip(' -*\t') for x in re.split(r'\n+',t or '') if x.strip(' -*\t')]
def extract_max(text):
 pats=[r"\b(?:max(?:imum)?|no more than|up to|under)\s*(\d+)\s*(?:characters?|chars?)\b",r"\b(\d+)\s*(?:characters?|chars?)\s*(?:or fewer|or less|maximum|max)\b"]
 vals=[]
 for p in pats:vals += [int(x) for x in re.findall(p,text,re.I)]
 return min(vals) if vals else None
def extract_relation(text):
 raw_lines=[x.strip() for x in re.split(r'\n+',text or '') if x.strip()]
 allowed=[];required=False;urls=[]
 for i,line in enumerate(raw_lines):
  ll=line.lower();line_allowed=[]
  if re.search(r"\bmust\s+quote\s+or\s+reply|\bquote\s+or\s+reply\s+to\b",ll):line_allowed=['quote','reply']
  elif re.search(r"\bmust\s+quote|\bquote\s+this\b",ll):line_allowed=['quote']
  elif re.search(r"\bmust\s+reply|\breply\s+to\s+this\b",ll):line_allowed=['reply']
  if line_allowed:
   required=True
   for x in line_allowed:
    if x not in allowed:allowed.append(x)
   line_urls=[u.rstrip('.,;') for u in re.findall(r"https?://[^\s)\]]+",line)]
   if not line_urls and i+1<len(raw_lines):
    line_urls=[u.rstrip('.,;') for u in re.findall(r"https?://[^\s)\]]+",raw_lines[i+1])]
   urls.extend(line_urls)
 return {'required':required,'allowedTypes':allowed,'sourceUrls':sorted(set(urls))}

def extract_surface_policy(text):
 required_hashtags=[];forbid_hashtags=False
 for line in lines(text):
  tags=re.findall(r"#[A-Za-z0-9_]+",line)
  ll=line.lower()
  if tags and re.search(r"\b(must|required|include|use)\b",ll) and not re.search(r"\b(do not|don't|must not|forbid|not allowed)\b",ll):
   required_hashtags.extend(tags)
  if re.search(r"\b(no hashtags?|hashtags? (?:are )?not allowed|do not use hashtags?|don't use hashtags?|must not use hashtags?)\b",ll):
   forbid_hashtags=True
 forbid_start=bool(re.search(r"\bdo not start (?:the )?post with (?:a )?mention or hashtag|\bmust not start .*?(?:mention|hashtag)",text,re.I))
 forbidden=[]
 if re.search(r"\bem dashes?\s*(?:\([^)]*—[^)]*\))?\s*(?:are|is)?\s*not allowed|\bno em dashes?\b|\bdo not use em dashes?\b",text,re.I):
  forbidden.append('—')
 if re.search(r"\ben dashes?\s*(?:\([^)]*–[^)]*\))?\s*(?:are|is)?\s*not allowed|\bno en dashes?\b|\bdo not use en dashes?\b",text,re.I):
  forbidden.append('–')
 ascii_only=bool(re.search(r"\bascii(?:-only| only)\b|\buse only ascii\b",text,re.I))
 smart_quotes_forbidden=ascii_only or bool(re.search(r"\bno smart quotes?\b|\bsmart quotes? (?:are )?not allowed\b",text,re.I))
 return {
  'requiredHashtags':sorted(set(required_hashtags)),
  'forbidHashtags':forbid_hashtags,
  'forbidStartMentionOrHashtag':forbid_start,
  'forbiddenPunctuation':sorted(set(forbidden)),
  'asciiOnly':ascii_only,
  'forbidSmartQuotes':smart_quotes_forbidden,
 }
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--campaign',required=True);ap.add_argument('--mission',required=True);ap.add_argument('--out-json',required=True);ap.add_argument('--out-md',required=True);ap.add_argument('--soft-target-min',type=int,default=600);ap.add_argument('--soft-target-max',type=int,default=850);args=ap.parse_args()
 c=json.load(open(args.campaign,encoding='utf-8'));m=next((x for x in c.get('missions',[]) if x.get('id')==args.mission),{});rows=[]
 mission_rules=m.get('rules') or '';campaign_rules=c.get('rules') or ''
 for x in lines(mission_rules):rows.append({'source':'MISSION_HARD','text':x})
 for x in lines(campaign_rules):
  if x and x!='.':rows.append({'source':'CAMPAIGN_HARD','text':x})
 for x in lines(c.get('goal')):rows.append({'source':'CAMPAIGN_GOAL','text':x})
 desc=m.get('description') or '';parts=re.split(r'(?i)\*\*proposed angles?:\*\*',desc,maxsplit=1)
 if parts and parts[0].strip():rows.append({'source':'MISSION_CORE','text':parts[0].strip()})
 if len(parts)>1:
  for x in lines(parts[1]):rows.append({'source':'OPTIONAL_ANGLE','text':x})
 rows += [{'source':'ENGINE_SOFT_TARGET','text':f'Tactical length target {args.soft_target_min}-{args.soft_target_max} chars; not an official campaign maximum.'},{'source':'WINNER_DNA_SIGNAL','text':'Winner length, opener, Portal, voice, and paragraph prevalence are conditional evidence, not hard law.'},{'source':'JUDGE_RISK_PRIOR','text':'Real-verdict deductions inform review pressure but do not override the literal mission.'}]
 hard_text=mission_rules+'\n'+campaign_rules
 mention_text=''
 core_text=(parts[0] if parts else '')
 for line in lines(hard_text+'\n'+core_text):
  if re.search(r"\b(must|required|have to)\b.*\b(mention|tag|include)\b.*@[A-Za-z0-9_]+|\b(mention|tag)\b.*@[A-Za-z0-9_]+.*\b(must|required)\b",line,re.I):
   mention_text+='\n'+line
 mentions=re.findall(r"@[A-Za-z0-9_]+",mention_text)
 # Compatibility patch 2026-07-18: Rally briefs often state `Your X post must include:`
 # and place the required handle/link/screenshot on following bullet lines. Treat
 # public handles inside hard rules as required unless contradicted elsewhere.
 if not mentions and re.search(r"\b(?:must|required|should)\b[^\n]{0,80}\binclude\b|your x post must include", hard_text, re.I):
  mentions=re.findall(r"@[A-Za-z0-9_]+", hard_text)
 official=extract_max(hard_text);one_sentence=bool(re.search(r"\b(one|single)\s+sentence\b",hard_text,re.I));relation=extract_relation(mission_rules+'\n'+desc)
 media_required=bool(re.search(r"\bmust\s+(?:include|attach|use)\s+(?:an?\s+)?(?:image|photo|video|media|screenshot)\b|\btake\s+a\s+screenshot\b|\bpost\s+(?:a\s+)?screenshot\b",mission_rules+'\n'+campaign_rules+'\n'+desc,re.I));surface=extract_surface_policy(hard_text)
 result={'tool':'rally-requirement-provenance.py v7.9.6','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'campaignSha256':sha256_file(args.campaign),'campaign':c.get('title'),'mission':args.mission,'missionTitle':m.get('title'),'requiredMentions':sorted(set(mentions)),'requirements':rows,'officialMaxChars':official,'officialOneSentence':one_sentence,'requiredRelation':relation,'mediaRequired':media_required,**surface,'engineSoftTarget':[args.soft_target_min,args.soft_target_max]}
 Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 md=['# REQUIREMENT PROVENANCE\n\n',f"Campaign: **{c.get('title')}**  \nMission: **{args.mission} - {m.get('title')}**\n\n",f"- Official max chars: {official}\n- Official one sentence: {one_sentence}\n- Required relation: {relation}\n- Required media: {media_required}\n- Required hashtags: {surface['requiredHashtags']}\n- Forbid hashtags: {surface['forbidHashtags']}\n- Forbid start mention/hashtag: {surface['forbidStartMentionOrHashtag']}\n- Forbidden punctuation: {surface['forbiddenPunctuation']}\n- ASCII only: {surface['asciiOnly']}\n\n"]
 for src in ['MISSION_HARD','CAMPAIGN_HARD','MISSION_CORE','CAMPAIGN_GOAL','OPTIONAL_ANGLE','ENGINE_SOFT_TARGET','WINNER_DNA_SIGNAL','JUDGE_RISK_PRIOR']:
  md.append(f'## {src}\n');rr=[r for r in rows if r['source']==src];md += [f'- {r["text"]}\n' for r in rr] or ['- none\n'];md.append('\n')
 Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f'REQUIREMENT PROVENANCE: rows={len(rows)}, officialMax={official}, relation={relation}')
if __name__=='__main__':main()
