#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Winner Pull Miner.

Mines positive judge language and content mechanisms from winner / near-winner
Rally submissions. This is offensive evidence: what makes a judge praise a post.
It complements hidden-gate mining, which is defensive evidence.
"""
import argparse, json, re, pathlib, collections, statistics

CAT_TO_GATE = {
    'Originality and Authenticity': 'OAA',
    'Content Alignment': 'CA',
    'Information Accuracy': 'IA',
    'Campaign Compliance': 'CC',
    'Engagement Potential': 'EP',
    'Technical Quality': 'TQ',
    'Reply Quality': 'RQ',
}

POSITIVE_CUES = re.compile(r"\b(strong|effective|excellent|compelling|clear|specific|concrete|original|authentic|fresh|unique|distinct|engaging|valuable|useful|memorable|relatable|natural|well[- ]structured|high[- ]quality|successfully|resonates|drives|invites|adds|provides|demonstrates|stands out|aligns|avoids|credible|thoughtful|punchy)\b", re.I)
NEGATIVE_CUES = re.compile(r"\b(however|but|although|minor|weak|lacks?|limited|could|would benefit|somewhat|not fully|less|deduction|risk|issue|drawback|generic|dense|too long|implicit)\b", re.I)

POS_CLASSES = [
    ('hook_magnet', r'\b(hook|opening|first line|attention|curiosity|grab|stopped|clicked|compelling|punchy|intrigue)\b'),
    ('fresh_frame', r'\b(original|fresh|unique|distinct|novel|reframing|angle|perspective|metaphor|analogy|frame)\b'),
    ('concrete_scenario', r'\b(concrete|specific|scenario|example|case|receipt|proof|itinerary|claim|lab|job|delivery|file|real[- ]world|relatable)\b'),
    ('mechanism_clarity', r'\b(mechanism|how|works|explains|interface|pipeline|workflow|stack|protocol|layer|connects|process|flow|adjudication)\b'),
    ('value_payload', r'\b(value|takeaway|useful|educat|mental model|rule|test|checklist|insight|explains why|reason to save|bookmark)\b'),
    ('conversation_trigger', r'\b(cta|question|reply|conversation|discussion|engagement|invites|prompt|respond|debate)\b'),
    ('human_voice', r'\b(authentic|natural|personal|voice|genuine|conversational|not generic|not ai|non-generic|human)\b'),
    ('brand_integration', r'\b(mention|brand|campaign|align|alignment|integrates|@|quoted|launch|thread)\b'),
    ('structure_pacing', r'\b(structure|pacing|line breaks|readable|scannable|paragraph|flow|digestible|clear progression)\b'),
    ('technical_accuracy', r'\b(accurate|accuracy|knowledge base|technical|factual|correctly|claim|context)\b'),
    ('shareable_line', r'\b(memorable|quotable|share|shareable|punchy|line|phrase|stands out)\b'),
]

STOP=set('the a an and or but to of in on for with is are was were be been being it this that as at by from you your i my me we they them if not just more most no one do does did into about how why what when where who'.split())

def toks(text):
    return [x for x in re.findall(r"[a-z0-9@']+", (text or '').lower()) if len(x)>2 and x not in STOP]

def ngrams(ts,n): return [' '.join(ts[i:i+n]) for i in range(len(ts)-n+1)]

def sent_split(text):
    return [p.strip() for p in re.split(r'(?<=[.!?])\s+|\n+', (text or '').strip()) if len(p.strip())>20]

def paras(text): return [p.strip() for p in re.split(r"\n\s*\n+", text or '') if p.strip()]

def classify(s):
    hits=[]
    for name,pat in POS_CLASSES:
        if re.search(pat,s,re.I): hits.append(name)
    return hits or ['positive_general']

def score_float(item):
    try:
        return int(item.get('atto_score','0'))/1e18, int(item.get('atto_max_score','0'))/1e18
    except Exception:
        return None,None

def gate_score(sub, gate):
    g=sub.get('gates') or {}
    if gate in g and isinstance(g[gate],list) and g[gate]: return float(g[gate][0])
    return None

def opener_type(text):
    first=(paras(text)[0] if paras(text) else text or '').lower()
    if '?' in first: return 'question_hook'
    if re.search(r"\b(i|i'm|i've|my|last month|last year|when i|i would)\b", first): return 'personal_confession'
    if re.search(r"\b(not|nobody|everyone|the first|the word|the detail|what hit|what sold|picture|imagine)\b", first): return 'tension_declarative'
    if re.search(r"\b(when|if|before|after)\b", first): return 'scenario_hook'
    return 'declarative'

def extract_positive_rows(subs):
    rows=[]
    for sub in subs:
        winner=bool(sub.get('winner'))
        allmax=bool(sub.get('allMax'))
        # near winner: EP5+OAA2 even if not winner, or norm high
        gates=sub.get('gates') or {}
        ep=(gates.get('EP') or [0])[0] if isinstance(gates.get('EP'),list) else 0
        oaa=(gates.get('OAA') or [0])[0] if isinstance(gates.get('OAA'),list) else 0
        near=winner or (ep>=5 and oaa>=2)
        if not near: continue
        for item in sub.get('analysis') or []:
            gate=CAT_TO_GATE.get(item.get('category'),item.get('category'))
            sc,mx=score_float(item)
            txt=item.get('analysis') or ''
            for sent in sent_split(txt):
                if POSITIVE_CUES.search(sent) and not NEGATIVE_CUES.search(sent):
                    rows.append({
                        'author':sub.get('xUsername'), 'winner':winner, 'allMax':allmax,
                        'nearWinner':near, 'gate':gate, 'score':sc, 'max':mx, 'gateScore':gate_score(sub,gate),
                        'sentence':sent, 'classes':classify(sent), 'contentStart':(sub.get('content') or '')[:260]
                    })
    return rows

def content_mechanisms(subs):
    winners=[s for s in subs if s.get('winner')]
    near=[]
    for s in subs:
        g=s.get('gates') or {}; ep=(g.get('EP') or [0])[0] if isinstance(g.get('EP'),list) else 0; oaa=(g.get('OAA') or [0])[0] if isinstance(g.get('OAA'),list) else 0
        if s.get('winner') or (ep>=5 and oaa>=2): near.append(s)
    sample=near or winners
    openers=collections.Counter(opener_type(s.get('content') or '') for s in sample)
    lens=[len(s.get('content') or '') for s in sample]
    pcounts=[len(paras(s.get('content') or '')) for s in sample]
    tails=[(paras(s.get('content') or '')[-1] if paras(s.get('content') or '') else '') for s in sample]
    # common ngrams in winners/near winners
    tri=collections.Counter(); four=collections.Counter()
    for s in sample:
        ts=toks(s.get('content') or '')
        tri.update(ngrams(ts,3)); four.update(ngrams(ts,4))
    return {
        'sampleCount':len(sample), 'winnerCount':len(winners),
        'openerTypes':dict(openers),
        'medianChars':statistics.median(lens) if lens else 0,
        'medianParagraphs':statistics.median(pcounts) if pcounts else 0,
        'ctaTails':tails[:20],
        'topWinnerTrigrams':tri.most_common(20),
        'topWinnerFourgrams':four.most_common(20),
        'samples':[{'author':s.get('xUsername'),'winner':bool(s.get('winner')),'gates':s.get('gates'),'content':(s.get('content') or '')[:1200]} for s in sample[:20]]
    }

def write_reports(subs, rows, mechanisms, out, mission):
    out=pathlib.Path(out); out.mkdir(parents=True, exist_ok=True)
    class_counts=collections.Counter(); gate_class=collections.Counter(); examples=collections.defaultdict(list)
    for r in rows:
        for cl in r['classes']:
            class_counts[cl]+=1; gate_class[(r['gate'],cl)]+=1
            if len(examples[(r['gate'],cl)])<8: examples[(r['gate'],cl)].append(r)
    data={'mission':mission,'submissionCount':len(subs),'winnerPullRows':rows,'classCounts':dict(class_counts),'gateClassCounts':{f'{g}::{c}':n for (g,c),n in gate_class.items()},'mechanisms':mechanisms}
    (out/'winner-pull-map.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append(f'# Winner Pull Map - {mission}\n\n')
    md.append(f'- Submissions: {len(subs)}\n- Winner/near-winner positive rows: {len(rows)}\n- Winner samples: {mechanisms.get("winnerCount")}\n- Winner/near-winner samples used: {mechanisms.get("sampleCount")}\n\n')
    md.append('## Positive pull classes\n\n')
    md.append('| Class | Count |\n|---|---:|\n')
    for cl,n in class_counts.most_common(20): md.append(f'| {cl} | {n} |\n')
    md.append('\n## Gate x positive class\n\n')
    for (gate,cl),n in gate_class.most_common(40): md.append(f'- **{gate} / {cl}**: {n}\n')
    md.append('\n## Winner / near-winner content mechanisms\n\n')
    md.append(f'- Opener types: {mechanisms.get("openerTypes")}\n')
    md.append(f'- Median chars: {mechanisms.get("medianChars")}\n')
    md.append(f'- Median paragraphs: {mechanisms.get("medianParagraphs")}\n')
    md.append('\n### CTA tails / endings\n')
    for t in mechanisms.get('ctaTails',[])[:12]: md.append(f'- `{t[:220]}`\n')
    md.append('\n### Top winner/near-winner trigrams to understand, not blindly copy\n')
    for ph,c in mechanisms.get('topWinnerTrigrams',[])[:15]: md.append(f'- {ph}: {c}\n')
    md.append('\n## Positive evidence examples\n')
    for (gate,cl),exs in sorted(examples.items(), key=lambda kv:(kv[0][0],kv[0][1])):
        md.append(f'\n### {gate} / {cl}\n')
        for e in exs[:5]:
            flag='WIN' if e['winner'] else 'NEAR'
            md.append(f'- @{e["author"]} [{flag}, gateScore={e.get("gateScore")}]: {e["sentence"]}\n')
    md.append('\n## Sample winner/near-winner content starts\n')
    for s in mechanisms.get('samples',[])[:8]:
        md.append(f'\n### @{s["author"]} winner={s["winner"]}\n```text\n{s["content"]}\n```\n')
    (out/'WINNER-PULL-MAP.md').write_text(''.join(md),encoding='utf-8')

    contract=[]
    contract.append(f'# WINNER-PULL CONTRACT STUB - {mission}\n\n')
    contract.append('Fill manually before drafting. Use mechanisms, not copied winner phrases.\n\n')
    contract.append('## Expected positive verdict lines\n\n1.\n2.\n3.\n4.\n5.\n\n')
    contract.append('## Winner mechanisms selected\n\n| Mechanism | Evidence | Use now? | Expression without copying |\n|---|---|---|---|\n')
    for cl,_ in class_counts.most_common(10): contract.append(f'| {cl} | see map | YES / NO |  |\n')
    contract.append('\n## Planned evidence lines\n\n- Hook:\n- Scenario:\n- Mechanism:\n- Value rule:\n- CTA:\n\n')
    contract.append('## Anti-copy safety\n\n- Winner phrase/motif to avoid copying:\n- Our fresh expression:\n\n')
    (out/'WINNER-PULL-CONTRACT.stub.md').write_text(''.join(contract),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--submissions',required=True)
    ap.add_argument('--mission',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    subs=json.load(open(args.submissions,encoding='utf-8'))
    rows=extract_positive_rows(subs)
    mechanisms=content_mechanisms(subs)
    write_reports(subs,rows,mechanisms,args.out,args.mission)
    print(f'winner pull mining complete: {args.mission}, submissions={len(subs)}, rows={len(rows)}, out={args.out}')

if __name__=='__main__':
    main()
