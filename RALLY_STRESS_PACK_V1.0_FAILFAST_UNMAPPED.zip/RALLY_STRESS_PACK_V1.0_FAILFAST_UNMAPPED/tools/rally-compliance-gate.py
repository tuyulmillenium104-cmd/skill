#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RALLY COMPLIANCE GATE v1.0 (V7.5.3 — Meta-Rule #0J enforcement)
Checker programatik yang TIDAK BISA dinego oleh reasoning LLM.
Pakai: python3 rally-compliance-gate.py content.txt contract.json
Exit code 0 = boleh lanjut. Exit code 1 = DILARANG output ke user.

contract.json dibuat SEBELUM konten ditulis (Step 1.5), contoh:
{
  "mention": "@RequiredHandle",
  "one_sentence": true,
  "require_closing_period": true,
  "max_chars": 280,
  "max_connectors": 1,
  "audience_max_word_len": 10,
  "banned_definitive_numbers": ["twelve", "12", "twenty-four", "24"],
  "require_cta_question": true,
  "forbid_fourth_wall": true,
  "scalar_targets": {"flip_test_pct": 90, "reveal_position_pct": 80}
}
"""
import sys, re, json, unicodedata

def fail(msgs):
    print("=" * 60)
    print("COMPLIANCE GATE: FAIL — DILARANG OUTPUT KE USER")
    for m in msgs: print("  FAIL: " + m)
    print("Per Meta-Rule #0J: fix dulu, atau buktikan 2 attempted-fix gagal.")
    print("=" * 60)
    sys.exit(1)

def main():
    content = open(sys.argv[1], encoding='utf-8').read().strip()
    contract = json.load(open(sys.argv[2], encoding='utf-8'))
    errs = []
    body = content
    m = contract.get("mention")
    if m:
        if content.count(m) != 1: errs.append("mention %s harus tepat 1x (found %d)" % (m, content.count(m)))
        body = content.replace(m, "").strip()
    if content[0] in "@#": errs.append("diawali mention/hashtag")
    dashes = [c for c in set(content) if unicodedata.category(c) == "Pd" and c != "-"]
    if dashes: errs.append("unicode dash terlarang: %r" % dashes)
    sq = sum(content.count(c) for c in "\u2018\u2019\u201c\u201d")
    if sq: errs.append("smart quotes: %d" % sq)
    if re.findall(r"#\w+", content): errs.append("hashtag ditemukan")
    nonascii = [c for c in set(content) if ord(c) > 127]
    if nonascii: errs.append("non-ascii/hidden: %r" % nonascii)
    if contract.get("max_chars") and len(content) > contract["max_chars"]:
        errs.append("chars %d > max %d" % (len(content), contract["max_chars"]))
    if contract.get("one_sentence"):
        # LESSON TQ (0I-11 L3): 0 internal enders TAPI WAJIB 1 period penutup
        stripped = body.rstrip(".")
        internal = len(re.findall(r"[.!?]", stripped))
        if internal: errs.append("one-sentence: %d sentence-ender internal" % internal)
        if contract.get("require_closing_period", True):
            # period boleh sebelum mention; cek body asli berakhir dengan '.'
            if not body.endswith("."): errs.append("TIDAK ADA period penutup (jury TQ deduction, 0I-11 L3)")
    if contract.get("max_connectors") is not None:
        conn = len(re.findall(r"\b(because|so that|so |which is why|and that means)\b", body.lower()))
        if conn > contract["max_connectors"]:
            errs.append("klausa konektor %d > max %d (readability anak, 0I-11 L3)" % (conn, contract["max_connectors"]))
    if contract.get("audience_max_word_len"):
        hard = [w for w in set(re.findall(r"[a-zA-Z'-]+", body.lower())) if len(w) > contract["audience_max_word_len"]]
        if hard: errs.append("kata terlalu panjang utk audiens: %s" % hard)
    for n in contract.get("banned_definitive_numbers", []):
        # LESSON IA (0I-11 L1): angka definitif pada fakta ber-varian
        if re.search(r"\bthe %s\b" % re.escape(n), body.lower()):
            errs.append("OVERSPECIFIED definitive number: 'the %s' (0I-11 L1 — WAJIB FIX, bukan residu)" % n)
    # REAL-JUDGE LESSON LJ1 (2026-06-30): a URL with attached trailing punctuation
    # (e.g. "app.rally.fun," ) is read by Twitter's linkifier and the TQ judge as a
    # malformed link ("app.rally.fun,/") and cost a real post a 2/5 TQ. Block it here
    # as a hard compliance failure so it can never reach the user again.
    for mu in re.finditer(r"(?:https?://)?(?:[a-z0-9-]+\.)+(?:fun|com|io|xyz|app|gg|org|net)(?:/[^\s]*)?", content, re.I):
        nxt = content[mu.end():mu.end()+1]
        if nxt in {',', '.', ';', ':', '/', '!', '?', ')', ']', '}', '>', '"', "'"}:
            errs.append("URL diikuti tanda baca menempel (juri baca jadi link rusak, LJ1): %r + %r" % (mu.group(0), nxt))
            break
    if contract.get("require_cta_question"):
        # LESSON EP (0I-11 L2): campaign ini butuh conversation starter
        if "?" not in body: errs.append("tidak ada pertanyaan/CTA (0I-11 L2 — cek modus kritik EP pool campaign INI)")
    if contract.get("forbid_fourth_wall"):
        fw = [p for p in ["asked for a", "this campaign", "this submission", "my entry", "characters of this"] if p in body.lower()]
        if fw: errs.append("fourth-wall break: %s" % fw)
    if errs: fail(errs)
    print("COMPLIANCE GATE: ALL BINARY PASS (%d chars)" % len(content))
    print("SCALAR targets (uji manual + laporkan terukur, JANGAN klaim PASS):")
    for k, v in contract.get("scalar_targets", {}).items(): print("  - %s: target %s" % (k, v))
    sys.exit(0)

if __name__ == "__main__":
    main()
