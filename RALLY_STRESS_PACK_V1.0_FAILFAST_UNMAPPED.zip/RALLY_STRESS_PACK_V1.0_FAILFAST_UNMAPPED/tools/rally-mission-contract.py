#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate a literal-first compliance contract from requirement provenance."""
import argparse
import json
import time
from pathlib import Path

from rally_common import surface_policy_from_provenance, sha256_file


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--provenance', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    p = json.load(open(args.provenance, encoding='utf-8'))
    surface = surface_policy_from_provenance(p)
    mentions = p.get('requiredMentions') or []
    c = {
        'tool': 'rally-mission-contract.py v7.9.6',
        'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
        'campaign': p.get('campaign'),
        'mission': p.get('mission'),
        'provenanceFile': args.provenance,
        'provenanceSha256': sha256_file(args.provenance),
        'mention': mentions[0] if len(mentions) == 1 else None,
        'required_mentions': mentions,
        'required_hashtags': surface['requiredHashtags'],
        'forbid_hashtags': surface['forbidHashtags'],
        'forbid_start_mention_or_hashtag': surface['forbidStartMentionOrHashtag'],
        'forbidden_punctuation': surface['forbiddenPunctuation'],
        'ascii_only': surface['asciiOnly'],
        'forbid_smart_quotes': surface['forbidSmartQuotes'],
        'official_max_chars': p.get('officialMaxChars'),
        'one_sentence': bool(p.get('officialOneSentence')),
        'engine_soft_target_min': (p.get('engineSoftTarget') or [None, None])[0],
        'engine_soft_target_max': (p.get('engineSoftTarget') or [None, None])[1],
        'require_relation': p.get('requiredRelation'),
        'media_required': bool(p.get('mediaRequired')),
        'forbid_fourth_wall': True,
        'scalar_targets': {
            'mission_type': 'derive from mission soul',
            'teach_back': 'reader can satisfy literal mission ask',
        },
    }
    Path(args.out).write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding='utf-8')
    print(
        f'MISSION CONTRACT: wrote {args.out} officialMax={c["official_max_chars"]} '
        f'soft={c["engine_soft_target_min"]}-{c["engine_soft_target_max"]}')


if __name__ == '__main__':
    main()
