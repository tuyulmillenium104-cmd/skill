#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gold V3 naturalness and voice-variance checker."""
import argparse, sys, time
from collections import Counter
from _rq_gold_common import *


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--combined', required=True)
    ap.add_argument('--content', required=True)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    content=read(args.content).strip(); combined=read(args.combined); rows=parse_pairs(combined)
    n=len(rows)
    qlist=[r['q'] for r in rows]
    alist=[r['a'] for r in rows]
    first_person=sum(1 for q in qlist if FIRST_PERSON_RE.search(q))
    decision_marker=sum(1 for q in qlist if has_decision_marker(q))
    casual=sum(1 for q in qlist if CONTRACTIONS_RE.search(q))
    anecdotal=sum(1 for q in qlist if ANECDOTE_RE.search(q))
    first_twos=[first_two(q) for q in qlist]
    first_words=[first_word(q) for q in qlist]
    distinct_first_two=len(set(first_twos))
    same_first_word_max=max(Counter(first_words).values() or [0])
    same_first_two_max=max(Counter(first_twos).values() or [0])
    fp_open=sum(1 for q in qlist if first_word(q) in {'i','my','we','our'})
    direct_q=sum(1 for q in qlist if q.strip().endswith('?'))
    two_sentence=sum(1 for q in qlist if sentence_count(q)==2)
    semicolon=sum(1 for q in qlist if ';' in q)
    formal=sum(1 for q in qlist if FORMAL_RE.search(q))
    metadata=sum(1 for q in qlist if METADATA_RE.search(q))
    def firstn(t,n): return ' '.join(re.findall(r"[A-Za-z0-9']+", t.lower())[:n])
    a5=[firstn(a,5) for a in alist]
    a3=[firstn(a,3) for a in alist]
    same_a5_max=max(Counter(a5).values() or [0])
    exact_a_dupe_count=sum(1 for a,c in Counter([a.strip().lower() for a in alist]).items() if c>1)
    adjacent_a_repeat=any(a3[i] and a3[i]==a3[i+1]==a3[i+2] for i in range(max(0,len(a3)-2)))
    structures=len(set(sentence_count(q) for q in qlist))
    lengths=[len(q) for q in qlist]
    length_cv=cv(lengths)
    failures=[]; reasons=[]
    checks=[
        ('explicit first-person Q <=75%', pct(first_person,n) <= 0.75, f'{pct(first_person,n):.0%}'),
        ('decision-marker Q >=75%', pct(decision_marker,n) >= 0.75, f'{pct(decision_marker,n):.0%}'),
        ('decision-marker Q <=80%', pct(decision_marker,n) <= 0.80, f'{pct(decision_marker,n):.0%}'),
        ('casual/contraction voice >=35%', pct(casual,n) >= 0.35, f'{pct(casual,n):.0%}'),
        ('anecdotal/applied surface >=35%', pct(anecdotal,n) >= 0.35, f'{pct(anecdotal,n):.0%}'),
        ('distinct first-two-word openers >=15', distinct_first_two >= 15, str(distinct_first_two)),
        ('same first Q word <=25%', pct(same_first_word_max,n) <= 0.25, f'{pct(same_first_word_max,n):.0%}'),
        ('same first-two-word shell <=15%', pct(same_first_two_max,n) <= 0.15, f'{pct(same_first_two_max,n):.0%}'),
        ('first-person Q openings <=40%', pct(fp_open,n) <= 0.40, f'{pct(fp_open,n):.0%}'),
        ('direct-question Q 20-35%', 0.20 <= pct(direct_q,n) <= 0.35, f'{pct(direct_q,n):.0%}'),
        ('two-sentence shell <=50%', pct(two_sentence,n) <= 0.50, f'{pct(two_sentence,n):.0%}'),
        ('semicolon usage <=15%', pct(semicolon,n) <= 0.15, f'{pct(semicolon,n):.0%}'),
        ('formal/abstract register <=40%', pct(formal,n) <= 0.40, f'{pct(formal,n):.0%}'),
        ('at least three sentence-count structures', structures >= 3, str(structures)),
        ('Q-length CV >=9%', length_cv >= 0.09, f'{length_cv:.1%}'),
        ('metadata/internal labels in Q =0', metadata == 0, str(metadata)),
        ('exact duplicate A groups =0', exact_a_dupe_count == 0, str(exact_a_dupe_count)),
        ('same A first-5-word shell <=15%', pct(same_a5_max,n) <= 0.15, f'{pct(same_a5_max,n):.0%}'),
        ('no 3 adjacent A openings repeat', not adjacent_a_repeat, str(adjacent_a_repeat)),
    ]
    for label,ok,val in checks:
        if not ok:
            msg=f'{label} failed (actual {val})'
            reasons.append(msg); failures.append(msg)
    decision='PASS' if not reasons else 'FAIL'
    result={'tool':'rally-naturalness-variance-check.py','standard':'Gold V3.1.3','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'contentChars':len(content),'pairCount':n,'metrics':{'firstPersonPct':round(pct(first_person,n),3),'decisionMarkerPct':round(pct(decision_marker,n),3),'casualPct':round(pct(casual,n),3),'anecdotalPct':round(pct(anecdotal,n),3),'distinctFirstTwoOpeners':distinct_first_two,'sameFirstWordMaxPct':round(pct(same_first_word_max,n),3),'sameFirstTwoMaxPct':round(pct(same_first_two_max,n),3),'firstPersonOpeningPct':round(pct(fp_open,n),3),'directQuestionPct':round(pct(direct_q,n),3),'twoSentencePct':round(pct(two_sentence,n),3),'semicolonPct':round(pct(semicolon,n),3),'formalPct':round(pct(formal,n),3),'sentenceStructureCount':structures,'qLengthCv':round(length_cv,3),'metadataQCount':metadata,'exactADupeGroups':exact_a_dupe_count,'sameAFirst5MaxPct':round(pct(same_a5_max,n),3),'adjacentAOpeningRepeat':adjacent_a_repeat},'decision':decision,'reasons':reasons,'failures':failures,'summary':{'pairs':n,'decision marker coverage':f'{pct(decision_marker,n):.0%}','casual voice':f'{pct(casual,n):.0%}','anecdotal surface':f'{pct(anecdotal,n):.0%}','distinct first-two openers':distinct_first_two,'direct-question Q':f'{pct(direct_q,n):.0%}','Q length CV':f'{length_cv:.1%}','same A first-5 shell':f'{pct(same_a5_max,n):.0%}','A duplicate groups':exact_a_dupe_count}}
    write_report(args.out_json,args.out_md,result,'NATURALNESS VARIANCE CHECK - GOLD V3')
    print(f"NATURALNESS VARIANCE CHECK: {decision} [openers={distinct_first_two}, directQ={direct_q}/{n}, cv={length_cv:.1%}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
