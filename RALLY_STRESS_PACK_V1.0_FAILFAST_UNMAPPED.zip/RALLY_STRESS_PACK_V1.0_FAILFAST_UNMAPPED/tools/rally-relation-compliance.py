#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pre/post relation, quote, reply, media, and campaign-goal spillover audit."""
import argparse
import json
import re
import time
from pathlib import Path

from rally_common import sha256_file


def norm_url(u):
    return (u or '').strip().rstrip('/').lower()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--provenance', required=True)
    ap.add_argument('--plan', required=True)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args = ap.parse_args()

    prov = json.load(open(args.provenance, encoding='utf-8'))
    plan = json.load(open(args.plan, encoding='utf-8'))
    errors = []
    warnings = []
    rel = prov.get('requiredRelation') or {}
    rtype = (plan.get('relationType') or 'original').lower()
    source = norm_url(plan.get('sourceUrl'))
    allowed = rel.get('allowedTypes') or []
    required_urls = [norm_url(x) for x in rel.get('sourceUrls') or []]

    if rel.get('required') and rtype not in allowed:
        errors.append(f'relation type {rtype!r} not in required {allowed}')
    if rel.get('required') and rtype in {'quote','reply'} and not source:
        errors.append('required quote/reply plan is missing sourceUrl')
    if rel.get('required') and required_urls and source not in required_urls:
        errors.append(f'source URL mismatch: {source!r} not in required URLs')
    if rel.get('required') and not required_urls:
        warnings.append('relation is required but provenance contains no source URL to lock')
    if prov.get('mediaRequired') and not plan.get('mediaUsed'):
        errors.append('mission requires media but plan mediaUsed=false')
    if plan.get('mediaUsed') and not plan.get('mediaDescription'):
        warnings.append('media used without a description/reference plan')

    campaign_goal = ' '.join(
        str(x.get('text') or '') for x in prov.get('requirements', [])
        if x.get('source') == 'CAMPAIGN_GOAL')
    campaign_relation_signal = bool(re.search(
        r'quot(?:e|ing)\s+or\s+repl(?:y|ying)|quote/reply|main thread',
        campaign_goal, re.I))
    spillover = bool(
        campaign_relation_signal and not rel.get('required') and rtype == 'original')
    if spillover:
        warnings.append(
            'CAMPAIGN_GOAL_RELATION_SPILLOVER: literal mission permits an original post, '
            'but the campaign-wide goal mentions quote/reply; external compliance judges '
            'have deducted for this exact mismatch')

    decision = 'PASS' if not errors else 'FAIL'
    result = {
        'tool': 'rally-relation-compliance.py v7.9.6',
        'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
        'provenanceSha256': sha256_file(args.provenance),
        'planSha256': sha256_file(args.plan),
        'requiredRelation': rel,
        'campaignGoalRelationSignal': campaign_relation_signal,
        'campaignGoalRelationSpillover': spillover,
        'plan': plan,
        'errors': errors,
        'warnings': warnings,
        'decision': decision,
    }
    Path(args.out_json).write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    Path(args.out_md).write_text(
        '# RELATION COMPLIANCE\n\n'
        f'Decision: **{decision}**\n\n'
        '## Campaign-goal spillover\n'
        f'- Detected: **{spillover}**\n\n'
        '## Errors\n' + (''.join(f'- {x}\n' for x in errors) or '- none\n') +
        '\n## Warnings\n' + (''.join(f'- {x}\n' for x in warnings) or '- none\n'),
        encoding='utf-8')
    print(f'RELATION COMPLIANCE: {decision} [{len(errors)} errors, {len(warnings)} warnings]')
    raise SystemExit(0 if decision == 'PASS' else 1)


if __name__ == '__main__':
    main()
