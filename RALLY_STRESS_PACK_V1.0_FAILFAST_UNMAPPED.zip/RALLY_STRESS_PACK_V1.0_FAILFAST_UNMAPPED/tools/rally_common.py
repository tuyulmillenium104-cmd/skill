#!/usr/bin/env python3
"""Shared helpers for Rally Engine V7.8.5 deep-audit patch."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

TRAILING_URL_PUNCT = set(',.;:/!?)]}>"\'')
MARKDOWN_LINK_RE = re.compile(r"\[[^\]\n]+\]\((?:https?://|www\.)[^)\s]+\)", re.I)
# Exclude Markdown wrappers from the URL path, but intentionally retain ordinary
# trailing punctuation so it can be reported as attached punctuation.
URL_RE = re.compile(
    r"(?:https?://|www\.)[^\s<>\[\]()]+"
    r"|(?:[a-z0-9-]+\.)+(?:com|io|xyz|fun|app|gg|org|net|co|me|dev|ai)(?:/[^\s<>\[\]()]*)?",
    re.I,
)

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def sha256_file(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def normalized_text(text: str) -> str:
    return re.sub(r"\s+", " ", (text or '').strip().lower())

# ---------------------------------------------------------------------------
# V7.9 SIMPLIFY: shared tokenization/similarity primitives.
#
# rally-oaa-structure-audit.py and rally-originality-saturation-check.py each
# hand-rolled their own tokenizer + Jaccard similarity against the
# non-winner/full submission corpus, with slightly different stop-word lists
# and independent similarity thresholds (0.42 vs 0.18) that could silently
# drift out of sync if one file was edited and the other was not. This
# module centralizes the token/Jaccard math itself while leaving each gate's
# own stop-word list and threshold as explicit parameters, so behavior for
# existing inputs is unchanged -- only the arithmetic implementation is
# shared, not the tuning.
# ---------------------------------------------------------------------------
DEFAULT_SIMILARITY_STOPWORDS = set(
    'the a an and or but to of in on for with is are was were be been being '
    'it this that as at by from you your i my me we they them if not just '
    'more most no one do does did'.split()
)

def similarity_tokens(text: str, stopwords: set[str] | None = None, min_len: int = 1) -> list[str]:
    """Lowercase alnum/@/'-token extraction with stop-word removal.

    `stopwords=None` uses DEFAULT_SIMILARITY_STOPWORDS; pass a gate-specific
    set (or an extended copy of the default) to preserve that gate's exact
    prior behavior.
    """
    sw = DEFAULT_SIMILARITY_STOPWORDS if stopwords is None else stopwords
    return [x for x in re.findall(r"[a-z0-9@']+", (text or '').lower())
            if len(x) >= min_len and x not in sw]

# ---------------------------------------------------------------------------
# V7.9 SIMPLIFY: shared tactical-post length targets.
#
# rally-tq-format-audit.py and rally-ep-compactness-check.py each hardcoded
# the same 850-char soft / 1050-char hard tactical thresholds independently.
# If a future tuning pass changed one without the other, the two gates could
# start disagreeing (PASS vs REVIEW) about the identical piece of content
# for no substantive reason. These constants are the single source of truth;
# both gates still expose their own --max-chars/--engine-review-threshold
# CLI flags with these as defaults, so existing invocations and outputs are
# unchanged.
# ---------------------------------------------------------------------------
TACTICAL_SOFT_TARGET_CHARS = 850
TACTICAL_HARD_MAX_CHARS = 1050
NARRATIVE_SOFT_TARGET_CHARS = 1400
NARRATIVE_HARD_MAX_CHARS = 1800
CONFESSIONAL_SOFT_TARGET_CHARS = 1800
CONFESSIONAL_HARD_MAX_CHARS = 2200

# V7.9.6 external-verdict calibration. Mission type and surface genre are
# related but not interchangeable. In particular, an EXPLAIN mission does not
# become narrative merely because it uses a scenario as a teaching device.
# Full-strict runs must use one resolved genre across Compactness, TQ, EP Max,
# and Final Integrity. Any exception needs explicit, machine-readable evidence.
DEFAULT_GENRE_BY_MISSION_TYPE = {
    'general': 'tactical',
    'explain': 'tactical',
    'identify': 'tactical',
    'predict': 'tactical',
    'argue': 'tactical',
    'persuade': 'tactical',
    'narrative': 'narrative',
}

ALLOWED_GENRES_BY_MISSION_TYPE = {
    'general': {'tactical'},
    'explain': {'tactical'},
    'identify': {'tactical'},
    'predict': {'tactical'},
    'argue': {'tactical', 'confessional'},
    'persuade': {'tactical'},
    'narrative': {'narrative', 'confessional'},
}

GENRE_OVERRIDE_SOURCE_TYPES = {'CAMPAIGN_LITERAL', 'FRESH_MISSION_VERDICT'}

def default_genre_for_mission_type(mission_type: str) -> str:
    return DEFAULT_GENRE_BY_MISSION_TYPE.get((mission_type or 'general').lower(), 'tactical')

def validate_genre_policy(mission_type: str, genre: str, override_evidence=None) -> dict:
    """Validate mission-type/genre compatibility without silent exemptions.

    `override_evidence` may be a loaded dict or a JSON path. An override is
    accepted only when it is explicitly approved, matches the mission type and
    requested genre, cites campaign-literal or fresh mission-verdict evidence,
    and contains a non-empty explanation. Winner median length by itself is not
    an accepted override source.
    """
    mt = (mission_type or 'general').lower()
    requested = (genre or 'auto').lower()
    expected = default_genre_for_mission_type(mt)
    errors = []
    override = None
    if requested == 'auto':
        errors.append('genre auto is prohibited in full-strict scoring; resolve one explicit genre')
    allowed = ALLOWED_GENRES_BY_MISSION_TYPE.get(mt, {'tactical'})
    if requested not in allowed:
        if override_evidence:
            try:
                override = (json.loads(Path(override_evidence).read_text(encoding='utf-8'))
                            if isinstance(override_evidence, (str, Path)) else override_evidence)
            except Exception as e:
                errors.append(f'genre override evidence unreadable: {e}')
                override = None
            if override is not None:
                source_type = str(override.get('sourceType') or '').upper()
                evidence = override.get('evidence')
                if not override.get('approved'):
                    errors.append('genre override evidence is not approved')
                if str(override.get('missionType') or '').lower() != mt:
                    errors.append('genre override missionType mismatch')
                if str(override.get('requestedGenre') or '').lower() != requested:
                    errors.append('genre override requestedGenre mismatch')
                if source_type not in GENRE_OVERRIDE_SOURCE_TYPES:
                    errors.append('genre override sourceType must be CAMPAIGN_LITERAL or FRESH_MISSION_VERDICT')
                if not evidence or not str(override.get('reason') or '').strip():
                    errors.append('genre override requires evidence and reason')
        else:
            errors.append(f'genre {requested!r} is incompatible with mission type {mt!r}; allowed={sorted(allowed)}')
    return {
        'missionType': mt,
        'requestedGenre': requested,
        'defaultGenre': expected,
        'allowedGenres': sorted(allowed),
        'overrideUsed': bool(override and not errors and requested not in allowed),
        'override': override,
        'errors': errors,
        'decision': 'PASS' if not errors else 'FAIL',
    }

def surface_policy_from_provenance(provenance: dict) -> dict:
    """Return literal surface rules, deriving them from old provenance if needed."""
    p = provenance or {}
    hard_text = '\n'.join(
        str(x.get('text') or '') for x in p.get('requirements', [])
        if x.get('source') in {'MISSION_HARD', 'CAMPAIGN_HARD'})
    required_hashtags = list(p.get('requiredHashtags') or [])
    if 'requiredHashtags' not in p:
        for line in hard_text.splitlines():
            tags = re.findall(r"#[A-Za-z0-9_]+", line)
            ll = line.lower()
            if tags and re.search(r"\b(must|required|include|use)\b", ll) and not re.search(r"\b(do not|don't|must not|forbid|not allowed)\b", ll):
                required_hashtags.extend(tags)
    forbid_hashtags = (bool(p.get('forbidHashtags')) if 'forbidHashtags' in p else
        bool(re.search(r"\b(no hashtags?|hashtags? (?:are )?not allowed|do not use hashtags?|don't use hashtags?|must not use hashtags?)\b", hard_text, re.I)))
    forbid_start = (bool(p.get('forbidStartMentionOrHashtag')) if 'forbidStartMentionOrHashtag' in p else
        bool(re.search(r"\bdo not start (?:the )?post with (?:a )?mention or hashtag|\bmust not start .*?(?:mention|hashtag)", hard_text, re.I)))
    forbidden = list(p.get('forbiddenPunctuation') or [])
    if 'forbiddenPunctuation' not in p:
        if re.search(r"\bem dashes?\s*(?:\([^)]*—[^)]*\))?\s*(?:are|is)?\s*not allowed|\bno em dashes?\b|\bdo not use em dashes?\b", hard_text, re.I):
            forbidden.append('—')
        if re.search(r"\ben dashes?\s*(?:\([^)]*–[^)]*\))?\s*(?:are|is)?\s*not allowed|\bno en dashes?\b|\bdo not use en dashes?\b", hard_text, re.I):
            forbidden.append('–')
    ascii_only = (bool(p.get('asciiOnly')) if 'asciiOnly' in p else
        bool(re.search(r"\bascii(?:-only| only)\b|\buse only ascii\b", hard_text, re.I)))
    forbid_smart = (bool(p.get('forbidSmartQuotes')) if 'forbidSmartQuotes' in p else
        ascii_only or bool(re.search(r"\bno smart quotes?\b|\bsmart quotes? (?:are )?not allowed\b", hard_text, re.I)))
    return {
        'requiredHashtags': sorted(set(required_hashtags)),
        'forbidHashtags': forbid_hashtags,
        'forbidStartMentionOrHashtag': forbid_start,
        'forbiddenPunctuation': sorted(set(forbidden)),
        'asciiOnly': ascii_only,
        'forbidSmartQuotes': forbid_smart,
    }

def jaccard_similarity(a: str, b: str, stopwords: set[str] | None = None,
                        exclude: set[str] | None = None, min_len: int = 1) -> float:
    """Token Jaccard similarity between two texts.

    `exclude` removes additional tokens (e.g. mandatory campaign phrases)
    from both sides after stop-word filtering, matching the
    mandatory-term-adjusted similarity originally implemented in
    rally-originality-saturation-check.py.
    """
    exclude = exclude or set()
    sa = set(similarity_tokens(a, stopwords, min_len)) - exclude
    sb = set(similarity_tokens(b, stopwords, min_len)) - exclude
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)

def find_url_issues(text: str) -> dict:
    """Return Markdown-link and attached-punctuation URL problems.

    A punctuation mark that directly touches a URL is intentionally treated as a
    hard problem because Rally's real TQ judge has interpreted it as malformed.
    """
    markdown = [m.group(0) for m in MARKDOWN_LINK_RE.finditer(text)]
    attached = []
    urls = []
    for m in URL_RE.finditer(text):
        raw = m.group(0)
        # Ignore the URL occurrence inside Markdown syntax after recording the
        # Markdown problem; reporting both would be noisy.
        in_markdown = any(mm.start() <= m.start() < mm.end() for mm in MARKDOWN_LINK_RE.finditer(text))
        urls.append(raw)
        if in_markdown:
            continue
        if raw and raw[-1] in TRAILING_URL_PUNCT:
            attached.append({'url': raw[:-1], 'punctuation': raw[-1], 'raw': raw})
            continue
        nxt = text[m.end():m.end()+1]
        if nxt in TRAILING_URL_PUNCT:
            attached.append({'url': raw, 'punctuation': nxt, 'raw': raw+nxt})
    return {'urls': urls, 'markdownLinks': markdown, 'attachedPunctuation': attached}

def extract_main_content_block(combined: str) -> str | None:
    m = re.search(r"(?ms)^## MAIN CONTENT[^\n]*\n.*?^```text\n(.*?)\n```", combined)
    return m.group(1) if m else None

def load_json(path: str | Path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write_json(path: str | Path, data) -> None:
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

def report_identity(content: str, combined: str | None = None) -> dict:
    out = {'contentChars': len(content), 'contentSha256': sha256_text(content)}
    if combined is not None:
        out['combinedSha256'] = sha256_text(combined)
    return out
