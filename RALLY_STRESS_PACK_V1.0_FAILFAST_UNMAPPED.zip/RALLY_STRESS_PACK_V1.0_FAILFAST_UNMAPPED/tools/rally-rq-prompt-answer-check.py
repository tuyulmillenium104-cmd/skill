#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gold V3 RQ Prompt-Answer Compliance checker.

Checks whether Q/A pairs respond to the actual CTA, add personal/decision/substantive
conversation value, avoid metadata in public copy, and follow Gold V3 answer constraints.
Question-ending is checked as pack coverage, not a per-pair law.
"""
import argparse, json, sys, time
from pathlib import Path
from _rq_gold_common import *


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--combined', required=True)
    ap.add_argument('--content', required=True)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    ap.add_argument('--min-pairs', type=int, default=20)
    args=ap.parse_args()
    combined=read(args.combined)
    content=read(args.content).strip()
    rows=parse_pairs(combined)
    failures=[]; out_rows=[]
    for r in rows:
        q,a=r['q'],r['a']
        personal=bool(FIRST_PERSON_RE.search(q) or FIRST_PERSON_RE.search(a) or ANECDOTE_RE.search(q))
        decision=has_decision_word(q+' '+a)
        aligned=cta_aligned(q, content) or cta_aligned(a, content)
        substantive=bool(MECHANIC_RE.search(q+' '+a) or SKEPTIC_RE.search(q+' '+a) or ANECDOTE_RE.search(q+' '+a) or len(a.split())>=28)
        no_meta=not METADATA_RE.search(q)
        not_generic=not GENERIC_FAQ_RE.search(q) and not LOW_EFFORT_RE.search(q)
        a_one_line='\n' not in a.strip()
        q_ok=160 <= len(q) <= 260
        a_ok=len(a) <= 280 and a_one_line
        answers=personal and decision and aligned and substantive and no_meta and not_generic
        decision_str='PASS' if q_ok and a_ok and answers else 'FAIL'
        reasons=[]
        if not q_ok: reasons.append(f'Q length {len(q)} outside 160-260')
        if not a_ok: reasons.append('A exceeds 280 chars or is not one line')
        if not personal: reasons.append('lacks personal/stake surface')
        if not decision: reasons.append('lacks decision/action word')
        if not aligned: reasons.append('not aligned with post CTA/mechanism')
        if not substantive: reasons.append('does not add substantive angle')
        if not no_meta: reasons.append('metadata/internal label inside Q-COPY')
        if not not_generic: reasons.append('generic FAQ/low-effort Q')
        if decision_str!='PASS': failures.append(f"R{r['idx']}: "+', '.join(reasons))
        out_rows.append({'idx':r['idx'],'qChars':len(q),'aChars':len(a),'personal':personal,'hasDecisionWord':decision,'ctaAligned':aligned,'substantive':substantive,'qLengthOk':q_ok,'aOk':a_ok,'metadataFreeQ':no_meta,'decision':decision_str,'reasons':reasons})
    n=len(rows)
    pass_count=sum(1 for x in out_rows if x['decision']=='PASS')
    q_end=sum(1 for r in rows if r['a'].strip().endswith('?'))
    q_end_pct=pct(q_end,n)
    reasons=[]
    if n < args.min_pairs: reasons.append(f'only {n} pairs < min {args.min_pairs}')
    if pass_count != n: reasons.append(f'{n-pass_count} pairs fail prompt-answer/advancement checks')
    if not (0.50 <= q_end_pct <= 0.75): reasons.append(f'question-ending A coverage {q_end_pct:.0%} outside 50-75%')
    decision='PASS' if not reasons else 'FAIL'
    result={'tool':'rally-rq-prompt-answer-check.py','standard':'Gold V3.1.3','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'contentChars':len(content),'pairCount':n,'passCount':pass_count,'answerQuestionEndingCount':q_end,'answerQuestionEndingPct':round(q_end_pct,3),'rows':out_rows,'failures':failures,'decision':decision,'reasons':reasons,'summary':{'pairs':n,'pass':f'{pass_count}/{n}','A question-ending coverage':f'{q_end_pct:.0%}'}}
    write_report(args.out_json,args.out_md,result,'RQ PROMPT-ANSWER COMPLIANCE CHECK - GOLD V3')
    print(f"RQ PROMPT-ANSWER CHECK: {decision} [pass={pass_count}/{n}, aQuestionEnd={q_end}/{n}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
