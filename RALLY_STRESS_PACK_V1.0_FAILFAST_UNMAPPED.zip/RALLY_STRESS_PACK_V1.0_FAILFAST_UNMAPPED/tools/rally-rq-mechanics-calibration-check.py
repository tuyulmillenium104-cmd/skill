#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gold V3 RQ mechanics calibration checker.

Campaign/product packs must show enough campaign mechanics, constructive skepticism,
subject-matter engagement, and decision coverage without forcing every row into the
same decision-marker formula.
"""
import argparse, sys, time, json
from pathlib import Path
from _rq_gold_common import *


def looks_protocol(content):
    return bool(MECHANIC_RE.search(content))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--combined', required=True)
    ap.add_argument('--content', required=True)
    ap.add_argument('--campaign', default=None)
    ap.add_argument('--mission', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    ap.add_argument('--min-mechanics-pct', type=float, default=0.70)
    ap.add_argument('--min-skeptic-pct', type=float, default=0.25)
    args=ap.parse_args()
    combined=read(args.combined); content=read(args.content).strip(); rows=parse_pairs(combined)
    proto=looks_protocol(content)
    out_rows=[]; failures=[]
    for r in rows:
        q,a=r['q'],r['a']; both=q+' '+a
        mech=bool(MECHANIC_RE.search(both))
        skeptic=bool(SKEPTIC_RE.search(both))
        decision_marker=has_decision_marker(q)
        decision_word=has_decision_word(both)
        subject=mech or exact_quote_from_content(q, content) or cta_aligned(q, content)
        low=bool(LOW_EFFORT_RE.search(both) or GENERIC_FAQ_RE.search(q) or METADATA_RE.search(q))
        # Per-row standard: no low-effort and at least subject-matter plus either decision, skepticism, or personal surface.
        personal=bool(FIRST_PERSON_RE.search(both) or ANECDOTE_RE.search(both))
        ok=(not low) and subject and (decision_word or skeptic or personal)
        reasons=[]
        if low: reasons.append('low-effort/generic/metadata')
        if not subject: reasons.append('missing campaign/post mechanism or source reference')
        if not (decision_word or skeptic or personal): reasons.append('missing decision/skeptic/personal angle')
        if not ok: failures.append(f"R{r['idx']}: "+', '.join(reasons))
        out_rows.append({'idx':r['idx'],'hasMechanic':mech,'hasSkeptic':skeptic,'hasDecisionMarker':decision_marker,'hasDecisionWord':decision_word,'subjectMatter':subject,'personalSurface':personal,'decision':'PASS' if ok else 'FAIL','reasons':reasons})
    n=len(rows)
    mech_count=sum(1 for r in out_rows if r['hasMechanic'])
    skeptic_count=sum(1 for r in out_rows if r['hasSkeptic'])
    dm_count=sum(1 for r in out_rows if r['hasDecisionMarker'])
    dw_count=sum(1 for r in out_rows if r['hasDecisionWord'])
    pass_count=sum(1 for r in out_rows if r['decision']=='PASS')
    mech_pct=pct(mech_count,n); skeptic_pct=pct(skeptic_count,n); dm_pct=pct(dm_count,n); dw_pct=pct(dw_count,n)
    reasons=[]
    if pass_count != n: reasons.append(f'{n-pass_count} rows fail per-row subject/decision/skeptic standard')
    if proto and mech_pct < args.min_mechanics_pct: reasons.append(f'mechanics coverage {mech_pct:.0%} < {args.min_mechanics_pct:.0%}')
    if skeptic_pct < args.min_skeptic_pct: reasons.append(f'skeptic/constructive coverage {skeptic_pct:.0%} < {args.min_skeptic_pct:.0%}')
    if dm_pct < 0.75: reasons.append(f'decision-marker coverage {dm_pct:.0%} < 75%')
    if dm_pct > 0.80: reasons.append(f'decision-marker coverage {dm_pct:.0%} > 80% (formula risk)')
    if dw_pct < 0.50: reasons.append(f'decision-word coverage {dw_pct:.0%} < 50%')
    decision='PASS' if not reasons else 'FAIL'
    result={'tool':'rally-rq-mechanics-calibration-check.py','standard':'Gold V3.1.3','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'contentChars':len(content),'protocolCampaign':proto,'mission':args.mission,'pairCount':n,'mechanicsPairCount':mech_count,'mechanicsPct':round(mech_pct,3),'decisionMarkerPairCount':dm_count,'decisionMarkerPct':round(dm_pct,3),'decisionWordPairCount':dw_count,'decisionWordPct':round(dw_pct,3),'skepticPairCount':skeptic_count,'skepticPct':round(skeptic_pct,3),'rows':out_rows,'failures':failures,'decision':decision,'reasons':reasons,'summary':{'protocol/product campaign':proto,'mechanics':f'{mech_count}/{n} ({mech_pct:.0%})','decision markers':f'{dm_count}/{n} ({dm_pct:.0%})','decision words':f'{dw_count}/{n} ({dw_pct:.0%})','skeptic':f'{skeptic_count}/{n} ({skeptic_pct:.0%})'}}
    write_report(args.out_json,args.out_md,result,'RQ MECHANICS CALIBRATION CHECK - GOLD V3')
    print(f"RQ MECHANICS CALIBRATION CHECK: {decision} [mechanics={mech_count}/{n}, decision={dm_count}/{n}, skeptic={skeptic_count}/{n}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
