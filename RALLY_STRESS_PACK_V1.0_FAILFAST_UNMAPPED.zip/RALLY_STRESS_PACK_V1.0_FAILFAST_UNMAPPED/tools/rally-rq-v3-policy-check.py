#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gold V3 machine policy checker.

Validates pack-level policy, ranking metadata, voicePersona/voiceMode, metadata hygiene,
and V3 thresholds from rq-gold-policy-v3.json.
"""
import argparse, sys, time, json, re
from collections import Counter
from pathlib import Path
from _rq_gold_common import *


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--combined', required=True)
    ap.add_argument('--content', required=True)
    ap.add_argument('--ranking-json', required=True)
    ap.add_argument('--policy', default=str(Path(__file__).with_name('rq-gold-policy-v3.json')))
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    policy=json.load(open(args.policy,encoding='utf-8'))
    content=read(args.content).strip(); combined=read(args.combined); rows=parse_pairs(combined)
    _, ranking_rows, by_idx=load_ranking(args.ranking_json)
    n=len(rows); qlist=[r['q'] for r in rows]
    type_counts=Counter((r.get('type') or normalize_type(r.get('heading','')) or normalize_type((by_idx.get(r['idx']) or {}).get('type','')) or 'UNKNOWN') for r in rows)
    lengths=[len(q) for q in qlist]
    decision_marker=sum(1 for q in qlist if has_decision_marker(q))
    decision_word=sum(1 for q in qlist if has_decision_word(q))
    cta_count=sum(1 for q in qlist if cta_aligned(q, content))
    because=sum(1 for q in qlist if re.search(r"\bbecause\b",q,re.I))
    iwould=sum(1 for q in qlist if re.search(r"\bi would\b",q,re.I))
    mydecision=sum(1 for q in qlist if re.search(r"\bmy decision\b",q,re.I))
    myconcern=sum(1 for q in qlist if re.search(r"\bmy concern is\b",q,re.I))
    myanswer=sum(1 for q in qlist if re.search(r"\bmy answer is\b",q,re.I))
    formula_starts=sum(1 for q in qlist if re.search(r"(?:\bmy concern is\b|\bmy decision is\b|\bmy answer is\b|^\s*hot take[, ]|^\s*the wrong lesson|^\s*i would argue\b|^\s*i would lead\b|^\s*i would pick\b|^\s*i would choose\b)",q,re.I))
    mention_starts=sum(1 for q in qlist if re.search(r"^\s*@[a-z0-9_]+\b",q,re.I))
    structures=len(set(sentence_count(q) for q in qlist))
    journalist=sum(1 for q in qlist if JOURNALIST_RE.search(q))
    generic=sum(1 for q in qlist if GENERIC_FAQ_RE.search(q))
    metadata=sum(1 for q in qlist if METADATA_RE.search(q))
    qdupes=[q for q,c in Counter([q.strip().lower() for q in qlist]).items() if c>1]
    spec_rows=[r for r in rows if (r.get('type') or normalize_type(r.get('heading','')) or normalize_type((by_idx.get(r['idx']) or {}).get('type',''))) == 'Specific Probe']
    spec_quote_ok=sum(1 for r in spec_rows if exact_quote_from_content(r['q'], content))

    reasons=[]; failures=[]
    if n != policy['pack']['pairCount']: reasons.append(f"pair count {n} != {policy['pack']['pairCount']}")
    for typ,need in policy['pack']['types'].items():
        if type_counts.get(typ,0) != need: reasons.append(f'type {typ}: {type_counts.get(typ,0)} != {need}')
    # q thresholds
    qc=policy['qCopy']; vc=policy['voiceDiversity']
    checks=[
        ('decision-marker coverage >=75%', pct(decision_marker,n) >= qc['decisionMarkerMinPct'], f'{pct(decision_marker,n):.0%}'),
        ('decision-marker coverage <=80%', pct(decision_marker,n) <= qc['decisionMarkerMaxPct'], f'{pct(decision_marker,n):.0%}'),
        ('decision-word coverage >=50%', pct(decision_word,n) >= qc['decisionWordMinPct'], f'{pct(decision_word,n):.0%}'),
        ('CTA-aligned Q >=40%', pct(cta_count,n) >= qc['ctaAlignedMinPct'], f'{pct(cta_count,n):.0%}'),
        ('Specific Probe exact-source quote =100%', len(spec_rows)>0 and spec_quote_ok==len(spec_rows), f'{spec_quote_ok}/{len(spec_rows)}'),
        ('because <=35%', pct(because,n) <= qc['becauseMaxPct'], f'{pct(because,n):.0%}'),
        ('I would <=25%', pct(iwould,n) <= qc['iWouldMaxPct'], f'{pct(iwould,n):.0%}'),
        ('my decision <=20%', pct(mydecision,n) <= qc['myDecisionMaxPct'], f'{pct(mydecision,n):.0%}'),
        ('my concern starts <=10%', pct(myconcern,n) <= qc.get('myConcernStartMaxPct',0.10), f'{pct(myconcern,n):.0%}'),
        ('my answer starts <=10%', pct(myanswer,n) <= qc.get('myAnswerStartMaxPct',0.10), f'{pct(myanswer,n):.0%}'),
        ('formula Q starts <=35%', pct(formula_starts,n) <= qc.get('formulaStartMaxPct',0.35), f'{pct(formula_starts,n):.0%}'),
        ('same mention Q starts <=25%', pct(mention_starts,n) <= qc.get('mentionStartMaxPct',0.25), f'{pct(mention_starts,n):.0%}'),
        ('Q-length CV >=9%', cv(lengths) >= qc['lengthCvMinPct'], f'{cv(lengths):.1%}'),
        ('sentence-count structures >=3', structures >= qc['sentenceStructureMin'], str(structures)),
        ('journalist framing =0', journalist == 0, str(journalist)),
        ('generic FAQ =0', generic == 0, str(generic)),
        ('exact duplicate Q =0', len(qdupes) == 0, str(len(qdupes))),
        ('metadata/internal labels in Q =0', metadata == 0, str(metadata)),
    ]
    for label,ok,val in checks:
        if not ok:
            msg=f'{label} failed (actual {val})'; reasons.append(msg); failures.append(msg)
    # ranking metadata
    if len(ranking_rows) != n: reasons.append(f'qa_ranking rows {len(ranking_rows)} != pair count {n}')
    personas=[]; modes=[]
    prev_persona=None
    for idx in range(1,n+1):
        rr=by_idx.get(idx)
        if not rr:
            failures.append(f'R{idx}: missing ranking metadata'); continue
        persona=str(rr.get('voicePersona','')).strip(); mode=str(rr.get('voiceMode','')).strip()
        typ=normalize_type(rr.get('type','')) or (rows[idx-1].get('type') if idx-1 < len(rows) else None)
        tier=str(rr.get('tier','')).upper().strip()[:1]
        score=rr.get('tierScore', rr.get('score'))
        deployment=str(rr.get('deployment','')).upper()
        if not persona: failures.append(f'R{idx}: missing voicePersona')
        if not mode: failures.append(f'R{idx}: missing voiceMode')
        if any(p in persona for p in vc['rejectPlaceholders']): failures.append(f'R{idx}: placeholder voicePersona rejected')
        if any(p in mode for p in vc['rejectPlaceholders']): failures.append(f'R{idx}: placeholder voiceMode rejected')
        if persona and prev_persona and persona.lower()==prev_persona.lower(): failures.append(f'R{idx}: adjacent same persona')
        prev_persona=persona or prev_persona
        personas.append(persona.lower()); modes.append(mode.lower())
        if tier in policy['pack']['tierScores']:
            expected=policy['pack']['tierScores'][tier]
            try: sc=int(score)
            except Exception: sc=None
            if sc is not None and sc != expected: failures.append(f'R{idx}: tier {tier} score {sc} != {expected}')
        # simulated Real Experience controls
        heading=rows[idx-1]['heading'] if idx-1 < len(rows) else ''
        is_real_exp=(typ=='Real Experience')
        simulated=('SIMULATED_ARCHETYPE' in heading.upper()) or ('SIMULATED_ARCHETYPE' in str(rr).upper())
        if is_real_exp and simulated and 'CONDITIONAL_ORGANIC_MATCH_ONLY' not in deployment and 'CONDITIONAL_ORGANIC_MATCH_ONLY' not in str(rr).upper():
            failures.append(f'R{idx}: simulated Real Experience missing CONDITIONAL_ORGANIC_MATCH_ONLY deployment metadata')
    distinct_personas=len(set(p for p in personas if p))
    distinct_modes=len(set(m for m in modes if m))
    if distinct_personas < vc['distinctPersonasMin']: reasons.append(f'distinct personas {distinct_personas} < {vc["distinctPersonasMin"]}')
    if distinct_modes < vc['distinctVoiceModesMin']: reasons.append(f'distinct voice modes {distinct_modes} < {vc["distinctVoiceModesMin"]}')
    if failures: reasons.append(f'{len(failures)} policy/ranking failures')
    decision='PASS' if not reasons else 'FAIL'
    result={'tool':'rally-rq-v3-policy-check.py','standard':'Gold V3.1.3','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'contentChars':len(content),'pairCount':n,'typeCounts':dict(type_counts),'metrics':{'decisionMarkerPct':round(pct(decision_marker,n),3),'decisionWordPct':round(pct(decision_word,n),3),'ctaAlignedPct':round(pct(cta_count,n),3),'specificProbeQuote':f'{spec_quote_ok}/{len(spec_rows)}','becausePct':round(pct(because,n),3),'iWouldPct':round(pct(iwould,n),3),'myDecisionPct':round(pct(mydecision,n),3),'myConcernStartPct':round(pct(myconcern,n),3),'myAnswerStartPct':round(pct(myanswer,n),3),'formulaStartPct':round(pct(formula_starts,n),3),'mentionStartPct':round(pct(mention_starts,n),3),'qLengthCv':round(cv(lengths),3),'sentenceStructureCount':structures,'journalistCount':journalist,'genericFaqCount':generic,'metadataQCount':metadata,'distinctPersonas':distinct_personas,'distinctVoiceModes':distinct_modes},'failures':failures,'decision':decision,'reasons':reasons,'summary':{'pairs':n,'types':dict(type_counts),'decision markers':f'{decision_marker}/{n} ({pct(decision_marker,n):.0%})','CTA aligned':f'{cta_count}/{n} ({pct(cta_count,n):.0%})','ranking rows':len(ranking_rows),'distinct personas':distinct_personas,'distinct voice modes':distinct_modes}}
    write_report(args.out_json,args.out_md,result,'RQ GOLD V3 POLICY CHECK')
    print(f"RQ GOLD V3 POLICY CHECK: {decision} [pairs={n}, ranking={len(ranking_rows)}, personas={distinct_personas}, modes={distinct_modes}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
