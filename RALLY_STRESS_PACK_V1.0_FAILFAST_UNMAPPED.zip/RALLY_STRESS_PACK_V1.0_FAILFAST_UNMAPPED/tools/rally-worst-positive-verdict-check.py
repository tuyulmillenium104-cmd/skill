#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Worst Positive Verdict checker.

Purpose: catch the common Rally failure mode where a judge praises the post but still
writes a small deduction sentence: "strong, but...". All-max pressure requires no
credible positive-but-capping sentence for EP/OAA/RQ.

This tool is heuristic and must be used as a blocker when it finds credible known
real-verdict deduction surfaces.
"""
import argparse, json, re, sys, time
from pathlib import Path

EP_CEILING_PATTERNS = [
    ("length_density", ["long", "length", "dense", "casual scroller", "accessibility"], "Strong content, but its length/density may limit casual-scroller engagement."),
    ("admire_not_reply", ["literary", "poetic", "admire", "metaphor", "crafted"], "The writing is memorable, but the literary tone may make users admire it more than reply."),
    ("reflective_not_actionable", ["reflective", "philosophical", "emotional", "not actionable"], "Value delivery is good, but more reflective than tactical/actionable."),
    ("cta_not_answerable", ["what do you think", "thoughts", "agree"], "CTA exists, but is too generic to drive deep replies."),
]

OAA_CEILING_PATTERNS = [
    ("semantic_saturation", ["saturated", "crowded", "similar", "overlap", "common pattern"], "Voice is authentic, but the core motif overlaps significantly with other entries."),
    ("template_progression", ["comfort", "trade", "?"], "Progression mirrors a common campaign template too closely."),
    ("polished_crafted", ["polished", "crafted", "clean lesson"], "Language is natural, but occasionally polished in a way that feels crafted rather than exceptional."),
]

RQ_CEILING_PATTERNS = [
    ("validation_not_advancement", ["relevant", "validates", "surface", "observational"], "Replies are relevant and authentic, but mostly validate the post rather than advancing the conversation."),
    ("not_answering_prompt", ["does not answer", "actual prompt", "drink", "decision", "trade"], "Replies do not answer the actual prompt or add a concrete personal decision."),
    ("craft_commentary", ["writing", "detail", "specificity", "metaphor", "works because"], "Replies drift into craft commentary rather than engaging the lived theme."),
]

POSITIVE_BUT_WORDS = ["but", "however", "though", "while", "slightly", "mostly", "may", "could", "rather than", "not especially"]


def load(path):
    if not path: return {}
    try: return json.load(open(path, encoding='utf-8'))
    except Exception: return {}


def text_of(path):
    return Path(path).read_text(encoding='utf-8', errors='ignore') if path and Path(path).exists() else ''


def add_if(condition, rows, gate, key, sentence, source, severity='precedented'):
    if condition:
        rows.append({
            'gate': gate, 'key': key, 'credibleDeductionSentence': sentence,
            'source': source, 'severity': severity, 'fixDecision': 'FIX_OR_REBUILD'
        })


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--content', required=True)
    ap.add_argument('--combined', default=None)
    ap.add_argument('--tactical-report', default=None)
    ap.add_argument('--originality-report', default=None)
    ap.add_argument('--compactness-report', default=None)
    ap.add_argument('--rq-report', default=None)
    ap.add_argument('--cta-report', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()

    content=text_of(args.content).strip()
    tl=content.lower()
    combined=text_of(args.combined)
    tactical=load(args.tactical_report)
    originality=load(args.originality_report)
    compact=load(args.compactness_report)
    rq=load(args.rq_report)
    cta=load(args.cta_report)
    rows=[]

    # Direct report blockers: these are already known real-verdict surfaces.
    add_if(tactical and tactical.get('decision')!='PASS', rows, 'EP', 'reflective_not_actionable',
           'Value delivery is good, but more reflective than tactical/actionable.', 'tactical-report')
    add_if(originality and originality.get('decision')!='PASS', rows, 'OAA', 'semantic_saturation',
           'Voice feels real, but the core motif overlaps significantly with other entries.', 'originality-report')
    add_if(compact and compact.get('decision')!='PASS', rows, 'EP', 'length_or_reply_conversion',
           'The post is compelling, but length, density, or literary tone may limit mass engagement.', 'compactness-report')
    add_if(rq and rq.get('decision')!='PASS', rows, 'RQ', 'rq_not_prompt_answer',
           'Replies are relevant, but do not answer the actual prompt or advance the conversation enough.', 'rq-report')
    add_if(cta and cta.get('decision')!='PASS', rows, 'EP', 'cta_ceiling',
           'The CTA is present, but not strong enough to maximize reply generation.', 'cta-report')

    # Content heuristics if reports are absent or too permissive.
    char_len=len(content)
    long=char_len>900
    paras=[p.strip() for p in re.split(r"\n\s*\n+", content) if p.strip()]
    longest=max((len(p) for p in paras), default=0)
    literary_hits=[w for w in ['metaphor','recipe','menu','ingredients','flavor','surrender','chaos','glass','poetic'] if w in tl]
    operational_hits=[w for w in ['rule','test','process','checklist','remove','cut','rewrite','decide','choose','step','method'] if re.search(r'\b'+re.escape(w)+r'\b', tl)]

    add_if(long and longest>360, rows, 'EP', 'long_dense',
           'Strong and vivid, though slightly long/dense for casual scrollers.', 'content-heuristic', 'plausible')
    add_if(len(literary_hits)>=3 and len(operational_hits)<2, rows, 'EP', 'admire_not_reply',
           'The literary tone is memorable, but may make some users admire it more than reply.', 'content-heuristic', 'plausible')
    add_if(len(operational_hits)<1, rows, 'EP', 'no_operational_payload',
           'Value delivery is meaningful, but not actionable enough for maximum engagement.', 'content-heuristic', 'precedented')

    # RQ heuristic on combined if no rq report provided.
    if combined:
        pairs=re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```", combined, flags=re.S)
        if pairs:
            meta=sum(1 for q,a in pairs if any(m in (q+' '+a).lower() for m in ['this works because','the writing','specificity','metaphor','detail makes']))
            no_open=sum(1 for q,a in pairs if '?' not in a)
            add_if(meta>2, rows, 'RQ', 'craft_commentary',
                   'Some replies sound like craft commentary rather than campaign participation.', 'combined-heuristic', 'precedented')
            add_if(no_open>0, rows, 'RQ', 'no_open_loop',
                   'Some replies do not advance the conversation with an open-loop follow-up.', 'combined-heuristic', 'precedented')

    # Decision rules.
    severe=[r for r in rows if r['severity'] in ['deterministic','precedented']]
    plausible=[r for r in rows if r['severity']=='plausible']
    decision='PASS'
    if severe or len(plausible)>=2:
        decision='FAIL'
    elif plausible:
        decision='REVIEW'

    result={
        'tool':'rally-worst-positive-verdict-check.py',
        'generated':time.strftime('%Y-%m-%d %H:%M:%S'),
        'contentChars':char_len,
        'credibleDeductions':rows,
        'worstPositiveVerdict': rows[:],
        'decision':decision,
        'summary': 'No credible positive-but-capping deduction sentence remains.' if decision=='PASS' else 'Credible positive-but-capping deduction sentence remains.'
    }
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append('# WORST POSITIVE VERDICT CHECK\n\n')
    md.append(f'Decision: **{decision}**\n\n')
    md.append(f"Summary: {result['summary']}\n\n")
    md.append('| Gate | Key | Credible positive-but-capping sentence | Severity | Source | Fix |\n|---|---|---|---|---|---|\n')
    if rows:
        for r in rows:
            md.append(f"| {r['gate']} | {r['key']} | {r['credibleDeductionSentence']} | {r['severity']} | {r['source']} | {r['fixDecision']} |\n")
    else:
        md.append('| none | none | none | none | none | none |\n')
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f"WORST POSITIVE VERDICT CHECK: {decision} [{len(rows)} credible deductions]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
