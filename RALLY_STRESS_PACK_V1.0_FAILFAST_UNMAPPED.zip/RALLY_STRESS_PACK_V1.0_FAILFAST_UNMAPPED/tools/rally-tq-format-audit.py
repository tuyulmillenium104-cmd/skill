#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TQ format and media audit for Rally content."""
import argparse, json, re, sys, time
from pathlib import Path
BAD_CHARS=["—","–","“","”","‘","’"]
IMG_RE=re.compile(r"https?://\S+\.(?:png|jpg|jpeg|gif|webp)(?:\?\S*)?", re.I)
# Match http(s) URLs AND bare URLs (e.g. app.rally.fun, example.com/path).
# REAL-JUDGE LESSON LJ1 (2026-06-30): Twitter's linkifier and the RQ/TQ judge
# treat trailing punctuation that TOUCHES a URL as part of the URL, producing a
# malformed link (e.g. "app.rally.fun," -> link "app.rally.fun,/"). This wrecked
# a real TQ score (2/5). The old regex only matched http(s):// URLs, so bare
# domains like "app.rally.fun" were never inspected. This version catches both
# and treats trailing-punctuation-on-URL as a HARD ERROR (FAIL), not a warning.
URL_RE=re.compile(r"(?:https?://)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?:/[^\s]*)?", re.I)
# Domains we only want to flag when they look like real links (avoid matching
# ordinary sentences that happen to contain a dotted abbreviation).
_URL_HINT=re.compile(r"(?:https?://|www\.|rally\.fun|\.com|\.io|\.xyz|\.fun|\.app|\.gg|\.org|\.net)", re.I)

def _find_urls(text):
    out=[]
    for m in URL_RE.finditer(text):
        tok=m.group(0)
        if _URL_HINT.search(tok):
            # capture the character immediately AFTER the matched url token
            nxt=text[m.end():m.end()+1]
            out.append((tok, nxt))
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--content',required=True)
    ap.add_argument('--out-json',required=True)
    ap.add_argument('--out-md',required=True)
    ap.add_argument('--media-used',action='store_true')
    ap.add_argument('--media-referenced',action='store_true')
    ap.add_argument('--genre',default='auto',choices=['auto','tactical','confessional'],
                    help='tactical posts are penalized for length much harder by the real TQ judge')
    args=ap.parse_args()
    text=Path(args.content).read_text(encoding='utf-8').strip()
    lower=text.lower()
    paras=[p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    words=re.findall(r"\b\w+\b", text)
    errors=[]; warnings=[]
    bad=[ch for ch in BAD_CHARS if ch in text]
    if bad: errors.append(f"bad unicode punctuation: {bad}")
    img=IMG_RE.findall(text)
    if img: errors.append(f"raw image/media URL in body: {img[:3]}")
    url_pairs=_find_urls(text)
    urls=[u for u,_ in url_pairs]
    # LJ1: punctuation that TOUCHES the URL (no space) is read as part of the link.
    ATTACHED_PUNCT=set([',','.',';',':','/','!','?',')',']','}','>','"',"'"])
    malformed=[u for u,nxt in url_pairs if nxt in ATTACHED_PUNCT]
    if malformed:
        errors.append("URL has attached trailing punctuation (judge reads it as part of the link): "
                      + ", ".join(f'{u!r}+next' for u in malformed[:3]))
    if text[:1] in ['@','#']: errors.append('starts with mention/hashtag')
    long_paras=[len(re.findall(r"\b\w+\b", p)) for p in paras if len(re.findall(r"\b\w+\b", p))>70]
    if long_paras: warnings.append(f"dense paragraph(s) >70 words: {long_paras}")
    if len(text)>1600: warnings.append(f"longform >1600 chars: {len(text)}")
    # LJ2 (REAL-JUDGE 2026-06-30): for TACTICAL/PRODUCT posts the real TQ + EP judge
    # penalizes length ("1047-character length exceeds standard Twitter constraints").
    # Confessional/memoir longform is tolerated (winners run 1200-1850), but tactical
    # posts should aim well under ~850. Warn loudly so the writer shortens.
    if args.genre=='tactical':
        if len(text)>1050:
            errors.append(f"tactical post over hard cap: {len(text)} chars (>1050)")
        elif len(text)>850:
            warnings.append(f"tactical post over real-judge target: {len(text)} chars (>850; aim ~600-850 for TQ/EP)")
    import re as _re
    _mh=_re.search(r"@[A-Za-z0-9_]+", text)
    if _mh:
        pos=_mh.start()/max(1,len(text))*100
        if pos>80: warnings.append(f"mention late/appended risk: {pos:.1f}%")
        if pos<3: errors.append(f"mention too early/start risk: {pos:.1f}%")
    if args.media_used and not args.media_referenced:
        errors.append('media_used=true but media not referenced/explained in text')
    decision='PASS' if not errors else 'FAIL'
    result={'tool':'rally-tq-format-audit.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'genre':args.genre,'contentChars':len(text),'wordCount':len(words),'paragraphs':len(paras),'rawImageUrls':img,'urls':urls,'malformedUrls':malformed,'errors':errors,'warnings':warnings,'decision':decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# TQ FORMAT AUDIT\n\n',f'- Content chars: {len(text)}\n',f'- Words: {len(words)}\n',f'- Paragraphs: {len(paras)}\n',f'- Decision: **{decision}**\n\n','## Errors\n']
    md += [f'- {e}\n' for e in errors] or ['- none\n']
    md += ['\n## Warnings\n'] + ([f'- {w}\n' for w in warnings] or ['- none\n'])
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'TQ FORMAT AUDIT: {decision} [{len(errors)} errors, {len(warnings)} warnings]')
    sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__': main()
