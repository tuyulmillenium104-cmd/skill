#!/usr/bin/env python3
import json, re, argparse, pathlib, collections, math

CAT_TO_GATE = {
    'Originality and Authenticity': 'OAA',
    'Content Alignment': 'CA',
    'Information Accuracy': 'IA',
    'Campaign Compliance': 'CC',
    'Engagement Potential': 'EP',
    'Technical Quality': 'TQ',
    'Reply Quality': 'RQ',
}
DEDUCTION_CUES = re.compile(r"\b(however|but|although|while|though|could|would benefit|benefit from|lacks?|limited|weaker|weak|minor|somewhat|not fully|does not|doesn't|did not|didn't|missing|reduce|reduces|risk|issue|drawback|generic|dense|length|long|implicit|rather than|fails?|diluted|capped|cap|overly|less|no direct|not especially|moderate|under|needs?|should)\b", re.I)

CLASS_PATTERNS = [
    ('cta_reply_engine', r'\b(cta|call[- ]to[- ]action|reply|replies|comment|conversation|engage|engagement|question|prompt|invite|interaction|low[- ]friction|respond)\b'),
    ('hook_stop_power', r'\b(hook|opening|first line|attention|stop|scroll|grab|magnetic|compelling|curiosity|intrigue|headline)\b'),
    ('readthrough_density', r'\b(dense|density|long|length|readability|read[- ]through|completion|paragraph|structure|format|scannable|digestible|clutter|skim|pacing)\b'),
    ('concrete_specificity', r'\b(concrete|specific|specificity|example|use case|detail|scenario|receipt|proof|case|story|anecdote|real[- ]world)\b'),
    ('mechanism_clarity', r'\b(mechanism|how it works|works|explain|explains|understand|clarity|technical|process|workflow|interface|pipeline|stack|protocol|layer)\b'),
    ('tactical_value_payload', r'\b(actionable|practical|tactical|useful|value|takeaway|rule|test|checklist|method|educational|bookmark|save)\b'),
    ('distinctiveness_saturation', r'\b(generic|formulaic|template|templated|cliche|similar|overlap|distinct|original|authentic|ai[- ]generated|derivative|common|familiar|standard)\b'),
    ('brand_bridge_promotional', r'\b(promotional|brand|mention|tag|product pitch|marketing|campaign|launch|hype|sales)\b'),
    ('accuracy_claim_boundary', r'\b(accuracy|accurate|claim|misleading|unsupported|overstate|overstates|factual|fact|context|knowledge base|kb)\b'),
    ('media_format_technical', r'\b(media|image|visual|format|punctuation|grammar|spelling|quote tweet|thread|hashtag|em dash|link)\b'),
    ('rq_reply_quality', r'\b(replies|reply quality|low[- ]effort|platitude|spam|substantive|subject[- ]matter|constructive|generic praise|dilute|dilution)\b'),
]

KNOWN_SKILL_CLASSES = set([
    'cta_reply_engine','hook_stop_power','readthrough_density','concrete_specificity','mechanism_clarity',
    'tactical_value_payload','distinctiveness_saturation','brand_bridge_promotional','accuracy_claim_boundary',
    'media_format_technical','rq_reply_quality'
])

def sent_split(text):
    # Conservative sentence split; keeps enough context.
    parts = re.split(r'(?<=[.!?])\s+(?=[A-Z"\'`])|\n+', text.strip())
    return [p.strip() for p in parts if len(p.strip()) > 20]

def classify(s):
    hits=[]
    for name, pat in CLASS_PATTERNS:
        if re.search(pat, s, re.I): hits.append(name)
    return hits or ['unknown_or_nuance']

def score_float(analysis_item):
    try:
        sc=int(analysis_item.get('atto_score','0'))/1e18
        mx=int(analysis_item.get('atto_max_score','0'))/1e18
        return sc,mx
    except Exception:
        return None,None

def gate_score(s, gate):
    g=s.get('gates') or {}
    if gate in g and isinstance(g[gate],list) and g[gate]: return float(g[gate][0])
    return None

def extract(subs):
    rows=[]
    for sub in subs:
        author=sub.get('xUsername')
        winner=bool(sub.get('winner'))
        allmax=bool(sub.get('allMax'))
        content=sub.get('content') or ''
        for item in sub.get('analysis') or []:
            cat=item.get('category')
            gate=CAT_TO_GATE.get(cat,cat)
            sc,mx=score_float(item)
            text=item.get('analysis') or ''
            gscore=gate_score(sub,gate)
            # Deduction candidates: score below max, or cue words in sentence.
            for sent in sent_split(text):
                cue=bool(DEDUCTION_CUES.search(sent))
                if (sc is not None and mx is not None and sc < mx) or cue:
                    rows.append({
                        'author':author,'winner':winner,'allMax':allmax,'gate':gate,'category':cat,
                        'score':sc,'max':mx,'gateScore':gscore,'sentence':sent,
                        'classes':classify(sent),'contentStart':content[:220]
                    })
    return rows

def summarize(rows, subs):
    by_class=collections.Counter()
    by_gate_class=collections.Counter()
    examples=collections.defaultdict(list)
    nonwinner=collections.Counter(); winner=collections.Counter(); ep_lt5=collections.Counter(); ep5=collections.Counter()
    for r in rows:
        for cl in r['classes']:
            by_class[cl]+=1
            by_gate_class[(r['gate'],cl)]+=1
            if len(examples[(r['gate'],cl)])<8: examples[(r['gate'],cl)].append(r)
            if r['winner']: winner[cl]+=1
            else: nonwinner[cl]+=1
            if r['gate']=='EP':
                if (r.get('gateScore') or 0) >=5: ep5[cl]+=1
                else: ep_lt5[cl]+=1
    return by_class, by_gate_class, examples, nonwinner, winner, ep_lt5, ep5

def winner_positive_patterns(subs):
    # Mine positive sentences in allMax/winners without deduction cues.
    pos=[]
    for sub in subs:
        if not sub.get('winner'): continue
        for item in sub.get('analysis') or []:
            gate=CAT_TO_GATE.get(item.get('category'),item.get('category'))
            text=item.get('analysis') or ''
            for sent in sent_split(text):
                if not DEDUCTION_CUES.search(sent):
                    if any(w in sent.lower() for w in ['strong','effective','clear','specific','original','authentic','engag','conversation','value','concrete','hook','cta','question','technical','mechanism','structure']):
                        pos.append({'author':sub.get('xUsername'),'gate':gate,'sentence':sent,'classes':classify(sent)})
    return pos

def write_reports(subs, rows, outbase, mission):
    outbase=pathlib.Path(outbase); outbase.mkdir(parents=True, exist_ok=True)
    by_class, by_gate_class, examples, nonwinner, winner, ep_lt5, ep5 = summarize(rows, subs)
    pos=winner_positive_patterns(subs)
    data={'mission':mission,'submissionCount':len(subs),'winnerCount':sum(1 for s in subs if s.get('winner')),
          'deductionRows':rows,'classCounts':dict(by_class),'gateClassCounts':{f'{g}::{c}':n for (g,c),n in by_gate_class.items()},
          'nonwinnerClassCounts':dict(nonwinner),'winnerClassCounts':dict(winner),'epLt5ClassCounts':dict(ep_lt5),'ep5ClassCounts':dict(ep5),'winnerPositiveRows':pos[:300]}
    (outbase/'hidden-gate-candidates.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append(f'# Hidden Gate Candidate Map - {mission}\n\n')
    md.append(f'- Submissions: {len(subs)}\n- Winners: {sum(1 for s in subs if s.get("winner"))}\n- Deduction candidate sentences: {len(rows)}\n\n')
    md.append('## Top candidate classes\n\n')
    md.append('| Class | Total | Non-winner | Winner | EP<5 | EP5 | Manual status |\n|---|---:|---:|---:|---:|---:|---|\n')
    for cl,n in by_class.most_common(20):
        status='KNOWN' if cl in KNOWN_SKILL_CLASSES else 'REVIEW/UNKNOWN'
        md.append(f'| {cl} | {n} | {nonwinner[cl]} | {winner[cl]} | {ep_lt5[cl]} | {ep5[cl]} | {status} |\n')
    md.append('\n## Gate x class counts\n\n')
    for (gate,cl),n in by_gate_class.most_common(40):
        md.append(f'- **{gate} / {cl}**: {n}\n')
    md.append('\n## Evidence examples by gate/class\n')
    for (gate,cl),exs in sorted(examples.items(), key=lambda kv:(kv[0][0],kv[0][1])):
        if len(exs)==0: continue
        md.append(f'\n### {gate} / {cl}\n')
        for e in exs[:5]:
            flag='WIN' if e['winner'] else 'NONWIN'
            gs=e.get('gateScore')
            md.append(f'- @{e["author"]} [{flag}, gateScore={gs}]: {e["sentence"]}\n')
    md.append('\n## Winner positive patterns (sample)\n')
    for p in pos[:40]:
        md.append(f'- @{p["author"]} [{p["gate"]}]: {p["sentence"]}\n')
    (outbase/'HIDDEN-GATE-CANDIDATES.md').write_text(''.join(md),encoding='utf-8')

    # Manual review scaffold with suggested accepted rules based on class prevalence.
    rev=[]
    rev.append(f'# Hidden Gate Manual Review - {mission}\n\n')
    rev.append('## Manual interpretation\n\n')
    rev.append('Use this file to decide which tool-mined candidates become drafting law. Do not blindly convert every phrase into a hard rule.\n\n')
    rev.append('## High-confidence hidden/mission gates to enforce pre-draft\n\n')
    # generic suggested rules from observed classes
    suggestions=[]
    if by_class['cta_reply_engine']>0: suggestions.append(('CTA reply engine','CTA must be direct, answerable in under 5 seconds, and use concrete options tied to the thesis.'))
    if by_class['readthrough_density']>0: suggestions.append(('Read-through density','Use short paragraphs; avoid mini-essay density unless each extra line adds concrete mechanism or tension.'))
    if by_class['concrete_specificity']>0: suggestions.append(('Concrete scenario','Use one specific scenario with receipts/proof/details; abstract stack language alone is not enough.'))
    if by_class['mechanism_clarity']>0: suggestions.append(('Mechanism clarity','Explain what the protocol/interface actually carries or decides, not only why it matters.'))
    if by_class['distinctiveness_saturation']>0: suggestions.append(('Pool distinctiveness','Avoid crowded frames unless adding a concrete twist; compare against nearest non-winner openings before drafting.'))
    if by_class['tactical_value_payload']>0: suggestions.append(('Actionable value','Include a rule/test/checklist that a reader can apply to an agent deal.'))
    for name,rule in suggestions:
        rev.append(f'### {name}\n- Tool evidence count: {by_class[name.lower().replace("-","_").replace(" ","_")] if False else "see candidate map"}\n- Manual decision: ACCEPT\n- Drafting rule: {rule}\n- Rebuild trigger: a fair judge could write a positive-but-capping sentence about this.\n\n')
    rev.append('## Candidate class decisions\n\n')
    rev.append('Every candidate must receive both a manual decision and a scope. Default scope is MISSION_ONLY.\n\n')
    for cl,n in by_class.most_common(15):
        rev.append(f'### {cl}\n- Count: {n}\n- Non-winner: {nonwinner[cl]}\n- Winner: {winner[cl]}\n- Manual decision: ACCEPT / REJECT / WATCH\n- Scope: GLOBAL / CAMPAIGN_FAMILY / CAMPAIGN_ONLY / MISSION_ONLY\n- Reason:\n- Rule to add if accepted:\n- Example fail:\n- Example pass:\n- Promotion evidence needed if broader than MISSION_ONLY:\n\n')
    (outbase/'HIDDEN-GATE-MANUAL-REVIEW.md').write_text(''.join(rev),encoding='utf-8')

    contract=[]
    contract.append(f'# PRE-DRAFT HIDDEN-GATE CONTRACT STUB - {mission}\n\n')
    contract.append('Fill this manually after reviewing `HIDDEN-GATE-CANDIDATES.md`. Do not promote mission rules globally without evidence.\n\n')
    contract.append('## Accepted hidden gates for this mission\n\n')
    contract.append('| Rule | Scope | Evidence | Why it applies now |\n|---|---|---|---|\n')
    contract.append('|  | MISSION_ONLY |  |  |\n\n')
    contract.append('## Drafting rules for this mission\n\n- \n\n')
    contract.append('## Watch-only risks\n\n- \n\n')
    contract.append('## Rebuild triggers\n\n- \n')
    (outbase/'PRE-DRAFT-HIDDEN-GATE-CONTRACT.stub.md').write_text(''.join(contract),encoding='utf-8')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--submissions',required=True)
    ap.add_argument('--mission',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    subs=json.load(open(args.submissions,encoding='utf-8'))
    rows=extract(subs)
    write_reports(subs, rows, args.out, args.mission)
    print(f'hidden gate mining complete: {args.mission}, submissions={len(subs)}, rows={len(rows)}, out={args.out}')

if __name__=='__main__': main()
