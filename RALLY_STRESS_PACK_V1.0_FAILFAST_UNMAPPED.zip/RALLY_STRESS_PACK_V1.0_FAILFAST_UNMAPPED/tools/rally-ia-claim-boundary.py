#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Campaign-specific IA claim boundary audit."""
import argparse,json,re,sys,time
from pathlib import Path
RISK=['guaranteed','guarantee','profit','roi','100x','fully transparent','perfectly fair','cannot be biased','will make you','income','assured','automatic win','guaranteed whitelist']
TECH=['validators','nodes','on-chain ai','democratic vote','zk proof','smart contract automatically judges','public model reasoning','cross validation']

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--content',required=True); ap.add_argument('--campaign',required=True); ap.add_argument('--out-json',required=True); ap.add_argument('--out-md',required=True); args=ap.parse_args()
    text=Path(args.content).read_text(encoding='utf-8').strip(); tl=text.lower(); c=json.load(open(args.campaign,encoding='utf-8'))
    kb=' '.join(str(c.get(k,'')) for k in ['goal','knowledgeBase','style','rules']).lower()
    for m in c.get('missions',[]): kb += ' '+str(m.get('description','')).lower()+' '+str(m.get('rules','')).lower()
    errors=[]; warnings=[]
    risk_hits=[r for r in RISK if r in tl]
    if risk_hits: errors.append(f'guarantee/overclaim terms: {risk_hits}')
    tech_hits=[t for t in TECH if t in tl and t not in kb]
    if tech_hits: warnings.append(f'technical terms not evident in KB, verify manually: {tech_hits}')
    nums=re.findall(r"\b\d+(?:\.\d+)?\s*(?:k|m|%|x)?\b", tl)
    num_risk=[n for n in nums if n not in kb]
    if num_risk: warnings.append(f'numbers not found in KB text: {num_risk}')
    # absolute superlatives
    if re.search(r"\b(first|only|best|single most|completely|fully)\b", tl):
        warnings.append('absolute/superlative wording present, verify against KB')
    decision='PASS' if not errors else 'FAIL'
    result={'tool':'rally-ia-claim-boundary.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'riskHits':risk_hits,'technicalWarnings':tech_hits,'numbers':nums,'numberWarnings':num_risk,'warnings':warnings,'errors':errors,'decision':decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# IA CLAIM BOUNDARY AUDIT\n\n',f'- Decision: **{decision}**\n\n','## Errors\n']+([f'- {e}\n' for e in errors] or ['- none\n'])+['\n## Warnings\n']+([f'- {w}\n' for w in warnings] or ['- none\n'])
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'IA CLAIM AUDIT: {decision} [{len(errors)} errors, {len(warnings)} warnings]')
    sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__': main()
