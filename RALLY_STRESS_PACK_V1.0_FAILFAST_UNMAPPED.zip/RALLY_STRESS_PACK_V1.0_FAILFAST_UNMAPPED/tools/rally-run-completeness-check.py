#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run completeness checker for strict/apex/irreducible workflows."""
import argparse, json, sys, time
from pathlib import Path

BASE_REQUIRED=['content.txt']
CONTENT_REPORTS=['reports/compliance.txt','reports/cta.json','reports/tactical-value.json','reports/compactness.json','reports/loser-dna.json','reports/originality.json','reports/tq.json','reports/oaa.json','reports/ia.json','reports/ep-semantic.json','reports/worst-positive.json']
QNA_REQUIRED=['combined.md','qa_ranking.json','reports/rq-prompt-answer.json','reports/rq-mechanics.json','reports/naturalness.json','reports/qna-gold.json','reports/rq-gold-v3-policy.json']
IRREDUCIBLE=['IRREDUCIBLE_APEX_REPORT.md']
APEX=['EXPONENTIAL-CONTENT-REPORT.md']
DATA_ARTIFACTS=['hidden-gates/HIDDEN-GATE-CANDIDATES.md','winner-pull/WINNER-PULL-MAP.md']
OPTIONAL_MANUAL=['artifacts/ORIGINAL-THESIS.md','artifacts/THESIS-OBJECT-CANDIDATES.md','artifacts/DATA-JUDGE-REVIEW.md']

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--run-dir', required=True)
    ap.add_argument('--require-qna', action='store_true')
    ap.add_argument('--require-apex', action='store_true')
    ap.add_argument('--require-irreducible', action='store_true')
    ap.add_argument('--require-data-artifacts', action='store_true')
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    root=Path(args.run_dir)
    required=list(BASE_REQUIRED)+CONTENT_REPORTS
    if args.require_qna: required+=QNA_REQUIRED
    if args.require_apex: required+=APEX
    if args.require_irreducible: required+=IRREDUCIBLE
    if args.require_data_artifacts: required+=DATA_ARTIFACTS
    missing=[p for p in required if not (root/p).exists()]
    present=[p for p in required if (root/p).exists()]
    # Check json decisions if possible
    bad=[]
    for p in present:
        if p.endswith('.json'):
            try:
                data=json.load(open(root/p,encoding='utf-8'))
                dec=data.get('decision')
                if dec and dec not in ['PASS']:
                    bad.append({'file':p,'decision':dec})
            except Exception:
                pass
    decision='PASS' if not missing and not bad else 'FAIL'
    result={'tool':'rally-run-completeness-check.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'runDir':str(root),'required':required,'present':present,'missing':missing,'badDecisions':bad,'decision':decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# RUN COMPLETENESS CHECK\n\n',f'Decision: **{decision}**\n\n',f'- Required files: {len(required)}\n- Present: {len(present)}\n- Missing: {len(missing)}\n- Bad decisions: {len(bad)}\n\n']
    md.append('## Missing\n'); md += [f'- {m}\n' for m in missing] or ['- none\n']
    md.append('\n## Bad decisions\n'); md += [f'- {b}\n' for b in bad] or ['- none\n']
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'RUN COMPLETENESS CHECK: {decision} [missing={len(missing)}, bad={len(bad)}]')
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
