#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Human-typed public copy audit.

Detects public-copy style smells: label-colon shells, audit voice, internal leakage,
and repetitive generated patterns in content / Q&A bodies.
"""
import argparse, json, re, sys, time
from pathlib import Path
from collections import Counter

INTERNAL_RE=re.compile(r"\b(5[- ]gram|loser[- ]DNA|qa_ranking|voicePersona|voiceMode|SIMULATED_ARCHETYPE|CONDITIONAL_ORGANIC_MATCH_ONLY|self[- ]judge|meta[- ]judge|Gold\s*V3|policy checker|prompt-answer checker|mechanics checker|naturalness checker|gold audit|internal audit)\b", re.I)
LABEL_RE=re.compile(r"^\s*(My concern|My answer|My decision|Hot take|Wrong lesson|Metadata|Persona|Type|Tier|Score|Audit)\s*:", re.I)
AUDIT_VOICE_RE=re.compile(r"\b(mechanism clarity|CTA alignment|decision-marker|semantic saturation|gate pass|fails? the checker|rubric|score probability|policy check|naturalness variance)\b", re.I)
SUPPORT_OPEN_RE=re.compile(r"^(Great question|Exactly\.|Yes,|Agreed\.|That is exactly|That is the right|Fair point\.)", re.I)
# Real Rally verdict lesson 2026-07-18: even substantive replies can get RQ capped
# when many replies share the same public shell (e.g. 'My concern is...',
# 'My decision is...', repeated @mention starts). These are public-copy smells,
# not just checker-style issues.
FORMULA_Q_START_RE=re.compile(r"(?:\bmy concern is\b|\bmy decision is\b|\bmy answer is\b|^\s*hot take[, ]|^\s*the wrong lesson|^\s*i would argue\b|^\s*i would lead\b|^\s*i would pick\b|^\s*i would choose\b)", re.I)
MENTION_START_RE=re.compile(r"^\s*@[a-z0-9_]+\b", re.I)

def pairs(text):
    pat=re.compile(r"(?P<head>^#{2,4}[^\n]*?)\n\s*\*\*Q-COPY\*\*\s*```text\n(?P<q>.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(?P<a>.*?)\n```", re.S|re.M)
    return [{'idx':i,'heading':m.group('head'),'q':m.group('q').strip(),'a':m.group('a').strip()} for i,m in enumerate(pat.finditer(text),1)]

def first_words(t,n=4):
    return ' '.join(re.findall(r"[A-Za-z0-9']+", t.lower())[:n])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--content', default=None)
    ap.add_argument('--combined', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    ap.add_argument('--strict', action='store_true', help='exit 1 on REVIEW')
    args=ap.parse_args()
    findings=[]; warnings=[]; rows=[]
    content=Path(args.content).read_text(encoding='utf-8') if args.content else ''
    combined=Path(args.combined).read_text(encoding='utf-8') if args.combined else ''
    if content:
        for i,line in enumerate([l.strip() for l in content.splitlines() if l.strip()],1):
            if INTERNAL_RE.search(line): findings.append({'where':'content','idx':i,'type':'internal_leakage','text':line})
            if LABEL_RE.search(line): warnings.append({'where':'content','idx':i,'type':'label_colon','text':line})
            if AUDIT_VOICE_RE.search(line): warnings.append({'where':'content','idx':i,'type':'audit_voice','text':line})
    ps=pairs(combined) if combined else []
    q_open=[]; a_open=[]; formula_q=[]; mention_start_count=0
    for r in ps:
        q,a=r['q'],r['a']; q_open.append(first_words(q,4)); a_open.append(first_words(a,4))
        fm=FORMULA_Q_START_RE.search(q)
        if fm: formula_q.append(fm.group(0).lower().strip())
        if MENTION_START_RE.search(q): mention_start_count += 1
        row={'idx':r['idx'],'qWarnings':[],'aWarnings':[],'qFindings':[],'aFindings':[]}
        for label,text,store_f,store_w in [('q',q,row['qFindings'],row['qWarnings']),('a',a,row['aFindings'],row['aWarnings'])]:
            if INTERNAL_RE.search(text): store_f.append('internal_leakage')
            if LABEL_RE.search(text): store_w.append('label_colon')
            if AUDIT_VOICE_RE.search(text): store_w.append('audit_voice')
            if label=='a' and SUPPORT_OPEN_RE.search(text): store_w.append('support_style_opening_review')
        rows.append(row)
    # Real-judge formula warnings: repeated public shells make replies feel coordinated.
    for shell,count in Counter(formula_q).items():
        if count>=3:
            warnings.append({'where':'qna','type':'real_judge_formula_q_shell','shell':shell,'count':count,'lesson':'Real Rally RQ verdict capped formulaic reply set despite substance'})
    if len(ps) and mention_start_count/max(1,len(ps)) > 0.25:
        warnings.append({'where':'qna','type':'repeated_mention_start','count':mention_start_count,'pct':round(mention_start_count/max(1,len(ps)),3),'lesson':'Real Rally RQ verdict flagged too many replies starting with same mention'})
    # repetition warnings
    for shell,count in Counter(q_open).items():
        if shell and count>=3: warnings.append({'where':'qna','type':'repeated_q_shell','shell':shell,'count':count})
    for shell,count in Counter(a_open).items():
        if shell and count>=3: warnings.append({'where':'qna','type':'repeated_a_shell','shell':shell,'count':count})
    for row in rows:
        if row['qFindings'] or row['aFindings']:
            findings.append({'where':'qna','idx':row['idx'],'type':'internal_leakage','q':row['qFindings'],'a':row['aFindings']})
        if row['qWarnings'] or row['aWarnings']:
            warnings.append({'where':'qna','idx':row['idx'],'type':'style_review','q':row['qWarnings'],'a':row['aWarnings']})
    decision='FAIL' if findings else ('REVIEW' if warnings else 'PASS')
    result={'tool':'rally-human-typed-audit.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'pairCount':len(ps),'findingCount':len(findings),'warningCount':len(warnings),'findings':findings,'warnings':warnings[:200],'decision':decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# HUMAN-TYPED PUBLIC COPY AUDIT\n\n',f'Decision: **{decision}**\n\n',f'- Findings: {len(findings)}\n- Warnings: {len(warnings)}\n- Q&A pairs: {len(ps)}\n\n']
    md.append('## Findings\n')
    md += [f'- {f}\n' for f in findings] or ['- none\n']
    md.append('\n## Warnings / style review\n')
    md += [f'- {w}\n' for w in warnings[:80]] or ['- none\n']
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'HUMAN-TYPED AUDIT: {decision} [findings={len(findings)}, warnings={len(warnings)}]')
    if decision=='FAIL' or (args.strict and decision!='PASS'):
        sys.exit(1)

if __name__=='__main__': main()
