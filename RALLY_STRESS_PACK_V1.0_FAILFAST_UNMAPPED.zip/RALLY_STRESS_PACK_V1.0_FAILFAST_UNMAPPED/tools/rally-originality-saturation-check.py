#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Originality Saturation / OAA semantic motif checker.

Real verdict lesson: a post can feel personal and well-written but still receive OAA 1/2
if its core trade and progression overlap with many other submissions. Lexical uniqueness
is not enough; semantic motif saturation must be checked before final.
"""
import argparse, json, re, sys, time
from pathlib import Path
from collections import Counter, defaultdict

MOTIFS = {
    "hidden_private_to_public_proof": [
        "private", "group chat", "hidden", "invisible", "unseen", "public", "proof", "evidence",
        "publish", "post", "share", "score", "visible", "proof trail", "creating in public", "publicly"
    ],
    "comfort_zone_to_growth": ["comfort", "comfortable", "safe", "safety", "stagnant", "growth", "grow", "faster", "progress"],
    "money_vs_values": ["money", "salary", "pay", "paid", "fund", "financial", "values", "integrity", "style", "committee"],
    "family_relationship_boundary": ["family", "relationship", "love", "partner", "sibling", "parent", "boundary", "self", "myself"],
    "certainty_performance_identity": ["certainty", "perform", "predictable", "identity", "personal brand", "audience", "version of myself"],
    "creator_content_extraction": ["content", "creator", "audience", "monetize", "brand", "story", "material", "views", "engagement"],
    "craft_perfection_delay": ["draft", "edit", "rewrite", "paragraph", "unfinished", "craft", "perfect", "publish earlier"],
}

PROGRESSION_MARKERS = {
    "comfort_or_safety_identified": ["comfort", "safe", "safety", "private", "hidden", "unseen"],
    "trade_named": ["my trade", "the trade", "trade is", "exchange", "giving up", "i stop", "i would stop"],
    "rally_tag_context": ["@"],
    "reflective_question_close": ["?"],
    "public_proof_gain": ["public", "proof", "evidence", "visible", "score", "trail"],
}

STOP=set('the a an and or but to of in on for with is are was were be been being it this that as at by from you your i my me we they them if not just more most no one do does did into about how why what when where who'.split())

def tokens(text):
    return [x for x in re.findall(r"[a-z0-9@']+", (text or '').lower()) if len(x)>2 and x not in STOP]

def classify_motifs(text):
    tl=(text or '').lower()
    found=[]
    evidence={}
    for motif, words in MOTIFS.items():
        hits=[w for w in words if w in tl]
        # Require at least 3 signals, except rare exact phrases count strongly.
        exact_strong=[w for w in hits if ' ' in w]
        if len(hits)>=3 or exact_strong:
            found.append(motif); evidence[motif]=hits
    return found, evidence

def progression(text):
    tl=(text or '').lower()
    res={}
    for k, words in PROGRESSION_MARKERS.items():
        res[k]=[w for w in words if w in tl]
    count=sum(bool(v) for v in res.values())
    return res, count

def jaccard(a,b):
    sa=set(tokens(a)); sb=set(tokens(b))
    if not sa or not sb: return 0
    return len(sa&sb)/len(sa|sb)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--content', required=True)
    ap.add_argument('--submissions', required=True)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()

    content=Path(args.content).read_text(encoding='utf-8').strip()
    subs=json.load(open(args.submissions, encoding='utf-8'))
    motif, ev=classify_motifs(content)
    prog, prog_count=progression(content)

    corpus_counts=Counter(); corpus_samples=defaultdict(list)
    for s in subs:
        m,_=classify_motifs(s.get('content') or '')
        for mm in m:
            corpus_counts[mm]+=1
            if len(corpus_samples[mm])<8:
                corpus_samples[mm].append({
                    'author':s.get('xUsername'),
                    'winner':bool(s.get('winner')),
                    'ep':(s.get('gates') or {}).get('EP',[None])[0],
                    'text':(s.get('content') or '')[:240]
                })

    nearest=[]
    for s in subs:
        st=s.get('content') or ''
        sim=jaccard(content,st)
        if sim>0:
            nearest.append({
                'author':s.get('xUsername'), 'winner':bool(s.get('winner')),
                'ep':(s.get('gates') or {}).get('EP',[None])[0],
                'oaa':(s.get('gates') or {}).get('OAA',[None])[0],
                'sim':round(sim,3), 'text':st[:240]
            })
    nearest=sorted(nearest,key=lambda x:x['sim'],reverse=True)[:12]

    saturated=[]
    for m in motif:
        count=corpus_counts[m]
        pct=count/max(1,len(subs))
        if count>=8 or pct>=0.08:
            saturated.append({'motif':m,'count':count,'pct':round(pct,3),'evidence':ev.get(m,[])})

    template_risk = prog_count >= 4
    reasons=[]
    if saturated:
        reasons.append('core semantic motif saturated in mission pool')
    if template_risk:
        reasons.append('progression mirrors a common campaign pattern too closely')
    if nearest and nearest[0]['sim']>=0.14:
        reasons.append('high lexical/semantic nearest-neighbor similarity')

    # FAIL is strong saturation + template, REVIEW if only one risk.
    decision='PASS'
    if saturated and template_risk:
        decision='FAIL'
    elif saturated or template_risk or (nearest and nearest[0]['sim']>=0.14):
        decision='REVIEW'

    result={
        'tool':'rally-originality-saturation-check.py',
        'generated':time.strftime('%Y-%m-%d %H:%M:%S'),
        'contentChars':len(content),
        'contentMotifs':motif,
        'motifEvidence':ev,
        'saturatedMotifs':saturated,
        'progressionMarkers':prog,
        'progressionMarkerCount':prog_count,
        'templateRisk':template_risk,
        'corpusMotifCounts':dict(corpus_counts),
        'nearest':nearest,
        'decision':decision,
        'reasons':reasons,
    }
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')

    md=[]
    md.append('# ORIGINALITY SATURATION CHECK\n\n')
    md.append(f'Decision: **{decision}**\n\n')
    md.append('## Reasons\n')
    md += [f'- {r}\n' for r in reasons] or ['- clear\n']
    md.append('\n## Content Motifs\n')
    for m in motif: md.append(f'- {m}: {ev.get(m)}\n')
    md.append('\n## Saturated Motifs\n')
    if saturated:
        for s in saturated: md.append(f"- {s['motif']}: {s['count']} submissions ({s['pct']*100:.1f}%) evidence={s['evidence']}\n")
    else: md.append('- none\n')
    md.append('\n## Progression Markers\n')
    for k,v in prog.items(): md.append(f'- {k}: {bool(v)} {v}\n')
    md.append('\n## Nearest Samples\n')
    for n in nearest[:8]:
        md.append(f"- @{n['author']} sim={n['sim']} winner={n['winner']} EP={n['ep']} OAA={n['oaa']} - {n['text']}\n")
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f"ORIGINALITY SATURATION CHECK: {decision} [{', '.join(reasons) if reasons else 'clear'}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
