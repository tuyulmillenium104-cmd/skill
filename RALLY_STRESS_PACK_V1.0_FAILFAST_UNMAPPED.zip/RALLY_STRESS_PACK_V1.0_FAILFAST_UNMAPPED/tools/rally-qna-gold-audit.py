#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gold V3 QnA audit: type distribution, Q/A quality heuristics, and no metadata in Q."""
import argparse, sys, time
from collections import Counter
from _rq_gold_common import *


def score_q(row, content):
    q=row['q']; typ=row.get('type')
    score=5; reasons=[]
    if not (160 <= len(q) <= 260): score-=1; reasons.append('Q length outside 160-260')
    if METADATA_RE.search(q): score=1; reasons.append('metadata/internal label inside Q')
    if GENERIC_FAQ_RE.search(q): score-=2; reasons.append('generic FAQ framing')
    if JOURNALIST_RE.search(q): score-=2; reasons.append('journalist framing')
    if LOW_EFFORT_RE.search(q): score-=2; reasons.append('low-effort phrase')
    if not (FIRST_PERSON_RE.search(q) or SKEPTIC_RE.search(q) or ANECDOTE_RE.search(q) or has_decision_word(q)): score-=1; reasons.append('no opinion/stake/experience')
    if not (cta_aligned(q, content) or exact_quote_from_content(q, content) or MECHANIC_RE.search(q)): score-=1; reasons.append('not tied to post/CTA/mechanism')
    if typ=='Specific Probe' and not exact_quote_from_content(q, content): score-=2; reasons.append('Specific Probe lacks exact source quote')
    if typ=='Challenge' and not SKEPTIC_RE.search(q): score-=1; reasons.append('Challenge lacks precise doubt/skeptic marker')
    if typ=='Technical Deep-Dive' and not MECHANIC_RE.search(q): score-=1; reasons.append('Technical Deep-Dive lacks bounded mechanism')
    if typ=='Hot Take' and not re.search(r"\b(overrated|underrated|hot take|wrong|bigger|smaller|real issue|real alpha|thesis|instead|actually)\b", q, re.I): score-=1; reasons.append('Hot Take lacks bold/alternative thesis')
    if typ=='Real Experience' and not ANECDOTE_RE.search(q): score-=1; reasons.append('Real Experience lacks mini-story surface')
    return max(1,min(5,score)), reasons


def score_a(a):
    score=5; reasons=[]
    words=len(a.split())
    if len(a)>280: score=1; reasons.append('A >280 chars')
    if '\n' in a: score-=1; reasons.append('A not one line')
    if words < 25: score-=1; reasons.append('A too thin')
    if not has_decision_word(a): score-=1; reasons.append('A lacks decision/action word')
    if LOW_EFFORT_RE.search(a): score-=2; reasons.append('A low-effort phrase')
    if FORMAL_RE.search(a): score-=1; reasons.append('A formal/abstract register')
    return max(1,min(5,score)), reasons


def score_feel(q,a):
    score=5; reasons=[]
    if METADATA_RE.search(q) or METADATA_RE.search(a): score=1; reasons.append('public copy contains internal label')
    if GENERIC_FAQ_RE.search(q) or JOURNALIST_RE.search(q): score-=2; reasons.append('not a natural reply')
    if not (CONTRACTIONS_RE.search(q+' '+a) or FIRST_PERSON_RE.search(q+' '+a) or SKEPTIC_RE.search(q+' '+a) or ANECDOTE_RE.search(q+' '+a)): score-=1; reasons.append('flat/non-personal voice')
    if a.startswith(('Yes,','Absolutely','Great question','That is a great question')): score-=1; reasons.append('support-style answer opening')
    return max(1,min(5,score)), reasons


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--combined', required=True)
    ap.add_argument('--content', required=True)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    content=read(args.content).strip(); combined=read(args.combined); rows=parse_pairs(combined)
    failures=[]; out_rows=[]; type_counts=Counter()
    for r in rows:
        typ=r.get('type') or normalize_type(r.get('heading',''))
        r['type']=typ
        if typ: type_counts[typ]+=1
        qscore,qreasons=score_q(r, content)
        ascore,areasons=score_a(r['a'])
        fscore,freasons=score_feel(r['q'],r['a'])
        ok=qscore>=4 and ascore>=4 and fscore>=4
        if not ok: failures.append(f"R{r['idx']}: Q={qscore}, A={ascore}, Feel={fscore}; "+'; '.join(qreasons+areasons+freasons))
        out_rows.append({'idx':r['idx'],'type':typ,'qChars':len(r['q']),'aChars':len(r['a']),'qScore':qscore,'aScore':ascore,'feelScore':fscore,'decision':'PASS' if ok else 'FAIL','reasons':qreasons+areasons+freasons})
    reasons=[]
    if len(rows)!=20: reasons.append(f'pair count {len(rows)} != 20')
    for typ,need in EXPECTED_TYPES.items():
        if type_counts.get(typ,0)!=need:
            reasons.append(f'type distribution {typ}: {type_counts.get(typ,0)} != {need}')
    if failures: reasons.append(f'{len(failures)} pairs have Q/A/Feel score below 4')
    # duplicate/formula checks
    qdupes=[q for q,c in Counter([r['q'].strip().lower() for r in rows]).items() if c>1]
    if qdupes: reasons.append(f'exact duplicate Q count {len(qdupes)} > 0')
    adupes=[a for a,c in Counter([r['a'].strip().lower() for r in rows]).items() if c>1]
    if adupes: reasons.append(f'exact duplicate A groups {len(adupes)} > 0')
    def firstn(t,n): return ' '.join(re.findall(r"[A-Za-z0-9']+", t.lower())[:n])
    a5=[firstn(r['a'],5) for r in rows]
    if a5:
        max_a5=max(Counter(a5).values())
        if max_a5/max(1,len(rows)) > 0.15:
            reasons.append(f'same A first-5-word shell {max_a5}/{len(rows)} > 15%')
    a3=[firstn(r['a'],3) for r in rows]
    for i in range(len(a3)-2):
        if a3[i] and a3[i]==a3[i+1]==a3[i+2]:
            reasons.append(f'3 adjacent A openings repeat at R{i+1}-R{i+3}')
            break
    decision='PASS' if not reasons else 'FAIL'
    result={'tool':'rally-qna-gold-audit.py','standard':'Gold V3.1.3','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'contentChars':len(content),'pairCount':len(rows),'typeCounts':dict(type_counts),'expectedTypes':EXPECTED_TYPES,'rows':out_rows,'failures':failures,'decision':decision,'reasons':reasons,'summary':{'pairs':len(rows),'type counts':dict(type_counts),'pairs Q/A/Feel>=4':f"{sum(1 for r in out_rows if r['decision']=='PASS')}/{len(rows)}"}}
    write_report(args.out_json,args.out_md,result,'QNA GOLD AUDIT - GOLD V3')
    print(f"QNA GOLD AUDIT: {decision} [pairs={len(rows)}, scoredPass={sum(1 for r in out_rows if r['decision']=='PASS')}/{len(rows)}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
