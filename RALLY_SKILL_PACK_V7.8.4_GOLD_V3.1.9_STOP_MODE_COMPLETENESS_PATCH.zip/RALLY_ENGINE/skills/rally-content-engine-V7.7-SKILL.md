# ARCHIVED POINTER - rally-content-engine-V7.7-SKILL.md

This legacy content-engine file has been archived and is **not active authority**.

Active workflow uses:

1. `ACTIVE_SKILL_MANIFEST.md`
2. `RALLY-EXECUTION-CORE.md`
3. `skills/HIDDEN-GATE-MINING-PROTOCOL.md`
4. `skills/EP-MANUAL-NO-CUT-PROTOCOL.md`
5. `skills/RALLY-QNA-ENGINE-V3.1.3.md`

Historical file location:

`skills/_archive/legacy_content_engines/`

Do not load archived legacy rules by default. They are historical reference only.
