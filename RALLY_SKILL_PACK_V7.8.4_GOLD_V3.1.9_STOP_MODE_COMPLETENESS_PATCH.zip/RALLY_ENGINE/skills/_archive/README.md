# Skill Archive

This folder contains historical/legacy skill files that should not be loaded as active authority.

Archived files may contain old campaign-specific references, old hard rules, or historical lessons. Use only for forensic reference.

Active authority is declared in `../ACTIVE_SKILL_MANIFEST.md`.
