# GOLD V3 Upgrade Report

Date: 2026-07-15

Status: upgraded active Rally Q&A/RQ skill layer from old V1/V2 rules to RALLY RQ GOLD STANDARD V3.1.3.

## What changed

### New active authority files

- `skills/GOLD_RQ_STANDARD_CALIBRATED.md`
- `skills/RALLY_QA_GENERATOR_GOLD_STANDARD.txt`
- `skills/RALLY-QNA-ENGINE-V3.1.3.md`
- `skills/rq-gold-policy-v3.json`

### Old Q&A versions replaced

These files are now compatibility aliases pointing to Gold V3.1.3 rules:

- `skills/rally-qna-engine.md`
- `skills/RALLY-QNA-ENGINE-V2.md`

### New / upgraded checkers

- `skills/rally-rq-prompt-answer-check.py` upgraded for Gold V3.
- `skills/rally-rq-mechanics-calibration-check.py` upgraded for Gold V3.
- `skills/rally-naturalness-variance-check.py` added.
- `skills/rally-qna-gold-audit.py` added.
- `skills/rally-rq-v3-policy-check.py` added.
- `skills/_rq_gold_common.py` added as shared parser/helper module.
- `skills/rq-gold-policy-v3.json` added as machine policy.
- `skills/rally-final-integrity-check.py` patched to accept Gold V3 reports and `qa_ranking.json`.

### Docs updated

- `skills/README.md`
- `RALLY-EXECUTION-CORE.md`
- `HOW_TO_RUN_COMMANDS.md`
- `START_HERE_FOR_NEXT_CHAT.md`
- `NEXT_CHAT_PROMPT.md`

### Content-engine override added

Because older content-engine files still contain historical Q&A notes, a Gold V3 override banner was inserted at the top of:

- `skills/rally-content-engine-V7.8-HARDCORE.md`
- `skills/rally-content-engine-V7.7-SKILL.md`
- `skills/rally-content-engine-V7.7-SKILL.original-duplicated.md`

The override says all Q&A/RQ instructions in those files are superseded by Gold V3.

## Mandatory Gold V3 gates

Run all five:

```bash
python3 skills/rally-rq-prompt-answer-check.py \
  --content content.txt --combined combined.md \
  --out-json rq-prompt-answer.json --out-md RQ-PROMPT-ANSWER.md

python3 skills/rally-rq-mechanics-calibration-check.py \
  --content content.txt --combined combined.md \
  --campaign campaign.json --mission <mission> \
  --out-json rq-mechanics.json --out-md RQ-MECHANICS.md

python3 skills/rally-naturalness-variance-check.py \
  --content content.txt --combined combined.md \
  --out-json naturalness.json --out-md NATURALNESS.md

python3 skills/rally-qna-gold-audit.py \
  --content content.txt --combined combined.md \
  --out-json qna-gold.json --out-md QNA-GOLD.md

python3 skills/rally-rq-v3-policy-check.py \
  --content content.txt --combined combined.md \
  --ranking-json qa_ranking.json \
  --out-json rq-gold-v3-policy.json --out-md RQ-GOLD-V3-POLICY.md
```

## Non-negotiable new rules

- Five Q types are mandatory: Specific Probe 4, Challenge 5, Technical Deep-Dive 5, Hot Take 4, Real Experience 2.
- Q-COPY must contain public reply text only. No metadata inside Q-COPY.
- Metadata such as `SIMULATED_ARCHETYPE`, `CONDITIONAL_ORGANIC_MATCH_ONLY`, `voicePersona`, `voiceMode`, type, tier, and deployment belongs in headings, audit tables, or `qa_ranking.json`.
- A-COPY question-ending coverage is 50-75%, not 100%.
- Decision-marker coverage is 75-80%, not 100%.
- `qa_ranking.json` is mandatory.
- Never claim `guaranteed RQ5`.

## Backup

Original replaced files were copied to:

`/home/user/backups/RALLY_SKILL_PACK_V7.8.4-pre-gold-v3/`
