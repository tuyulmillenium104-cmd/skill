# START HERE FOR NEXT CHAT - GOLD V3 ACTIVE

The Rally skill pack has been upgraded to RQ Gold V3.1.3.

Use these active authorities:

1. `skills/GOLD_RQ_STANDARD_CALIBRATED.md`
2. `skills/RALLY_QA_GENERATOR_GOLD_STANDARD.txt`
3. `skills/RALLY-QNA-ENGINE-V3.1.3.md`
4. `skills/rq-gold-policy-v3.json`

Do not use older V1/V2 Q&A rules if they conflict with Gold V3.

Mandatory Q&A gates:

1. `rally-rq-prompt-answer-check.py`
2. `rally-rq-mechanics-calibration-check.py`
3. `rally-naturalness-variance-check.py`
4. `rally-qna-gold-audit.py`
5. `rally-rq-v3-policy-check.py`

Remember: Q-COPY must contain public reply text only. Metadata belongs in headings,
audit tables, or `qa_ranking.json`, never inside Q-COPY.
- Apply `skills/PUBLIC_COPY_LEAKAGE_POLICY.md` in prompt mode; do not use broad hard bans for normal Rally/campaign terms.


## Hidden-gate-first rule

For every `/rally` run, mine real judge verdicts before drafting:

1. Fetch mission-scoped submissions.
2. Run `rally-hidden-gate-miner.py`.
3. Manually review hidden-gate candidates.
4. Write a pre-draft hidden-gate contract.
5. Draft only after the contract is clear.

## Winner-pull mining

Before drafting, mine winner/near-winner positive judge language:

```bash
python3 skills/rally-winner-pull-miner.py   --submissions <run>/cartography/submissions_enriched.json   --mission <mission-id>   --out <run>/winner-pull
```

Use `WINNER-PULL-MAP.md` and `WINNER-PULL-CONTRACT.stub.md` to define what the draft must make the judge praise. Winner-pull rules are mechanisms, not copied phrases.

## First-principles creation before data benchmarking

Before using winner examples to shape a draft, create an original thesis first:

- `skills/DATA_AS_JUDGE_NOT_WRITER_POLICY.md`
- `skills/ORIGINAL-THESIS-ENGINE.md`
- `skills/FIRST_PRINCIPLES_CONTENT_BUILD.md`
- `skills/ANTI_COPY_WINNER_TRANSFORM.md`

Rule: winner/loser data judges and stress-tests the draft. It must not write the draft or turn winner examples into templates.

## Exponential content standard

Before final content is accepted, complete an exponential content report using:

- `skills/EXPONENTIAL-CONTENT-STANDARD.md`
- `skills/EXPONENTIAL_CONTENT_REPORT_TEMPLATE.md`

Content must show a multiplicative chain:

```text
Hook -> Scenario -> Mechanism -> Value Rule -> CTA
```

A draft that merely passes Python gates but lacks exponential chain is not final.

## Apex exponential upgrade

Exponential standard is now v2 / apex. A draft must satisfy:

```text
Hook -> Scenario -> Mechanism -> Value Rule -> CTA
+ Inevitability
+ Emotional Compression
+ Pool Dominance
+ Specific Positive Verdict
+ Frictionless Reader Path
```

Passing Python gates alone is not enough. The apex exponential report must score at least 67/70 with no axis below 4.7.

## Irreducible Apex lock

Final content must pass the highest manual standard:

- `skills/IRREDUCIBLE-APEX-STANDARD.md`
- `skills/IRREDUCIBLE_APEX_REPORT_TEMPLATE.md`

A content draft is not final until it passes line necessity, substitution, compression, expansion, hostile judge 10-attack, non-expert retell, expert respect, product inevitability, and winner-without-copying tests.

Python gates remain safety nets and cannot replace Irreducible Apex review.

## Human-typed public copy standard

Final public copy must pass:

- `skills/HUMAN-TYPED-PUBLIC-COPY-STANDARD.md`

This standard prevents content and Q&A from sounding like checker output, rubric prose, or repeated generated shells. If a line passes Python gates but sounds engineered rather than human, rewrite it.

## AI human taste director

When the user does not want to be involved in manual taste decisions, the agent must run:

- `skills/AI-HUMAN-TASTE-DIRECTOR.md`
- `skills/HUMAN_TASTE_DIRECTOR_REPORT_TEMPLATE.md`

The agent must review the draft as normal reader, skeptical Rally judge, non-expert, crypto/agent-native reader, human voice editor, brand/accuracy editor, and competitor comparison judge.

No final output if any persona finds a credible issue.

## Step conflict check

Every strict run must apply:

- `skills/STEP-CONFLICT-CHECK-PROTOCOL.md`

Each step must check whether it created conflict with mission truth, source truth, data scope, winner/loser evidence, human voice, or final output quality. If a conflict appears, stop and resolve before continuing.

## Memetic Apex creative layer

For top-tier output, content must also pass the creative spread layer:

- `skills/MEMETIC-INSIGHT-ENGINE.md`
- `skills/AUDIENCE-PSYCHOLOGY-MAP.md`
- `skills/CONTRARIAN-POSITIONING-LOCK.md`
- `skills/SCENE-VIVIDNESS-CHECK.md`
- `skills/REPLY-IDENTITY-TEST.md`
- `skills/COMPRESSION-VARIANT-TOURNAMENT.md`

This layer prevents the workflow from producing content that is merely safe, clear, and gate-passing. It forces a repeatable insight, human scene, contrarian stance, and CTA that gives readers an identity to perform.

## Rally Fundamental Law

Every run is governed by:

- `skills/RALLY-FUNDAMENTAL-LAW.md`

Core formula:

```text
Campaign Ask x Rally Judge Desire
```

All other frameworks are subordinate to the literal campaign brief and real Rally judge evidence.

## Known-Gate Absolute standard

The highest honest certainty label is defined by:

- `skills/KNOWN-GATE-ABSOLUTE-STANDARD.md`
- `skills/KNOWN_GATE_ABSOLUTE_REPORT_TEMPLATE.md`

This standard does not mean guaranteed all-max. It means all known controllable cut surfaces are closed. Unknown/future judge gates, judge variance, engagement, timing, account behavior, and organic replies remain external risks.

## Workflow enforcement utilities

Strict runs can be checked with:

- `skills/rally-data-sufficiency-check.py`
- `skills/rally-human-typed-audit.py`
- `skills/rally-run-completeness-check.py`
- `skills/CANDIDATE-TOURNAMENT-PROTOCOL.md`

Use these to prevent skipped artifacts, over-mechanical public copy, and first-draft bias.
