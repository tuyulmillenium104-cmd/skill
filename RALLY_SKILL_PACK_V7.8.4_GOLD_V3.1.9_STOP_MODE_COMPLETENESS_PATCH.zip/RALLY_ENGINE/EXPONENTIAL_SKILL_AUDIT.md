# Exponential Skill Audit

Date: 2026-07-17

## Verdict

**Workflow support: PASS.**

The skill pack now contains the required structure to generate and evaluate content at an exponential standard:

- original thesis first;
- data as judge, not writer;
- anti-copy winner transform;
- hidden-gate mining with scope discipline;
- winner-pull mining;
- exponential content report;
- Python gates as safety nets.

This does **not** guarantee external Rally all-max or winner status. It means the skill now has the process required to aim at exponential content without becoming a winner-template copier.

## Required files present

- `skills/EXPONENTIAL-CONTENT-STANDARD.md`
- `skills/EXPONENTIAL_CONTENT_REPORT_TEMPLATE.md`
- `skills/DATA_AS_JUDGE_NOT_WRITER_POLICY.md`
- `skills/ORIGINAL-THESIS-ENGINE.md`
- `skills/FIRST_PRINCIPLES_CONTENT_BUILD.md`
- `skills/ANTI_COPY_WINNER_TRANSFORM.md`
- `skills/HIDDEN-GATE-MINING-PROTOCOL.md`
- `skills/HIDDEN_GATE_SCOPE_REGISTRY.md`
- `skills/WINNER-PULL-MINING-PROTOCOL.md`
- `skills/WINNER_PULL_CONTRACT_TEMPLATE.md`
- `skills/rally-hidden-gate-miner.py`
- `skills/rally-winner-pull-miner.py`

## Manifest integration

`ACTIVE_SKILL_MANIFEST.md` now includes:

- hidden-gate mining;
- winner-pull mining;
- data-as-judge policy;
- original thesis engine;
- anti-copy transform;
- exponential content standard;
- Python checkers as safety nets.

## Documentation integration

The following files reference the newer workflow:

- `ACTIVE_SKILL_MANIFEST.md`
- `RALLY-EXECUTION-CORE.md`
- `HOW_TO_RUN_COMMANDS.md`
- `START_HERE_FOR_NEXT_CHAT.md`
- `skills/README.md`

## Legacy contamination check

Legacy full content engines are archived:

- `skills/_archive/legacy_content_engines/`

Legacy protocol docs are archived:

- `skills/_archive/legacy_protocol_docs/`

Top-level legacy files are pointer stubs only and are not active authority.

Active Python/core docs were scanned for old campaign hardcodes such as:

- `@RallyOnChain`
- `Wingston`
- `RLP`

No active hardcoded old-campaign references remain in active Python/core docs.

Remaining references like `RLP`, `Wingston`, or `whitelist` in `HIDDEN_GATE_SCOPE_REGISTRY.md` are examples of terms that must not be globally hardcoded, not active campaign rules.

## Python validation

All active Python files compile:

```text
python3 -m py_compile skills/*.py
```

Result: PASS.

## Important limitation

There is no reliable fully automated checker for “exponential content.”

The exponential standard is intentionally manual because it evaluates:

- hook force;
- scenario proof;
- mechanism inevitability;
- positive verdict density;
- distinctiveness;
- whether every line has function.

Python can catch known failures, but exponential quality must be judged through the report template and manual no-cut review.

## Operational rule

A future `/rally` run is only complete if it produces these pre-draft/manual artifacts before final content:

- `ORIGINAL-THESIS.md`
- `THESIS-OBJECT-CANDIDATES.md`
- `HIDDEN-GATE-CANDIDATES.md`
- `HIDDEN-GATE-MANUAL-REVIEW.md`
- `PRE-DRAFT-HIDDEN-GATE-CONTRACT.md`
- `WINNER-PULL-MAP.md`
- `WINNER-PULL-CONTRACT.md`
- `DATA-JUDGE-REVIEW.md`
- `EXPONENTIAL-CONTENT-REPORT.md`

If these are skipped, the workflow is not truly exponential even if Python gates pass.

## Final status

The skill can now run a complete exponential workflow safely, provided the user/agent actually follows the manual artifacts and does not shortcut directly to drafting or Python checks.
