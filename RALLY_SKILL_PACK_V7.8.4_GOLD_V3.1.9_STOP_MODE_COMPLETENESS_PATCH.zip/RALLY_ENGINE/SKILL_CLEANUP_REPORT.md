# Skill Cleanup Report

Date: 2026-07-17

## Purpose

Remove or neutralize legacy/static rules that could compete with the current hidden-gate-first workflow or degrade content quality.

## Changes made

### 1. Active manifest added

Created:

- `ACTIVE_SKILL_MANIFEST.md`

This declares current authority order and marks legacy content engines as non-active.

### 2. Legacy content engines archived

Moved historical full files to:

- `skills/_archive/legacy_content_engines/rally-content-engine-V7.7-SKILL.md`
- `skills/_archive/legacy_content_engines/rally-content-engine-V7.7-SKILL.original-duplicated.md`
- `skills/_archive/legacy_content_engines/rally-content-engine-V7.8-HARDCORE.md`

Old paths now contain short pointer stubs only. These files must not be loaded as active authority.

### 3. EP semantic review patched

Updated:

- `skills/rally-ep-semantic-review.py`

Old behavior:

- Corpus EP deduction map unknown classes caused content-level FAIL.

New behavior:

- Content-specific risks decide PASS/FAIL.
- Corpus unknown classes are reported as `Corpus review / non-content dependency`, not as content failure.

This prevents valid content from being mislabeled as failed due to unresolved corpus mining classes.

### 4. Hardcoded old campaign references removed from active Python/core docs

Patched old hardcoded references such as:

- `@RallyOnChain`
- `Wingston`
- `RLP`

from active Python tools/core docs where they could contaminate unrelated campaigns.

Files patched include:

- `rally-pre-draft-risk-contract.py`
- `rally-winner-build-spec.py`
- `rally-winner-dna-map.py`
- `rally-tq-format-audit.py`
- `rally-originality-saturation-check.py`
- `rally-worst-positive-verdict-check.py`
- `rally-compliance-gate.py`
- `rally-dna-fetcher.py`
- `_rq_gold_common.py`

Smoke check result:

```text
No old campaign hardcodes in active py/core docs
```

### 5. Loser-DNA whitelist made generic

Updated:

- `skills/rally-loser-dna-scan.py`

Old default whitelist contained campaign-specific Wingston/RLP/whitelist terms.

New behavior:

- Default whitelist is tiny and generic.
- Campaign-required phrases should be passed via `--whitelist` from the run contract.

### 6. CTA checker made more generic

Updated:

- `skills/rally-cta-quality-check.py`

Added broader generic terms for contract/proof/escrow/appeal/agent/interface workflows and removed reliance on old campaign-specific objects.

### 7. Hidden-gate-first workflow retained as active

Active new files:

- `skills/rally-hidden-gate-miner.py`
- `skills/HIDDEN-GATE-MINING-PROTOCOL.md`
- `skills/PRE_DRAFT_HIDDEN_GATE_CONTRACT_TEMPLATE.md`
- `skills/EP-MANUAL-NO-CUT-PROTOCOL.md`

## Validation

All Python files compile:

```text
python3 -m py_compile skills/*.py
```

EP semantic review smoke test now correctly reports content PASS with corpus review separated.

## Current principle

The current workflow is:

1. Mission brief truth first.
2. Fetch real submissions and verdicts.
3. Mine hidden-gate candidates per mission.
4. Manual hidden-gate review.
5. Pre-draft hidden-gate contract.
6. Manual EP no-cut review.
7. Python checkers as safety net.
8. Q&A Gold V3 only after content stabilizes.

Legacy static rules must not override mission-specific evidence.

## Second audit cleanup - legacy protocol docs

After auditing the skill again, I found that old V7.x protocol/addendum markdown files still existed at top level in `skills/`. Even if not declared in the active manifest, they could confuse an agent that loads the whole folder.

Action taken:

- Moved legacy protocol docs to `skills/_archive/legacy_protocol_docs/`.
- Replaced old top-level files with short archived-pointer stubs.
- Added `Legacy protocol archive` section to `ACTIVE_SKILL_MANIFEST.md`.

Current rule:

- Historical V7.x addendum/protocol files are **not active authority**.
- Useful historical lessons must be promoted through hidden-gate/manual review with explicit scope.

Remaining references such as `RLP`, `Wingston`, or `whitelist` in `HIDDEN_GATE_SCOPE_REGISTRY.md` are examples of terms that must not be globally hardcoded. They are not active campaign rules.

Remaining `whitelist` strings in Python are generic variable/argument names for loser-DNA phrase whitelisting, not old campaign rules.
