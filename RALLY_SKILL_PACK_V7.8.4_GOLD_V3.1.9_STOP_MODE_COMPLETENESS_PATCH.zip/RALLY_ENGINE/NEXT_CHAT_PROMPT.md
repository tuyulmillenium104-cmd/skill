Use Rally Engine Gold V3.1.3.

Load:
- skills/GOLD_RQ_STANDARD_CALIBRATED.md
- skills/RALLY_QA_GENERATOR_GOLD_STANDARD.txt
- skills/RALLY-QNA-ENGINE-V3.1.3.md
- skills/rq-gold-policy-v3.json

Generate 20 Q-COPY/A-COPY pairs with distribution:
Specific Probe 4, Challenge 5, Technical Deep-Dive 5, Hot Take 4, Real Experience 2.
Create qa_ranking.json with voicePersona and voiceMode for every row.
Never put metadata inside Q-COPY.
Run all five Gold V3 gates plus final integrity before calling the pack RQ5-ready.
- Apply public-copy privacy prompt: no private skill/checker/audit leakage in Q/A; official Rally/campaign terms are allowed when natural.
