# One-Shot Complete Parity Report - 2026-07-18

Goal: ensure one-session/one-run mode does not leave behind any artifacts from the older full workflow.

## New enforcement

Added tool:

```text
skills/rally-one-run-completeness-check.py
```

It requires both:

1. Older full workflow artifacts:
   - content gates,
   - Q&A gates,
   - final integrity,
   - hidden-gates,
   - winner-pull,
   - apex/irreducible/known-gate reports.

2. New one-run artifacts:
   - RUN_MODE.md,
   - GENERATE_OUTPUT_FOR_STRESS.md,
   - CANDIDATE_LEDGER.md,
   - MAIN_CONTENT_STRESS_REPORT.md,
   - UNMAPPED_RISK_GATE.md,
   - QNA_STRESS_REPORT.md,
   - FINAL_REPORT.md.

## Test on current FUD one-run folder

Run folder:

```text
/home/user/konten/FUD_Markets/mission-0_one_session_one_run_20260718_122155
```

Result:

```text
ONE-RUN COMPLETENESS CHECK: PASS [mode=final, missing=0, bad=0, text=0]
```

Required files:

```text
68 / 68 present
```

## Honest caveat

This proves artifact parity and gate coverage for the revalidated FUD one-run folder. It does not erase the earlier note that this specific run reused previous FUD content/Q&A as the starting artifact. Future fresh `/rally` runs must generate candidates and only create Q&A after main-content stress pass.
