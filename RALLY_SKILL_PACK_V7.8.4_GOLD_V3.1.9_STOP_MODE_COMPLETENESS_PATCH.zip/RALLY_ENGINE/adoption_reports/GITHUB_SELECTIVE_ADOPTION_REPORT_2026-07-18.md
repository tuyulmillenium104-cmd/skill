# GitHub Selective Adoption Report - 2026-07-18

Source inspected:

```text
https://github.com/tuyulmillenium104-cmd/skill/tree/main
```

Decision: **SELECTIVE ADOPTION**, not full replacement.

## Adopted safely

### Protocols added

```text
skills/REAL-JUDGE-4CAP-CALIBRATION-PROTOCOL.md
skills/EP-SURFACE-SELECTION-PROTOCOL.md
skills/RUN-LEDGER-PROTOCOL.md
skills/RELATION-MEDIA-PLAN-PROTOCOL.md
skills/UNIVERSAL-RALLY-CAMPAIGN-SAFETY-PROTOCOL.md
```

### Tools added

```text
skills/rally_common.py
skills/rally-requirement-provenance.py
skills/rally-mission-contract.py
skills/rally-relation-compliance.py
```

Source copies preserved at:

```text
skills/_adopted_from_github_v797/
```

## Compatibility patches made

`rally-requirement-provenance.py` was patched so Rally briefs like FUD are detected correctly when requirements appear as section headers plus bullets:

- required handles in hard rules are captured as required mentions,
- `screenshot` is treated as media requirement,
- FUD mission now detects:

```text
requiredMentions = ['@FUDmarkets']
mediaRequired = True
```

## FUD adoption test

Adopted tools were tested on:

```text
/home/user/konten/FUD_Markets/mission-1_first_mission_known_gate
```

New reports created:

```text
reports/REQUIREMENT-PROVENANCE.md
reports/requirement-provenance.json
reports/mission-contract.json
reports/submission-plan.json
reports/RELATION.md
reports/relation.json
reports/EP-SURFACE-SELECTION.md
reports/RUN-LEDGER.md
```

Results:

```text
REQUIREMENT PROVENANCE: PASS artifact generated
MISSION CONTRACT: PASS artifact generated
RELATION COMPLIANCE: PASS [0 errors, 0 warnings]
FINAL INTEGRITY CHECK: PASS (content 671 chars, Q=20, A=20)
```

## Manifest update

`ACTIVE_SKILL_MANIFEST.md` now includes a `GitHub selective adoption - 2026-07-18` section.

## Version update

```text
RALLY_ENGINE_VERSION=V7.8.4_GOLD_V3.1.5_GITHUB_SELECTIVE_ADOPTION
```

## Explicitly not adopted

- Full V7.9.7 engine replacement.
- Old examples as templates.
- V9 `PATH-TO-100-PERCENT` guarantee framing.
- One-shot auto-writer as final writing authority.

## Why not full replacement

The current engine has newer custom law and real-verdict ratchets that the GitHub packs do not fully contain:

- Campaign Ask x Rally Judge Desire,
- Data does not write, data judges,
- hidden-gate scope registry,
- AI Human Taste Director,
- Known-Gate Absolute local framing,
- Gold V3.1.4 real-formula-cap from InternetCourt real Rally verdict.

## Honest status

The adopted material strengthens evidence capture, relation/media planning, EP surface selection, and final run ledger. It does not guarantee all-max, winner, top 1%, EP5, or RQ5.
