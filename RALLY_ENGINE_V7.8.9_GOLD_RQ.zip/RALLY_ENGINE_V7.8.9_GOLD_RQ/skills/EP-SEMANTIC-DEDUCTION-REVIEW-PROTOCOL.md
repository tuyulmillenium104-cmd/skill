# RALLY V7.7 ADDENDUM v2.2 — EP SEMANTIC DEDUCTION REVIEW PROTOCOL

**Date:** 2026-06-25 Asia/Jakarta  
**Status:** ACTIVE  
**Purpose:** Close the gap between regex/tool mining and subtle semantic EP4 reasons. EP deduction map catches known/unknown textual classes; this protocol forces a final semantic red-team pass focused only on whether a real judge could still write an EP4 sentence.

---

## 1. NEW META-RULE #0W: EP5 REQUIRES SEMANTIC DEDUCTION CLEARANCE

A content is not EP5-ready merely because:
- EP deduction map PASS;
- CTA tool PASS;
- loser DNA PASS;
- scanner PASS.

It must also pass a semantic question:

```text
Could a real Rally judge still write a credible EP4 criticism sentence about this post?
```

If yes, fix or document why the criticism is not credible.

---

## 2. SEMANTIC REVIEW TARGETS

The semantic review specifically checks EP4 reasons that are easy to miss by regex:

1. **Surprise / memorability gap**
   - Is the take true but not surprising?
   - Is the phrase quotable enough for a judge to remember?

2. **Conviction performance**
   - Does the post perform boldness without actually taking a costly stance?
   - Is the verdict/argument too safe?

3. **Cultural sharpness**
   - Does it understand the current discourse, or could it apply to any cycle?
   - Is the target specific enough?

4. **Emotional / identity pull**
   - Does it make readers feel implicated, annoyed, relieved, called out, or eager to argue?
   - Or is it only intellectually neat?

5. **Brand / campaign bridge trust**
   - If brand/platform is mentioned, does it emerge from the argument or feel inserted?

6. **CTA as reply engine**
   - Is the CTA not only direct, but likely to produce specific replies?

7. **Value delivery ceiling**
   - Is the takeaway exceptional, or merely solid/competent?

8. **TQ/format interference with EP**
   - Does length, media, or formatting reduce read-through or shareability?

---

## 3. REQUIRED TOOL

Run:

```bash
python3 skills/rally-ep-semantic-review.py \
  --content content.txt \
  --ep-map ep-deduction-map.json \
  --cta-report cta-quality-report.json \
  --oaa-report oaa-structure-report.json \
  --tq-report tq-format-report.json \
  --out-json ep-semantic-review.json \
  --out-md EP-SEMANTIC-REVIEW.md
```

This tool does not claim perfect human understanding. Its job is to force a structured semantic red-team and block obvious unresolved risks.

---

## 4. FINAL AUDIT REQUIREMENT

Final audit must include:

```text
EP SEMANTIC DEDUCTION REVIEW (#0W):
- Surprise/memorability: PASS/FAIL
- Conviction/costly stance: PASS/FAIL
- Cultural sharpness: PASS/FAIL
- Emotional/identity pull: PASS/FAIL
- Brand bridge trust: PASS/FAIL/N/A
- CTA reply engine: PASS/FAIL
- Value delivery ceiling: exceptional/solid/risk
- Credible EP4 sentence remaining: none / quote
- Decision: PASS / FIX / REBUILD
```

---

## 5. PASS THRESHOLD

Content passes only if:

1. No credible unresolved EP4 criticism sentence remains.
2. CTA is direct and reply-generating.
3. The core phrase/thesis is memorable enough for a judge to quote.
4. The value is exceptional, not merely competent.
5. The argument is mission-specific and not portable generic advice.

---

## 6. RELATION TO OTHER TOOLS

- `rally-ep-deduction-map.py` mines real EP4/EP3 reasons.
- `rally-ep-semantic-review.py` asks whether any subtle EP4 reason still applies to the current content.
- Final integrity fails if semantic review is not PASS.

---

## ENFORCEMENT SUMMARY

For every future `/rally` run targeting top 1%:

1. Mine EP deductions.
2. Clear unknown classes.
3. Run semantic EP review.
4. If any credible EP4 sentence remains, fix before final.
