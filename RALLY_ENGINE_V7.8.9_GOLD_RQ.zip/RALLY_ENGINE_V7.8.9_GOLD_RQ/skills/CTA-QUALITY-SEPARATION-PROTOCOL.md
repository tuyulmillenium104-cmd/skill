# RALLY V7.7 ADDENDUM v1.7 — CTA QUALITY SEPARATION PROTOCOL

**Date:** 2026-06-24 Asia/Jakarta  
**Status:** ACTIVE  
**Source:** Real Rally verdict on Wingston VIP Community mission-0 content. Internal prediction: EP5. Actual judge: EP4. Root miss: the post had strong conversation potential via a rhetorical debate question, but lacked a direct, explicit CTA.  
**Purpose:** Prevent future campaigns from confusing **Conversation Potential** with **CTA Quality**.

---

## 1. NEW META-RULE #0T: CTA QUALITY ≠ CONVERSATION POTENTIAL

**A rhetorical question is not automatically a max-quality CTA.**

EP has separate sub-rubrics. A post can have:

- excellent Hook Effectiveness;
- excellent Content Structure;
- excellent Conversation Potential;
- excellent Value Delivery;

and still receive EP4 if **CTA Quality** is not explicit enough.

**Rule:** For EP5 targeting, the post must contain a direct behavioral CTA unless the campaign format explicitly forbids it. If explicit CTA is forbidden, the post still needs an embedded behavioral micro-CTA.

---

## 2. FAILURE CASE — WINGSTON MISSION-0

Closing used:

```text
If two creators have equal skill, but one gets the brief, context, and whitelist path earlier, are we judging talent, or access?
```

Judge praised it as:

```text
The closing rhetorical question is excellent for driving conversation and replies.
```

But EP stayed 4/5 because:

```text
However, it lacks a direct, explicit call-to-action (CTA) inviting users to mint, join, or comment, which slightly lowers the CTA Quality score.
```

**Lesson:** A debate question can satisfy Conversation Potential but still fail CTA Quality.

---

## 3. CTA QUALITY HARD CHECK — WAJIB UNTUK SEMUA CAMPAIGN

Before finalizing content, ask:

```text
CTA QUALITY HARD CHECK:
1. Is the ending only rhetorical? yes/no
2. Does the reader know a specific action to take after reading? yes/no
3. Is there an explicit CTA verb? reply / comment / choose / tell me / check / visit / learn / join / mint / compare / name
4. Is the CTA campaign-native and non-generic? yes/no
5. Does the CTA deepen the thesis instead of feeling pasted on? yes/no
```

**Pass threshold:**

```text
- Direct behavioral CTA present, OR
- If campaign forbids explicit CTA, embedded behavioral micro-CTA present.
```

If not, **EP ceiling = 4/5**, even if the final question is excellent for discussion.

---

## 4. CTA TYPES AND EP RISK

| CTA Type | Example | CTA Quality Risk |
|---|---|---|
| Pure rhetorical | "are we judging talent, or access?" | EP4 risk |
| Debate fork without action verb | "audience or access?" | EP4 risk unless one-liner format forbids explicit CTA |
| Behavioral choice CTA | "Which edge would you rather have: audience, or earlier access?" | stronger |
| Explicit reply CTA | "Reply with the edge you would rather have: audience, or earlier access." | strongest for comment behavior |
| Learn/check CTA | "Check the details and tell me which perk matters most." | strong for utility campaigns |
| Generic CTA | "Thoughts?" / "What do you think?" | weak / OAA risk |

---

## 5. CAMPAIGN-TYPE CTA REQUIREMENTS

### Educational / utility / explain-benefit campaigns
Need direct behavioral CTA.

Good:

```text
Tell me which perk would change your creator workflow first: private campaigns, early updates, WL paths, or RLP.
```

```text
Check the announcement, then choose the edge you would rather have: bigger reach, or earlier access.
```

Bad:

```text
are we judging talent, or access?
```

Reason: interesting, but too rhetorical for CTA Quality max.

### Persuasive / urgency campaigns
Need action CTA tied to campaign destination or next step.

Good:

```text
Visit app.rally.fun and learn how Wingston VIP works before the room fills.
```

```text
If you plan to build on Rally, start at app.rally.fun before the public timeline catches up.
```

### One-liner / just-the-take campaigns
If explicit standalone CTA violates the brief, use embedded behavioral micro-CTA.

Good:

```text
...which side are you defending: the principle, or your position in it?
```

Better if allowed:

```text
...choose one: fairness, or your turn holding the lever.
```

### Narrative / creative campaigns
Explicit CTA may be harmful if it breaks immersion. Use implicit but behavioral invitation only if compatible.

Good:

```text
If you noticed the camera before the mother did, tell me where the story turned.
```

If campaign explicitly values no CTA, document CTA trade-off and do not force.

### Raw / confession campaigns
CTA must sound human, not marketing.

Good:

```text
Tell me the version you almost posted and deleted.
```

Bad:

```text
Engage below with your thoughts.
```

---

## 6. CTA VERB WHITELIST

A CTA Quality max candidate should include at least one concrete behavioral verb unless the format forbids it:

```text
reply
comment
tell me
choose
name
check
visit
learn
join
mint
compare
pick
show me
share
```

Avoid generic weak verbs/phrases:

```text
thoughts?
what do you think?
agree?
drop yours
let me know
```

These can be used only if campaign style explicitly rewards casual prompts, and even then stronger campaign-native wording is preferred.

---

## 7. CTA QUALITY VS CONVERSATION POTENTIAL — SEPARATE SCORING

During EP evaluation, score separately:

```text
Conversation Potential:
- Does the post create a discussion/debate/reply path?

CTA Quality:
- Does the post directly ask the reader to do something campaign-native?
```

**Do not merge these scores.**

A post can pass Conversation Potential and fail CTA Quality.

---

## 8. UPDATE TO #0R EP HARSH JUDGE

EP Harsh Judge must now ask:

```text
1. Is there a debate fork? yes/no
2. Is there a direct behavioral CTA? yes/no
3. If no direct CTA, does the campaign format explicitly forbid it? yes/no
4. If explicit CTA is forbidden, is there an embedded behavioral micro-CTA? yes/no
5. Would a real judge write: "lacks a direct, explicit CTA"? yes/no
```

If answer to #5 is yes, **predict EP4 risk**, not EP5.

---

## 9. UPDATE TO FINAL AUDIT

Final audit must include:

```text
CTA QUALITY SEPARATION (#0T):
- Conversation Potential device: [quote]
- Direct behavioral CTA: [quote / none]
- CTA verb present: [verb / none]
- Campaign format permits explicit CTA: yes/no
- If no explicit CTA, embedded behavioral micro-CTA: [quote / none]
- Generic CTA avoided: yes/no
- EP ceiling risk: EP5 / EP4 risk
```

---

## 10. PASS THRESHOLD

Content passes #0T only if:

1. It has a clear Conversation Potential device.
2. It has a direct behavioral CTA, unless explicitly forbidden.
3. If explicit CTA is forbidden, it has an embedded behavioral micro-CTA.
4. The CTA is campaign-native, not generic.
5. The CTA does not feel pasted on or promotional against the campaign style.

If any fail: revise before final output, rerun #0R, #0S2, compliance, and scanner if verdict changes.

---

## ENFORCEMENT SUMMARY

For every future `/rally` run:

1. Do not treat rhetorical question as CTA Quality max.
2. Score Conversation Potential and CTA Quality separately.
3. Require behavioral CTA verb unless format forbids it.
4. If format forbids explicit CTA, require embedded behavioral micro-CTA.
5. If a judge could write "lacks a direct, explicit CTA," EP5 prediction is invalid.
