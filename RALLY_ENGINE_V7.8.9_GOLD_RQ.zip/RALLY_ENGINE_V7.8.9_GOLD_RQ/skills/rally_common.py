#!/usr/bin/env python3
"""Shared helpers for Rally Engine V7.8.5 deep-audit patch."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path

TRAILING_URL_PUNCT = set(',.;:/!?)]}>"\'')
MARKDOWN_LINK_RE = re.compile(r"\[[^\]\n]+\]\((?:https?://|www\.)[^)\s]+\)", re.I)
# Exclude Markdown wrappers from the URL path, but intentionally retain ordinary
# trailing punctuation so it can be reported as attached punctuation.
URL_RE = re.compile(
    r"(?:https?://|www\.)[^\s<>\[\]()]+"
    r"|(?:[a-z0-9-]+\.)+(?:com|io|xyz|fun|app|gg|org|net|co|me|dev|ai)(?:/[^\s<>\[\]()]*)?",
    re.I,
)

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def sha256_file(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def normalized_text(text: str) -> str:
    return re.sub(r"\s+", " ", (text or '').strip().lower())

def find_url_issues(text: str) -> dict:
    """Return Markdown-link and attached-punctuation URL problems.

    A punctuation mark that directly touches a URL is intentionally treated as a
    hard problem because Rally's real TQ judge has interpreted it as malformed.
    """
    markdown = [m.group(0) for m in MARKDOWN_LINK_RE.finditer(text)]
    attached = []
    urls = []
    for m in URL_RE.finditer(text):
        raw = m.group(0)
        # Ignore the URL occurrence inside Markdown syntax after recording the
        # Markdown problem; reporting both would be noisy.
        in_markdown = any(mm.start() <= m.start() < mm.end() for mm in MARKDOWN_LINK_RE.finditer(text))
        urls.append(raw)
        if in_markdown:
            continue
        if raw and raw[-1] in TRAILING_URL_PUNCT:
            attached.append({'url': raw[:-1], 'punctuation': raw[-1], 'raw': raw})
            continue
        nxt = text[m.end():m.end()+1]
        if nxt in TRAILING_URL_PUNCT:
            attached.append({'url': raw, 'punctuation': nxt, 'raw': raw+nxt})
    return {'urls': urls, 'markdownLinks': markdown, 'attachedPunctuation': attached}

def extract_main_content_block(combined: str) -> str | None:
    m = re.search(r"(?ms)^## MAIN CONTENT[^\n]*\n.*?^```text\n(.*?)\n```", combined)
    return m.group(1) if m else None

def load_json(path: str | Path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write_json(path: str | Path, data) -> None:
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

def report_identity(content: str, combined: str | None = None) -> dict:
    out = {'contentChars': len(content), 'contentSha256': sha256_text(content)}
    if combined is not None:
        out['combinedSha256'] = sha256_text(combined)
    return out
