---
name: rally-qna-engine
version: V1.0 (2026-06-13)
status: AKTIF — dipanggil oleh rally-content-engine V7.6 Step 8 (HANDOFF)
data-basis: 1.061 vonis RQ / 13 pool + 3 vonis RQ asli milik kita (5/5, 5/5, 4/5)
peran: Q&A REPLY-PACK ENGINE — memproduksi naskah balasan yang membuat juri RQ
       menulis 3+ konsep-positif. RQ adalah satu-satunya gate yang hidup SETELAH
       posting; skill ini adalah senjatanya.
---

# RALLY QNA-ENGINE V1.0 — REPLY-PACK UNTUK RQ 5/5

## 0. GERBANG MASUK (WAJIB — tidak boleh dipanggil sebelum semuanya hijau)

1. Konten FINAL ada di `/konten/<campaign>/<NAMA>-FINAL.txt` + EXECUTION LEDGER terisi.
2. Battery #0O konvergen (zero debatable gaps) & `rally-compliance-gate.py` exit 0.
3. RQ weight campaign > 0%. Jika RQ weight = 0% → STOP, pack tidak dibuat.
4. Output skill ini = `/konten/<campaign>/<NAMA>-QNA.txt` — TIDAK pernah mengedit konten final.

---

## 1. MODEL RQ — APA YANG SEBENARNYA DINILAI (0I-30B-c, 651+1061 vonis)

RQ BUKAN template 5-sub seperti EP/CA. RQ = **KAMUS KONSEP DUA ARAH**. Juri membaca
replies di bawah tweet lalu menulis esai; skor mengikuti konsep yang sempat ia tulis:

**KONSEP POSITIF (kehadirannya menaikkan — target produksi):**
engagement(545) · authenticity(481) · specificity(398) · subject-matter(315) ·
constructive(236) · substantive(199) · civility(186) · anecdote · distinct voice

**KONSEP NEGATIF (kehadirannya memotong):**
templated(296) · vague(223) · platitudes(209) · ai-generated(111) · generic praise ·
one-word replies · spam/emoji-only

**MEKANIKA TERUKUR (monoton sempurna):**
- pos-concepts 0→5 dalam vonis = mean RQ 0.46 → 3.14, %RQ5 1% → 14%.
- net-score (pujian−kritik) −3→+4 = mean 3.11 → 4.54 (0I-31J).
- **"ADA replies > replies sempurna"**: vonis tanpa konsep-negatif mayoritas =
  "No replies to analyze" = RQ 0. Kehadiran balasan mengalahkan kesempurnaan.
- Sweet spot panjang vonis 6-8 kalimat — juri yang menulis 9+ kalimat menemukan
  lebih banyak cacat. Pack yang baik memberi juri 3-5 hal jelas untuk dipuji,
  bukan 20 hal untuk dibedah.

**TARGET OPERASIONAL TUNGGAL:** juri RQ menulis ≥3 konsep-positif dan 0 konsep-negatif
dalam vonisnya. Semua aturan di bawah ini adalah turunan dari target itu.

---

## 2. RQ = TRAIT AUTHOR YANG PORTABEL & KUMULATIF (0I-31J — jackpot)

Mining 110 author lintas pool: stdev intra-author 0.77 vs antar-author 1.29 —
**RQ menempel pada AUTHOR, bukan pada konten.** (@nicolaspescheux mean 5.0;
35/110 author kronis ≤1 di semua pool.)

Artinya:
- Pack engine + jaringan replier + kebiasaan balas <30 menit = ASET yang dibawa
  ke setiap campaign berikutnya. Setiap eksekusi menaikkan baseline RQ permanen.
- Track record kita: Twist Ending 5/5, iPad 5/5, Two-Column 4/5 (dilusi — lihat §5).
  Pola pack ini SUDAH terbukti 2x menghasilkan RQ 5/5 (4 dari 64 author di pool iPad).
- KONSEKUENSI: pack BUKAN proyek per-campaign — dia program pembinaan trait.
  Replier yang sama boleh dipakai lintas campaign; suara mereka justru makin otentik.

---

## 3. SPESIFIKASI PACK (format terbukti 2x RQ 5/5)

**VOLUME: DEFAULT 12 naskah** multi-persona. 30 hanya jika ranking butuh volume.
KUALITAS > VOLUME — bukti: RQ5 dicapai dengan 3-14 replies; 29-replies-campur = RQ3.
Setiap naskah ekstra yang lemah adalah PENGENCER, bukan tambahan.

**FORMAT FILE (`<NAMA>-QNA.txt`):**
```
[A1] Jika reply seperti: "<jenis reply organik yang diantisipasi>"
>>> COPY:
<balasan SATU BARIS utuh, ≤280 chars, siap paste tanpa edit>
```
- Balasan SELALU satu baris di bawah `>>> COPY:` — select sampai habis, copy, paste.
- Sertakan blok **DETAIL KANONIK** di header file: fakta-fakta konten yang SEMUA
  balasan wajib konsisten (angka, status, klaim). Satu kontradiksi kanonik = bahan
  kritik IA/RQ.

**DISTRIBUSI KATEGORI (12 naskah):**
- [A] CONFESSION-MIRROR 4-5 — replier menyambung tema konten dgn cerita sendiri;
  balasan kita menambah anekdot + pertanyaan balik spesifik.
- [B] SKEPTIC/CHALLENGE 3-4 — replier meragukan ("scam?", "worth it?"); balasan
  menjawab dengan fakta kanonik tanpa defensif, lalu open loop.
- [C] HOW/MECHANIC 2-3 — replier tanya cara; balasan = walkthrough singkat konkret
  (nama platform, langkah, durasi) — konsep "subject-matter expertise" lahir di sini.
- [D] HUMOR/CT-NATIVE 1-2 — crypto-native wit, self-deprecating; konsep "distinct
  voice" + "authenticity".

---

## 4. TUJUH POLA WAJIB PER NASKAH (#0B3 — dari vonis RQ5 asli)

Setiap balasan WAJIB lolos ketujuhnya:
1. **CONFESSION-BASED** — Q organik = pengakuan/anekdot, BUKAN pertanyaan wawancara.
2. **DISTINCT VOICES** — tidak ada 2 naskah bersebelahan yang terdengar sama
   (newbie/degen/researcher/skeptic/comic).
3. **ZERO ACADEMIC** — tanpa jargon psikologi/esai ("meta-cognition", dst).
4. **CRYPTO-NATIVE HUMOR** — minimal 2 naskah witty ("exit liquidity", slang CT).
5. **CONCRETE SPECIFICS** — harga, nama, platform, durasi di setiap balasan.
6. **ADVANCES CONVERSATION** — tiap balasan menambah angle BARU + diakhiri
   pertanyaan-balik spesifik (open loop) → juri menulis "engagement".
7. **ZERO AI-PHRASES** — termasuk yang menyamar ("research theater problem").

**STRUKTUR BALASAN (3 ketukan):** Direct answer → bukti/anekdot spesifik (KB-backed
bila menyangkut fakta campaign) → open loop pertanyaan balik. Vonis mother-camera
mengutip 5 balasan pack VERBATIM di vonis RQ — juri benar-benar membaca kalimatnya;
tiap kalimat harus tahan dikutip sendirian.

---

## 5. HUKUM ANTI-DILUSI (0I-15 L4 — pelajaran vonis asli Two-Column RQ 4/5)

Vonis nyata memotong RQ kita karena balasan LEMAH DARI NASKAH SENDIRI ikut tampil
("good luck...", "do I need a big account?"). Hukumnya:
1. **Naskah pendek-fungsional DILARANG** ("thanks!", "good luck", "DM me") — satu
   balasan vague yang juri kutip menghapus nilai lima balasan substantif.
2. **Audit pack = audit baris-per-baris**: untuk SETIAP balasan tanya "jika juri
   mengutip HANYA baris ini, konsep apa yang ia tulis?" Jawaban harus salah satu
   konsep-positif §1. Tidak bisa jawab = HAPUS naskah, jangan perbaiki sambil lewat.
3. Lebih sedikit naskah kuat > genap 12 dengan pengencer.
4. Balasan kita ke reply organik di luar pack mengikuti standar yang sama —
   juri tidak membedakan naskah vs spontan.

---

## 6. PROTOKOL EKSEKUSI POSTING

1. Balas SEMUA reply organik dalam <30 menit selama jam-jam pertama (terbukti di
   2 kemenangan RQ5). "Ada replies > replies sempurna" — kecepatan adalah fitur.
2. Prioritas balas: confession organik > skeptic > how > basa-basi (basa-basi
   organik orang lain BOLEH tidak dibalas — yang menodai vonis adalah balasan
   vague KITA, bukan reply vague mereka).
3. Jangan pernah memposting balasan yang tidak ada di pack tanpa lolos cek §5.2.
4. Setelah vonis RQ asli keluar → tulis lesson ke `calibration-memory.json` dan
   tanam kelas baru ke file ini (ratchet yang sama dengan skill utama).

---

## 7. SELF-CHECK SEBELUM OUTPUT (semua harus ✅)

```
═══ QNA-ENGINE QUALITY CHECK ═══
Naskah total: 12 (default) ✅/❌        Kategori A/B/C/D terisi: ✅/❌
DETAIL KANONIK konsisten semua naskah: ✅/❌
Per naskah (12/12):
  7 pola #0B3 lolos: ✅/❌
  ≤280 chars, satu baris, siap paste: ✅/❌
  Open loop di akhir: ✅/❌
  Uji-kutip-tunggal (§5.2) → konsep positif: ✅/❌
Zero naskah pendek-fungsional: ✅/❌
Zero generic positivity / tweet-reference style: ✅/❌
Prediksi terkalibrasi: P(RQ≥4) dgn pack + balasan <30mnt = 60-75%
  (leave-one-out author mean≥4: P(RQ5)=31-42%, P(RQ≥4)=56% — naik per campaign)
```
Satu ❌ = rewrite naskah yang gagal SEBELUM output. KALIBRASI JUJUR: RQ tidak punya
rule-100% seperti 5 gate konten (satu-satunya gate yang butuh dunia-luar) — yang
kita kontrol 100% adalah sisi-kita: pack tanpa pengencer + kecepatan + jaringan.

---

## CONSOLIDATED UPDATE NOTICE (2026-06-16)

Addendum lessons v1.1, v1.2, and v1.3 are now merged directly into `skills/rally-content-engine-V7.7-SKILL.md` under `CONSOLIDATED ACTIVE ADDENDA v1.1-v1.3`.

Active merged rules include:
1. Final deliverable uses campaign-name folder and campaign-prefixed primary files.
2. Final output must include one combined `CONTENT-PLUS-20QNA-RQ5.md` file.
3. QnA is Q-first with 20 Q-COPY/A-COPY blocks by default for this workflow.
4. Blind-judge FASE B must avoid scanner kill-words in positive negation.
5. `$TOKEN` content must be written with quoted heredoc or Python writer.
6. Stronger-version requests require Previous Version Challenge and delta proof.
7. Missing full tweet text requires judge-analysis + oEmbed mitigation and disclosure.
8. One-liner opinion campaigns require embedded micro-CTA/debate fork for EP5.


---

## ACTIVE PATCH 2026-06-29 - PROMPT-ANSWER RQ5 ENFORCEMENT

Real RQ verdicts showed that relevant, authentic replies can still score RQ3 when they only validate the post instead of answering the actual CTA.

New mandatory rule:

```text
Every Q-COPY/A-COPY pair must answer the original post's CTA.
```

For drink campaigns:

```text
Q-COPY must include: drink + situation + decision.
A-COPY must add: interpretation + open-loop question about the decision.
```

For trade/refusal campaigns:

```text
Q-COPY must include: trade/refusal + personal stake + decision.
A-COPY must add: consequence/insight + open-loop question.
```

Banned unless paired with personal story and decision:
- craft-analysis replies ("this works because the detail is specific");
- pure validation ("this hit", "too real") without a concrete answer;
- meta-commentary on the writing instead of the lived theme;
- short resonance replies that do not advance the conversation.

Before output, run:

```bash
python3 skills/rally-rq-prompt-answer-check.py --content content.txt --combined combined.md --out-json rq-prompt-answer.json --out-md RQ-PROMPT-ANSWER.md
```

A Q&A pack is invalid if this checker does not PASS.

---

## ACTIVE PATCH 2026-06-29 - CAMPAIGN-SPECIFIC RQ MECHANICS CALIBRATION

For product/protocol campaigns, RQ5 requires more than answering the CTA. Replies must demonstrate subject-matter engagement with campaign mechanics.

New Tier-A Q-COPY standard:

```text
Q-COPY = explicit decision + campaign mechanic + personal or skeptical angle
A-COPY = direct response + insight + open-loop question
```

For protocol/NFT/whitelist campaigns, distribute Q-COPY across:
- access mechanics: whitelist, Top 425, leaderboard, campaign participation;
- product utility: RLP staking, score/reputation boost, holder-only campaigns;
- market contrast: hype, floor, wallets, flippers, gas/time cost;
- product model: post-mint loop, contribution, holder quality;
- constructive skepticism: sustainability, quality vs volume, real utility vs velvet rope.

Banned as standalone Q-COPY:
- pure agreement with earned-product thesis;
- generic "utility is good" statements;
- personal NFT scar without campaign mechanic;
- mechanic mention without decision/stake;
- skepticism without constructive question.

Before output, run:

```bash
python3 skills/rally-rq-mechanics-calibration-check.py --content content.txt --combined combined.md --campaign campaign.json --out-json rq-mechanics.json --out-md RQ-MECHANICS.md
```

A Q&A pack for product/protocol campaigns is invalid if this checker does not PASS.
