# RALLY V7.7 ADDENDUM v1.7.1 — CTA QUALITY MAX FORMULA FROM REAL VERDICTS

**Date:** 2026-06-25 Asia/Jakarta  
**Status:** ACTIVE  
**Source:** Mining of 1,474 real Rally EP verdicts in local mission-scoped datasets after Wingston CTA miss.  
**Purpose:** Upgrade #0T from "direct CTA exists" to "CTA Quality MAX candidate".

---

## 1. CORE FINDING

Rally judges separate **Conversation Potential** from **CTA Quality**.

A question mark can create conversation, but CTA Quality max usually requires:

```text
behavioral verb + concrete object + campaign-native choice + low-friction reply path
```

Do not treat a rhetorical question as CTA Quality max unless campaign format forbids direct CTA and the question contains a behavioral micro-action.

---

## 2. CTA QUALITY MAX FORMULA

A top-1% CTA should satisfy at least 4/5:

1. **Behavioral verb**: choose, tell me, name, reply, comment, visit, check, test, compare, pick, share.
2. **Concrete object**: first 200 RLP, gas, two campaigns, whitelist gate, one reviewer, independent LLM consensus, private campaigns, early updates, WL paths.
3. **Campaign-native options**: choices come directly from the mission's benefits/mechanism.
4. **Low-friction reply path**: reader can answer in one short reply without inventing context.
5. **Thesis-integrated**: CTA feels like the natural consequence of the post, not pasted on.

If CTA gets 0-2/5, EP5 prediction is invalid. If 3/5, EP4 risk unless all other EP sub-rubrics are exceptional. Target is 4-5/5.

---

## 3. CTA STRENGTH LADDER

| Rank | CTA Form | EP5 Robustness |
|---|---|---|
| 1 | Direct action + multiple choice | Highest |
| 2 | Direct action + personal experience prompt | Very high |
| 3 | Direct URL/action + follow-up question | Very high for CTA-required missions |
| 4 | This-or-that choice | High |
| 5 | Reflective rhetorical question | Medium, can be EP4 risk |
| 6 | Generic prompt: thoughts/agree/drop yours | Low / OAA risk |
| 7 | No CTA / declarative ending | EP4 risk |

For top-1% attempts, use ranks 1-4 unless the campaign format explicitly forbids them.

---

## 4. REAL VERDICT PATTERNS THAT WORKED

### Resource routing CTA
```text
What would you spend your first 200 RLPs on, and which campaign are you trying first?
```
Why it worked: concrete asset + direct use case + personal reply path.

### This-or-that CTA
```text
Tell me which matters more to you: access now, or points later?
```
Why it worked: low cognitive friction and binary choice.

### Multiple-choice utility CTA
```text
What utility do you think will drive the most demand for RLPs: gas, campaign access, USDC opportunities, or whitelists?
```
Why it worked: specific options, campaign-native, easy replies.

### Action + discussion CTA
```text
Go check Rally yourself: app.rally.fun. What's the worst random rejection experience you've had on other platforms?
```
Why it worked: required action + personal experience prompt.

---

## 5. ANTI-PATTERNS FROM REAL VERDICTS

### Declarative ending
Jury language:
```text
lacks a strong, direct Call-to-Action at the end
```

### Implicit CTA only
Jury language:
```text
The implicit CTA is to look into X, but a direct prompt could have boosted engagement further.
```

### Rhetorical-only question
Risk: boosts Conversation Potential but may fail CTA Quality.

### Tacked-on CTA
Jury language:
```text
clear but feels somewhat tacked on
```

### Generic CTA
Avoid:
```text
Thoughts?
What do you think?
Agree?
Drop yours below.
Let me know.
```

---

## 6. REQUIRED FINAL AUDIT UPGRADE

Final audit must score CTA with the 5-point formula:

```text
CTA QUALITY MAX FORMULA (#0T+):
- CTA quote: [exact quote]
- Behavioral verb: yes/no, [verb]
- Concrete object: yes/no, [object]
- Campaign-native options: yes/no, [options]
- Low-friction reply path: yes/no
- Thesis-integrated: yes/no
- CTA Strength Rank: 1-7
- CTA Formula Score: X/5
- EP CTA ceiling: MAX-safe / EP4-risk
```

Pass threshold for top-1%: CTA Formula Score >=4/5 and CTA Strength Rank 1-4.

---

## 7. INTEGRATION WITH #0R EP HARSH JUDGE

EP Harsh Judge must ask:

```text
Could the judge praise conversation potential while still writing 'lacks direct CTA'?
```

If yes, revise CTA before final.

---

## ENFORCEMENT SUMMARY

For every `/rally` run:

1. Question mark is not enough.
2. Direct verb is not enough by itself.
3. Target CTA = behavioral verb + concrete object + campaign-native choice + low-friction reply path.
4. Prefer multiple-choice or this-or-that CTA for utility/explain/persuade campaigns.
5. For required URL campaigns, pair visit/check/test with a concrete choice or personal prompt when format allows.
