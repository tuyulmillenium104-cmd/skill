#!/usr/bin/env python3
"""Verify that a detached chat receives a complete portable handoff."""
import argparse,json,sys
from pathlib import Path

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',default=None);args=ap.parse_args();root=Path(args.root).resolve() if args.root else Path(__file__).resolve().parents[1];errors=[]
 mf=root/'PORTABLE_MANIFEST.json'
 if not mf.exists():errors.append('PORTABLE_MANIFEST.json missing');data={}
 else:data=json.loads(mf.read_text())
 keys=['entrypoint','skillFile','precedence','commandGuide','core','qna','goldQnaStandard','goldQnaAuditTool','epMaxTool','naturalnessTool','provenanceTool','missionContractTool','relationTool','finalIntegrityTool','handoffSelfCheck','regressionTest']
 for k in keys:
  p=data.get(k)
  if not p:errors.append(f'manifest key missing: {k}')
  elif not (root/p).exists():errors.append(f'manifest target missing: {k} -> {p}')
 required=['README_START_HERE.md','SKILL.md','AGENT_HANDOFF_PROMPT.md','PATCH_V7.8.8_PORTABLE.md','PATCH_V7.8.7_EP_MAX.md','PATCH_V7.8.6_ANTI_RIGIDITY.md','ANTI_RIGIDITY_PROTOCOL.md','skills/ACTIVE-PRECEDENCE.md','submission-plan.example.json']
 for p in required:
  if not (root/p).exists():errors.append(f'required portable file missing: {p}')
 if (root/'README_START_HERE.md').exists():
  t=(root/'README_START_HERE.md').read_text()
  for phrase in ['SNAPSHOT-MANIFEST.json','requirement provenance','EP Max Pressure Audit','Final integrity']:
   if phrase.lower() not in t.lower():errors.append(f'entrypoint lacks instruction: {phrase}')
 print('HANDOFF SELF-CHECK:', 'FAIL' if errors else 'PASS')
 for e in errors:print('  FAIL:',e)
 if not errors:print(f'  Version: {data.get("version")} | entrypoint={data.get("entrypoint")} | required targets={len(keys)}')
 sys.exit(1 if errors else 0)
if __name__=='__main__':main()
