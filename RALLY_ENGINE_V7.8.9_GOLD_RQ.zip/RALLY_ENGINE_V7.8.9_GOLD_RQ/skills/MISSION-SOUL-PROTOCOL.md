# RALLY V7.7 ADDENDUM v1.4 — MISSION-SOUL PROTOCOL (2026-06-24)

**Date:** 2026-06-24 Asia/Jakarta
**Status:** ACTIVE
**Reason:** Post-mortem dari sesi `/rally 0x797E72FA` campaign "What's GenLayer?" mengungkap 8 kegagalan sistematik yang akarnya sama: **agent tidak memahami jiwa misi secara mendalam sebelum menulis, dan DNA tidak di-scope per-misi.** Addendum ini menutup semua celah.

---

## 1. NEW META-RULE #0B2: MISSION-SCOPED DNA

**DNA WAJIB DI-SCOPE PER MISI, BUKAN HANYA PER CAMPAIGN.**

Campaign multi-misi punya perintah BERBEDA per misi. Mission-0 dan mission-1 pada campaign yang sama bisa minta hal fundamental berbeda (mis. "explain WHAT GenLayer is" vs "identify WHO needs GenLayer"). DNA yang dicampur lintas misi = TERKONTAMINASI = invalid untuk pembuatan keputusan.

**KENAPA ATURAN INI ADA:** Sesi 2026-06-24 membuktikan bahwa 3/8 winner yang dianalisis untuk mission-0 ternyata adalah submission mission-1. Pola mereka (deep-dive proyek spesifik: ResearchHub, Dework) adalah pola mission-1, BUKAN mission-0. Analisis jalan di data yang salah.

**RULE:**
1. Jika campaign punya >1 mission → DNA WAJIB di-filter by `missionId` sebelum analisis.
2. `python3 skills/rally-dna-fetcher.py --address <addr> --mission mission-0` (flag `--mission` WAJIB untuk campaign multi-misi).
3. Winner DNA dari mission A TIDAK BOLEH dipakai untuk produksi konten mission B.
4. Failure patterns (loser DNA) juga WAJIB mission-scoped. Vonis EP4 dari mission-1 tidak relevan untuk audit mission-0.

**TEST:** Sebelum load DNA, tanya: "Apakah campaign ini punya >1 mission?" Jika YA → filter WAJIB. Jika mission target belum punya submissions → disclose dan pakai Appendix B (projected).

---

## 2. NEW STEP 0.5: MISSION-SOUL DECODE (SEBELUM STEP 1)

**SEBELUM SATU KATA DITULIS, WAJIB MEMAHAMI JIWA MISI SECARA MENDALAM.**

Akar dari hampir semua kegagalan terdokumentasi: agent langsung lompat ke "skenario visceral" tanpa paham jiwa misi. Hasilnya: konten kuat secara emosi tapi salah secara purpose.

**PROSES (WAJIB, output ke user):**

```
═══ STEP 0.5 — MISSION-SOUL DECODE ═══

MISSION TARGET: [id] — [title]

A. BRIEF VERBATIM (paste persis, jangan parafrase):
   [paste mission description lengkap]

B. JIWA MISI (apa yang SEBENARNYA diminta):
   - VERB utama: [explain? identify? persuade? predict? imagine?]
   - OUTPUT yang diminta: [pemahaman konsep? daftar proyek? opini?]
   - Pembaca yang diminta: [non-crypto native? crypto native? builder?]
   - Apa yang pembaca harus RASAKAN setelah baca: [paham? tertarik? tertantang?]

C. MISSION-TYPE (dari playbook §3 di bawah):
   [EXPLAIN / IDENTIFY / PERSUADE / PREDICT / IMAGINE / lainnya]
   -> Struktur yang benar untuk tipe ini: [...]

D. STRUCTURE & VOICE DECISION:
   - Struktur: [conceptual teaching / project deep-dive / argument / narrative]
   - Voice: [authoritative / analytical / personal / provocative]
   - Purpose: [teach / identify / argue / evoke]

E. VERIFIKASI (sebelum tulis konten):
   □ Apakah skenario yang akan kupakai SERVE tujuan misi? (bukan menggantikan?)
   □ Apakah struktur yang kupilih cocok UNTUK MISI INI? (bukan template default?)
   □ Jika campaign punya multiple mission: apakah struktur misi INI berbeda dari mission LAIN?

Compliance: X% — PASS / FAIL
══════════════════════════════════════════
```

---

## 3. MISSION-TYPE PLAYBOOK

**Skill sebelumnya punya Principle G (Philosophical/Tactical/Hybrid) untuk klasifikasi campaign STYLE. Tapi TIDAK punya klasifikasi MISSION TYPE — yang menentukan STRUKTUR konten. Ini celah yang menyebabkan template duplikasi.**

### MISSION-TYPE TAXONOMY:

| Mission Type | Brief Signal | Struktur yang Benar | Struktur yang SALAH | Skenario Berperan Sebagai |
|---|---|---|---|---|
| **EXPLAIN** | "Explain what X is", "Describe", "Make it easy to understand" | Conceptual teaching: insight → mechanism → why it matters | Emotional narrative yang menggantikan penjelasan | Ilustrasi pengajaran (membuat konsep klik) |
| **IDENTIFY** | "Identify who needs X", "Which projects/industries" | Project deep-dive: named project → why it breaks → specific fix | Industri abstrak / generic "this industry needs it" | Kasus nyata proyek spesifik yang patah |
| **PERSUADE** | "Argue", "Make the case", "Why is X important" | Argument: thesis → evidence → conclusion | List fitur / educational tanpa posisi | Bukti yang mendukung thesis |
| **PREDICT** | "Predict", "What will happen" | Prediction + reasoning + stakes | Vague speculation tanpa komitmen | Skenario masa depan yang konkret |
| **IMAGINE** | "Imagine", "Invent", "Create" | Creative output yang match format ask | Generic content yang tidak inventif | Konsep orisinal yang belum ada |

### EXPLAIN MISSION RULES (mis. mission-0 "What is GenLayer?"):
1. **MENGAJAR dulu.** Pembaca harus keluar BENAR-BENAR PAHAM konsep, bukan hanya merasakan emosi.
2. **Skenario = ilustrasi pengajaran**, bukan manipulasi emosi. Test: setelah baca, apakah pembaca bisa MENJELASKAN kembali apa GenLayer ke orang lain? Jika tidak → konten gagal mengajar.
3. **Pakai analogi/kontras** yang brief sarankan (court of appeals? consensus engine? kenapa chain lain tidak bisa?).
4. **GenLayer = konsep yang dijelaskan**, bukan jawaban emosional untuk trauma.

### IDENTIFY MISSION RULES (mis. mission-1 "Who needs GenLayer?"):
1. **WAJIB named specific project** (bisa ditunjuk: ResearchHub, Dework, RetroPGF). Industri abstrak ("lending platforms") = LEMAH.
2. **Deep-dive satu proyek**: kenapa proyek INI spesifik patah tanpa GenLayer.
3. **GenLayer = perbaikan spesifik untuk proyek itu**, bukan jawaban generik.
4. **Ekstensi ke kategori** di akhir (optional): "every project like this needs it."

---

## 4. TEMPLATE DUPLICATION BAN

**SAAT PRODUKSI KONTEN UNTUK MULTIPLE MISSION, STRUKTUR/VOICE/PURPOSE WAJIB BERBEDA PER MISI.**

**KENAPA ATURAN INI ADA:** Sesi 2026-06-24 menghasilkan mission-0 dan mission-1 dengan template IDENTIK (trauma narrative → "nobody could tell me why" → "this is the gap @GenLayer" → validators → CTA). Bukan dua karya, satu formula diisi dua skenario.

**RULE:**
1. Jika produksi konten untuk >1 mission pada campaign yang sama → setiap mission WAJIB punya struktur/voice/purpose yang BERBEDA.
2. **CEK EKSPLISIT sebelum output:** bandingkan struktur misi A vs misi B. Jika opener/arc/voice sama → **TEMPLATE DUPLICATION** → REWRITE salah satu.
3. Beda yang WAJIB: opener type, narrative arc, voice register, purpose.

**DUPLICATION TEST:**
```
Bandingkan opener mission A vs mission B:
  - Apakah keduanya mulai dengan first-person trauma? -> DUPLIKASI
  - Apakah keduanya pakai "nobody could tell me why"? -> DUPLIKASI
  - Apakah keduanya pakai "this is the gap @GenLayer"? -> DUPLIKASI
  - Apakah arc keduanya identical (problem→emotion→GenLayer→CTA)? -> DUPLIKASI
Jika ADA duplikasi → REWRITE dengan struktur yang cocok mission-type-nya.
```

---

## 5. SCANNER SELF-VALIDATION DISCLOSURE

**SCANNER PASS PADA VONIS YANG DITULIS SENDIRI = BUKAN BUKTI.**

**KENAPA ATURAN INI ADA:** Agent menulis vonis simulasi dengan vocab winner ("demonstrates exceptional engagement") lalu menjalankan scanner yang PASS. Skill sendiri bilang ini TIDAK SAH (anti-self-deception rule a). Tapi agent mempresentasikan "5 GATE PASS" sebagai bukti top-1%.

**RULE:**
1. Scanner PASS pada self-written vonis WAJIB didisclosure sebagai: **"SCANNER: PASS (self-validated — vonis ditulis oleh agent yang sama, BUKAN bukti vonis juri asli. Per Meta-Rule anti-self-deception, ini hanya menunjukkan vonis-saya-anggap-lolos.)"**
2. DILARANG presentasikan "5 GATE PASS" tanpa konteks ini.
3. DILARANG klaim "siap submit / top-1%" berdasarkan scanner self-validated saja.
4. Yang scanner self-validated BISA klaim: "vonis simulasi tidak mengandung kill-words yang dikenal." Itu saja.

---

## 6. #0F PENGUAT: REBUILD VS PATCH

**JIKA EVALUASI JUJUR MENUNJUKKAN STRUKTUR/ANGLE SALAH (BUKAN DETAIL), WAJIB REBUILD BUKAN PATCH.**

**KENAPA PENGUAT INI ADA:** Sesi 2026-06-24 menunjukkan agent iteratif patch konten yang salah fondasi (tambah Optimistic Democracy, tambah framing, tambah stanza breaks) alih-alih mengakui fondasinya salah dan rebuild. Hasilnya: "compressed thread" 6 gerakan yang ditambal, bukan satu pukulan bersih.

**RULE (penguat Meta-Rule #0F):**
1. Jika evaluasi menunjukkan masalah di level **STRUKTUR/ANGLE/PURPOSE** (bukan detail word-level) → **WAJIB REBUILD dari nol**, bukan patch.
2. Patch hanya untuk detail-level fixes (ganti kata, tambah stanza break, sesuaikan CTA).
3. Tanda struktur salah (REBUILD trigger):
   - Konten punya >4 "moves" (multi-arc) dalam satu post
   - Skenario tidak SERVE purpose misi (mis. emosi menggantikan teaching)
   - Template duplikasi dengan mission lain
   - Reader tidak bisa menjelaskan kembali konsep setelah baca (EXPLAIN mission)
4. Setelah REBUILD, jalankan ulang Step 0.5 Mission-Soul Decode untuk verifikasi.

---

## 7. EXECUTION-LEVEL DNA EXTRACTION (Addendum v1.4 — NEW)

**WINNER DNA EXTRACTION WAJIB MENCAPAP LEVEL EKSEKUSI, BUKAN HANYA LEVEL KONTEN.**

**KENAPA ATURAN INI ADA:** Sesi Wingston (2026-06-24) mengungkap bahwa agent "membaca" winner DNA dan "melihat" bagaimana winner menempatkan mention, tetapi SAAT MENULIS tidak mengekstrak pola itu. Hasilnya: `@RallyOnChain` ditempel sebagai paragraf kosong yang berdiri sendiri — persis anti-pattern M1 (tacked-on mention) — padahal KEDUA winner mengintegrasikannya secara natural sebagai subjek/lokasi kalimat.

**Akar masalah:** Perbandingan DNA berhenti di level makro (angle, struktur, panjang) dan MELEWATKAN level mikro (bagaimana winner mengeksekusi detail). Mention diperlakukan sebagai CHECKLIST ITEM ("apakah ada?") bukan EXECUTION PATTERN ("bagaimana winner menempatkannya?").

**RULE: Setelah load Winner DNA, WAJIB ekstrak execution-level patterns berikut:**

| Pattern | Yang Dicek | Contoh Ekstraksi |
|---|---|---|
| **Mention placement** | Bagaimana winner menempatkan @brand? (subjek/objek/lokasi vs standalone/appended) | "@RallyOnChain just announced..." (subjek) BUKAN "@RallyOnChain" (paragraph kosong) |
| **Mention position** | Pada posisi char ke berapa? (winner biasanya 30-50%, bukan appended di akhir) | Jika winner di 35%, jangan tempel di 90% |
| **Mention count** | Berapa kali? (winner biasanya tepat 1x) | Jangan 0x (missing) atau 3x (spam) |
| **Sentence rhythm** | Pola paragraph winner: panjang/pendek? Staccato vs flowing? | Match ritme, jangan semua paragraf panjang jika winner pakai staccato |
| **Opener type** | Bagaimana winner membuka? (declarative/question/confession/fact) | Jangan pakai opener generic kalau winner pakai declarative punch |
| **CTA execution** | Bagaimana winner menutup? (pertanyaan vs statement vs challenge) | Match execution style CTA winner |
| **Paragraph count** | Berapa paragraf winner? Stanza breaks? | Jangan 1 wall of text jika winner pakai 8+ stanza |

**EXECUTION-LEVEL DNA EXTRACTION FORMAT (WAJIB output sebelum Step 4):**

```
═══ EXECUTION-LEVEL DNA (dari N winner) ═══
Mention placement: [subjek/objek/lokasi/standalone] — contoh winner: "..."
Mention position: [X]% avg — range [A-B]%
Mention count: [N]x avg
Sentence rhythm: [staccato/flowing/mixed] — winner pattern: [desc]
Opener type: [declarative/question/confession/fact]
CTA execution: [question/challenge/statement]
Paragraph count: [N] avg — stanza breaks: [Y/N]

KONTEN SAYA MUST MATCH execution-level ini, bukan hanya content-level.
═════════════════════════════════════════════
```

**TEST SEBELUM OUTPUT:** Bandingkan konten draft vs execution-level DNA. Jika mention berdiri sendiri (standalone), posisi di akhir (appended), atau ritme tidak match winner → FIX sebelum output.

---

## ENFORCEMENT SUMMARY

Untuk setiap future `/rally` run:

1. **STEP 0.5 MISSION-SOUL DECODE** — WAJIB sebelum Step 1. Bedah brief, identifikasi jiwa, tentukan struktur.
2. **MISSION-SCOPED DNA** — `--mission` flag WAJIB untuk campaign multi-misi. DNA campur = invalid.
3. **MISSION-TYPE PLAYBOOK** — struktur konten WAJIB cocok dengan tipe misi (EXPLAIN=teach, IDENTIFY=named project).
4. **TEMPLATE DUPLICATION BAN** — multi-mission: struktur WAJIB beda. Cek eksplisit.
5. **SCANNER SELF-VALIDATION DISCLOSURE** — scanner PASS = self-validated, BUKAN bukti.
6. **REBUILD VS PATCH** — struktur salah = rebuild, bukan patch.
7. **EXECUTION-LEVEL DNA** — ekstrak BAGAIMANA winner menulis (mention placement, rhythm, opener), bukan hanya APA. Cek sebelum output.
