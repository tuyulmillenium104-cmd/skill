#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rally Campaign Cartographer.

Maps a campaign mission before content generation:
- mission-scoped DNA fetch/cache
- DNA confidence
- winner DNA map
- EP deduction map
- OAA/TQ/RQ verdict pattern maps
- topic saturation
- strategy recommendation

This is an orchestration/intelligence tool, not a writer.
"""
import argparse, json, os, re, subprocess, sys, time
from pathlib import Path
from collections import Counter, defaultdict

ROOT = Path.cwd()

DEDUCTION_MARKERS = [
    'however','but ','lacks','lack of','missing','could','would benefit','slightly','somewhat',
    'not fully','limited','generic','formulaic','dense','too long','media','cta','call-to-action',
    'question','conversation','value delivery','solid','promotional','overlap','similar','template',
    'unclear','weak','minor','notably','moderate','competent','AI-generated'.lower(), 'vague'
]

GATE_CATEGORY = {
    'EP': 'Engagement Potential',
    'OAA': 'Originality',
    'TQ': 'Technical Quality',
    'IA': 'Information Accuracy',
    'CA': 'Content Alignment',
    'CC': 'Campaign Compliance',
    'RQ': 'Reply Quality',
}

STOP = set('the a an and or but to of in on for with is are was were be been being it this that as at by from you your i my me we they them if not just more most no one do does did into about how why what when where who'.split())

def run(cmd, allow_fail=False):
    print('RUN:', ' '.join(map(str, cmd)))
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(p.stdout)
    if p.returncode and not allow_fail:
        raise SystemExit(p.returncode)
    return p

def load_json(path):
    return json.load(open(path, encoding='utf-8'))

def text_tokens(t):
    return [x for x in re.findall(r"[a-z0-9@']+", (t or '').lower()) if x not in STOP and len(x)>2]

def split_sentences(t):
    return [s.strip() for s in re.split(r'(?<=[.!?。；;])\s+|\n+', t or '') if s.strip()]

def category_text(sub, gate):
    needle = GATE_CATEGORY[gate]
    return ' '.join(a.get('analysis','') for a in sub.get('analysis') or [] if needle in (a.get('category') or ''))

def gate_deduction_map(subs, gate, max_score):
    rows=[]; cls=Counter(); samples=defaultdict(list)
    for s in subs:
        score=(s.get('gates') or {}).get(gate, [None])[0]
        if score is None or score >= max_score: continue
        txt=category_text(s, gate)
        for sent in split_sentences(txt):
            sl=sent.lower()
            if any(m in sl for m in DEDUCTION_MARKERS):
                label='general'
                if any(x in sl for x in ['cta','call-to-action','question','prompt','reply']): label='cta/conversation'
                elif any(x in sl for x in ['generic','template','formulaic','common','similar','overlap','familiar']): label='generic/overlap'
                elif any(x in sl for x in ['media','url','image','format','dense','readability','too long']): label='format/media'
                elif any(x in sl for x in ['unsupported','unverified','misleading','overstate','inaccurate','claim']): label='claim/accuracy'
                elif any(x in sl for x in ['specific','concrete','detail','vague']): label='specificity'
                elif any(x in sl for x in ['value','solid','underdeveloped','limited']): label='value ceiling'
                cls[label]+=1
                if len(samples[label])<8: samples[label].append({'author':s.get('xUsername'),'score':score,'sentence':sent})
                rows.append({'author':s.get('xUsername'),'score':score,'class':label,'sentence':sent})
    return {'gate':gate,'nonMaxCount':sum(1 for s in subs if (s.get('gates') or {}).get(gate,[max_score])[0] < max_score),'sentenceCount':len(rows),'classCounts':dict(cls),'samples':dict(samples),'rows':rows[:300]}

def topic_saturation(subs):
    unig=Counter(); big=Counter(); tri=Counter()
    for s in subs:
        toks=text_tokens(s.get('content') or '')
        unig.update(toks)
        big.update(' '.join(toks[i:i+2]) for i in range(len(toks)-1))
        tri.update(' '.join(toks[i:i+3]) for i in range(len(toks)-2))
    return {
        'topTerms': unig.most_common(40),
        'topBigrams': big.most_common(40),
        'topTrigrams': tri.most_common(40),
    }

def infer_mission_type(mission):
    """Infer mission intent from the ask, not incidental technical nouns."""
    title=(mission.get('title') or '').strip().lower()
    desc=(mission.get('description') or '').strip().lower()
    rules=(mission.get('rules') or '').strip().lower()
    lead=' '.join((title+' '+desc).split()[:80])
    # Title intent outranks supporting verbs in the description. For example,
    # "Make a Bold Prediction ... explain why" is PREDICT, not EXPLAIN.
    if re.search(r"\b(predict|prediction|forecast)\b", title):
        return 'PREDICT'
    if re.search(r"\b(explain|what is|describe|define)\b", title):
        return 'EXPLAIN'
    if re.search(r"\b(identify|who needs|which projects|which industries)\b", title):
        return 'IDENTIFY'
    if re.search(r"\b(predict|prediction|forecast|what will happen)\b", lead):
        return 'PREDICT'
    if re.search(r"\b(explain|describe|define|what is|make it easy|in simple words)\b", lead):
        return 'EXPLAIN'
    if re.search(r"\b(identify|who needs|which projects|which industries)\b", lead):
        return 'IDENTIFY'
    if re.search(r"\b(imagine|invent|create a|design a)\b", lead):
        return 'IMAGINE'
    if re.search(r"\b(tell us about a time|personal experience|share the moment|confess)\b", lead):
        return 'PERSONAL EXPERIENCE'
    # ARGUE requires an explicit instruction, not the mere noun "verdict".
    if re.search(r"\b(hot take|controversial opinion|argue|defend your position|give your verdict|your opinion)\b", lead):
        return 'ARGUE / HOT TAKE / VERDICT'
    if re.search(r"\b(persuade|make the case|urge|drive people|visit|join|mint)\b", lead+' '+rules):
        return 'PERSUADE'
    return 'GENERAL'

def strategy_reco(campaign, mission, dna, confidence, winner_map, ep_map, topic_map, gate_maps):
    mtype=infer_mission_type(mission)
    lines=[]
    lines.append('# MISSION STRATEGY RECOMMENDATION\n')
    lines.append(f"Campaign: **{campaign.get('title')}**  \nMission: **{mission.get('id')} — {mission.get('title')}**  \nMission type: **{mtype}**\n\n")
    lines.append('## Brief Core\n\n')
    lines.append((mission.get('description') or campaign.get('goal') or '').strip()+"\n\n")
    lines.append('## DNA Confidence\n\n')
    lines.append(f"- Winners: {dna.get('winners')}\n- Non-winners: {dna.get('nonWinners')}\n- Full content retrieval: {dna.get('contentRetrieval',{}).get('fullContent')}/{dna.get('totalSubmissions')}\n\n")
    lines.append('## Winner Construction Signals\n\n')
    lines.append(f"- Winner-like samples: {winner_map.get('winnerLikeCount')}\n")
    lines.append(f"- Opener types: {winner_map.get('openerCounts')}\n")
    lines.append(f"- Median chars: {winner_map.get('charMedian')}\n")
    lines.append(f"- Median paragraphs: {winner_map.get('paragraphMedian')}\n")
    lines.append(f"- Mention position median: {winner_map.get('mentionPosMedian')}\n\n")
    if winner_map.get('rows'):
        lines.append('### Winner CTA tails / endings\n')
        for r in winner_map['rows'][:8]: lines.append(f"- @{r['author']}: `{r.get('ctaTail','')[:220]}`\n")
        lines.append('\n')
    lines.append('## EP Deduction Classes To Avoid\n\n')
    for k,v in sorted((ep_map.get('classCounts') or {}).items(), key=lambda x:x[1], reverse=True): lines.append(f"- {k}: {v}\n")
    lines.append(f"\nUnknown EP classes: **{ep_map.get('unknownClassCount',0)}**  \nDecision: **{ep_map.get('decision')}**\n\n")
    lines.append('## Other Gate Risk Maps\n\n')
    for gm in gate_maps:
        lines.append(f"### {gm['gate']}\n")
        for k,v in sorted(gm.get('classCounts',{}).items(), key=lambda x:x[1], reverse=True): lines.append(f"- {k}: {v}\n")
        lines.append('\n')
    lines.append('## Topic Saturation\n\n')
    lines.append('Top bigrams/trigrams are crowded. Avoid copying these unless campaign-mandatory.\n\n')
    lines.append('### Top bigrams\n')
    for t,c in topic_map['topBigrams'][:20]: lines.append(f"- {t}: {c}\n")
    lines.append('\n### Top trigrams\n')
    for t,c in topic_map['topTrigrams'][:20]: lines.append(f"- {t}: {c}\n")
    lines.append('\n## Recommended Strategy\n\n')
    if 'VERDICT' in mtype or 'HOT TAKE' in mtype:
        lines.append('- Start with verdict label if required.\n- Pick a specific target, not a broad category.\n- Defend with one memorable mechanism/nameable frame.\n- End with a campaign-native choice CTA.\n')
    elif 'PERSONAL' in mtype:
        lines.append('- Use one concrete lived moment.\n- Show obstacle, action, result, and lesson.\n- Keep brand bridge earned by story pain.\n- End with personal-experience CTA.\n')
    elif 'EXPLAIN' in mtype:
        lines.append('- Teach mechanism first.\n- Use analogy only to clarify, not replace explanation.\n- Include concrete required facts.\n- End with direct behavioral CTA if EP matters.\n')
    else:
        lines.append('- Follow mission verb and avoid crowded topic structures.\n')
    lines.append('\n## Mandatory Final Gates\n\n- CTA #0T+ PASS\n- EP deduction map PASS unknown=0\n- EP semantic review PASS\n- Loser DNA #0S2 PASS\n- OAA/TQ/IA adaptive audits PASS\n- Final integrity v2 PASS\n')
    return ''.join(lines)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--address', required=True)
    ap.add_argument('--mission', required=True)
    ap.add_argument('--page-size', type=int, default=300)
    ap.add_argument('--max-total', type=int, default=0, help='0 fetches complete current API pool')
    ap.add_argument('--limit', type=int, default=None, help='deprecated alias for --max-total')
    ap.add_argument('--out', default=None)
    ap.add_argument('--use-cache', action='store_true')
    args=ap.parse_args()
    short=args.address[:10]
    out=Path(args.out or f'rally-data/learn/{short}-{args.mission}')
    out.mkdir(parents=True, exist_ok=True)

    dna_path=out/'dna.json'
    if not args.use_cache or not dna_path.exists():
        cmd=['python3','skills/rally-dna-fetcher.py','--address',args.address,'--mission',args.mission,'--page-size',str(args.page_size),'--out',str(out)]
        max_total=args.limit if args.limit is not None else args.max_total
        if max_total:
            cmd += ['--max-total',str(max_total)]
        run(cmd)
    campaign=load_json(out/'campaign.json')
    dna=load_json(out/'dna.json')
    subs=load_json(out/'submissions_enriched.json')
    mission=next((m for m in campaign.get('missions',[]) if m.get('id')==args.mission), {'id':args.mission,'title':args.mission,'description':campaign.get('goal',''),'rules':''})

    run(['python3','skills/rally-requirement-provenance.py','--campaign',str(out/'campaign.json'),'--mission',args.mission,'--out-json',str(out/'requirement-provenance.json'),'--out-md',str(out/'REQUIREMENT-PROVENANCE.md')], allow_fail=False)
    run(['python3','skills/rally-mission-contract.py','--provenance',str(out/'requirement-provenance.json'),'--out',str(out/'mission-contract.json')], allow_fail=False)
    run(['python3','skills/rally-dna-confidence.py','--dna',str(dna_path),'--out',str(out/'dna-confidence.md')], allow_fail=True)
    run(['python3','skills/rally-winner-dna-map.py','--submissions',str(out/'submissions_enriched.json'),'--campaign',str(out/'campaign.json'),'--mission',args.mission,'--out-json',str(out/'winner-dna-map.json'),'--out-md',str(out/'WINNER-DNA-MAP.md')], allow_fail=True)
    # EP map pre-content can return REVIEW due unknown classes; this is cartography, so allow fail.
    run(['python3','skills/rally-ep-deduction-map.py','--submissions',str(out/'submissions_enriched.json'),'--out-json',str(out/'ep-deduction-map.json'),'--out-md',str(out/'EP-DEDUCTION-MAP.md')], allow_fail=True)

    confidence=(out/'dna-confidence.md').read_text(encoding='utf-8') if (out/'dna-confidence.md').exists() else ''
    winner_map=load_json(out/'winner-dna-map.json') if (out/'winner-dna-map.json').exists() else {}
    ep_map=load_json(out/'ep-deduction-map.json') if (out/'ep-deduction-map.json').exists() else {}
    gate_maps=[]
    max_scores={'OAA':2,'TQ':5,'IA':2,'CC':2,'RQ':5}
    for gate,mx in max_scores.items():
        gm=gate_deduction_map(subs, gate, mx)
        gate_maps.append(gm)
        (out/f'{gate.lower()}-deduction-map.json').write_text(json.dumps(gm,ensure_ascii=False,indent=2),encoding='utf-8')
    topic=topic_saturation(subs)
    (out/'topic-saturation.json').write_text(json.dumps(topic,ensure_ascii=False,indent=2),encoding='utf-8')
    mission_map=strategy_reco(campaign, mission, dna, confidence, winner_map, ep_map, topic, gate_maps)
    (out/'MISSION-MAP.md').write_text(mission_map, encoding='utf-8')
    summary={
        'campaign':campaign.get('title'), 'address':args.address, 'mission':args.mission,
        'missionType':infer_mission_type(mission), 'submissions':len(subs), 'winners':dna.get('winners'),
        'nonWinners':dna.get('nonWinners'), 'fullContent':dna.get('contentRetrieval',{}).get('fullContent'),
        'outputs':[str(out/'MISSION-MAP.md'), str(out/'WINNER-DNA-MAP.md'), str(out/'EP-DEDUCTION-MAP.md')]
    }
    (out/'cartography-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print('\nCARTOGRAPHY COMPLETE')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
