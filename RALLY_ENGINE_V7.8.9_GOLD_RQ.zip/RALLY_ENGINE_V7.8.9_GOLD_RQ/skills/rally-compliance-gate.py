#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RALLY COMPLIANCE GATE v1.0 (V7.5.3 — Meta-Rule #0J enforcement)
Checker programatik yang TIDAK BISA dinego oleh reasoning LLM.
Pakai: python3 rally-compliance-gate.py content.txt contract.json
Exit code 0 = boleh lanjut. Exit code 1 = DILARANG output ke user.

contract.json dibuat SEBELUM konten ditulis (Step 1.5), contoh:
{
  "mention": "@RallyOnChain",
  "one_sentence": true,
  "require_closing_period": true,
  "max_chars": 280,
  "max_connectors": 1,
  "audience_max_word_len": 10,
  "banned_definitive_numbers": ["twelve", "12", "twenty-four", "24"],
  "require_cta_question": true,
  "forbid_fourth_wall": true,
  "scalar_targets": {"flip_test_pct": 90, "reveal_position_pct": 80}
}
"""
import sys, re, json, unicodedata
from rally_common import find_url_issues, sha256_text

def fail(msgs):
    print("=" * 60)
    print("COMPLIANCE GATE: FAIL — DILARANG OUTPUT KE USER")
    for m in msgs: print("  FAIL: " + m)
    print("Per Meta-Rule #0J: fix dulu, atau buktikan 2 attempted-fix gagal.")
    print("=" * 60)
    sys.exit(1)

def main():
    content = open(sys.argv[1], encoding='utf-8').read().strip()
    contract = json.load(open(sys.argv[2], encoding='utf-8'))
    errs = []
    warnings = []
    body = content
    m = contract.get("mention")
    required_mentions=contract.get('required_mentions') or ([m] if m else [])
    for req in required_mentions:
        if content.count(req)!=1:errs.append("mention %s harus tepat 1x (found %d)" % (req,content.count(req)))
        body=body.replace(req,'').strip()
    if content[0] in "@#": errs.append("diawali mention/hashtag")
    dashes = [c for c in set(content) if unicodedata.category(c) == "Pd" and c != "-"]
    if dashes: errs.append("unicode dash terlarang: %r" % dashes)
    sq = sum(content.count(c) for c in "\u2018\u2019\u201c\u201d")
    if sq: errs.append("smart quotes: %d" % sq)
    if re.findall(r"#\w+", content): errs.append("hashtag ditemukan")
    nonascii = [c for c in set(content) if ord(c) > 127]
    if nonascii: errs.append("non-ascii/hidden: %r" % nonascii)
    # Only a literal campaign/platform maximum is compliance-hard. Legacy
    # `max_chars` is treated as an engine soft target unless explicitly marked
    # official, preventing the 850 EP target from becoming fake campaign law.
    official_max=contract.get('official_max_chars')
    if official_max is None and contract.get('max_chars_is_official'):
        official_max=contract.get('max_chars')
    soft_max=contract.get('engine_soft_target_max',contract.get('max_chars'))
    if official_max and len(content)>official_max:
        errs.append("chars %d > official max %d" % (len(content),official_max))
    elif soft_max and len(content)>soft_max:
        warnings.append("chars %d > engine soft target %d (review, not campaign violation)" % (len(content),soft_max))
    if contract.get("one_sentence"):
        # LESSON TQ (0I-11 L3): 0 internal enders TAPI WAJIB 1 period penutup
        stripped = body.rstrip(".")
        internal = len(re.findall(r"[.!?]", stripped))
        if internal: errs.append("one-sentence: %d sentence-ender internal" % internal)
        if contract.get("require_closing_period", True):
            # period boleh sebelum mention; cek body asli berakhir dengan '.'
            if not body.endswith("."): errs.append("TIDAK ADA period penutup (jury TQ deduction, 0I-11 L3)")
    if contract.get("max_connectors") is not None:
        conn = len(re.findall(r"\b(because|so that|so |which is why|and that means)\b", body.lower()))
        if conn > contract["max_connectors"]:
            errs.append("klausa konektor %d > max %d (readability anak, 0I-11 L3)" % (conn, contract["max_connectors"]))
    if contract.get("audience_max_word_len"):
        hard = [w for w in set(re.findall(r"[a-zA-Z'-]+", body.lower())) if len(w) > contract["audience_max_word_len"]]
        if hard: errs.append("kata terlalu panjang utk audiens: %s" % hard)
    for n in contract.get("banned_definitive_numbers", []):
        # LESSON IA (0I-11 L1): angka definitif pada fakta ber-varian
        if re.search(r"\bthe %s\b" % re.escape(n), body.lower()):
            errs.append("OVERSPECIFIED definitive number: 'the %s' (0I-11 L1 — WAJIB FIX, bukan residu)" % n)
    # Real-judge URL guard, including Markdown wrappers and path URLs.
    url_issues=find_url_issues(content)
    if url_issues['markdownLinks']:
        errs.append("Markdown link syntax tidak valid untuk copy X: %r" % url_issues['markdownLinks'][:3])
    if url_issues['attachedPunctuation']:
        x=url_issues['attachedPunctuation'][0]
        errs.append("URL diikuti tanda baca menempel: %r + %r" % (x['url'],x['punctuation']))
    if contract.get("require_cta_question"):
        # LESSON EP (0I-11 L2): campaign ini butuh conversation starter
        if "?" not in body: errs.append("tidak ada pertanyaan/CTA (0I-11 L2 — cek modus kritik EP pool campaign INI)")
    if contract.get("forbid_fourth_wall"):
        fw = [p for p in ["asked for a", "this campaign", "this submission", "my entry", "characters of this"] if p in body.lower()]
        if fw: errs.append("fourth-wall break: %s" % fw)
    if errs: fail(errs)
    print("COMPLIANCE GATE: ALL BINARY PASS (%d chars)" % len(content))
    print("CONTENT SHA256: %s" % sha256_text(content))
    for w in warnings: print("COMPLIANCE REVIEW: " + w)
    print("SCALAR targets (uji manual + laporkan terukur, JANGAN klaim PASS):")
    for k, v in contract.get("scalar_targets", {}).items(): print("  - %s: target %s" % (k, v))
    sys.exit(0)

if __name__ == "__main__":
    main()
