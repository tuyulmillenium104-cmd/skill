# INTERNAL DECISION SUMMARY — TEMPLATE RESMI (WAJIB)
## Untuk Semua /rally setelah Foundation Locked (Anti-Skip v1.0 + META-RULE #0S)

**Tujuan Template Ini:**
- Memaksa agent tetap teliti dalam evaluasi internal (karena reasoning akan terlihat).
- Memberi transparansi kepada user tanpa menampilkan multiple full versions.
- Menjaga 1 run full continuous (tidak ada pause, tidak ada "pilih mana").
- Hanya 1 konten final + 1 ringkasan keputusan yang boleh keluar.

---

## FORMAT WAJIB (Copy-paste dan isi persis)

```markdown
INTERNAL DECISION SUMMARY (per META-RULE #0S — WAJIB)

**1. Kandidat Internal yang Dievaluasi (maks 2)**
- Draft 1 [xxx chars]:  
  "The opinion that ... @RallyOnChain"
  - Three-Lens Total: X/9 (L1: /3, L2: /3, L3: /3)
  - EP (rally-rules.py): PASS / FAIL — nc_ep=...
  - OAA: X/5 | CA: X/5
  - Winner DNA Fit: [kuat/sedang/lemah] — cocok dengan: [sebutkan 1-2 marker]
  - Gap/Overlap: 0% / X% (dari STEP 3)
  - Compliance Gate: PASS / FAIL
  - Alasan potensial: ...

- Draft 2 [xxx chars] ← **DIPILIH sebagai Single Best**
  "The opinion that ... @RallyOnChain"
  - Three-Lens Total: X/9 (L1: /3, L2: /3, L3: /3)
  - EP (rally-rules.py): PASS / FAIL — nc_ep=...
  - OAA: X/5 | CA: X/5
  - Winner DNA Fit: [kuat/sedang/lemah] — cocok dengan: [sebutkan 1-2 marker]
  - Gap/Overlap: 0% / X% (dari STEP 3)
  - Compliance Gate: PASS / FAIL
  - Alasan potensial: ...

**2. Alasan Pemilihan Single Best**
- Kriteria utama yang menentukan kemenangan: [contoh: EP bersih (nc_ep=0), mekanisme lebih tajam, cocok Winner DNA, 0% overlap]
- Mengapa bukan Draft 1: [alasan singkat, misal: EP masih ada residu / mekanisme kurang spesifik / panjang kurang optimal]

**3. Trade-off & Rollback yang Terjadi (jika ada)**
- Trade-off: [contoh: sedikit lebih panjang, tapi tidak melanggar brief]
- Rollback: Ya / Tidak. Jika Ya → alasan singkat (misal: versi iterasi 2 lemah di Three-Lens total)

**4. Key Reason Versi Ini Unggul vs Pool & vs Kandidat Lain**
- [1-2 kalimat kuat yang menjelaskan champion delta]

**5. Key Metrics Akhir**
- EP: X/5 (nc_ep=...)
- OAA: X/5
- CA: X/5
- Three-Lens: X/9
- Panjang: xxx chars
- 0% overlap: Ya / Tidak

**Catatan Akhir Agent (opsional, max 1 kalimat):**
...
```

---

## ATURAN PENGGUNAAN (WAJIB)

1. **Hanya 1 konten final** yang boleh muncul sebagai "copy-paste ready".
2. **Internal Decision Summary** WAJIB muncul **setelah** konten final.
3. Summary **harus ringkas** — tidak boleh menampilkan full teks versi alternatif.
4. Semua skor dan alasan harus jujur (pessimistic bias tetap berlaku).
5. Jika hanya 1 draft yang dibuat, tetap isi template dengan "Hanya 1 draft dievaluasi".
6. Template ini mengalahkan semua instruksi lama yang minta "build 2 versions" atau "tampilkan pilihan ke user".

---

## Lokasi di Skill (sudah diintegrasikan)

- CONTINUOUS EXECUTION MODE (setelah foundation locked)
- META-RULE #0S
- STEP 9 / Final Audit + Output
- LEDGER requirement

Template ini adalah bagian resmi dari Anti-Skip Protocol v1.0 + META-RULE #0S.

Gunakan selalu format di atas supaya konsisten antar run.
