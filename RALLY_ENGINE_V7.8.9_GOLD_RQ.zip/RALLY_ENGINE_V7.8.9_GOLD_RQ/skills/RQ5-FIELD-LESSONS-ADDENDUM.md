# RALLY V7.7 ADDENDUM — RQ5 FIELD LESSONS (THE FIRST DISPUTE)

**Date:** 2026-06-30 Asia/Jakarta
**Status:** ACTIVE — binding on every future `/rally` run targeting top 1%
**Source:** Real lessons earned while shipping the `The First Dispute / mission-0`
submission for `0x7F0A7BA88f38e2dB27124C74dD2bB108Ac9B4227`. These are mistakes we
actually made or nearly made. Each rule below exists because a tool did NOT catch
the problem on its own. Tools answer "can this pass?"; these laws answer "can this
win, and are we being honest?".

---

## LAW 1 — RQ TRUTH LAW (anti-overclaim, NON-NEGOTIABLE)

A Q&A pack is a **stimulus**, never a guarantee. Final RQ depends on factors the
pack does not control:

1. The **real external replies** people write under the post.
2. **Reply speed** — first quality replies should land <30 minutes after posting.
3. The **judge** and which sentences they happen to quote.
4. The **posting account itself**. RQ is **author-portable**: stdev intra-author
   0.77 vs antar-author 1.29 — the account moves the score more than the text.

Therefore the ONLY honest status levels are:

- `RQ5-ready` = data-backed, anti-dilution clean, all engine gates green.
- NOT `guaranteed RQ 5/5`. That phrase is BANNED in every report and reply.

If a tool, a draft, or the user's hope says "this guarantees RQ5", override it and
state the truth. Honesty about ceiling > comforting overclaim.

---

## LAW 2 — CONTENT-BLOCK + SYNC LAW

When delivering MAIN CONTENT inside a `combined.md`:

1. Main content MUST be wrapped in a ```text fenced block (jury/reader copy needs
   a clean, copy-pasteable body).
2. The text inside that block MUST be **byte-identical** to `content.txt`.
3. Any edit to `content.txt` REQUIRES re-syncing the block in the same turn.

Mandatory verification before declaring done:

```bash
# extract the fenced block and diff against content.txt
diff <(awk '/^```text$/{f=1;next}/^```$/{f=0}f' combined.md) content.txt && echo "BLOCK==content.txt OK"
```

No green diff = not done. We had to fix desync twice; no tool catches it, so this
check is now mandatory.

---

## LAW 3 — MANDATORY-PHRASE vs LOSER-DNA COLLISION LAW

Campaign-mandatory phrases structurally collide with loser DNA. For this campaign:
`@GenLayer`, `the adjudication layer for the agentic economy`, `agentic economy`.

Hard rules learned in the field:

1. Mention `@GenLayer` **exactly once**. Frame it as "the adjudication layer for an
   agentic economy". NEVER call it trust layer, intelligent blockchain, court of the
   internet, or trusted intermediary.
2. Use `an agentic economy`, NOT `the agentic economy`. The article `the` recreated
   a loser 5-gram with non-winners; `an` breaks it while staying on-brand.
3. The brand bridge MUST be rewritten so 5/6/7/8-gram overlap with non-winners = 0.
   Only campaign-mandatory 4-grams may remain, and ONLY if whitelisted via
   `--whitelist` in `rally-loser-dna-scan.py`.
4. The bridge must **emerge from the argument** (the "neither judges meaning" gap),
   never be bolted on. Our working bridge:
   `That gap is the job @GenLayer was built for: the adjudication layer for an
   agentic economy.`

Re-run `rally-loser-dna-scan.py` after ANY brand-sentence edit. 5-gram+ overlap
must stay 0.

---

## LAW 4 — EP-SEMANTIC DATASET-ARTIFACT LAW

`rally-ep-semantic-review.py` can FAIL for reasons that are NOT about our content.

Diagnostic: open `ep-deduction-map.json`. If it shows
`decision: REVIEW`, a high `unknownClassCount` (e.g. 72), AND `contentRisks` is
EMPTY, the FAIL is a **dataset artifact**, not a content defect.

Decision rule:

- This EP-semantic FAIL is **ACCEPTABLE and expected** when, in the SAME run:
  - `rally-worst-positive-verdict-check.py` (which judges OUR content) PASSES with
    0 credible deductions, AND
  - CTA quality PASS, loser-DNA PASS, compactness PASS.
- DOCUMENT it explicitly in the final audit as "EP-semantic FAIL = dataset map
  REVIEW/unknown=N; contentRisks EMPTY; NOT our content."
- Do NOT panic-edit content to chase this FAIL. Editing good content to satisfy a
  broken map injects risk.
- OPTIONAL clean PASS: classify the unknown sentences in `ep-deduction-map.json`.
  That is **audit-data work**, not content work — only do it if the user asks.

---

## LAW 5 — RQ-MECHANICS FALSE-POSITIVE TRAP

`rally-rq-mechanics-calibration-check.py` flags LOW_EFFORT via **substring** match.
Substrings include `agree` and `gm`. This produces false positives on legitimate
words. Avoid words that CONTAIN these substrings inside Q/A copy:

- `disagree`, `agreed`, `agreement` (contain `agree`)
- `judgment`, `judgmental` (contain `gm`)
- `magma`, `stigma`, `enigma`, `dogma` (contain `gm`)

Substitutions that keep meaning: use `push back`, `counter`, `object`, `the call`,
`the ruling`, `the verdict` instead. Re-run the checker after Q/A edits; mechanics
must stay above `--min-mechanics-pct 0.70` and skeptic above `--min-skeptic-pct 0.25`.

---

## LAW 6 — EQUAL-STRENGTH WITH CONTROLLED VARIATION

From `10-QNA-RQ5-ENGINE.md` self-check `20/20 equal-strength: PASS` AND the
anti-dilution single-quote test (`rally-qna-engine.md` §5.2):

1. Every Q-COPY 160-260 chars (hard cap 280), >=2 layers (specific point +
   concrete scenario + consequence/trade-off/mechanism).
2. Every A-COPY one line, <=280, ends with a specific open-loop `?`, no generic
   positivity, canonically consistent with the content.
3. Single-quote test per block: if the jury quotes ONLY this line, does a positive
   concept (specificity / subject-matter / constructive / anecdote) appear? If no →
   DELETE the block, do not patch. "Fewer strong > 20 with diluters."
4. Vary Q endings: mix statements and questions (do NOT make every Q end with `?`).
   A always ends `?`.
5. Equal-strength is the floor, NOT perfect homogeneity. A tiny score spread is
   healthy — RQ rewards natural variation, and 20 identical-feeling lines read as
   templated (a NEGATIVE concept).

---

## REAL-JUDGE CALIBRATION 2026-06-30 (from actual Rally RQ/EP/TQ verdicts on our posted content)

Three real judge verdicts landed on our own posts. These are ground truth, not tool output. Lessons promoted to hard rules:

### LJ1 - URL must NEVER be followed by attached punctuation (TQ kill)
Real verdict on "Doing nothing with your Wingston..." (Stake mission-1) gave **TQ 2/5**, quote: the URL `https://app.rally.fun,/` is "malformed with an erroneous comma". Our content.txt was `Stake now at app.rally.fun, then reply...` - the comma after the domain made the judge (and Twitter's linkifier) read the comma as part of the URL.
RULE: a campaign URL must sit at the END of its line/sentence with NO trailing comma, period, colon, or slash touching it. Put any punctuation BEFORE the URL, or break to a new line after it. Add a preflight grep: `grep -nE "rally\.fun[,.;:/]" content.txt` must return nothing. This passed ALL our tools (CTA, Compliance) yet failed the real TQ judge, so it is now a mandatory preflight, not a tool check.

### LJ2 - For TACTICAL/PRODUCT posts, ~1000+ chars is penalized by BOTH EP and TQ, not just EP soft-target
Same verdict: EP 4/5 noted "the 1047-character length reduces digestibility slightly"; TQ explicitly said "1047-character length exceeds standard Twitter constraints, reducing readability". Our compactness tool (hard cap 1050) PASSED it. The real judge wants tactical posts SHORTER.
RULE: for tactical/product genre, treat ~600-850 chars as the real target, not 1050. The 1050 hard cap is a confessional-genre ceiling; tactical posts should aim well under it. The winning "Most whitelists..." verdict (TQ word-perfect) was a short, stepwise, media-bearing post - that is the tactical TQ ideal.

### LJ3 - Confessional no-CTA + closing question is VALIDATED, not a weakness
Real verdict on "For years I told people the moment for that apology..." (The Apology mission-1): "While it lacks a direct CTA, the closing rhetorical question seamlessly aligns with the campaign's mission... raw vulnerability and thematic alignment strongly compensate." Only soft note: "slightly caps immediate reply conversion."
CONFIRMATION: our genre-calibration rule (do NOT force a CTA on confessional/memoir posts) is correct in the field. Keep ending confessional posts on a reflective question.

### LJ4 - Our skeptic RQ replies work in the field (RQ 4/5)
Same Stake verdict scored the reply (a yield-transparency skeptic line) **RQ 4/5**: "raises a legitimate transparency concern... natural, skeptical phrasing that feels authentic rather than templated... constructively advances the discussion." The skeptic-first ranked pack design is validated. Keep front-loading honest, specific, non-templated skeptic replies.

---

## ENFORCEMENT SUMMARY (append to every final audit)

```text
RQ5 FIELD LESSONS CHECK:
- L1 RQ truth: status = RQ5-ready (NOT guaranteed)            PASS/FAIL
- L2 block==content.txt diff clean                            PASS/FAIL
- L3 mandatory-phrase: @GenLayer x1, "an agentic economy",
     5gram+ loser overlap = 0                                 PASS/FAIL
- L4 EP-semantic FAIL classified (artifact vs real)           ARTIFACT/REAL
- L5 no agree/gm substrings in Q/A                            PASS/FAIL
- L6 equal-strength floor + controlled variation              PASS/FAIL
```
