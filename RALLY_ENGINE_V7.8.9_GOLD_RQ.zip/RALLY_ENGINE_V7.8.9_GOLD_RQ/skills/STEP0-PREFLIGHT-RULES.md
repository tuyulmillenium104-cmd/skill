# STEP 0 — PREFLIGHT RULES (WAJIB sebelum Step 1)
**Versi:** v1.1 (2026-06-24 — Addendum v1.4: + Mission-Soul Decode ke preflight, + Mission-Scoped DNA check)
**Status:** AKTIF — di-trigger SETIAP `/rally <address>` SEBELUM step apapun
**Tujuan:** Menghentikan pola skip yang berulang. Re-load aturan kunci ke working memory + audit gate per step + final audit jujur.
**Asal:** kesepakatan user 2026-06-14 setelah 3 run `/rally` menunjukkan pola skip konsisten

---

## 0.1 RE-LOAD 15 ATURAN KUNCI SKILL V7.6.54

Sebelum tool call apapun, deklarasikan eksplisit ke user bahwa 15 aturan berikut di-load:

### CONTRACT (2)
1. **EXECUTION CONTRACT 10-step** — centang per item, urut, tanpa skip (skill header)
2. **Anti-self-deception (a/b/c/d)** — (a) blind-judge sesi terpisah · (b) DILARANG edit vonis biar scanner PASS · (c) DILARANG skip karena "campaign mirip" · (d) panen selisih prediksi vs vonis-asli jadi lesson

### META-RULES (5)
3. **#0A Brief = Absolute Law** — setiap kata brief = hukum, override pattern manapun
4. **#0J Compliance Gate binary** — tak bisa dinego LLM, exit 1 = dilarang output
5. **#0M Blind-judge sesi terpisah** — kalau self-judge: WAJIB disclosure + se-objektif mungkin
6. **#0O Debatable-gap loop + BAN pool-mode-defense** untuk style class
7. **V7.5.6 Top-1% Mandate** — paritas ≠ top-1%, WAJIB SUPERIOR vs winner pool di minimum 1 axis

### LEXICON & RULES (8)
8. **HUKUM LEXICON rally-rules.py** — jangan share antar gate
9. **0I-13 EP pattern map** — klasifikasi LONGFORM vs ONE-LINER first
10. **0I-14 EP5 zero-deduction state** — pre-kill 12 kelas deduction
11. **0I-16 external-critique L1-L5** — mention-konsekuensi, hiperbola, personal naik, forced-choice, slogan-cadence
12. **0I-17 Target-Defender** — 4 pertanyaan (defender alive, identity attack, loved-used, debate aktif)
13. **0I-25 Angle-fit scoring numerik** — matriks per-kriterium per kandidat
14. **AP1-AP5 anti-patterns** — campaign-context classification (STRICT/RELAXED/ACTIONABLE)
15. **Specificity #0B1 (min 4 concrete) + Behavioral #0B2 (min 1 observable)**

---

## 0.2 8 PREFLIGHT CHECK

Sebelum Step 1, run semua 8 checks:

| # | Check | Action jika gagal |
|---|---|---|
| 1 | Skill files exist (5 file: SKILL.md, qna-engine.md, rally-rules.py, compliance-gate.py, BLIND-JUDGE-PROMPT.md) | STOP, laporkan ke user, JANGAN coba recover |
| 2 | Workspace siap: `/rally-data/learn/<addr>/`, `/konten/`, `/skills/` | Buat folder yang missing |
| 3 | Buat ledger kosong dengan 10-step checklist | Auto-create LEDGER.md skeleton |
| 4 | Brief signals → tentukan mode RAW-FIRST atau EP-FIRST | Default EP-FIRST, switch ke RAW-FIRST kalau ada trigger: "raw / unfiltered / first thought / fire off / don't overthink / honest / gut reaction" |
| 5 | gateWeights + metricWeights + RQ-weight + hashtag-mandatory? + length-constraint? | Catat ke ledger sebagai mission contract |
| 6 | Deadline + sisa waktu (timing strategy) | Kalau < 4 jam → STOP & tanya: tetap lanjut full loop atau simplified path? |
| 7 | ZERO assumption dari run sebelumnya (#0O pool-mode-defense BAN) | Reset semua pattern dari campaign lain |
| 7b | **[v1.4 NEW] MISSION-SOUL DECODE** — bedah brief misi target per kata, identifikasi JIWA (teach/identify/persuade), tentukan struktur. Lihat MISSION-SOUL-PROTOCOL.md | STOP, jalankan Step 0.5 sebelum fetch |
| 7c | **[v1.4 NEW] MISSION-SCOPED DNA**
| 7d | **[v1.4 NEW] EXECUTION-LEVEL DNA** — ekstrak BAGAIMANA winner menulis (mention placement/position/rhythm/opener), bukan hanya APA. Lihat MISSION-SOUL-PROTOCOL.md §7 | Ekstrak execution patterns sebelum Step 4 | — campaign punya >1 mission? Jika YA, dna-fetcher --mission WAJIB | Filter DNA by missionId sebelum analisis |
| 8 | Self-judge independensi mode | Deklarasikan disclosure protocol di FASE A/B |

---

## 0.3 OUTPUT FORMAT PER STEP (skor compliance)

Setelah setiap step selesai, output:

```
═══════════════════════════════════════════════════════════════
STEP N — [nama step]
═══════════════════════════════════════════════════════════════
[bukti spesifik: tool call, hasil, angka]

Compliance: X% — PASS / BORDERLINE / FAIL
  ✓ aturan A diperiksa, hasil X
  ✓ aturan B diperiksa, hasil Y
  ⚠️ aturan C borderline: [reason] → severity HIGH = STOP & tanya, LOW = dokumentasi
  ❌ aturan D skipped: [reason eksplisit]

Lanjut STEP N+1 (otomatis) atau STOP (kalau ada HIGH severity)
```

---

## 0.4 STOP TRIGGERS

WAJIB STOP & tanya user kalau:
- ⚠️ Borderline severity **HIGH**: AP1 violation, length out of winner range, frasa overlap pool, Top-1% mandate threatened (paritas saja)
- ❌ Ada SKIP yang tidak bisa di-fix dalam step
- FAIL scanner setelah iterasi-3 (skill max 3 loop)
- Brief Absolute Law potential violation
- Deadline < 4 jam & masih perlu loop

LANJUT otomatis kalau:
- ✓ semua check pass
- ⚠️ borderline **LOW** yang di-disclosure & informed trade-off

---

## 0.5 SELF-JUDGE DISCIPLINE (Step 6)

Karena Step 6 ideal sesi terpisah tapi kita self-judge:

### DEKLARASI DI HEADER vonis (WAJIB tampil):
```
⚠️ BLIND-JUDGE SELF — disclosure protocol:
- Step 6 ideal sesi terpisah/model lain (skill #0M)
- Saya self-judge atas izin user dengan mitigasi:

  MITIGASI 1: FASE A serangan adversarial PENUH
  - 3+ serangan per gate EP/TQ/OAA (cari celah, kutipan literal)
  - Cek mekanik CA/IA/CC per item
  - Overlap 4-lapis vs pool (struktur > angle > frasa > tema)
  - Baca brief literal per kata
  - Kadens AI check (moral spell-out, metafora-rangkuman, reveal→lesson→Q)

  MITIGASI 2: FASE B kalibrasi vocab POOL EMPIRIK
  - Vocab vonis pakai SAMA dengan vonis MAX real pool ini
  - Tidak pakai vocab generik LLM
  - Cite frequency: kalau pool MAX 0/N pakai kata X, jangan pakai X

  MITIGASI 3: ATURAN KEJUJURAN MUTLAK (dua arah, BLIND-JUDGE-PROMPT v2.0)
  - Serangan FASE A yang menurut saya juri ASLI akan tulis → WAJIB muncul 
    sebagai kritik di vonis FASE B
  - DILARANG sembunyikan kritik supaya scanner lolos (#0J-b violation)
  - DILARANG paksakan kritik yang juri tidak akan tulis (false-FAIL)
  - Pilihan kata = prediksi skor:
    "exceptional/outstanding/flawless" = kelas MAX
    "strong/effective/solid" = kelas 4
    "moderate/competent/acceptable" = kelas 3-

  MITIGASI 4: bias residual diperkirakan 15-25%
  - Pakai prediksi pessimistic range
  - Audit final WAJIB highlight self-judge sebagai residu risk
```

### YANG DILARANG saat self-judge:
- Sembunyikan kritik supaya scanner lolos
- Tulis "exceptional" kalau saya pikir juri tulis "moderate"
- Skip serangan yang menurut saya juri akan tulis
- Recalibrasi vocab vonis HANYA untuk loloskan scanner (#0J-b)

---

## 0.6 AUDIT FINAL WAJIB sebelum klaim selesai

DILARANG klaim "siap submit" / "100% pass" tanpa output audit final lengkap.

### Format AUDIT FINAL:

```
═══════════════════════════════════════════════════════════════
AUDIT FINAL — pre-submit
═══════════════════════════════════════════════════════════════

KONTEN — checklist literal skill:
✓ Brief Absolute Law (7 rule): X/7 → bukti per rule
✓ Specificity Gate #0B1: X markers (min 4)
✓ Behavioral #0B2: X verbs (min 1)
✓ AP1-AP5: X/5 pass dengan classification context
✓ EP zero-deduction sweep 0I-14: X/12 KILL
✓ 0I-16 L1-L5: X/5 pass (per-lesson cite)
✓ 0I-17 Target-Defender: X/4
✓ Three-Lens #0D: X/3 lensa pass
✓ Mechanical: X/10 binary
✓ Banned phrases Step 5.4: X hits
✓ Frasa-overlap pool: X/N unique
✓ Scanner rally-rules.py: ALL PASS / detail per gate
✓ Scanner compliance-gate.py: exit code
✓ Top-1% Champion Delta vs top-2 pool: SUPERIOR/PARITY/INFERIOR per axis

QnA PACK (kalau RQ weight > 0%):
✓ Volume: X (default 12, max 30)
✓ Distribusi A/B/C/D: scaled vs target
✓ PAIR format (Q-trigger + A-copy + Uji-kutip-tunggal): X/X
✓ DETAIL KANONIK header sync ke konten v-terbaru: ya/tidak
✓ Voice adjacency: X violations
✓ Anti-trigger AI/academic/templated/generic: X hits

COMPLIANCE OVERALL (JUJUR):
- Literal skill compliance: X%
- Mirror pool data: X%
- Step yang skip + alasan eksplisit: [list]
- Borderline + disclosure eksplisit: [list]
- Self-judge bias residu: 15-25%

PREDIKSI TERKALIBRASI (range, BUKAN titik):
- Per gate dengan confidence interval
- P(ALL MAX content) range pessimistic-optimistic
- Residu irreducible
```

---

## 0.7 ANTI-OVERCONFIDENCE RULES

DILARANG:
1. Klaim "100% pass" tanpa jalankan AUDIT FINAL lengkap
2. Klaim "siap submit" tanpa output AUDIT FINAL ke user
3. Sebut compliance numerik (mis "95%") tanpa breakdown per item
4. Skip disclosure borderline / self-judge bias

WAJIB:
1. Audit FINAL output **sebelum** klaim selesai
2. Sebut % compliance dengan breakdown jujur per item
3. Tampilkan SKIP eksplisit + alasan, BUKAN sembunyikan
4. Self-judge bias residu disebut di audit final

---

## 0.8 KASUS EDGE

| Kasus | Action |
|---|---|
| RQ weight = 0% | Skip QnA pack, hanya konten |
| Campaign sudah end / lewat deadline | STOP, tanya user: latihan atau abort? |
| Skill files missing (preflight #1) | STOP, laporkan, jangan recover diam-diam |
| Deadline < 4 jam | STOP, tanya: full loop atau simplified? |
| Pool < 20 submissions | Pakai default winner DNA dari skill, tandai PROJECTED |
| Pool brand-new (0 subs) | Use Winner DNA dari campaign style-similar + disclosure |
| Mention TIDAK dimention di mission rules | Cek campaign-level rules; kalau juga absent → skip mention |

---

## 0.9 VERSION & UPDATE

- v1.0 (2026-06-14): inisial, hasil diskusi user 6 keputusan
- Updates: setiap run yang menemukan skip baru, append ke file ini sebagai aturan baru
- Format update: append `## v1.X (date) — [aturan baru] — [trigger insight]`

---

## CONSOLIDATED UPDATE NOTICE (2026-06-16)

Addendum lessons v1.1, v1.2, and v1.3 are now merged directly into `skills/rally-content-engine-V7.7-SKILL.md` under `CONSOLIDATED ACTIVE ADDENDA v1.1-v1.3`.

Active merged rules include:
1. Final deliverable uses campaign-name folder and campaign-prefixed primary files.
2. Final output must include one combined `CONTENT-PLUS-20QNA-RQ5.md` file.
3. QnA is Q-first with 20 Q-COPY/A-COPY blocks by default for this workflow.
4. Blind-judge FASE B must avoid scanner kill-words in positive negation.
5. `$TOKEN` content must be written with quoted heredoc or Python writer.
6. Stronger-version requests require Previous Version Challenge and delta proof.
7. Missing full tweet text requires judge-analysis + oEmbed mitigation and disclosure.
8. One-liner opinion campaigns require embedded micro-CTA/debate fork for EP5.

