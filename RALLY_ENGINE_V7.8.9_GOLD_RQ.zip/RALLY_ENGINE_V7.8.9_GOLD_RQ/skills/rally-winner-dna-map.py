#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mission-aware adaptive winner DNA mapper (V7.8.5)."""
import argparse,json,re,time,statistics,math
from pathlib import Path
from collections import Counter
from rally_common import normalized_text, sha256_file

def paras(t): return [p.strip() for p in re.split(r"\n\s*\n", t or "") if p.strip()]
def opener_type(text):
    first=paras(text)[0] if paras(text) else (text or "")[:160]
    fl=first.lower().strip()
    if "?" in first: return "question"
    if re.match(r"^(hot take|unpopular|controversial)\b",fl): return "hot_take"
    if re.match(r"^(i\b|i'm\b|i've\b|my\b)",fl): return "personal_confession"
    if re.match(r"^(the first|the most|everyone|nobody|most\b|the problem)",fl): return "tension_declarative"
    return "declarative"
def cta_tail(text):
    ps=paras(text); return ps[-1] if ps else ""
def required_mention(campaign, mission_id):
    mission=next((m for m in campaign.get('missions',[]) if m.get('id')==mission_id),{}) if campaign else {}
    text=' '.join([mission.get('rules') or '',mission.get('description') or '',campaign.get('rules') or ''])
    ms=re.findall(r"@[A-Za-z0-9_]+",text)
    return ms[0] if ms else None
def lane(chars):
    if chars<600:return 'short_under_600'
    if chars<=1050:return 'concise_600_1050'
    if chars<=1600:return 'mid_1051_1600'
    return 'long_over_1600'

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--submissions",required=True);ap.add_argument("--campaign",default=None);ap.add_argument("--mission",default=None)
    ap.add_argument("--out-json",required=True);ap.add_argument("--out-md",required=True);args=ap.parse_args()
    subs=json.load(open(args.submissions,encoding="utf-8"));campaign=json.load(open(args.campaign,encoding='utf-8')) if args.campaign else {}
    mention=required_mention(campaign,args.mission) if args.mission else None
    winners=[]
    for s in subs:
        gates=s.get("gates") or {};ep=gates.get("EP",[0])[0] if "EP" in gates else 0;oaa=gates.get("OAA",[0])[0] if "OAA" in gates else 0;tq=gates.get("TQ",[0])[0] if "TQ" in gates else 0
        if s.get("winner") or (ep==5 and oaa==2 and tq>=4): winners.append(s)
    # Remove exact duplicate texts and keep fragments as evidence but out of structural medians.
    unique=[];seen=set()
    for s in winners:
        key=normalized_text(s.get('content') or '')
        if not key or key in seen:continue
        seen.add(key);unique.append(s)
    reliable=[s for s in unique if s.get('contentSource')!='judge-quote-fragments' and s.get('contentComplete',True) and len(s.get('content') or '')>=300]
    source=reliable or unique
    # Fallback to the dominant required/campaign mention if rules did not specify it.
    if not mention:
        mc=Counter(m for s in source for m in re.findall(r"@[A-Za-z0-9_]+",s.get('content') or ''))
        mention=mc.most_common(1)[0][0] if mc else None
    rows=[]
    for s in source:
        text=s.get("content") or "";ps=paras(text);pos=(text.find(mention)/len(text)*100) if mention and mention in text and text else None
        rows.append({"author":s.get("xUsername"),"chars":len(text),"lane":lane(len(text)),"paragraphs":len(ps),"openerType":opener_type(text),"mention":mention,"mentionPosPct":pos,"ctaTail":cta_tail(text),"content":text[:4000],"contentSource":s.get('contentSource'),"temporalPoints":s.get('temporalPoints'),"gates":{k:v[0] for k,v in (s.get('gates') or {}).items()}})
    lane_counts=Counter(r['lane'] for r in rows);lane_stats={}
    for ln in lane_counts:
        rr=[r for r in rows if r['lane']==ln];positions=[r['mentionPosPct'] for r in rr if r['mentionPosPct'] is not None]
        lane_stats[ln]={"count":len(rr),"medianChars":statistics.median([r['chars'] for r in rr]),"medianParagraphs":statistics.median([r['paragraphs'] for r in rr]),"questionClosePct":round(sum('?' in r['ctaTail'] for r in rr)/len(rr),3),"portalPct":round(sum('portal.' in r['content'].lower() for r in rr)/len(rr),3),"mentionPosMedian":statistics.median(positions) if positions else None}
    opener_counts=Counter(r['openerType'] for r in rows);positions=[r['mentionPosPct'] for r in rows if r['mentionPosPct'] is not None]
    def tp(r):
        try:return float(r.get('temporalPoints') or 0)
        except:return 0
    top_n=max(1,math.ceil(len(subs)*0.01));champions=sorted(rows,key=tp,reverse=True)[:top_n]
    result={"tool":"rally-winner-dna-map.py v7.8.5","generated":time.strftime("%Y-%m-%d %H:%M:%S"),"submissionsSha256":sha256_file(args.submissions),"mission":args.mission,"requiredMention":mention,"winnerLikeCount":len(rows),"rawWinnerCount":len(winners),"openerCounts":dict(opener_counts),"charMedian":statistics.median([r['chars'] for r in rows]) if rows else 0,"paragraphMedian":statistics.median([r['paragraphs'] for r in rows]) if rows else 0,"mentionPosMedian":statistics.median(positions) if positions else None,"laneStats":lane_stats,"championTop1Count":top_n,"championTop1Rows":champions,"rows":rows[:200]}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    md=["# WINNER DNA MAP - MISSION AWARE\n\n",f"Winner-like reliable samples: **{len(rows)}**  \nRequired mention: **{mention}**  \n\n","## Conditional Winner Lanes\n\n"]
    for ln,v in lane_stats.items():md.append(f"- **{ln}**: {v}\n")
    md.append("\n## Temporal Top-1% Champions\n\n")
    for r in champions:md.append(f"- @{r['author']}: {r['chars']} chars, lane={r['lane']}, temporal={r['temporalPoints']}\n")
    md.append("\n## Opener Types\n\n")
    for k,v in opener_counts.most_common():md.append(f"- {k}: {v}\n")
    md.append("\n## Samples\n\n")
    for r in rows[:50]:md.append(f"### @{r['author']} - {r['chars']} chars - {r['lane']} - {r['openerType']}\nCTA: `{r['ctaTail'][:240]}`\n\n```text\n{r['content']}\n```\n\n")
    Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f"WINNER DNA MAP: {len(rows)} reliable unique samples, lanes={dict(lane_counts)}")
if __name__=='__main__':main()
