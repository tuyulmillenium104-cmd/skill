# RALLY V7.7 ADDENDUM v2.0 — ADAPTIVE GATE EXPANSION PROTOCOL

**Date:** 2026-06-25 Asia/Jakarta  
**Status:** ACTIVE  
**Purpose:** Extend adaptivity beyond EP/CTA/loser surface into TQ media/readability, OAA structure/trope, IA claim boundaries, and final integrity enforcement.

---

## 1. WHY THIS EXISTS

Recent real verdicts showed that a post can pass CTA, loser-DNA, and scanner checks but still lose points due to:

- media/direct image URL or uncontextualized media;
- semantic OAA familiarity without exact n-gram overlap;
- campaign-specific IA overclaims or technical drift;
- final files missing fresh adaptive reports.

Therefore adaptivity must expand beyond known EP and n-gram checks.

---

## 2. NEW ACTIVE GATES

### Gate TQ-A — TQ Format + Media Audit

Tool:

```bash
python3 skills/rally-tq-format-audit.py --content content.txt --out-json tq-format-report.json --out-md TQ-FORMAT-REPORT.md
```

Checks:
- raw image/media URLs;
- smart punctuation / em dash;
- URL punctuation;
- paragraph density;
- mention placement;
- media referenced if media is used;
- longform readability.

### Gate OAA-A — OAA Structure/Trope Audit

Tool:

```bash
python3 skills/rally-oaa-structure-audit.py --content content.txt --submissions submissions_enriched.json --out-json oaa-structure-report.json --out-md OAA-STRUCTURE-REPORT.md
```

Checks:
- opener family overlap;
- CTA tail family overlap;
- theme/trope overlap;
- nearest non-winners by token Jaccard;
- generic/template phrase risks.

### Gate IA-A — IA Claim Boundary Audit

Tool:

```bash
python3 skills/rally-ia-claim-boundary.py --content content.txt --campaign campaign.json --out-json ia-claim-report.json --out-md IA-CLAIM-REPORT.md
```

Checks:
- guarantee/profit/ROI claims;
- technical drift;
- unsupported superlatives;
- numbers not present in KB;
- claim terms absent from KB;
- risky absolutes.

### Gate FI-v2 — Final Integrity Requires Adaptive Reports

Final integrity must verify fresh reports exist and PASS:

- loser DNA report;
- CTA report;
- EP deduction map;
- TQ format report;
- OAA structure report;
- IA claim report;
- winner DNA map;
- DNA confidence report.

---

## 3. EXECUTION ORDER UPDATE

Official flow now:

```text
Mission DNA
→ DNA Confidence
→ Winner DNA Map
→ EP Deduction Map
→ Draft
→ CTA #0T+
→ TQ-A Format/Media Audit
→ IA-A Claim Boundary Audit
→ OAA-A Structure/Trope Audit
→ Judge Variance #0R
→ Loser DNA #0S2
→ Scanner
→ Final Integrity v2
→ Ratchet Writeback
```

---

## 4. FINAL AUDIT ADDITION

Final audit must include:

```text
ADAPTIVE GATE EXPANSION (v2.0):
- TQ Format Audit: PASS/FAIL
- OAA Structure/Trope Audit: PASS/FAIL
- IA Claim Boundary Audit: PASS/FAIL
- Final Integrity v2 adaptive reports: PASS/FAIL
```

---

## 5. PRINCIPLE

If a real verdict can name a deduction class, the skill must either:

1. detect it programmatically, or
2. force an explicit manual/adversarial check in the final audit.

No silent gaps.
