#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTA Quality Max checker with semantic option parallelism (V7.8.5)."""
import argparse,json,re,sys,time
from pathlib import Path
from rally_common import report_identity
VERBS=["reply","comment","tell me","choose","name","check","visit","learn","join","mint","compare","pick","show me","share","test","spend","route","appeal","challenge"]
GENERIC=["thoughts?","what do you think?","agree?","drop yours","let me know"]
CHOICE_MARKERS=[" or ",":","which","choose","pick","rather","first"]
OBJECT_TERMS=["decision","ruling","verdict","appeal","claim","credit","coverage","hiring","copyright","risk","contract","process","test","work","brief","quality","protocol","validator","consensus","campaign","access","reward","dashboard","genlayer","wingston","rlp"]
OUTCOME_TERMS=set("ruling denial rejection approval ban suspension refund verdict decision claim block removal dismissal award penalty refusal cancellation".split())

def extract_last_cta(text):
    ps=[p.strip() for p in re.split(r"\n\s*\n",text.strip()) if p.strip()]
    return "\n\n".join(ps[-2:]) if ps else text.strip()
def last_prompt(cta):
    lines=[x.strip() for x in cta.splitlines() if x.strip()]
    return lines[-1] if lines else cta.strip()
def option_parallelism(prompt):
    if ':' not in prompt:return {'applicable':False,'pass':True,'reason':'no explicit option list','options':[]}
    head,raw=prompt.rsplit(':',1);raw=raw.strip().rstrip('?!.')
    opts=[x.strip(' .') for x in re.split(r",|\bor\b",raw) if x.strip(' .')]
    if len(opts)<2:return {'applicable':False,'pass':True,'reason':'fewer than two options','options':opts}
    hl=head.lower();decision_head=any(x in hl for x in ['decision','ruling','verdict','appeal'])
    if not decision_head:return {'applicable':True,'pass':True,'reason':'head does not require decision-outcome options','options':opts}
    classified=[]
    for o in opts:
        ts=set(re.findall(r"[a-z]+",o.lower()));classified.append(bool(ts&OUTCOME_TERMS))
    ok=all(classified)
    return {'applicable':True,'pass':ok,'reason':'all options are decision outcomes' if ok else 'decision/ruling prompt contains domain labels instead of parallel outcomes','options':opts,'outcomeFlags':classified}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--campaign',default=None);ap.add_argument('--mission',default=None);ap.add_argument('--out-json');ap.add_argument('--out-md');ap.add_argument('--require-url',default=None);args=ap.parse_args()
    text=Path(args.content).read_text(encoding='utf-8').strip();tl=text.lower();cta=extract_last_cta(text);prompt=last_prompt(cta);cl=cta.lower();pl=prompt.lower()
    verbs=[v for v in VERBS if re.search(r"\b"+re.escape(v)+r"\b",cl)];has_verb=bool(verbs)
    has_url=(args.require_url.lower() in tl) if args.require_url else True
    generic=[g for g in GENERIC if g in cl]
    has_choice=any(m in pl for m in CHOICE_MARKERS) or '?' in prompt
    dynamic_terms=[]
    if args.campaign:
        camp=json.load(open(args.campaign,encoding='utf-8'));parts=[camp.get('title',''),camp.get('goal',''),camp.get('knowledgeBase','')]
        for m in camp.get('missions',[]):
            if args.mission and m.get('id')!=args.mission:continue
            parts += [m.get('title',''),m.get('description',''),m.get('rules','')]
        stop=set('the a an and or but to of in on for with is are was were be it this that from what when where who your you'.split())
        campaign_tokens={x for x in re.findall(r"[a-z][a-z0-9-]+",' '.join(str(x or '') for x in parts).lower()) if len(x)>3 and x not in stop}
        dynamic_terms=sorted(x for x in campaign_tokens if re.search(r"\b"+re.escape(x)+r"\b",pl))
    objects=sorted(set([o for o in OBJECT_TERMS if re.search(r"\b"+re.escape(o)+r"\b",pl)]+dynamic_terms));has_object=bool(objects)
    parallel=option_parallelism(prompt)
    low_friction=has_choice and has_object and ('?' in prompt or any(v in pl for v in ['choose','pick','tell me','name','reply'])) and parallel['pass']
    thesis_integrated=has_object and not generic
    score=sum([has_verb,has_object,has_choice,low_friction,thesis_integrated])
    if has_verb and has_choice and has_object and parallel['pass'] and has_url:rank=1
    elif has_verb and has_object and '?' in prompt and parallel['pass']:rank=2
    elif args.require_url and has_url and has_verb:rank=3
    elif has_choice and has_object and parallel['pass']:rank=4
    elif '?' in prompt:rank=5
    elif generic:rank=6
    else:rank=7
    engagement_bait=bool(re.match(r"^(reply with|drop|comment below|engage)",pl))
    decision='PASS' if score>=4 and rank<=4 and has_url and not generic and parallel['pass'] else 'FAIL'
    result={"tool":"rally-cta-quality-check.py v7.8.5",**report_identity(text),"content":args.content,"ctaQuote":cta,"prompt":prompt,"behavioralVerb":has_verb,"verbs":verbs,"concreteObject":has_object,"objects":objects,"campaignNativeChoice":has_choice,"semanticParallelism":parallel,"lowFrictionReplyPath":low_friction,"thesisIntegrated":thesis_integrated,"engagementBaitRisk":engagement_bait,"genericCTA":generic,"requiredUrlPresent":has_url,"requiredUrl":args.require_url,"ctaStrengthRank":rank,"ctaFormulaScore":score,"decision":decision}
    if args.out_json:Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=f"""# CTA QUALITY CHECK (#0T+) - SEMANTIC

CTA:
```text
{cta}
```

- Behavioral verb: {has_verb} {verbs}
- Concrete object: {has_object} {objects}
- Choice/options: {has_choice}
- Semantic parallelism: {parallel}
- Low-friction reply path: {low_friction}
- Thesis-integrated: {thesis_integrated}
- Engagement-bait risk: {engagement_bait}
- Generic CTA: {generic or 'NONE'}
- CTA rank: {rank}
- Formula score: {score}/5
- Decision: **{decision}**
"""
    if args.out_md:Path(args.out_md).write_text(md,encoding='utf-8')
    print(f"CTA QUALITY CHECK: {decision} [score={score}/5 rank={rank} parallel={parallel['pass']} bait={engagement_bait}]");sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__':main()
