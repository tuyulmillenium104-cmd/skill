#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Calibrated Gold Standard Q&A audit (V7.8.9)."""
import argparse,json,re,sys,time
from collections import Counter
from pathlib import Path
from rally_common import report_identity
TYPES=['Specific Probe','Challenge','Technical Deep-Dive','Hot Take','Real Experience']
TARGET={'Specific Probe':4,'Challenge':5,'Technical Deep-Dive':5,'Hot Take':4,'Real Experience':2}
STOP=set('the a an and or but to of in on for with is are was were be been it this that from as at by you your i my me we they them if not just'.split())
def toks(t):return {x for x in re.findall(r"[a-z0-9']+",t.lower()) if len(x)>2 and x not in STOP}
def parse(combined):
 pat=r"## R(\d+)[^\n]*\(([^)]+)\)\s*\n\s*\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```"
 return [(int(i),typ.strip(),q.strip(),a.strip()) for i,typ,q,a in re.findall(pat,combined,re.S)]
def norm_type(t):
 for x in TYPES:
  if x.lower() in t.lower():return x
 return None
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--combined',required=True);ap.add_argument('--out-json',required=True);ap.add_argument('--out-md',required=True);ap.add_argument('--min-question-close-pct',type=float,default=.50);ap.add_argument('--max-question-close-pct',type=float,default=.75);args=ap.parse_args()
 content=Path(args.content).read_text(encoding='utf-8').strip();combined=Path(args.combined).read_text(encoding='utf-8');rows=parse(combined);ct=toks(content);counts=Counter();fails=[];reviews=[];scores=[]
 qopen=Counter();aopen=Counter();question_closes=0
 for idx,rawtype,q,a in rows:
  typ=norm_type(rawtype);counts[typ or 'UNKNOWN']+=1;qwords=re.findall(r"\b[a-zA-Z0-9']+\b",q);awords=re.findall(r"\b[a-zA-Z0-9']+\b",a);qover=len(toks(q)&ct);qstart=' '.join(q.lower().split()[:2]);astart=' '.join(a.lower().split()[:2]);qopen[qstart]+=1;aopen[astart]+=1;question=bool(a.rstrip().endswith('?'));question_closes+=question
  persona=bool(re.search(r"\b(i|i'm|i've|my|me|we|our)\b",q.lower()))
  reasoning=bool(re.search(r"\b(because|if|but|so|while|depends|before|instead|which|why)\b",q.lower()))
  specific=(qover>=2 or bool(re.search(r"\b(q[1-4]|2027|2028|five|three|priced|appeal|escrow|chargeback|wallet|stablecoin)\b",q.lower())))
  type_ok=True
  if typ=='Specific Probe':type_ok=specific
  elif typ=='Challenge':type_ok=reasoning and bool(re.search(r"\b(concern|challenge|wrong|risk|depends|would not|would rather|counter|hard line)\b",q.lower()))
  elif typ=='Real Experience':type_ok=persona and bool(re.search(r"\b(once|last year|last month|sent|paid|used|got|learned|burned)\b",q.lower()))
  elif typ=='Technical Deep-Dive':type_ok=specific and bool(re.search(r"\b(escrow|appeal|evidence|pricing|capital|merchant|claim|settlement|wallet|issuer|metric)\b",q.lower()))
  elif typ=='Hot Take':type_ok=bool(re.search(r"\b(my answer|my bet|my hot take|i would bet|counter-prediction|never|instead|moves first|will not|won't|wrong|irony|business model|wallet margins)\b",q.lower()))
  qscore=5 if persona and reasoning and specific and type_ok else (4 if persona and specific and type_ok else 3)
  achar=len(a);aw=len(awords);insight=bool(re.search(r"\b(because|means|instead|line|definition|distinction|design|falsifier|wedge|split|use case|milestone|strategy|my test|my threshold|my bet|the cost|the model|the signal|the metric)\b",a.lower()))
  ascore=5 if 30<=aw<=45 and achar<=280 and insight else (4 if 24<=aw<=50 and achar<=280 and insight else 3)
  convscore=5 if achar<=280 and persona and not re.search(r"\b(thoughts\?|what do you think\?)$",a.lower()) else (4 if achar<=280 and persona else 3)
  if min(qscore,ascore,convscore)<4:fails.append(f'R{idx} below 4: Q={qscore}, A={ascore}, Feel={convscore}')
  if typ=='Real Experience' and 'SIMULATED_ARCHETYPE' not in rawtype:reviews.append(f'R{idx} Real Experience lacks SIMULATED_ARCHETYPE label')
  scores.append({'rank':idx,'type':typ,'rawType':rawtype,'qChars':len(q),'aChars':achar,'aWords':aw,'qContentOverlap':qover,'questionClose':question,'qQuality':qscore,'aInsight':ascore,'conversationalFeel':convscore,'decision':'PASS' if min(qscore,ascore,convscore)>=4 else 'FAIL'})
 if len(rows)!=20:fails.append(f'pair count {len(rows)} != 20')
 for t,n in TARGET.items():
  if counts[t]!=n:fails.append(f'{t} count {counts[t]} != target {n}')
 close_pct=question_closes/max(1,len(rows))
 if not args.min_question_close_pct<=close_pct<=args.max_question_close_pct:fails.append(f'question-ending coverage {close_pct:.0%} outside {args.min_question_close_pct:.0%}-{args.max_question_close_pct:.0%}')
 if max(qopen.values(),default=0)>5:reviews.append(f'Q opener concentration: {qopen.most_common(1)}')
 if max(aopen.values(),default=0)>5:reviews.append(f'A opener concentration: {aopen.most_common(1)}')
 decision='FAIL' if fails else ('REVIEW' if reviews else 'PASS');result={'tool':'rally-qna-gold-audit.py v7.8.9',**report_identity(content,combined),'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'targetDistribution':TARGET,'actualDistribution':dict(counts),'questionCloseCount':question_closes,'questionClosePct':round(close_pct,3),'qOpenerCounts':dict(qopen),'aOpenerCounts':dict(aopen),'rows':scores,'fails':fails,'reviews':reviews,'decision':decision,'externalGuarantee':False}
 Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');md=['# Q&A GOLD STANDARD AUDIT\n\n',f'Decision: **{decision}**\n\n',f'- Distribution: {dict(counts)}\n- Question endings: {question_closes}/{len(rows)} ({close_pct:.0%})\n\n','## Pair Scores\n\n','|R|Type|Q|A|Feel|A words|Close|\n|---:|---|---:|---:|---:|---:|---|\n']
 for r in scores:md.append(f"|{r['rank']}|{r['type']}|{r['qQuality']}|{r['aInsight']}|{r['conversationalFeel']}|{r['aWords']}|{'?' if r['questionClose'] else 'statement'}|\n")
 md+=['\n## Fails\n']+([f'- {x}\n' for x in fails] or ['- none\n'])+['\n## Reviews\n']+([f'- {x}\n' for x in reviews] or ['- none\n']);Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f'QNA GOLD AUDIT: {decision} [pairs={len(rows)}, closes={close_pct:.0%}, fails={len(fails)}, reviews={len(reviews)}]');sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__':main()
