---
name: rally-qna-engine
version: V2.0 (2026-06-30)
status: AKTIF - konsolidasi V1.0 + active patches 2026-06-29 + RANKING PROTOCOL baru
supersedes: skills/rally-qna-engine.md V1.0 (file lama tetap disimpan sebagai arsip)
data-basis: 1.061 vonis RQ / 13 pool + vonis RQ asli (Twist Ending 5/5, iPad 5/5, Two-Column 4/5)
peran: Q&A REPLY-PACK ENGINE - memproduksi 20 pasang Q-COPY/A-COPY yang membuat
       juri RQ menulis >=3 konsep-positif dan 0 konsep-negatif. RQ adalah satu-satunya
       gate yang hidup SETELAH posting; skill ini senjatanya.
output: blok Q&A di dalam satu combined.md (BUKAN file terpisah), siap lolos
        rally-rq-prompt-answer-check.py + rally-rq-mechanics-calibration-check.py +
        rally-final-integrity-check.py
---

# RALLY QNA-ENGINE V2.0 - REPLY-PACK 20-PAIR UNTUK RQ5-READY

> CATATAN VERSI. V1.0 (skills/rally-qna-engine.md) memakai 12 naskah format `>>> COPY:`
> dan file terpisah `<NAMA>-QNA.txt`. Workflow yang dipakai sekarang sudah pindah ke
> 20 pasang Q-COPY/A-COPY di dalam SATU combined.md, dengan dua checker baru sebagai
> gate wajib. V2 ini mengonsolidasikan itu. Filosofi inti V1 (RQ = kamus konsep dua
> arah, anti-dilusi, kecepatan balas, trait author portabel) TETAP berlaku penuh.

---

## 0. KEJUJURAN KALIBRASI (BACA DULU - jangan overclaim)

- Status target = **RQ5-READY**, BUKAN "dijamin RQ 5/5". Tidak ada output tool yang
  bisa menjanjikan 5/5.
- RQ adalah **trait author yang portabel**: stdev intra-author 0.77 vs antar-author 1.29.
  Skor akhir bergantung pada **balasan nyata orang lain**, **kecepatan balas <30 menit**,
  **juri**, dan **akun yang memposting** - hal-hal di luar kcontrol pack.
- Yang kita kontrol 100% = sisi kita: pack tanpa pengencer + kecepatan + jaringan replier.
- Lolos checker = pack VALID, bukan kemenangan. Lolos adalah lantai, bukan langit-langit.

---

## 1. GERBANG MASUK (WAJIB - jangan dipanggil sebelum semua hijau)

1. Konten FINAL ada (content.txt) + semua gate konten PASS (Compliance, dan untuk
   campaign tactical: CTA/Tactical/Compactness; untuk confessional: Loser-DNA/OAA/TQ/IA
   + length di bawah hard cap).
2. RQ weight campaign > 0%. Jika RQ weight = 0% -> STOP, pack tidak dibuat.
3. Pack ditulis ke blok Q&A di dalam combined.md. JANGAN pernah mengedit content.txt
   demi memuaskan checker Q&A.

---

## 2. MODEL RQ - APA YANG SEBENARNYA DINILAI

RQ BUKAN template 5-sub seperti EP/CA. RQ = **KAMUS KONSEP DUA ARAH**. Juri membaca
replies di bawah tweet lalu menulis esai; skor mengikuti konsep yang sempat ia tulis.

**KONSEP POSITIF (kehadirannya menaikkan - target produksi):**
engagement (545) - authenticity (481) - specificity (398) - subject-matter (315) -
constructive (236) - substantive (199) - civility (186) - anecdote - distinct voice

**KONSEP NEGATIF (kehadirannya memotong):**
templated (296) - vague (223) - platitudes (209) - ai-generated (111) -
generic praise - one-word replies - spam/emoji-only

**MEKANIKA TERUKUR:**
- pos-concepts 0->5 dalam vonis = mean RQ 0.46 -> 3.14, %RQ5 1% -> 14%.
- "ADA replies > replies sempurna": vonis tanpa replies = "No replies to analyze" = RQ 0.
  Kehadiran balasan mengalahkan kesempurnaan.
- Sweet spot vonis 6-8 kalimat. Beri juri 3-5 hal jelas untuk dipuji, bukan 20 hal
  untuk dibedah.

**TARGET OPERASIONAL TUNGGAL:** juri RQ menulis >=3 konsep-positif dan 0 konsep-negatif.

---

## 3. SPESIFIKASI PACK V2 (20 PAIR, FORMAT GATE-PASS)

### 3.1 Volume & format
- VOLUME default = **20 pasang** Q-COPY/A-COPY (sesuai --min-pairs 20 pada checker).
- Output = blok di dalam combined.md. Setiap pair PERSIS format ini (regex checker
  mengandalkannya, jangan diubah spasinya):

```
## R1  [tier S] (Adoption)
**Q-COPY**
```text
<teks Q, 160-260 chars, mengandung decision-marker>
```
**A-COPY**
```text
<teks A, <=280 chars, satu baris, diakhiri "?", ada first-person token + decision-word>
```
```

- combined.md WAJIB punya: `## MISSION`, `## MAIN CONTENT` (blok ```text == content.txt
  byte-identik), `## DETAIL KANONIK`, 20 pair, lalu `# FINAL AUDIT`, `# LOSER-DNA`,
  `# JUDGE-VARIANCE`. Empat heading terakhir + DETAIL KANONIK adalah section WAJIB
  yang dicek rally-final-integrity-check.py.

### 3.2 Aturan keras per Q-COPY (semua wajib)
- Panjang **160-260 chars**.
- Mengandung minimal satu **DECISION_MARKER** (frasa apa adanya, dicek di Q lowercased):
  `i would`, `my decision`, `i choose`, `i would choose`, `i would rather`, `i trust`,
  `i would pick`, `i like`, `my concern`, `my answer`.
- Sudut pandang orang pertama + ada kata keputusan (decide/forced/cut/stop/start/choose/
  remove/protect/rewrite/change/cancel/publish/share/make).
- Berupa pengakuan/anekdot/objection, BUKAN pertanyaan wawancara kosong.

### 3.3 Aturan keras per A-COPY (semua wajib)
- Panjang **<=280 chars**, SATU baris.
- WAJIB diakhiri tanda tanya `?` (open loop).
- Mengandung **first-person token DENGAN SPASI**: ` i `, ` my `, ` me `, ` i've `,
  ` i'm `, ` mine `, ` we `, ` our ` (perhatikan spasi di kedua sisi - ini cara
  checker mendeteksi; "I" di awal kalimat tetap perlu konteks bersisian).
- Mengandung minimal satu DECISION_WORD.
- Untuk campaign protocol/produk: idealnya juga memuat DECISION_MARKER (lihat 3.2)
  supaya lolos rq-mechanics dengan margin.

### 3.4 Larangan mutlak (otomatis gugur)
- Substring `agree` atau `gm` di mana pun dalam Q atau A (LOW_EFFORT trigger).
- Em dash (-) di seluruh combined.md.
- Generic praise / pure validation ("this hit", "too real", "love this") tanpa
  jawaban konkret + keputusan.
- Craft/meta-commentary tentang tulisannya, bukan tema hidupnya.
- Naskah pendek-fungsional ("thanks!", "good luck", "DM me").
- Angka/klaim yang tidak ada di konten (invented APR, harga token).

---

## 4. DISTRIBUSI KATEGORI (sumber 20 pair)

Tarik 20 pair dari 4 kategori. Komposisi disesuaikan genre; untuk campaign
produk/protocol, perbanyak skeptic & mechanic:

- **[A] ADOPTION-MIRROR / CONFESSION** (~6-7) - replier menyambung tema dengan cerita
  sendiri; balasan menambah anekdot + pertanyaan balik spesifik tentang keputusan.
- **[B] SKEPTIC / CHALLENGE** (~5) - objection nyata (yield? dilusi? smart-contract
  risk? "ini marketing"?). Jawab jujur dengan fakta kanonik, tanpa defensif, open loop.
  INI KATEGORI BERNILAI TERTINGGI: skeptic-pass dihargai checker mechanics, dan
  objection tajam yang dijawab jujur paling sulit ditiru.
- **[C] HOW / MECHANIC** (~5) - replier tanya cara; balasan = walkthrough konkret
  (nama platform, langkah, durasi). Di sinilah konsep "subject-matter expertise" lahir.
- **[D] HUMOR / CT-NATIVE** (~3) - wit crypto-native, self-deprecating. Konsep
  "distinct voice" + "authenticity". Engagement tinggi TAPI skeptic/decision lemah.

Banned sebagai Q-COPY berdiri sendiri (untuk campaign produk/protocol):
- pure agreement dengan tesis produk;
- pernyataan "utility itu bagus" generik;
- luka NFT pribadi tanpa mekanik campaign;
- sebut mekanik tanpa keputusan/stake;
- skeptisisme tanpa pertanyaan konstruktif.

---

## 5. TUJUH POLA WAJIB PER PAIR (dari vonis RQ5 asli)

1. **CONFESSION-BASED** - Q = pengakuan/anekdot/objection, bukan wawancara.
2. **DISTINCT VOICES** - tidak ada 2 pair bersebelahan terdengar sama.
3. **ZERO ACADEMIC** - tanpa jargon esai ("meta-cognition" dst).
4. **CRYPTO-NATIVE HUMOR** - minimal 2 pair witty.
5. **CONCRETE SPECIFICS** - nama, platform, langkah, durasi di tiap balasan
   (tanpa mengarang angka yang tak ada di konten).
6. **ADVANCES CONVERSATION** - tiap A menambah angle BARU + diakhiri pertanyaan
   balik spesifik (open loop).
7. **ZERO AI-PHRASES** - termasuk yang menyamar.

**STRUKTUR A (3 ketukan):** jawab langsung -> bukti/anekdot spesifik -> open loop
pertanyaan balik. Uji setiap baris: "jika juri mengutip HANYA baris ini, konsep apa
yang ia tulis?" Jawaban harus salah satu konsep-positif (§2). Tidak bisa jawab = HAPUS.

---

## 6. HUKUM ANTI-DILUSI (pelajaran vonis asli Two-Column RQ 4/5)

Vonis nyata memotong RQ karena balasan LEMAH dari pack sendiri ikut tampil
("good luck...", "do I need a big account?"). Hukumnya:
1. Naskah pendek-fungsional DILARANG - satu balasan vague yang dikutip juri menghapus
   nilai lima balasan substantif.
2. Audit pack = audit baris-per-baris (uji-kutip-tunggal §5).
3. Lebih sedikit pair kuat > genap 20 dengan pengencer (tapi checker butuh >=20,
   jadi pastikan ke-20 nya lolos uji-kutip, bukan diisi pengencer).

---

## 7. PROTOKOL RANKING STRONGEST -> WEAKEST (BARU di V2)

RQ menilai tiap pair terpisah; urutan TIDAK menaikkan skor gate. Ranking murni untuk
KEPRAKTISAN: saat waktu balas mepet (<30 menit), pakai dari atas. Default V2:
urutkan 20 pair dari terkuat ke terlemah, beri label R1..R20 + tier (S/A/B/C).

**Rubrik skor (per pair, 0-5 tiap sumbu, lalu kalikan bobot):**

| Sumbu | Bobot | Apa yang dinilai |
|---|---|---|
| Skeptic / objection depth | 1.4 | objection tajam yang dijawab jujur (paling sulit ditiru, memancing diskusi panjang) |
| Open-loop CTA force | 1.0 | pertanyaan balik biner/spesifik > pertanyaan umum |
| Mechanic specificity | 1.1 | menyentuh detail nyata (non-custodial, accrual harian, score, URL resmi) > generik |
| Originality pull | 0.8 | mengundang orang cerita pengalaman sendiri |

total = skeptic*1.4 + openloop*1.0 + mechanic*1.1 + originality*0.8, lalu sort desc.

**Pola hasil khas:** objection terberat (smart-contract risk, dilusi, yield, custody)
naik ke tier S di atas; mekanik dalam + adoption-mirror kuat di tier A; humor
(engagement tinggi tapi decision/skeptic lemah) turun ke tier C di bawah.

**PERINGATAN OPERASIONAL:** saat me-reorder pack di combined.md, JANGAN sampai
memotong section wajib di ekor file (FINAL AUDIT / LOSER-DNA / JUDGE-VARIANCE).
Section itu berada SETELAH blok Q&A; rebuild yang ceroboh akan menghapusnya dan
rally-final-integrity-check.py akan FAIL "required section missing". Selalu jalankan
ulang final-integrity setelah reorder.

---

## 8. CHECKER WAJIB (pack tidak valid jika salah satu tidak PASS)

```bash
cd <engine-root>

# 1) Setiap pair menjawab CTA post asli (first-person + decision + A diakhiri "?")
python3 skills/rally-rq-prompt-answer-check.py \
  --combined combined.md --out-json rq.json --out-md RQ.md --min-pairs 20

# 2) Kalibrasi mekanik (untuk campaign produk/protocol: butuh decision-marker +
#    mechanic + open-loop, hindari low-effort). Cek rows[].decision=='FAIL' untuk
#    kegagalan nyata; "mechanics=N/20" di ringkasan = hitungan KATEGORI, bukan gagal.
python3 skills/rally-rq-mechanics-calibration-check.py \
  --combined combined.md --content content.txt \
  --out-json rqm.json --out-md RQM.md \
  --min-mechanics-pct 0.70 --min-skeptic-pct 0.25

# 3) Integritas akhir: no em dash, semua section ada, kedua report RQ = PASS
python3 skills/rally-final-integrity-check.py \
  --content content.txt --combined combined.md --min-qna 20 \
  --rq-report rq.json --rq-mechanics-report rqm.json
```

Target output:
```
RQ PROMPT-ANSWER CHECK: PASS [pass=20/20, meta=0]
RQ MECHANICS CALIBRATION CHECK: PASS [mechanics=20/20, ...skeptic>=25%]
FINAL INTEGRITY CHECK: PASS (content NNNN chars, Q=20, A=20)
```

---

## 9. PROTOKOL EKSEKUSI POSTING

1. Balas SEMUA reply organik dalam <30 menit di jam-jam pertama. Kecepatan = fitur.
2. Prioritas balas: confession organik > skeptic > how > basa-basi. Pakai R1 ke bawah
   (urutan ranking §7) saat waktu mepet.
3. Jangan posting balasan di luar pack tanpa lolos uji-kutip-tunggal (§5).
4. Setelah vonis RQ asli keluar -> catat lesson, tanam kelas baru ke file ini.

---

## 10. SELF-CHECK SEBELUM OUTPUT (semua harus PASS)

```
=== QNA-ENGINE V2 QUALITY CHECK ===
[ ] 20 pair, format **Q-COPY**/**A-COPY** + blok ```text persis
[ ] Kategori A/B/C/D terisi (skeptic >=25%)
[ ] Tiap Q 160-260 chars + ada DECISION_MARKER
[ ] Tiap A <=280 chars, satu baris, diakhiri "?", first-person-token + DECISION_WORD
[ ] Zero substring agree/gm; zero em dash
[ ] DETAIL KANONIK konsisten di semua pair (tidak ada kontradiksi kanonik)
[ ] Uji-kutip-tunggal lolos per pair -> konsep positif
[ ] Pair diranking strongest->weakest, label R1..R20 + tier
[ ] Section wajib utuh: MISSION, MAIN CONTENT(==content.txt), DETAIL KANONIK,
    FINAL AUDIT, LOSER-DNA, JUDGE-VARIANCE
[ ] 3 checker (§8) semua PASS
```

Satu item gagal = perbaiki SEBELUM output. Lolos = pack VALID & RQ5-READY,
BUKAN jaminan RQ 5/5.
