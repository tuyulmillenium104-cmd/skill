# TOP-1% DNA-FIRST MANDATE

**Status:** ACTIVE ADDENDUM
**Date:** 2026-06-29 Asia/Jakarta
**Reason:** Post-run correction on The Trade Off / mission-0 showed that tool PASS can still produce content that is too safe. Top-1% Rally output requires winner-DNA sharpness before mechanical validation.

---

## CORE LAW

Do not write safe content and then validate it.

Build from Winner DNA first, sterilize against Loser DNA second, then use tools only as final gates.

Correct order:

```text
1. Mission brief decode
2. Winner DNA construction map
3. Loser DNA contamination map
4. Top-1% sharpness target
5. Draft from winner mechanisms
6. Sterilize loser patterns before finalizing
7. Tool validation
```

A tool PASS is not enough if the content does not feel like the strongest winner-DNA mechanism in the mission pool.

---

## TOP-1% CONSTRUCTION REQUIREMENTS

Before drafting, extract these from mission-scoped winners:

1. **Hook family**
   - personal confession
   - sharp contradiction
   - specific lived moment
   - concrete image

2. **Core trade mechanism**
   - exact thing sacrificed
   - exact thing gained
   - why this trade matters now

3. **Memorable frame**
   - a quotable phrase or binary tension
   - examples: safety vs proof, comfort vs momentum, attention vs reward

4. **Brand bridge style**
   - must feel earned by the story
   - must not become a product pitch

5. **CTA style**
   - reflective question, not mechanical engagement bait
   - should sound like a continuation of the story
   - must still create an easy reply path

---

## LOSER-DNA MUST BE USED BEFORE WRITING

Loser DNA is not only an end scan.

Before drafting, identify and ban:

- crowded phrases from non-winners;
- generic give-up/get templates;
- overused comfort/scrolling/success motifs unless re-framed sharply;
- brand mention that reads promotional or tacked on;
- weak CTA endings;
- abstract trade names without concrete receipts.

If a draft contains loser-style mechanics, rebuild. Do not patch.

---

## SHARPNESS FLOOR

A candidate cannot be final unless it has all five:

1. A first line that a reader can remember.
2. A trade-off more specific than the average non-winner.
3. A concrete receipt/proof object.
4. A sentence that can be quoted by another user.
5. A reflective CTA that fits the story and the mission.

If the content is merely compliant, it is not top 1%.

---

## TOOL USE RULE

Tools answer:

```text
Can this pass?
```

Winner DNA answers:

```text
Can this win?
```

If those conflict, follow Winner DNA and rebuild until both are true.

---

## REQUIRED FINAL DISCLOSURE

Every future final audit must include:

```text
DNA-FIRST TOP-1% CHECK:
- Winner hook mechanism used:
- Winner trade mechanism used:
- Memorable frame:
- Loser-DNA patterns avoided before drafting:
- Why this is sharper than a safe PASS draft:
```

---

## REAL VERDICT PATCH - EP5 TACTICAL VALUE PAYLOAD

A real verdict on The Trade Off / mission-0 scored EP 4/5 because the content was "slightly more philosophical than tactical" despite strong hook, CTA, structure, and brand bridge.

Therefore, every future top-1% draft must include a **Tactical Value Payload**.

Required check before final:

```text
TACTICAL VALUE PAYLOAD:
- What practical rule/test/method does the reader get?
- Can the reader apply it today?
- Is it more than reflection?
- Is it integrated into the story rather than bolted on?
```

If the answer is only philosophical, rebuild. Tool PASS is invalid for EP5 prediction.

---

## WINNER DNA BUILD SPEC IS MANDATORY

Having winner DNA is not enough. The agent must convert it into a written build spec before drafting.

Required pre-draft artifact:

```text
WINNER-DNA BUILD PLAN:
- Hook mechanism selected:
- Trade/refusal mechanism selected:
- Value delivery mechanism selected:
- Tactical payload selected:
- Brand bridge style selected:
- CTA style selected:
- Loser-DNA exclusions:
```

No build plan = no draft.

---

## ORIGINALITY SATURATION CHECK IS MANDATORY

Loser-DNA n-gram cleanliness is not enough. A draft can be original in wording but common in idea.

Before final, check:

```text
ORIGINALITY SATURATION:
- Is the core trade motif crowded in the mission pool?
- Does the progression mirror common entries?
- Is the angle semantically distant from non-winners and average winners?
- Is the memorable frame genuinely new, not just polished?
```

If core motif is saturated, rebuild the angle. Do not only rewrite the phrasing.

---

## EP COMPACTNESS AND REPLY CONVERSION ARE MANDATORY

A post can be vivid and original but still lose EP if it is too long for casual scrollers or too literary to invite replies.

Before final, check:

```text
EP COMPACTNESS:
- Is content under the soft target or justified by extra value?
- Can a casual scroller grasp hook, story, value, and CTA quickly?
- Does the tone invite replies, not just admiration?
- Is the tactical payload operational, not only poetic?
```

If content is long and the value is mostly emotional/reflective, compress or rebuild.

---

## RQ MUST ANSWER THE ACTUAL CTA

RQ5-oriented replies must not merely validate the post. They must answer the prompt.

For drink missions:
```text
reply = drink + situation + decision
```

For trade/refusal missions:
```text
reply = trade/refusal + personal stake + decision
```

Banned unless paired with personal story:
- pure craft analysis;
- "this line works because...";
- generic resonance without a concrete answer;
- short validation replies.

---

## WORST POSITIVE VERDICT IS MANDATORY

All-max pressure requires more than positive self-judgment. Before final, ask:

```text
What is the nicest EP4/OAA1/RQ3 sentence a judge could write about this?
```

Examples:
- "Strong, but slightly long for casual scrollers."
- "Authentic, but the core motif overlaps with several other entries."
- "Replies are relevant, but mostly validate rather than advance conversation."
- "Value is emotional and reflective rather than highly actionable."

If the sentence is credible and precedented, the draft is not final.

Rule: **No credible positive-but-capping sentence = final candidate.**

---

## PRE-DRAFT RISK CONTRACT IS MANDATORY

Fresh Winner/Loser/Judge data must be converted into a hard contract before writing.

Required artifact:

```text
PRE-DRAFT RISK CONTRACT:
- Banned motifs:
- Banned phrases:
- Saturated angles:
- Winner mechanisms to use:
- Required tactical payload type:
- Required CTA answer format:
- Required Q&A answer format:
- Likely judge deduction sentences to avoid:
- Rebuild triggers:
```

No pre-draft contract = no draft.

If the draft violates the contract, rebuild the angle. Do not patch wording.

---

## Q&A MUST BE CAMPAIGN-MECHANIC CALIBRATED

For product/protocol campaigns, prompt-answer compliance is not enough. RQ5 requires subject-matter engagement.

Required Q-COPY shape:

```text
explicit decision + campaign mechanic + personal/skeptical angle
```

Required distribution:
- at least 70% of Q-COPY pairs mention a concrete campaign mechanic;
- at least 4 mechanic categories covered;
- at least 25% include constructive skepticism;
- zero pure validation or craft commentary.
