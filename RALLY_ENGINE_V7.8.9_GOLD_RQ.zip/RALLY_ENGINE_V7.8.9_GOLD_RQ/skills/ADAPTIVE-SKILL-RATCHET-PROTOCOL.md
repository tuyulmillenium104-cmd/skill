# RALLY V7.7 ADDENDUM v1.9 — ADAPTIVE SKILL RATCHET PROTOCOL

**Date:** 2026-06-25 Asia/Jakarta  
**Status:** ACTIVE  
**Purpose:** Skill must evolve from real Rally verdicts and campaign-specific pools immediately, not merely store lessons in memory. Every new EP deduction class and every recurring winner mechanism must become active execution material for future runs.

---

## 1. NEW META-RULE #0U: SKILL RATCHET, NOT MEMORY ONLY

Calibration memory is not enough. If a real verdict or mission-scoped pool reveals a new class, the skill must be updated in an active location that future runs load.

There are two ratchet streams:

1. **Deduction Ratchet** — EP4/EP3 reasons become active avoidance checks.
2. **Winner Ratchet** — EP5/all-max mechanisms become active positive construction patterns.

---

## 2. ACTIVE LESSON LOCATION

All adaptive lessons are written to:

```text
skills/ADAPTIVE-RATCHET-LESSONS.md
```

This file is part of the active skill. It is not an archive. Step 0 preflight must load it together with the execution core.

The main skill references it as active:

```text
RALLY-EXECUTION-CORE.md → ADAPTIVE-RATCHET-LESSONS.md
```

---

## 3. ADAPTIVE DEDUCTION DISCOVERY

Before writing final content, mine all mission-scoped EP<5 verdicts:

```bash
python3 skills/rally-ep-deduction-map.py \
  --submissions rally-data/learn/<campaign-mission>/submissions_enriched.json \
  --content konten/<campaign>/<content>.txt \
  --out-json ep-deduction-map.json \
  --out-md EP-DEDUCTION-MAP.md
```

The tool extracts:
- deduction sentences;
- known classes;
- unknown/new classes;
- evidence quotes;
- content risk flags.

If unknown class appears, it is not ignored. It is recorded as:

```text
CLASS_NEW_<date>_<slug>
```

and must be checked manually/adversarially before final output.

---

## 4. ADAPTIVE WINNER DNA DISCOVERY

Before writing final content, mine all mission-scoped winners and near-winners:

```bash
python3 skills/rally-winner-dna-map.py \
  --submissions rally-data/learn/<campaign-mission>/submissions_enriched.json \
  --out-json winner-dna-map.json \
  --out-md WINNER-DNA-MAP.md
```

The tool extracts:
- opener types;
- CTA forms;
- mention placement;
- paragraph rhythm;
- recurring winner mechanisms;
- recurring winner vocabulary;
- direct quote examples.

Winner DNA must be treated adaptively:

```text
Winner DNA = current mission empirical construction guide, not a static universal pattern.
```

If winner count is low, use near-winners and deduction map more heavily.

---

## 5. ACTIVE RATCHET WRITEBACK

After mining, append a concise active lesson to:

```text
skills/ADAPTIVE-RATCHET-LESSONS.md
```

Required format:

```text
## [date] — [campaign] — [mission] — [lesson slug]

TYPE: DEDUCTION / WINNER / EXECUTION / CTA / MEDIA / BRAND-BRIDGE
SOURCE: [real verdict / mission pool / live miss]
EVIDENCE:
- "quote from judge or winner"
ACTIVE RULE:
- [specific rule future runs must enforce]
CHECK:
- [how to detect it]
ACTION:
- [fix/rewrite/rebuild rule]
```

This writeback is a skill update, not merely memory.

---

## 6. SAFETY RULE: DO NOT AUTO-OVERWRITE CORE LOGIC

The ratchet can append active lessons and update reference files. It must not destructively rewrite the main skill or tools without explicit user approval.

Safe direct update:
- append to ADAPTIVE-RATCHET-LESSONS.md;
- append addendum to main skill;
- create/update tool reports;
- update README/all-in-one backup.

Unsafe without approval:
- deleting existing rules;
- changing scanner lexicons;
- replacing core execution order;
- overwriting historical evidence.

---

## 7. REQUIRED EXECUTION ORDER UPDATE

Official core flow now includes:

```text
Mission-scoped DNA
→ DNA Confidence
→ Adaptive Winner DNA Map
→ Adaptive EP Deduction Map
→ Draft
→ CTA #0T+
→ Judge Variance #0R
→ Loser DNA #0S2
→ Scanner
→ Final Integrity
→ Ratchet writeback
```

---

## 8. FINAL AUDIT ADDITION

Final audit must include:

```text
ADAPTIVE RATCHET (#0U):
- Winner DNA map generated: yes/no
- EP deduction map generated: yes/no
- Unknown deduction classes found: [N]
- New active lessons appended: [N]
- ADAPTIVE-RATCHET-LESSONS.md updated: yes/no
```

---

## ENFORCEMENT SUMMARY

For every future `/rally` run:

1. Mine winners adaptively.
2. Mine EP deductions adaptively.
3. Treat unknown classes as real until cleared.
4. Append new active rules to ADAPTIVE-RATCHET-LESSONS.md.
5. Do not rely on memory alone.
