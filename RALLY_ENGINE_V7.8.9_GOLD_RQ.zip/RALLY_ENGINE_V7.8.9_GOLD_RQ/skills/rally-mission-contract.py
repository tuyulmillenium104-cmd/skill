#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate compliance contract from requirement provenance (V7.8.8)."""
import argparse,json,time
from pathlib import Path

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--provenance',required=True);ap.add_argument('--out',required=True);args=ap.parse_args();p=json.load(open(args.provenance,encoding='utf-8'))
 mentions=p.get('requiredMentions') or []
 c={'tool':'rally-mission-contract.py v7.8.8','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'campaign':p.get('campaign'),'mission':p.get('mission'),'provenanceFile':args.provenance,'mention':mentions[0] if len(mentions)==1 else None,'required_mentions':mentions,'official_max_chars':p.get('officialMaxChars'),'one_sentence':bool(p.get('officialOneSentence')),'engine_soft_target_min':(p.get('engineSoftTarget') or [None,None])[0],'engine_soft_target_max':(p.get('engineSoftTarget') or [None,None])[1],'require_relation':p.get('requiredRelation'),'media_required':bool(p.get('mediaRequired')),'forbid_fourth_wall':True,'scalar_targets':{'mission_type':'derive from mission soul','teach_back':'reader can satisfy literal mission ask'}}
 Path(args.out).write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8');print(f'MISSION CONTRACT: wrote {args.out} officialMax={c["official_max_chars"]} soft={c["engine_soft_target_min"]}-{c["engine_soft_target_max"]}')
if __name__=='__main__':main()
