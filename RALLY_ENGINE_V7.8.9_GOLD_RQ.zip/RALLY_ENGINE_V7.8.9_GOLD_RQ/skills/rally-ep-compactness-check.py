#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EP Compactness and Reply Conversion checker.

Real verdict lesson: a long, vivid, campaign-aligned tweet can still receive EP4
if it is too long/dense for casual scrollers or too literary, making users admire it
more than reply.
"""
import argparse, json, re, sys, time
from pathlib import Path
from rally_common import report_identity

LITERARY_MARKERS = [
    "flavor of the year", "useful chaos", "plastic spoon", "lemon-flavored", "surrender",
    "the universe served", "life handed", "the glass", "metaphor", "recipe", "menu",
    "ingredients", "promised", "actually holding", "half full", "half empty"
]

REPLY_CONVERSION_MARKERS = [
    "name", "tell me", "what", "which", "share", "choose", "pick", "reply", "drink", "decision",
    "story", "forced", "promise", "holding", "plan", "became"
]


def paras(text):
    return [p.strip() for p in re.split(r"\n\s*\n+", text.strip()) if p.strip()]


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--content', required=True)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    ap.add_argument('--max-chars', type=int, default=850, help='soft EP5 compactness target')
    ap.add_argument('--hard-max-chars', type=int, default=None)
    ap.add_argument('--genre', default='tactical', choices=['tactical','confessional','narrative','auto'])
    args=ap.parse_args()
    if args.genre=='confessional':
        args.max_chars = max(args.max_chars, 1800); args.hard_max_chars = args.hard_max_chars or 2200
    elif args.genre=='narrative':
        args.max_chars = max(args.max_chars, 1400); args.hard_max_chars = args.hard_max_chars or 1800
    else:
        args.hard_max_chars = args.hard_max_chars or 1050
    text=Path(args.content).read_text(encoding='utf-8').strip()
    tl=text.lower()
    ps=paras(text)
    words=re.findall(r"\b\w+\b", text)
    longest=max((len(p) for p in ps), default=0)
    avg_para=(sum(len(p) for p in ps)/len(ps)) if ps else 0
    last=ps[-1] if ps else text

    long_risk=len(text)>args.max_chars
    hard_long=len(text)>args.hard_max_chars
    dense_para=longest>360 or avg_para>210
    literary_hits=[m for m in LITERARY_MARKERS if m in tl]
    too_literary=len(literary_hits)>=3
    cta_markers=[m for m in REPLY_CONVERSION_MARKERS if m in last.lower()]
    cta_easy=("?" in last and len(last)<=140 and len(cta_markers)>=2)
    if args.genre in ['confessional','narrative']:
        # Field lesson: reflective closing questions can be valid without a
        # marketing-style behavioral CTA.
        cta_easy=("?" in last and len(last)<=220)

    # If long, it needs a clear tactical or operational sentence to justify length.
    operational=bool(re.search(r"\b(rule|test|process|checklist|step|if .* then|before you|remove|cut|write|share|name|decide|choose)\b", tl))
    length_justified=(not long_risk) or ((operational or args.genre in ['confessional','narrative']) and cta_easy and not dense_para)
    admiration_over_reply_risk=too_literary and not cta_easy

    checks={
        'underSoftMaxChars': not long_risk,
        'underHardMaxChars': not hard_long,
        'noDenseParagraph': not dense_para,
        'ctaEasyReplyPath': cta_easy,
        'lengthJustifiedByOperationalValue': length_justified,
        'notAdmirationOverReply': not admiration_over_reply_risk,
    }
    reasons=[]
    if long_risk: reasons.append(f'content {len(text)} chars > soft EP compactness target {args.max_chars}')
    if hard_long: reasons.append(f'content {len(text)} chars > hard max {args.hard_max_chars}')
    if dense_para: reasons.append(f'dense paragraph risk longest={longest} avg={avg_para:.1f}')
    if too_literary: reasons.append(f'literary/metaphor density risk {literary_hits}')
    if not cta_easy: reasons.append('CTA may not be low-friction enough for casual reply')
    if not length_justified: reasons.append('longform length not justified by operational value + easy CTA')

    # PASS if no hard blockers and longform is justified by operational value + easy CTA.
    # Longform alone is a warning, not a blocker, if it earns the length.
    decision='PASS'
    if hard_long or dense_para or not cta_easy or not length_justified or admiration_over_reply_risk:
        decision='FAIL'

    result={
        'tool':'rally-ep-compactness-check.py v7.8.5',
        **report_identity(text),
        'generated':time.strftime('%Y-%m-%d %H:%M:%S'),
        'genre':args.genre,
        'wordCount':len(words),
        'paragraphCount':len(ps),
        'longestParagraphChars':longest,
        'avgParagraphChars':round(avg_para,1),
        'literaryHits':literary_hits,
        'ctaQuote':last,
        'ctaMarkers':cta_markers,
        'checks':checks,
        'decision':decision,
        'reasons':reasons,
    }
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append('# EP COMPACTNESS / REPLY CONVERSION CHECK\n\n')
    md.append(f'Decision: **{decision}**\n\n')
    md.append(f'- Content chars: {len(text)}\n- Words: {len(words)}\n- Paragraphs: {len(ps)}\n- Longest paragraph chars: {longest}\n- CTA: `{last}`\n\n')
    md.append('## Checks\n')
    for k,v in checks.items(): md.append(f'- {k}: {v}\n')
    md.append('\n## Reasons\n')
    md += [f'- {r}\n' for r in reasons] or ['- clear\n']
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f"EP COMPACTNESS CHECK: {decision} [{', '.join(reasons) if reasons else 'clear'}]")
    sys.exit(0 if decision=='PASS' else 1)

if __name__=='__main__': main()
