#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OAA structure/trope audit against mission-scoped non-winner corpus."""
import argparse,json,re,sys,time,math
from pathlib import Path
from rally_common import report_identity, normalized_text, sha256_file
STOP=set('the a an and or but to of in on for with is are was were be been being it this that as at by from you your i my me we they them if not just more most no one do does did'.split())
GENERIC=['game changer','in today','not just','more than','future of','unlock','huge advantage','secret weapon','alpha','no brainer','this is why']

def toks(t): return [x for x in re.findall(r"[a-z0-9@']+", (t or '').lower()) if x not in STOP]
def jacc(a,b):
    A=set(toks(a)); B=set(toks(b)); return len(A&B)/max(1,len(A|B))
def opener_family(text):
    first=(re.split(r"\n\s*\n", text.strip())[0] if text.strip() else '')[:220].lower()
    if '?' in first: return 'question'
    if any(x in first for x in ['hot take','unpopular','controversial']): return 'hot_take'
    if first.startswith('i ') or first.startswith('my '): return 'personal'
    if first.startswith('most '): return 'most_generalization'
    if 'not ' in first and 'but' in first: return 'not_but_contrast'
    return 'declarative'
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--content',required=True); ap.add_argument('--submissions',required=True); ap.add_argument('--out-json',required=True); ap.add_argument('--out-md',required=True); ap.add_argument('--motif',action='append',default=[]); args=ap.parse_args()
    text=Path(args.content).read_text(encoding='utf-8').strip(); tl=text.lower(); subs=json.load(open(args.submissions,encoding='utf-8'))
    raw_non=[s for s in subs if not s.get('winner')];non=[];seen=set()
    for s in raw_non:
        key=normalized_text(s.get('content') or '')
        if not key or key in seen:continue
        seen.add(key);non.append(s)
    sims=[]
    for s in non:
        st=s.get('content') or ''
        sims.append({'author':s.get('xUsername'),'score':jacc(text,st),'ep':(s.get('gates') or {}).get('EP',[None])[0],'snippet':st[:260]})
    sims=sorted(sims,key=lambda x:x['score'], reverse=True)[:10]
    opener=opener_family(text)
    opener_hits=[s.get('xUsername') for s in non if opener_family(s.get('content') or '')==opener]
    generic_hits=[g for g in GENERIC if g in tl]
    motif_hits={m:[s.get('xUsername') for s in non if m.lower() in ((s.get('content') or '').lower())] for m in args.motif}
    errors=[]; warnings=[]
    if sims and sims[0]['score']>0.42: errors.append(f"high semantic token similarity to non-winner @{sims[0]['author']}: {sims[0]['score']:.2f}")
    if generic_hits: warnings.append(f"generic/template phrase hits: {generic_hits}")
    if len(opener_hits)>max(8, len(non)*0.25): warnings.append(f"opener family common in non-winners: {opener} ({len(opener_hits)})")
    contaminated={m:h for m,h in motif_hits.items() if h}
    if contaminated: warnings.append(f"motif exact hits in non-winners: {contaminated}")
    decision='PASS' if not errors else 'FAIL'
    result={'tool':'rally-oaa-structure-audit.py v7.8.5',**report_identity(text),'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'submissionsSha256':sha256_file(args.submissions),'rawNonWinnerCount':len(raw_non),'dedupNonWinnerCount':len(non),'openerFamily':opener,'openerFamilyNonWinnerHits':len(opener_hits),'nearestNonWinners':sims,'genericHits':generic_hits,'motifHits':motif_hits,'errors':errors,'warnings':warnings,'decision':decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# OAA STRUCTURE/TROPE AUDIT\n\n',f'- Opener family: {opener}\n',f'- Non-winner opener hits: {len(opener_hits)}\n',f'- Decision: **{decision}**\n\n','## Nearest Non-Winners\n']
    for s in sims[:8]: md.append(f"- @{s['author']} sim={s['score']:.3f} EP={s['ep']} — {s['snippet'][:140]}\n")
    md+=['\n## Warnings\n']+([f'- {w}\n' for w in warnings] or ['- none\n'])
    md+=['\n## Errors\n']+([f'- {e}\n' for e in errors] or ['- none\n'])
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'OAA STRUCTURE AUDIT: {decision} [{len(errors)} errors, {len(warnings)} warnings]')
    sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__': main()
