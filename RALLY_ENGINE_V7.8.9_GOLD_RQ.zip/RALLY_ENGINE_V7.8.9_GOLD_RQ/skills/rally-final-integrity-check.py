#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Hash-backed final deliverable integrity checker (V7.8.5)."""
import argparse,json,re,sys
from pathlib import Path
from rally_common import sha256_text,extract_main_content_block,find_url_issues
BAD_CHARS=["—","–","“","”","‘","’"]
def fail(msgs):
 print('FINAL INTEGRITY CHECK: FAIL')
 for m in msgs:print('  FAIL:',m)
 sys.exit(1)
def load(path):return json.load(open(path,encoding='utf-8'))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--combined',required=True);ap.add_argument('--compliance-output');ap.add_argument('--rules-output');ap.add_argument('--loser-report');ap.add_argument('--min-qna',type=int,default=0);ap.add_argument('--require-url');ap.add_argument('--require-cta-verb',action='store_true');ap.add_argument('--cta-report');ap.add_argument('--ep-map');ap.add_argument('--winner-map');ap.add_argument('--tq-report');ap.add_argument('--oaa-report');ap.add_argument('--ia-report');ap.add_argument('--ep-semantic-report');ap.add_argument('--tactical-report');ap.add_argument('--originality-report');ap.add_argument('--compactness-report');ap.add_argument('--rq-report');ap.add_argument('--worst-verdict-report');ap.add_argument('--rq-mechanics-report');ap.add_argument('--naturalness-report');ap.add_argument('--ep-max-report');ap.add_argument('--requirement-provenance');ap.add_argument('--relation-report');ap.add_argument('--qna-gold-report');ap.add_argument('--snapshot-manifest');ap.add_argument('--min-q-chars',type=int,default=160);ap.add_argument('--max-q-chars',type=int,default=260);ap.add_argument('--max-a-chars',type=int,default=280);args=ap.parse_args()
 errs=[];warnings=[];content=Path(args.content).read_text(encoding='utf-8').strip();combined=Path(args.combined).read_text(encoding='utf-8');ch=sha256_text(content);bh=sha256_text(combined)
 block=extract_main_content_block(combined)
 if block is None:errs.append('MAIN CONTENT fenced text block missing')
 elif block!=content:errs.append('MAIN CONTENT block is not byte-identical to content.txt')
 for c in BAD_CHARS:
  if c in combined:errs.append(f'bad Unicode punctuation in combined: {c!r}')
 ui=find_url_issues(content)
 if ui['markdownLinks']:errs.append(f'Markdown links in X content: {ui["markdownLinks"][:3]}')
 if ui['attachedPunctuation']:errs.append(f'URL attached punctuation: {ui["attachedPunctuation"][:3]}')
 if args.require_url and args.require_url not in content:errs.append(f'required URL missing: {args.require_url}')
 if args.require_cta_verb:
  verbs=['reply','comment','tell me','choose','name','check','visit','learn','join','mint','compare','pick','show me','share','appeal','challenge']
  if not any(re.search(r"\b"+re.escape(v)+r"\b",content.lower()) for v in verbs):errs.append('no direct behavioral CTA verb')
 if args.compliance_output:
  co=Path(args.compliance_output).read_text(encoding='utf-8',errors='ignore')
  if 'COMPLIANCE GATE: ALL BINARY PASS' not in co:errs.append('compliance output is not PASS')
  m=re.search(r'CONTENT SHA256:\s*([0-9a-f]{64})',co)
  if not m:errs.append('compliance output lacks content SHA256')
  elif m.group(1)!=ch:errs.append('compliance output hash is stale')
 if args.rules_output:
  ro=Path(args.rules_output).read_text(encoding='utf-8',errors='ignore')
  if 'SEMUA PASS' not in ro:errs.append('self-verdict lexicon output is not all-pass')
 if args.loser_report:
  d=load(args.loser_report)
  if d.get('decision')!='PASS':errs.append('loser report is not PASS')
  if d.get('contentSha256')!=ch:errs.append('loser report hash stale/missing')
 qn=len(re.findall(r"\*\*Q-COPY\*\*\s*```text",combined));an=len(re.findall(r"\*\*A-COPY\*\*\s*```text",combined))
 if args.min_qna and (qn<args.min_qna or an<args.min_qna):errs.append(f'QnA below minimum Q={qn} A={an} min={args.min_qna}')
 ps=re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```",combined,flags=re.S)
 for i,(q,a) in enumerate(ps,1):
  if len(q)<args.min_q_chars:errs.append(f'Q{i} below {args.min_q_chars} chars ({len(q)})')
  if len(q)>args.max_q_chars:errs.append(f'Q{i} exceeds {args.max_q_chars} chars ({len(q)})')
  if len(a)>args.max_a_chars:errs.append(f'A{i} exceeds {args.max_a_chars} chars ({len(a)})')
 for sec in ['DETAIL KANONIK','FINAL AUDIT','LOSER-DNA','JUDGE-VARIANCE']:
  if sec.lower() not in combined.lower():errs.append(f'required section missing: {sec}')
 reports=[('cta',args.cta_report,True,False),('tq',args.tq_report,True,False),('oaa',args.oaa_report,True,False),('ia',args.ia_report,True,False),('ep_semantic',args.ep_semantic_report,True,False),('tactical',args.tactical_report,True,False),('originality',args.originality_report,True,False),('compactness',args.compactness_report,True,False),('rq_prompt',args.rq_report,True,True),('worst',args.worst_verdict_report,True,True),('rq_mechanics',args.rq_mechanics_report,True,True)]
 for label,path,need_pass,needs_combined in reports:
  if not path:continue
  d=load(path)
  if need_pass and d.get('decision')!='PASS':errs.append(f'{label} report is not PASS')
  if d.get('contentSha256')!=ch:errs.append(f'{label} report content hash stale/missing')
  if needs_combined and d.get('combinedSha256')!=bh:errs.append(f'{label} report combined hash stale/missing')
 if args.naturalness_report:
  d=load(args.naturalness_report);dec=d.get('decision')
  if dec=='FAIL':errs.append('naturalness report is FAIL')
  elif dec=='REVIEW':warnings.append('naturalness report requires controlled-variation review')
  if d.get('contentSha256')!=ch:errs.append('naturalness report content hash stale/missing')
  if d.get('combinedSha256')!=bh:errs.append('naturalness report combined hash stale/missing')
 if args.ep_max_report:
  d=load(args.ep_max_report)
  if d.get('decision')!='PASS' or d.get('epDecision')!='EP5_PRESSURE':errs.append(f'EP Max report is not EP5_PRESSURE: {d.get("decision")}/{d.get("epDecision")}')
  if d.get('contentSha256')!=ch:errs.append('EP Max report content hash stale/missing')
  if d.get('combinedSha256')!=bh:errs.append('EP Max report combined hash stale/missing')
 if args.requirement_provenance:
  d=load(args.requirement_provenance)
  if not d.get('requirements'):errs.append('requirement provenance is empty')
 if args.relation_report:
  d=load(args.relation_report)
  if d.get('decision')!='PASS':errs.append('relation compliance report is not PASS')
  if args.requirement_provenance and d.get('provenanceSha256')!=__import__('hashlib').sha256(Path(args.requirement_provenance).read_bytes()).hexdigest():errs.append('relation report uses stale provenance')
 if args.qna_gold_report:
  d=load(args.qna_gold_report)
  if d.get('decision')!='PASS':errs.append('Q&A Gold Standard report is not PASS')
  if d.get('contentSha256')!=ch:errs.append('Q&A Gold report content hash stale/missing')
  if d.get('combinedSha256')!=bh:errs.append('Q&A Gold report combined hash stale/missing')
 if args.snapshot_manifest:
  man=load(args.snapshot_manifest);expected=man.get('submissionsEnrichedSha256')
  if not expected:errs.append('snapshot manifest lacks submissionsEnrichedSha256')
  for label,path in [('winner',args.winner_map),('loser',args.loser_report),('originality',args.originality_report),('oaa',args.oaa_report),('ep_map',args.ep_map)]:
   if path:
    rd=load(path);actual=rd.get('submissionsSha256')
    if not actual:errs.append(f'{label} report lacks submissionsSha256 under snapshot lock')
    elif actual!=expected:errs.append(f'{label} report uses different submissions snapshot')
 if args.ep_map:
  d=load(args.ep_map)
  if d.get('decision')!='PASS':errs.append(f'EP candidate map is not PASS: {d.get("decision")}')
  if d.get('contentSha256')!=ch:errs.append('EP map content hash stale/missing')
  if d.get('candidateUnknownRiskCount',0):errs.append(f'EP candidate unknown risks: {d.get("candidateUnknownRiskCount")}')
  if d.get('activeContentRisks'):errs.append(f'EP active content risks: {d.get("activeContentRisks")}')
 if args.winner_map and not Path(args.winner_map).exists():errs.append('winner map missing')
 if errs:fail(errs)
 for w in warnings:print('  REVIEW:',w)
 print(f'FINAL INTEGRITY CHECK: PASS (content {len(content)} chars, Q={qn}, A={an}, reviews={len(warnings)}, contentSha256={ch}, combinedSha256={bh})')
if __name__=='__main__':main()
