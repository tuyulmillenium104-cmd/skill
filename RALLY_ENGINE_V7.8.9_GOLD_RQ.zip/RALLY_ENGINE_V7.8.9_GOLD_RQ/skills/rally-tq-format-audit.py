#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TQ format/media audit with robust URL parsing (V7.8.5)."""
import argparse,json,re,sys,time
from pathlib import Path
from rally_common import find_url_issues,report_identity
BAD_CHARS=["—","–","“","”","‘","’"]
IMG_RE=re.compile(r"https?://\S+\.(?:png|jpg|jpeg|gif|webp)(?:\?\S*)?",re.I)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--out-json',required=True);ap.add_argument('--out-md',required=True);ap.add_argument('--media-used',action='store_true');ap.add_argument('--media-referenced',action='store_true');ap.add_argument('--genre',default='auto',choices=['auto','tactical','confessional']);ap.add_argument('--official-max',type=int,default=None);ap.add_argument('--engine-review-threshold',type=int,default=1050);args=ap.parse_args()
 text=Path(args.content).read_text(encoding='utf-8').strip();ps=[p.strip() for p in re.split(r"\n\s*\n",text) if p.strip()];words=re.findall(r"\b\w+\b",text);errors=[];warnings=[]
 bad=[x for x in BAD_CHARS if x in text]
 if bad:errors.append(f'bad unicode punctuation: {bad}')
 img=IMG_RE.findall(text)
 if img:errors.append(f'raw image/media URL in body: {img[:3]}')
 ui=find_url_issues(text)
 if ui['markdownLinks']:errors.append(f'Markdown links are invalid X copy: {ui["markdownLinks"][:3]}')
 if ui['attachedPunctuation']:errors.append(f'URL attached punctuation: {ui["attachedPunctuation"][:3]}')
 if text[:1] in ['@','#']:errors.append('starts with mention/hashtag')
 long_ps=[len(re.findall(r"\b\w+\b",p)) for p in ps if len(re.findall(r"\b\w+\b",p))>70]
 if long_ps:warnings.append(f'dense paragraph(s) >70 words: {long_ps}')
 if len(text)>1600:warnings.append(f'longform >1600 chars: {len(text)}')
 if args.official_max and len(text)>args.official_max:errors.append(f'post exceeds official max: {len(text)} > {args.official_max}')
 if args.genre=='tactical':
  if len(text)>args.engine_review_threshold:warnings.append(f'tactical post over engine high-review threshold: {len(text)} > {args.engine_review_threshold}')
  elif len(text)>850:warnings.append(f'tactical post over soft target: {len(text)} chars (>850)')
 mentions=re.findall(r"@[A-Za-z0-9_]+",text)
 for m in set(mentions):
  pos=text.find(m)/max(1,len(text))*100
  if pos>80:warnings.append(f'mention late/appended risk: {m} at {pos:.1f}%')
  if pos<3:errors.append(f'mention too early/start risk: {m} at {pos:.1f}%')
 if args.media_used and not args.media_referenced:errors.append('media_used=true but media not referenced')
 decision='PASS' if not errors else 'FAIL'
 result={'tool':'rally-tq-format-audit.py v7.8.5',**report_identity(text),'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'genre':args.genre,'officialMax':args.official_max,'engineSoftTargetMax':850,'engineReviewThreshold':args.engine_review_threshold,'wordCount':len(words),'paragraphs':len(ps),'rawImageUrls':img,'urlAudit':ui,'errors':errors,'warnings':warnings,'decision':decision}
 Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 md=['# TQ FORMAT AUDIT\n\n',f'- Content chars: {len(text)}\n',f'- Content SHA-256: `{result["contentSha256"]}`\n',f'- Words: {len(words)}\n',f'- Paragraphs: {len(ps)}\n',f'- Decision: **{decision}**\n\n','## Errors\n']+([f'- {e}\n' for e in errors] or ['- none\n'])+['\n## Warnings\n']+([f'- {w}\n' for w in warnings] or ['- none\n'])
 Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f'TQ FORMAT AUDIT: {decision} [{len(errors)} errors, {len(warnings)} warnings]');sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__':main()
