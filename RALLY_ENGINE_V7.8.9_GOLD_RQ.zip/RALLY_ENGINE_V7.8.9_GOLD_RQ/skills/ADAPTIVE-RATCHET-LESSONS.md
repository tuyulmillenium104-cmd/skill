# ADAPTIVE RATCHET LESSONS — ACTIVE (V7.8.3)
(Update: Mission-Soul Separation, Jargon-Kill, Confession-First RQ5, ASCII-Safe)

## 2026-06-29 - The Trade Off / mission-0 - Top-1% DNA-first correction

Lesson: A draft can pass Compliance, CTA, Loser-DNA, EP semantic, and final integrity while still being too safe for top-1% competition.

Failure mode observed:
- CTA/tool formula dominated the decision.
- Winner-DNA tone was not used aggressively enough during revision.
- Safe brief-fit content lacked the sharp memorable hook found in stronger candidate angles.

Correction:
- Future runs must build a sharp, winner-DNA-native hook before validation.
- Loser DNA must sterilize the sharp draft, not force a bland draft.
- Final content needs a quotable frame plus concrete trade receipts.
- Tool PASS means "allowed", not "competitive".

Canonical rule: **sharp first, sterilize second, validate third.**

## 2026-06-29 - Real verdict miss: The Trade Off / mission-0 - EP 4/5 value delivery philosophical tax

Real verdict on the "private group chats / public proof" content gave EP 4/5, despite praising hook, structure, CTA, natural brand bridge, and non-generic tone.

Exact deduction class:
- "While the value delivery is slightly more philosophical than tactical..."

Root cause:
- The draft had a strong frame and clean CTA, but did not give the reader a tactical enough takeaway, method, or decision rule.
- We optimized for memorable philosophy and loser-sterilization, but did not force a practical value payload.
- Existing EP semantic review passed because it checked CTA, formatting, brand bridge, and concrete detail density, but it did not require a tactical/useful mechanism.

New rule:
- EP5 needs more than a resonant insight. It must include a practical value unit: a decision rule, a test, a checklist, a repeatable method, or a specific behavioral step the reader can use immediately.

Patch:
- Every future top-1% draft must contain a **Tactical Value Payload** sentence.
- The payload must answer: "What can the reader do differently after reading this?"
- If the answer is only "reflect," EP5 is unsafe.

Canonical fix pattern:
```text
Philosophical frame -> concrete decision rule -> public/private test -> CTA
```

Bad EP5 assumption:
- strong hook + strong CTA + personal frame = EP5

Correct EP5 assumption:
- strong hook + strong CTA + personal frame + tactical value payload = EP5 candidate

## 2026-06-29 - Real verdict miss: The Trade Off / mission-0 - OAA 1/2 semantic saturation

Real verdict on the "private group chats / public proof" content gave OAA 1/2.

Exact deduction class:
- Core trade was too similar to other submissions moving from invisible/hidden/private to creating in public.
- Progression mirrored common pattern: identify comfort zone, name trade, tag @RallyOnChain, ask reflective question.
- Voice felt real, but polished/crafted and not exceptional in originality.

Root cause:
- Loser-DNA n-gram sterilization passed, but semantic motif saturation was not checked.
- Winner DNA was used for shape, but we did not ask whether the theme itself was crowded in the whole mission pool.
- OAA audit relied too much on nearest text similarity and opener family, not enough on motif-level overlap.

Correction:
- Add mission-pool semantic motif saturation check before final.
- A draft must not only avoid copied phrases; it must avoid crowded idea paths.
- If the core trade sits in a saturated motif, rebuild the angle, not the wording.

Canonical rule: **originality is semantic distance, not just clean wording.**

## 2026-06-29 - Real verdict miss: The Glass Half / mission-1 - EP4 length, literary admiration, operational payload

Real verdict on "ceramic cup of chamomile tea" gave EP 4/5 while praising hook, CTA, structure, originality, and campaign fit.

Deduction classes:
- 901 characters may be long for casual scrollers.
- Literary tone may make users admire more than reply.
- Value delivery was emotional/reflective rather than highly actionable, even with a metaphorical rule.

Correction:
- Add EP compactness / reply conversion check.
- Longform over 850 chars must justify itself with operational value and low-friction CTA.
- Tactical payload must be operational, not only poetic/metaphorical.
- If the strongest value sentence is still a metaphor (menu/recipe/ingredients) without a literal action, EP5 prediction is unsafe.

## 2026-06-29 - Real verdict miss: The Glass Half replies - RQ3 validation without prompt answer

Real RQ verdicts on The Glass Half contents gave RQ 3/5.

Deduction classes:
- Replies referenced specific lines but mostly validated the post.
- Replies did not answer the actual CTA prompt.
- Replies lacked personal story, vulnerability, deeper reflection, or a forced decision.
- Meta-commentary on writing craft did not engage the underlying theme.

Correction:
- Add RQ prompt-answer compliance check.
- Every Q-COPY/A-COPY pair must answer the content's actual CTA.
- For drink missions, replies need drink + situation + decision.
- Ban pure craft-analysis replies unless they include personal story and decision.
- A-COPY must advance conversation, not only affirm.

## 2026-06-29 - Consistency patch: Real verdict logic must become blockers

Discussion conclusion: repeated submit issues happened because Winner DNA and Loser/Judge DNA were not always converted into hard decision rules before submit.

Root causes:
- Winner DNA was sometimes read at surface level: opener, CTA, paragraph rhythm.
- Loser DNA was initially too lexical: n-gram and phrase overlap, not idea-path and judge-ceiling language.
- Tool PASS sometimes replaced real verdict logic.
- Q&A was treated as support material instead of a scored reply layer.

Canonical operating fix:
- Build from Winner DNA mechanism, not only style.
- Block by Loser/Judge DNA, including semantic saturation and positive-but-capping verdict language.
- Before final, write the worst positive verdict: the nicest possible EP4/OAA1/RQ3 sentence a judge could write.
- If that sentence is credible, fix or rebuild.

New rule: **Do not submit strong content. Submit hard-to-deduct content.**

## 2026-06-29 - Preventive layer: Pre-Draft Risk Contract

Lesson: Fresh campaign data is not enough if it remains a reference. It must become a hard pre-draft contract before content is written.

Failure mode:
- Winner DNA existed, but was sometimes used for inspiration instead of constraints.
- Loser/Judge DNA existed, but was sometimes applied after drafting instead of blocking risky angles beforehand.
- Post-draft validators caught issues, but prevention is stronger than repair.

Correction:
- Add `rally-pre-draft-risk-contract.py`.
- Every run must generate a PRE-DRAFT RISK CONTRACT before drafting.
- The contract must list banned phrases, saturated motifs, required winner mechanisms, required CTA answer format, likely judge deduction sentences, and rebuild triggers.

Rule: **Fresh data -> Pre-draft contract -> Build plan -> Draft.**

## 2026-06-29 - RQ calibration: all Q-COPY must be Tier-A for protocol campaigns

Real Wingston RQ5 verdicts praised protocol mechanics and constructive skepticism: RLP staking, Rally Score, Top 425, whitelist process, holder-only campaigns, product NFT sustainability, gas/time cost.

Correction:
- Add `rally-rq-mechanics-calibration-check.py`.
- For product/protocol campaigns, Q-COPY must include explicit decision + campaign mechanic + personal/skeptical angle.
- Q&A pack is not RQ5-ready if only some questions are strong; all 20 should be Tier-A calibrated.
