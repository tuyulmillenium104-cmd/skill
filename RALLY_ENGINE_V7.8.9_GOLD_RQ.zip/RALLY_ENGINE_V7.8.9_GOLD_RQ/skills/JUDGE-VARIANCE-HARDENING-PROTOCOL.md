# RALLY V7.7 ADDENDUM v1.5 — JUDGE-VARIANCE HARDENING PROTOCOL

**Date:** 2026-06-24 Asia/Jakarta  
**Status:** ACTIVE  
**Reason:** Masalah inti yang belum cukup ditutup oleh single blind-judge: juri LLM tidak deterministik. Target baru bukan sekadar "lolos satu simulasi", tetapi **robust across plausible judge variance**.

---

## 1. NEW META-RULE #0R: ROBUST ACROSS JUDGE VARIANCE

**Konten belum final hanya karena satu blind/self judge memberi ALL MAX.**

Konten baru boleh dianggap kandidat final jika ia tahan terhadap beberapa jalur perhatian juri yang masuk akal:

1. Literal Compliance Judge
2. IA Skeptic Judge
3. OAA Similarity Judge
4. EP Harsh Judge
5. TQ Native-Platform Judge

**Prinsip:** juri asli hanya perlu menemukan satu kalimat kritik yang cukup kuat untuk memotong skor. Karena itu prediksi utama memakai **worst credible verdict**, bukan average verdict.

---

## 2. JUDGE-VARIANCE ENSEMBLE — 5 PERSONA WAJIB

Setelah draft single-best lolos Step 7.7 dan sebelum klaim final, jalankan 5 persona judge berikut.

### A. LITERAL COMPLIANCE JUDGE
Fokus:
- brief word-by-word;
- format, length, mission rules;
- mention/hashtag/media;
- one sentence / one line / no thread;
- banned symbols, raw URL, fourth-wall.

Pertanyaan utama:
> Jika aku ingin memotong CC/CA/TQ secara literal, kalimat mana yang bisa kupakai?

### B. IA SKEPTIC JUDGE
Fokus:
- factual claim;
- implied claim;
- overspecified number;
- unsupported product capability;
- causal claim;
- omission of required facts;
- terminology drift.

Pertanyaan utama:
> Apakah ada klaim eksplisit atau tersirat yang tidak didukung campaign material?

### C. OAA SIMILARITY JUDGE
Fokus:
- struktur mirip pool;
- angle/motif/trope mirip;
- opener pattern;
- CTA pattern;
- mention execution;
- formula yang bisa dinamai.

Pertanyaan utama:
> Apakah ini terasa seperti versi lebih rapi dari submission lain?

### D. EP HARSH JUDGE
Fokus:
- hook effectiveness;
- CTA / embedded micro-CTA;
- conversation path;
- value delivery;
- social/emotional stakes;
- bookmark/share value;
- apakah vocab vonis akan "solid/strong" bukan "exceptional".

Pertanyaan utama:
> Kenapa ini EP4, bukan EP5?

### E. TQ NATIVE-PLATFORM JUDGE
Fokus:
- rhythm;
- readability;
- density;
- punctuation;
- awkward/vocative/appended mention;
- platform-native polish;
- raw URL/media handling;
- line breaks and scanability.

Pertanyaan utama:
> Apakah ini terasa natural di X, atau constructed?

---

## 3. OUTPUT FORMAT WAJIB — JUDGE-VARIANCE MATRIX

```text
═══ JUDGE-VARIANCE HARDENING MATRIX (#0R) ═══

| Persona | Gate at Risk | Exact Criticism Sentence Judge Might Write | Severity Class | Recurrence Key | Fix Decision |
|---|---|---|---|---|---|
| Literal Compliance | [gate] | "..." | deterministic/precedented/plausible/style/hallucinated | [short key] | fix/attempt/ignore |
| IA Skeptic | ... | ... | ... | ... | ... |
| OAA Similarity | ... | ... | ... | ... | ... |
| EP Harsh | ... | ... | ... | ... | ... |
| TQ Native | ... | ... | ... | ... | ... |

Worst credible verdict: [gate scores]
Repeated criticisms: [none / list]
Required fixes: [none / list]
Residual after fixes: [low/medium/high per gate]
DECISION: PASS / FIX / REBUILD
═════════════════════════════════════════════
```

---

## 4. SEVERITY CLASSIFICATION

Setiap kritik dari persona judge WAJIB diklasifikasikan:

| Class | Definisi | Action |
|---|---|---|
| **Deterministic** | jelas melanggar brief/tool/contract | WAJIB FIX |
| **Precedented** | pernah dipotong di pool/skill/vonis asli | WAJIB FIX |
| **Plausible** | masuk akal, belum ada preseden jelas | attempted fix jika tidak merusak lensa lebih tinggi |
| **Style preference** | selera tanpa bukti/preseden | jangan otomatis fix |
| **Hallucinated** | kritik salah baca / bertentangan dengan brief/data | ignore, tapi catat |

**Rule:** deterministic + precedented = blocker. Plausible menjadi blocker jika berulang.

---

## 5. RECURRENCE RULE — BEDAKAN NOISE VS WEAKNESS

Jangan anggap semua variasi juri sebagai dadu.

```text
Muncul 1x → possible noise / monitor.
Muncul 2x → weakness candidate / attempted fix wajib.
Muncul 3x+ → real weakness / wajib fix atau rebuild.
```

Jika kritik yang sama muncul di 2+ persona, itu bukan sekadar non-determinism. Itu deduction surface yang nyata.

---

## 6. WORST-CREDIBLE VERDICT RULE

Prediksi akhir tidak boleh memakai average dari lima judge.

Jika lima persona menghasilkan:
- 4 persona ALL MAX;
- 1 persona memberi EP4 dengan kritik plausible yang valid;

maka prediksi utama adalah:

```text
Worst credible verdict: EP4 risk until fixed.
```

**Kecuali** kritik tersebut diklasifikasikan hallucinated atau pure style preference tanpa preseden dan tanpa recurrence.

---

## 7. REDUNDANT PROOF PER GATE

Agar tahan judge variance, setiap gate penting harus punya lebih dari satu proof surface.

### EP redundant proof
Wajib minimal 3 dari 5:
- hook kuat;
- CTA/micro-CTA jelas;
- conversation fork;
- value insight;
- personal/social stakes;
- reply path di ending.

### OAA redundant proof
Wajib minimal 3 dari 5:
- angle unik;
- struktur unik;
- motif/trope unik;
- execution/voice unik;
- mention placement natural dan tidak template.

### IA redundant proof
Wajib minimal 4 dari 5:
- klaim minimal;
- opinion/personal framing;
- product capability bounded;
- no unsupported implied mechanism;
- no overspecified number;
- no omission of required facts.

### TQ redundant proof
Wajib minimal 4 dari 5:
- readable rhythm;
- clean punctuation;
- natural mention placement;
- platform-native formatting;
- no raw URL;
- no density/readability issue.

---

## 8. DEDUCTION SURFACE MAP

Sebelum final audit, buat peta permukaan deduction:

```text
DEDUCTION SURFACE MAP

EP:
- Possible attack: [quote/issue]
- Defense: [quote from content]
- Residual: low/medium/high

OAA:
- Possible attack: ...
- Defense: ...
- Residual: ...

IA:
...
```

**Rule:** medium/high residual di gate ber-weight tinggi = tidak boleh klaim final. Fix atau rebuild.

---

## 9. PASS THRESHOLD #0R

Konten lolos Judge-Variance Hardening hanya jika:

1. 0 deterministic criticism.
2. 0 precedented criticism unresolved.
3. 0 repeated plausible criticism unresolved.
4. No persona predicts a non-max gate for a valid unresolved reason.
5. Deduction Surface Map residual = low untuk semua gate ber-weight.
6. Worst credible verdict = ALL MAX atau only hallucinated/style-preference objections remain.

Jika gagal:
- issue word-level → fix;
- issue structure/angle/purpose → rebuild, bukan patch;
- issue uncertainty karena missing data → disclose PROJECTED, jangan klaim guarantee.

---

## 10. INTEGRATION POINT

Protocol ini berjalan setelah Step 7.7 dan sebelum final audit / output final:

```text
Step 7.7 Top-1% Gate
→ Step 7.8 Judge-Variance Hardening (#0R)
→ Blind Judge FASE B / scanner validation
→ Final Audit
→ Single final output
```

Jika blind judge eksternal tersedia, gunakan hasil eksternal sebagai salah satu persona tambahan, tetapi tetap jalankan 5 persona internal untuk coverage.

---

## 11. FINAL AUDIT ADDITION

Final audit wajib menambah blok:

```text
JUDGE-VARIANCE HARDENING (#0R):
- Personas run: 5/5
- Worst credible verdict: [scores]
- Deterministic criticisms unresolved: 0
- Precedented criticisms unresolved: 0
- Repeated plausible criticisms unresolved: 0
- Deduction Surface residual: low/medium/high per gate
- Verdict: PASS / FIX / REBUILD
```

---

## ENFORCEMENT SUMMARY

Untuk setiap future `/rally` run:

1. Single blind judge saja tidak cukup.
2. Jalankan 5 persona judge variance.
3. Pakai worst credible verdict.
4. Track recurrence kritik.
5. Fix deterministic, precedented, dan repeated plausible criticism.
6. Buat Deduction Surface Map.
7. Final hanya jika residual low di semua gate ber-weight.
