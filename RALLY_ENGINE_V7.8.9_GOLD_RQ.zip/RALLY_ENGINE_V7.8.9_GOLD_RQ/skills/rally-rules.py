#!/usr/bin/env python3
"""
RALLY-RULES — SATU FILE untuk SEMUA rule-100% gate konten (seri 0I-31L/M/N/O, V7.6.53).
Menggantikan: ep5-rule-final.py, oaa-rule-final.py, tq-rule-final.py,
              ia-ca-rule-final.py, rally-verdict-scanner.py (5 file -> 1).

Basis: 7.400+ vonis nyata / 13 pool. Semua rule = kondisi-CUKUP tanpa pengecualian:
  EP  38/38   (CP95-lb 92.4%) | OAA 192/192 (98.5%) | TQ 246/246 (98.8%)
  CA  256/256 (98.8%)         | IA  185/185 (98.4%)
CC TIDAK di sini -> rally-compliance-gate.py (beda spesies: scan KONTEN vs mission,
bukan scan VONIS vs lexicon; aturan CC berubah per campaign, lexicon di sini stabil).

PAKAI:
  python3 rally-rules.py vonis.json            # semua gate sekaligus; exit 0 = layak submit
  python3 rally-rules.py --gate EP < vonis.txt # satu gate via stdin
  format vonis.json: {"EP": "...", "OAA": "...", "TQ": "...", "IA": "...", "CA": "..."}

⚠️ HUKUM LEXICON (pelajaran regresi 2026-06-13): LEXICON PER-GATE TIDAK BOLEH
DI-SHARE/DINORMALISASI. Percobaan basis-bersama menjaga purity 100% tapi memangkas
recall (OAA 192->184, TQ 246->192) karena kata yang tervalidasi di gate X belum
tentu kritik di gate Y ('rather than' = kritik di EP, PUJIAN di OAA; 'generic' ada
di EP/OAA, tidak pernah divalidasi utk TQ). Setiap lexicon di bawah = SALINAN PERSIS
versi yang menghasilkan angka basis. Edit hanya per-gate + tanggal + sumber vonis.
"""
import re, sys, json

def _sents(t):
    return [s for s in re.split(r'(?<=[.!?。；;])\s*', t) if s.strip()]

def _nc(text, hard, save):
    n = 0
    for s in _sents(text):
        sl = ' ' + s.lower() + ' '
        if any(w in sl for w in hard) and not any(v in sl for v in save):
            n += 1
    return n

# ============================================================================
# SECTION 1 — EP (0I-31L: 38/38, lb 92.4%, OOS 12/12 — LEXICON v6 PERSIS)
# ============================================================================
EP_HARD = ['however', ' but ', 'lacks', 'lacking', 'missing', 'weak', 'could be',
    'would benefit', 'could have', 'might be', 'should ', 'fails to', 'does not ',
    "doesn't ", 'absence of', 'no clear', 'not clear', 'limited', 'unclear',
    'slightly', 'somewhat', 'minor', 'only partially', 'not fully', 'rather than',
    'instead of', 'falls short', 'detract', 'reduces', 'reducing', 'diminish',
    'dilut', 'crowded', 'generic', 'common', 'standard', 'familiar', 'typical',
    'plain', 'functional', 'moderate', 'too long', 'dense', 'cliché', 'cliche',
    'templated', 'similar to', 'overlap', 'less ', 'vague', 'basic ', 'simple ',
    'simplistic', 'superficial', 'modest', 'average', 'adequate', 'decent',
    'though ', ' soft', 'implicit', 'minimal', 'no explicit', 'the only call',
    'only the mention', 'while no', 'while the cta', 'understated', 'subdued',
    '较弱', '不足', '不过', '缺少', '缺乏', '偏弱', '一般', '中等', '中上', '仍然',
    '略受', '略显', '受限', '不算', '没有明确', '没有显式', '没有主动', '较常见',
    '偏常见', '还不算', '可以更', '会更强', '更偏',
    '다소', '부족', '단순', '일반적', '아쉽', '약한', '약하']
EP_SAVE = ['overall still', 'does not significantly detract', 'do not detract',
    'still exceptional', 'does not diminish', 'minor and do not',
    'remains exceptional', 'nonetheless']
EP_SUPER_OPEN = ['exceptional', 'outstanding', 'masterful', 'brilliant', 'superb',
    'perfectly', 'exceptionally', 'masterclass']
EP_SWEEP = ['across all', 'all five', 'all criteria', 'every criteri', 'all dimensions']

def nc_ep(text): return _nc(text, EP_HARD, EP_SAVE)

def _ep_first_sent(text):
    ss = _sents(text)
    return ss[0].lower() if ss else ''

def _exc_adj(s):
    """'exceptional' sebagai ADJECTIVE saja — BUKAN 'exceptionally' (adverb).
    Data v2: opener adjective 82% EP5 vs adverb 45% — 'exceptionally well' = kelas-4!"""
    return bool(re.search(r'exceptional(?!ly)', s))

def ep_rule(text):
    """EP5-PASTI v2 (0I-31P, 2026-06-13): 8 klausa, 58/58 = 100%, CP95-lb 95.0%,
    OOS 18/18 (11 pool termasuk Cancel Something live). Menggantikan v1 38/38.
    Kunci upgrade: (a) adjective-only 'exceptional' (menutup bocor 'exceptionally well'),
    (b) klausa verdict-noun 'exceptional engagement' toleransi nc<=3,
    (c) klausa nc0&curiosity/compelling (vonis bersih + kata-mekanik). """
    tl = text.lower()
    first = _ep_first_sent(text)
    osup = _exc_adj(first) or any(w in first for w in
        ['outstanding', 'masterful', 'brilliant', 'superb', 'perfectly', 'masterclass'])
    hexc = _exc_adj(tl[:150])
    swp = any(p in tl for p in ['across all', 'all five', 'all criteria',
                                'every criteri', 'all dimensions'])
    n = nc_ep(text)
    return (
        (hexc and n <= 1) or                                            # K1 30/30
        ('demonstrates exceptional' in tl and n <= 1) or                # K2 29/29
        ('exceptional engagement' in tl and n <= 3) or                  # K3 27/27
        ('perfectly' in tl and n == 0) or                               # K4 16/16
        (n == 0 and osup) or                                            # K5 13/13
        (hexc and swp) or                                               # K6 15/15
        (n == 0 and ('curiosity' in tl or 'compelling' in tl)) or       # K7 17/17
        ('demonstrates exceptional' in tl and 'fomo' in tl and n <= 2)  # K8 13/13
    )

# ============================================================================
# SECTION 2 — OAA (0I-31M: 192/192, lb 98.5%, OOS 86/86 — LEXICON OAA-v2 PERSIS)
# ============================================================================
OAA_HARD = ['however', ' but ', 'lacks', 'lacking', 'missing', 'weak', 'could be',
    'would benefit', 'might be', 'should ', 'fails to', 'does not introduce',
    'not highly original', 'not notably', 'no clear', 'limited', 'unclear',
    'slightly', 'somewhat', 'minor', 'only partially', 'not fully', 'falls short',
    'detract', 'reduces', 'diminish', 'dilut', 'generic', 'common', 'standard',
    'familiar', 'typical', 'plain', 'moderate', 'derivative', 'mirrors', 'closely',
    'echoes', 'well-worn', 'template', 'formula', 'same as', 'close to',
    'resembles', 'reliance on', 'similar to the', 'shared with', 'seen in similar',
    'crowded field', 'acceptable', 'competent', 'undermined', 'heavy', 'heavily',
    'straightforward', 'conventional', 'expected', 'predictable',
    '较弱', '不足', '不过', '缺少', '缺乏', '一般', '中等', '中上',
    '다소', '부족', '단순', '일반적']
# GUARD kontras-pujian (khas OAA: 'rather than templated' dst = KEMENANGAN, bukan kritik)
OAA_SAVE = ['avoids', 'avoiding', 'unlike', 'in contrast', 'rather than templated',
    'rather than relying', 'rather than using', 'rather than the typical',
    'rather than a generic', 'instead of relying', 'instead of the typical',
    'not present in', 'absent from', 'none of the', 'no other', 'departs from',
    'breaks from', 'diverges from', 'distinct from', 'sets it apart', 'stands out',
    'overall still', 'does not significantly detract', 'do not detract', 'nonetheless']
# OVERRIDE kritik-dalam-pujian: mengalahkan SAVE (3 kasus gagal nc0 semuanya kelas ini)
OAA_OVERRIDE = ['relies on a familiar', 'familiar trope', "familiar '", 'is common',
    'trope appears', 'keeping it from', 'without highly innovative',
    'without surprising', 'though the', 'falls back on', 'still leans on',
    'remains close', 'prevents it from', 'stops short of', 'holds it back',
    'short of exceptional', 'from exceptional']
OAA_HEAD = ['high originality', 'highly original', 'strong originality',
    'exceptional originality']

def nc_oaa(text):
    n = 0
    for s in _sents(text):
        sl = ' ' + s.lower() + ' '
        if any(o in sl for o in OAA_OVERRIDE):
            n += 1
        elif any(v in sl for v in OAA_SAVE):
            continue
        elif any(w in sl for w in OAA_HARD):
            n += 1
    return n

def oaa_rule(text):
    """OAA-2-PASTI: (A) 'demonstrates exceptional' | (B) nc0 | (C) headORIG & nc<=1."""
    tl = text.lower()
    return ('demonstrates exceptional' in tl) or (nc_oaa(text) == 0) \
        or (any(w in tl[:160] for w in OAA_HEAD) and nc_oaa(text) <= 1)

# ============================================================================
# SECTION 3 — TQ (0I-31N: 246/246, lb 98.8%, OOS 109/109 — LEXICON TQ-v2 PERSIS)
# ============================================================================
TQ_HARD = ['however', ' but ', 'lacks', 'lacking', 'missing', 'weak', 'could be',
    'would benefit', 'might be', 'should ', 'fails to', 'issues', 'error', 'typo',
    'awkward', 'clunky', 'run-on', 'somewhat', 'slightly', 'minor', 'though ',
    'there are', 'there is a', 'inconsisten', 'too long', 'dense', 'wall of text',
    'cramped', 'crowded', 'hard to read', 'readability suffers', 'competent',
    'acceptable', 'good', 'solid', 'adequate', 'decent', 'functional', 'appears',
    'detract', 'reduces', 'diminish', 'borderline', 'verbose', 'lengthy',
    'excessive', 'could have', 'not fully', 'unclear', 'confus', 'disrupt',
    'choppy', 'abrupt', 'violation', 'suffer',
    '较弱', '不足', '不过', '缺少', '缺乏', '一般', '中等', '中上', '较高', '基本',
    '尚可', '仍有', '略', '다소', '부족', '단순', '일반적', '무난']
TQ_SAVE = ['no issues', 'without issues', 'without any issues', 'free of errors',
    'error-free', 'no errors', 'no typos', 'without errors', 'no grammatical',
    'flawless', 'overall still', 'nonetheless', 'does not significantly detract',
    'do not detract', 'no awkward', 'avoids']

def nc_tq(text): return _nc(text, TQ_HARD, TQ_SAVE)

def tq_rule(text):
    """TQ-5-PASTI: (A) 'demonstrates excellent' | (B) 'excellent technical' | (C) nc0."""
    tl = text.lower()
    return ('demonstrates excellent' in tl or 'excellent technical' in tl
            or nc_tq(text) == 0)

# ============================================================================
# SECTION 4 — IA & CA (0I-31O: 229/229 & 256/256 — KILL-WORDS PERSIS)
# IA v3 (2026-06-13, live-run Cancel Something): + SAVE-guard deklarasi-bersih
# ('no false or misleading' = vonis BERSIH, bukan kritik; regresi 185->229, lb 98.7%)
# + kill baru 'not contain any factual/no factual information' (story tanpa konten
# verifiable = IA dipotong, ditemukan saat validasi guard).
# ============================================================================
IA_KILL = ['unverified', 'unsubstantiated', 'cannot be verified', "can't be verified",
    'not verifiable', 'no evidence', 'without evidence', 'overstat', 'exaggerat',
    'inaccura', 'incorrect', 'misleading', 'false', 'fabricat', 'unsupported',
    'not supported', 'speculative', 'speculation', 'dubious', 'questionable',
    'hyperbol', 'misrepresent', 'wrong', 'error', 'mistake', 'however',
    'but the claim', 'is not', 'not accurate', 'lacks verification',
    'fails verification', 'omits', 'minor issue', 'acceptable', 'not fully',
    'loose interpretation', 'loosely', 'implies', 'discrepan', 'mismatch',
    'deviat', 'contradic', 'unclear',
    'not contain any factual', 'no factual information']
IA_SAVE = ['no false or misleading', 'does not contain false or misleading',
    'does not present any false or misleading', 'does not present false or misleading',
    'not present false or misleading', 'avoids false or misleading',
    'not contain false or misleading', 'absence of any false or misleading',
    'does not introduce any false or misleading', 'not make any false or misleading',
    'nothing materially false', 'no false', 'no misleading', 'not misleading',
    'without misleading', 'no evident misleading', 'no evidence of misleading',
    'nothing misleading', 'no incorrect', 'no inaccura', 'no errors',
    'free of false', 'free of misleading', 'no factual error',
    'without factual error', 'no wrong']

# CA v3 (2026-06-13, audit pasca-live-run): + SAVE-guard deklarasi-compliance
# ("does not start with a mention" = PUJIAN, bukan kritik; kelas yang sama dgn
# IA v3) + kill baru 'deduction/beyond one/exactly one' (kelas length-quote).
# Regresi: purity 100%, recall 256->299, lb 99.0%, OOS 122/122.
CA_KILL = ['however', 'only partially', 'partially align', 'loosely align',
    'partial align', 'misses', 'fails to', 'does not address', 'not address',
    'omits', 'but it', 'but the', 'lacks', 'not fully', 'falls short',
    'single sentence', 'sentence or short', 'requirement', ' but ', 'while the',
    'missing', 'does not', "doesn't", 'deduction', 'beyond one', 'exactly one']
CA_SAVE = ['does not start with', 'does not begin with', 'does not open with',
    'does not use em', 'does not contain em', 'does not include em',
    'does not violate', 'does not break', 'does not start the post',
    "doesn't start with", "doesn't begin", "doesn't use em", 'does not miss',
    'does not contain any prohibited', 'does not contain prohibited']

def ia_rule(text):
    """IA-2-PASTI: ZERO kill-word v3 (SAVE-guard dihapus dulu). Return (ok, hits)."""
    tl = text.lower()
    for s in IA_SAVE:
        tl = tl.replace(s, ' [CLEAN] ')
    hits = [w for w in IA_KILL if w in tl]
    return len(hits) == 0, hits

def ca_rule(text):
    """CA-2-PASTI v3: (A) 'demonstrates exceptional'/'exceptional alignment with'
    | (B) zero kill setelah SAVE-guard dihapus."""
    tl = text.lower()
    A = 'demonstrates exceptional' in tl or 'exceptional alignment with' in tl
    if A:
        return True, ('klausa-A', [])
    for s in CA_SAVE:
        tl = tl.replace(s, ' [CLEAN] ')
    hits = [w for w in CA_KILL if w in tl]
    return len(hits) == 0, (None, hits)

# ============================================================================
# SECTION 5 — SCANNER CLI
# ============================================================================
def scan(gate, text):
    g = gate.upper()
    if g == 'EP':
        return ep_rule(text), f"nc_ep={nc_ep(text)}"
    if g == 'OAA':
        return oaa_rule(text), f"nc_oaa={nc_oaa(text)} dem-exc={'demonstrates exceptional' in text.lower()}"
    if g == 'TQ':
        return tq_rule(text), f"nc_tq={nc_tq(text)}"
    if g == 'IA':
        ok, hits = ia_rule(text)
        return ok, f"kill={hits or 'NONE'}"
    if g == 'CA':
        ok, (a, hits) = ca_rule(text)
        return ok, f"klausaA={bool(a)} kill={hits or 'NONE'}"
    return None, f"gate tidak dikenal: {gate}"

def main():
    if len(sys.argv) >= 3 and sys.argv[1] == '--gate':
        ok, detail = scan(sys.argv[2], sys.stdin.read())
        print(f"{sys.argv[2].upper()}: {'PASS' if ok else 'FAIL'}  [{detail}]")
        sys.exit(0 if ok else 1)
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(2)
    data = json.load(open(sys.argv[1]))
    print("=" * 72)
    print("SELF-VERDICT LEXICON CHECK — 5 GATE VOCABULARIES — NOT EXTERNAL PROOF")
    print("=" * 72)
    all_ok, results = True, {}
    for gate in ['EP', 'OAA', 'TQ', 'IA', 'CA']:
        if gate not in data:
            print(f"{gate:4} -    (tidak disertakan)")
            continue
        ok, detail = scan(gate, data[gate])
        results[gate] = ok
        all_ok = all_ok and ok
        print(f"{gate:4} {'PASS' if ok else 'FAIL'}  [{detail}]")
    print("-" * 72)
    if all_ok:
        print("SEMUA PASS — simulated verdict avoids known gate kill-language.")
        print("DISCLOSURE: if the verdict was written by the same agent, this is self-validation, NOT evidence of the real judge outcome.")
    else:
        print(f"FAIL di: {', '.join(g for g, ok in results.items() if not ok)} — "
              f"perbaiki objek yang dirujuk kalimat-kritik, scan ulang. JANGAN submit.")
    sys.exit(0 if all_ok else 1)

if __name__ == '__main__':
    main()
