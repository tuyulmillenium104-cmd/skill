# RALLY V7.7 ADDENDUM v1.6 — LOSER-DNA STERILIZATION PROTOCOL

**Date:** 2026-06-24 Asia/Jakarta  
**Status:** ACTIVE  
**Reason:** Post-run `/rally 0x2267D442... mission-0` menunjukkan bahwa konten bisa lolos compliance, scanner, self-judge, dan #0R Judge-Variance Hardening tetapi masih memiliki phrase-surface overlap dengan non-winner corpus. Ini bukan fatal loser DNA, tetapi cukup untuk membuktikan perlu gate eksplisit: **winner-DNA presence tidak otomatis berarti loser-DNA absence.**

---

## 1. NEW META-RULE #0S2: WINNER DNA FIT ≠ LOSER DNA ABSENCE

**Konten belum final hanya karena punya winner DNA.**

Dua hal wajib diuji secara terpisah:

1. **Winner DNA Fit** — apakah konten membawa mekanisme pemenang?
2. **Loser DNA Sterilization** — apakah konten bebas dari motif, struktur, phrase, dan failure pattern non-winner?

Jika hanya #1 yang pass tapi #2 belum diuji programatik, final output belum sah.

---

## 2. FAILURE ROOT CAUSE YANG DITUTUP

Pada run Wingston mission-0, draft awal:

- lolos compliance gate;
- lolos rally-rules.py via self-vonis;
- lolos #0R dari sisi fatal gate risk;
- membawa winner DNA secara struktur;

namun masih punya 5-6 gram overlap non-winner seperti:

```text
before everyone else is reacting
updates before the timeline catches up
whitelist opportunities for future ecosystem projects
ways to earn and use
and more like a creator
```

Sebagian adalah mandatory benefit language, tetapi sebagian merupakan phrasing non-winner yang bisa dihindari. Ini menunjukkan bahwa #0R belum cukup karena #0R menguji judge-variance/failure-surface, bukan exact corpus contamination.

---

## 3. LOSER-DNA STERILIZATION GATE — WAJIB

Jalankan setelah draft final sementara dan SETIAP kali ada revisi konten.

### 3.1 Exact n-gram overlap scan

Bandingkan konten terhadap **non-winner corpus mission-scoped**.

Minimum scan:

```text
4-gram, 5-gram, 6-gram, 7-gram, 8-gram
```

Pass threshold:

```text
8-gram overlap: 0
7-gram overlap: 0
6-gram overlap: 0
5-gram overlap: 0, kecuali mandatory/common phrase whitelist
4-gram overlap: allowed only if mandatory campaign vocabulary or product terminology
```

If 5-gram+ overlap appears and is not mandatory campaign language → rewrite phrase and rerun scan.

### 3.2 Motif overlap scan

Define the content's core motif in 3-7 short phrases, then scan winner + non-winner corpus.

Example:

```text
queue position
creator edge
access vs talent
access credential
advantage layer
```

Pass threshold:

```text
Core motif exact hits in non-winner: 0 preferred.
If >0: prove structural execution differs, or rebuild motif.
```

### 3.3 Structure overlap scan

Compare structure, not only phrase:

- opener type;
- argument progression;
- benefit delivery shape;
- CTA ending type;
- mention placement;
- paragraph rhythm.

If structure matches a common non-winner template, phrase uniqueness is not enough.

### 3.4 Fatal loser-pattern checklist

Check against non-winner failure patterns per gate:

- missing/weak CTA;
- generic VIP hype;
- unsupported earning/profit/guarantee claims;
- missing required benefit set;
- promotional density;
- dense readability;
- tacked-on mention;
- AI-looking phrasing;
- overused access/community tropes;
- incomplete quote/mention/media compliance.

Any fatal loser pattern = blocker.

---

## 4. MANDATORY/COMMON PHRASE WHITELIST

Not all overlap is loser DNA. Some terms are required by campaign materials.

Allowed common phrases include campaign-required terms such as:

```text
token gated
Wingston VIP Community
private campaigns
higher reward campaigns
early updates
whitelist opportunities
RLP benefits
Wingston NFT
@RallyOnChain
```

But even mandatory terms should be recomposed where possible. Example:

```text
whitelist opportunities for future ecosystem projects
```

can become:

```text
whitelist access connected to future ecosystem drops
```

The first may overlap; the second preserves meaning with cleaner surface.

---

## 5. OUTPUT FORMAT WAJIB

Add this block before final audit:

```text
LOSER-DNA STERILIZATION (#0S2):
- Non-winner corpus: [N] mission-scoped submissions
- Exact overlap:
  - 8-gram: [N] hits
  - 7-gram: [N] hits
  - 6-gram: [N] hits
  - 5-gram: [N] hits after whitelist
  - 4-gram: [N] mandatory/common only? yes/no
- Motif hits in non-winner: [N] per motif
- Structure overlap: low/medium/high
- Fatal loser patterns unresolved: [N]
- Decision: PASS / REWRITE / REBUILD
```

---

## 6. PASS THRESHOLD

Content passes only if:

1. 0 unwhitelisted 5-gram+ overlap with non-winner corpus.
2. 0 core motif contamination, or explicitly proven structural divergence.
3. Structure overlap = low.
4. 0 fatal loser patterns unresolved.
5. Re-scan completed after last revision.

If any requirement fails, update the content file and rerun:

```text
compliance-gate.py
rally-rules.py if vonis changed
loser-dna scan
final combined file rebuild
```

---

## 7. INTEGRATION POINT

Official flow becomes:

```text
Step 7.7 Top-1% Gate
→ Step 7.8 Judge-Variance Hardening (#0R)
→ Step 7.9 Loser-DNA Sterilization (#0S2)
→ Blind Judge / scanner validation
→ Final Audit
→ Single final output
```

Important: #0S2 must run **after every revision**, not only once.

---

## ENFORCEMENT SUMMARY

For every future `/rally` run:

1. Winner DNA fit and loser DNA absence are separate gates.
2. Exact n-gram scan vs mission-scoped non-winners is mandatory.
3. 5-gram+ non-mandatory overlap is a blocker.
4. Motif and structure overlap are checked separately.
5. Fatal loser pattern checklist is mandatory.
6. Final file must show loser-DNA sterilization results.
