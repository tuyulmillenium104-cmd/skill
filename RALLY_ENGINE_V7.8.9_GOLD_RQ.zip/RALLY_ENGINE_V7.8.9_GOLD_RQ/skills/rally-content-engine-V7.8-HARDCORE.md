---
name: rally-content-engine
version: V7.8.9 GOLD-RQ + PORTABLE + HARDCORE + DEEP-AUDIT + ANTI-RIGIDITY + EP-MAX
locked: true
lock-date: 2026-06-28
lock-reason: V7.8 = V7.7 + HARDCORE MODE ENFORCEMENT (Zero Unicode, English-Only, Confession-First RQ5, ASCII Sterilization, 280-char limit). 
---

# Rally Content Engine V7.8  -  HARDCORE EDITION (Top-1% Engineering)

## ⚠️⚠️⚠️ THE HARDCORE MANDATE  -  READ FIRST ⚠️⚠️⚠️

This edition is NOT for creative writing; it is for **TECHNICAL CONTENT ENGINEERING**. Every run MUST execute the following Hardcore Pillars without exception:

1. **ENGLISH-ONLY MERITOCRACY:** All content and Q&A MUST be in English. No exceptions for global campaigns.
2. **ZERO UNICODE POLICY:** Em dashes ( - ), En dashes (-), and Smart Quotes (' “ ”) are BANNED. Use only standard ASCII (- ' ").
3. **CONFESSION-FIRST RQ5:** Q&A pairs MUST NOT be interview questions. Every Q-COPY must start with an anecdote or sharp analytical insight to force an Authenticity verdict from the AI jury.
4. **280-CHAR STRICT LIMIT:** Every Q-COPY must be under 280 characters to match platform X organic behavior.
5. **TOOL-BACKED VALIDATION:** No content is final until it passes `rally-rules.py`, `compliance-gate.py`, and `rally-loser-dna-scan.py` with exit code 0.

---

## 🛠️ HARDCORE EXECUTION CONTRACT (10 Steps)

[ ] 0. **PREFLIGHT:** Load 15 rules + 8 checks + Hardcore Mandate.
[ ] 1. **CARTOGRAPHY:** Run `rally-dna-fetcher.py` and map mission-scoped DNA.
[ ] 2. **ANGLE-FIT:** Scoring candidate angles (0I-25).
[ ] 3. **GAP-SCAN:** Find structure gaps in the mission pool (0I-31I).
[ ] 4. **DRAFTING:** EP Zero-Deduction 12-class kill sweep.
[ ] 5. **COMPLIANCE:** `rally-compliance-gate.py` must return EXIT 0.
[ ] 6. **STERILIZATION:** `rally-loser-dna-scan.py` must return EXIT 0 (0 overlaps).
[ ] 7. **RQ-ENGINE:** Generate 20 randomized, Confession-First Q&A blocks (<280 chars).
[ ] 8. **BLIND-JUDGE:** Simulate All-Max (23/23) using isolated prompts.
[ ] 9. **INTEGRITY:** `rally-final-integrity-check.py` to verify ASCII and stale outputs.
[ ] 10. **OUTPUT:** Combined MD file in code blocks.

---

## 📝 HARDCORE Q&A ARCHETYPE (Lesson 0I-34)

❌ **LOOSER DNA (4/5 Trap):** "Does Rally pay for small accounts?" (Generic Question)
✅ **HARDCORE DNA (5/5):** "I wasted three years on other apps for 'exposure' and got zero equity back. Seeing Rally distribute USDC directly for missions is a total perspective shift. I'm finally an owner." (Confession-First)

**Mandate:** Every reply pair must be randomized in the final deliverable to look organic.

---
[Rest of V7.7 content remains active but subordinate to the Hardcore Mandate above]

---

## HARDCORE ADDENDUM - DNA-FIRST TOP-1% ENFORCEMENT

V7.8 HARDCORE now requires top-1% construction, not just tool compliance.

Before writing content:
1. Winner DNA must define the construction mechanism.
2. Loser DNA must define banned motifs and phrasing.
3. The draft must include a memorable frame or quotable sentence.
4. CTA must match winner-DNA tone, not merely CTA-checker formula.
5. Tools are final validators, not creative drivers.

If a line passes tools but feels less sharp than winner DNA, it is invalid.
