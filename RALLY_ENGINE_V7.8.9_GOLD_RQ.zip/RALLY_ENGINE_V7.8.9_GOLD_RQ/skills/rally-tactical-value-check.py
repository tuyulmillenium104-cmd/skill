#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tactical Value Payload checker for Rally EP5 risk.

Real verdict lesson: content can have a strong hook, CTA, structure, and brand bridge
but still receive EP4 if value delivery is "more philosophical than tactical".

This checker enforces a practical reader takeaway: rule/test/method/checklist/action
that can be applied today and is integrated into the story.
"""
import argparse, json, re, sys, time
from pathlib import Path
from rally_common import report_identity

TACTICAL_MARKERS = [
    r"\bmy rule is\b", r"\bthe rule is\b", r"\bnew rule\b", r"\bsimple rule\b",
    r"\bthe test is\b", r"\bmy test is\b", r"\buse this test\b", r"\btry this\b",
    r"\bif .* then\b", r"\bif .* has to\b", r"\bwhen .* then\b",
    r"\bbefore you\b", r"\bask yourself\b", r"\bmeasure\b", r"\btrack\b",
    r"\bcheck\b", r"\bscore\b", r"\bdecide\b", r"\bchoose\b",
    r"\bfirst\b", r"\bsecond\b", r"\bthird\b", r"\bstep\b", r"\bsteps\b",
    r"\bframework\b", r"\bmethod\b", r"\bprocess\b", r"\bchecklist\b",
    r"\bpublic test\b", r"\bproof trail\b", r"\breceipt\b", r"\bevidence\b",
]

PHILOSOPHY_ONLY_MARKERS = [
    r"\bthis taught me\b", r"\bthe lesson is\b", r"\bi realized\b", r"\bi believe\b",
    r"\bwhat matters is\b", r"\bit means\b", r"\bthe point is\b",
]

ACTION_VERBS = [
    "write", "post", "publish", "share", "test", "track", "measure", "compare",
    "ask", "choose", "decide", "name", "list", "cut", "protect", "stop", "start",
    "ship", "score", "show", "build", "draft", "reply"
]

OBJECT_TERMS = [
    "rule", "test", "draft", "post", "thread", "note", "score", "proof", "receipt",
    "checklist", "dashboard", "process", "method", "boundary", "decision", "trade",
    "work", "idea", "story", "public", "private", "evidence", "version"
]

GENERIC_REFLECTION = [
    "reflect", "think about", "mindset", "perspective", "journey", "growth", "authenticity"
]


def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if s.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--mission-type", default="general", choices=["general","explain","predict","argue","persuade","narrative"])
    ap.add_argument("--out-json", required=True)
    ap.add_argument("--out-md", required=True)
    args = ap.parse_args()

    text = Path(args.content).read_text(encoding="utf-8").strip()
    ps=[p.strip() for p in re.split(r"\n\s*\n+",text) if p.strip()]
    # Tactical payload must exist before the final CTA paragraph. CTA verbs such
    # as choose/reply cannot manufacture a tactical PASS.
    body='\n\n'.join(ps[:-1]) if len(ps)>1 else text
    tl = body.lower()
    sents = sentences(body)

    tactical_hits = []
    active_markers=list(TACTICAL_MARKERS)
    actions=list(ACTION_VERBS)
    objects=list(OBJECT_TERMS)
    if args.mission_type=='predict':
        active_markers += [r"\bmy signal\b",r"\bsignal i am watching\b",r"\bwatch for\b",r"\bif this happens\b",r"\bwithin \w+ months\b"]
        actions += ["watch","track","verify"]
        objects += ["signal","trigger","threshold","timeline","prediction"]
    for pat in active_markers:
        if re.search(pat, tl): tactical_hits.append(pat)
    action_hits = [v for v in actions if re.search(r"\b" + re.escape(v) + r"\b", tl)]
    object_hits = [o for o in objects if re.search(r"\b" + re.escape(o) + r"\b", tl)]
    philosophy_hits = [p for p in PHILOSOPHY_ONLY_MARKERS if re.search(p, tl)]
    generic_hits = [g for g in GENERIC_REFLECTION if g in tl]

    # Extract likely payload sentences.
    payload_candidates = []
    for s in sents:
        sl = s.lower()
        if any(re.search(p, sl) for p in active_markers) or (
            any(re.search(r"\b" + re.escape(v) + r"\b", sl) for v in ACTION_VERBS)
            and any(re.search(r"\b" + re.escape(o) + r"\b", sl) for o in OBJECT_TERMS)
        ):
            payload_candidates.append(s)

    # Core pass requirements.
    has_marker = bool(tactical_hits)
    has_action_object = bool(action_hits) and bool(object_hits)
    has_payload_sentence = bool(payload_candidates)
    apply_verbs=["write", "post", "publish", "share", "test", "track", "ask", "choose", "decide", "name", "list", "ship"]
    if args.mission_type=='predict': apply_verbs += ["watch","verify"]
    apply_today = any(v in action_hits for v in apply_verbs)
    not_only_reflection = has_marker or len(action_hits) >= 2
    integrated = len(payload_candidates) >= 1 and len(text) > 250

    score = sum([has_marker, has_action_object, has_payload_sentence, apply_today, not_only_reflection, integrated])
    reasons = []
    if not has_marker: reasons.append("no explicit rule/test/method/process marker")
    if not has_action_object: reasons.append("no clear action+object practical payload")
    if not has_payload_sentence: reasons.append("no identifiable tactical payload sentence")
    if not apply_today: reasons.append("reader cannot clearly apply it today")
    if not not_only_reflection: reasons.append("payload is mostly reflective/philosophical")

    decision = "PASS" if score >= 5 and has_payload_sentence and has_action_object and apply_today else "FAIL"

    result = {
        "tool": "rally-tactical-value-check.py v7.8.5",
        **report_identity(text),
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "missionType":args.mission_type,
        "content": args.content,
        "tacticalMarkers": tactical_hits,
        "actionHits": action_hits,
        "objectHits": object_hits,
        "philosophyOnlyMarkers": philosophy_hits,
        "genericReflectionHits": generic_hits,
        "payloadCandidates": payload_candidates[:8],
        "checks": {
            "hasMarker": has_marker,
            "hasActionObject": has_action_object,
            "hasPayloadSentence": has_payload_sentence,
            "applyToday": apply_today,
            "notOnlyReflection": not_only_reflection,
            "integrated": integrated,
        },
        "score": score,
        "decision": decision,
        "reasons": reasons,
    }

    Path(args.out_json).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    md = []
    md.append("# TACTICAL VALUE PAYLOAD CHECK\n\n")
    md.append(f"Decision: **{decision}**\n\n")
    md.append(f"Score: **{score}/6**\n\n")
    md.append("## Checks\n\n")
    for k, v in result["checks"].items():
        md.append(f"- {k}: {v}\n")
    md.append("\n## Payload candidates\n\n")
    if payload_candidates:
        for s in payload_candidates[:8]: md.append(f"- {s}\n")
    else:
        md.append("- none\n")
    md.append("\n## Reasons\n\n")
    if reasons:
        for r in reasons: md.append(f"- {r}\n")
    else:
        md.append("- clear\n")
    Path(args.out_md).write_text("".join(md), encoding="utf-8")
    print(f"TACTICAL VALUE CHECK: {decision} [score={score}/6]")
    sys.exit(0 if decision == "PASS" else 1)

if __name__ == "__main__":
    main()
