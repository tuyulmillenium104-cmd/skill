# RALLY EXECUTION CORE — ACTIVE OPERATING PROTOCOL

**Version:** Core v1.0, 2026-06-24 Asia/Jakarta  
**Purpose:** Ringkasan eksekusi aktif yang wajib dijalankan setiap `/rally`. File ini adalah operating system. File panjang lain adalah library/reference.

---

## CORE PRINCIPLE

Do not trust vibes. Do not trust one self-judge. Do not trust winner DNA without loser sterilization. Do not trust final files without integrity check.

Final content is valid only if all active gates below are executed and documented.

---

## REQUIRED FLOW

```text
0. Preflight
1. Fetch campaign + mission data
2. Mission-Soul Decode
3. Mission-scoped DNA fetch
4. DNA Confidence Report
5. Adaptive Winner DNA Map
6. Adaptive EP Deduction Map
7. Winner DNA Fit
8. Draft single-best internally
9. Compliance Gate
10. CTA Quality Separation (#0T/#0T+)
11. Judge-Variance Hardening (#0R)
12. Loser-DNA Sterilization (#0S2)
13. Self/Blind Judge + rally-rules.py
14. QnA pack if RQ exists
15. Final Integrity Check
16. Adaptive Ratchet Writeback (#0U)
17. Final output single file
```

---

## GATE 0 — PREFLIGHT

Required:
- skill files exist;
- workspace ready;
- no assumption from previous run;
- mission target clear;
- multi-mission campaign uses mission-scoped DNA;
- self-judge disclosure active.

Stop if required files missing.

---

## GATE 1 — MISSION-SOUL DECODE

Before writing, output:
- mission title;
- brief verbatim core;
- mission type: EXPLAIN / IDENTIFY / PERSUADE / PREDICT / IMAGINE / OTHER;
- correct structure for that mission type;
- what reader should feel/do after reading.

If mission type and structure are unclear, stop and decode again.

---

## GATE 2 — MISSION-SCOPED DNA

Run:

```bash
python3 skills/rally-dna-fetcher.py --address <addr> --mission <mission-id>
```

Never use campaign-level mixed DNA for multi-mission campaigns.

---

## GATE 3 — DNA CONFIDENCE

Run:

```bash
python3 skills/rally-dna-confidence.py --dna rally-data/learn/<folder>/dna.json --out <folder>/dna-confidence.md
```

Use confidence to decide how hard to follow winner DNA:
- HIGH: winner patterns are reliable.
- MEDIUM: use winner + near-winner + loser scan.
- LOW: brief-first, projected judge language, strong sterilization.


---

## GATE 3B — ADAPTIVE WINNER DNA MAP

Run:

```bash
python3 skills/rally-winner-dna-map.py --submissions submissions_enriched.json --out-json winner-dna-map.json --out-md WINNER-DNA-MAP.md
```

Use this as the positive construction guide for the current mission.

---

## GATE 3C — ADAPTIVE EP DEDUCTION MAP

Run:

```bash
python3 skills/rally-ep-deduction-map.py --submissions submissions_enriched.json --content content.txt --out-json ep-deduction-map.json --out-md EP-DEDUCTION-MAP.md
```

Unknown/new classes are treated as real risks until cleared.

---

## GATE 4 — WINNER DNA FIT

Extract:
- opener type;
- core frame;
- benefit delivery style;
- CTA style;
- mention placement;
- paragraph rhythm;
- concrete benefit coverage.

Do not copy winner. Extract mechanism.

---

## GATE 5 — DRAFT SINGLE-BEST

Generate internal drafts only. Output one final candidate.

If foundation/angle wrong, rebuild. Do not patch structure-level failure.

---

## GATE 6 — COMPLIANCE GATE

Run:

```bash
python3 skills/rally-compliance-gate.py content.txt contract.json
```

Exit 1 = do not output.

---

## GATE 7 — CTA QUALITY SEPARATION (#0T)

Do not merge Conversation Potential and CTA Quality.

Required block:

```text
CTA QUALITY SEPARATION (#0T):
- Conversation Potential device: [quote]
- Direct behavioral CTA: [quote / none]
- CTA verb present: [verb / none]
- Campaign format permits explicit CTA: yes/no
- If no explicit CTA, embedded behavioral micro-CTA: [quote / none]
- Generic CTA avoided: yes/no
- EP ceiling risk: EP5 / EP4 risk
```

If a judge could write "lacks a direct, explicit CTA," EP5 prediction is invalid.

---

## GATE 8 — JUDGE-VARIANCE HARDENING (#0R)

Run 5 persona judges:
1. Literal Compliance
2. IA Skeptic
3. OAA Similarity
4. EP Harsh
5. TQ Native-Platform

Use worst credible verdict, not average.

Unresolved deterministic / precedented / repeated plausible criticism = blocker.

---

## GATE 9 — LOSER-DNA STERILIZATION (#0S2)

Run:

```bash
python3 skills/rally-loser-dna-scan.py \
  --content content.txt \
  --submissions submissions_enriched.json \
  --out-json loser-dna-sterilization-report.json \
  --out-md loser-dna-sterilization-report.md \
  --motif "core phrase" --motif "second phrase"
```

Pass threshold:
- 8/7/6-gram = 0 unwhitelisted hits;
- 5-gram = 0 unwhitelisted hits;
- 4-gram reviewed, mandatory/common only;
- fatal loser patterns unresolved = 0.

Rerun after every content revision.

---

## GATE 10 — BLIND/SELF JUDGE + SCANNER

Write honest `vonis.json`. Do not hide real criticism.

Run:

```bash
python3 skills/rally-rules.py vonis.json
```

Disclosure: self-written scanner PASS means only that the simulated verdict avoids known kill-word patterns. It is not proof of actual judge outcome.

---

## GATE 11 — QNA PACK

If RQ matters, create combined content + QnA file with:
- canonical detail block;
- 20 Q-COPY/A-COPY blocks by this workflow;
- Q-first, distinct voices, concrete specifics;
- no generic praise;
- no canonical contradictions.

---

## GATE 12 — FINAL INTEGRITY CHECK

Run:

```bash
python3 skills/rally-final-integrity-check.py \
  --content content.txt \
  --combined CONTENT-PLUS-20QNA-RQ5.md \
  --compliance-output compliance-gate-output.txt \
  --rules-output rally-rules-output.txt \
  --loser-report loser-dna-sterilization-report.json \
  --min-qna 20
```

Exit 1 = final file stale or unsafe.

---

## FINAL OUTPUT REQUIREMENTS

Final answer points to one combined file:

```text
konten/<Campaign-Slug>/<Campaign-Slug>-CONTENT-PLUS-20QNA-RQ5.md
```

Never claim guaranteed outcome. Report:
- process compliance;
- scanner status self-validated;
- #0R status;
- #0S2 status;
- integrity check status;
- residual risks.

---

## ACTIVE ADDENDUM - TOP-1% DNA-FIRST MANDATE

File: `TOP1-DNA-FIRST-MANDATE.md`

This addendum is mandatory for every future `/rally` run.

**New law:** Tool PASS is not enough. Build from mission-scoped Winner DNA first, sterilize Loser DNA before drafting, then validate with tools.

Required before drafting:
- extract winner hook family;
- extract winner trade mechanism;
- extract winner brand bridge style;
- extract winner CTA style;
- map loser phrases/motifs to avoid;
- define one quotable/memorable frame.

Required in final audit:

```text
DNA-FIRST TOP-1% CHECK:
- Winner hook mechanism used:
- Winner trade mechanism used:
- Memorable frame:
- Loser-DNA patterns avoided before drafting:
- Why this is sharper than a safe PASS draft:
```

If content is only compliant but not sharp, rebuild. Do not patch.

### EP5 Tactical Value Payload Patch

Real verdict lesson: a content piece can have strong hook, strong CTA, clean structure, natural brand bridge, and still score EP4 if value delivery is "more philosophical than tactical."

Before final output, add this mandatory block:

```text
TACTICAL VALUE PAYLOAD CHECK:
- Practical rule/test/method included:
- Reader can apply it today:
- Not merely reflective/philosophical:
- Integrated into narrative:
```

No tactical value payload = no EP5 claim.

### Required Tool Addition - Tactical Value Check

After CTA check and before EP semantic review, run:

```bash
python3 skills/rally-tactical-value-check.py --content content.txt --out-json tactical-value.json --out-md TACTICAL-VALUE.md
```

Final integrity should include `--tactical-report tactical-value.json`.

A PASS draft without tactical value is not EP5-safe.

### Required Tool Addition - Winner DNA Build Spec

Before drafting any content, run:

```bash
python3 skills/rally-winner-build-spec.py --submissions submissions_enriched.json --campaign campaign.json --out-json winner-build-spec.json --out-md WINNER-BUILD-SPEC.md
```

This file is the pre-draft blueprint. Drafting is invalid until the agent writes a content plan from it:

```text
WINNER-DNA BUILD PLAN:
- Hook mechanism selected:
- Trade/refusal mechanism selected:
- Value delivery mechanism selected:
- Tactical payload selected:
- Brand bridge style selected:
- CTA style selected:
- Loser-DNA exclusions:
```

If the final draft does not match this plan, rebuild. Do not patch.

### Required Tool Addition - Originality Saturation Check

Before final output, run:

```bash
python3 skills/rally-originality-saturation-check.py --content content.txt --submissions submissions_enriched.json --out-json originality-saturation.json --out-md ORIGINALITY-SATURATION.md
```

Final integrity should include `--originality-report originality-saturation.json`.

A draft with clean n-grams can still fail OAA if the core semantic motif is crowded. If saturated motif + common progression are detected, rebuild the angle.

### Required Tool Addition - EP Compactness / Reply Conversion Check

Run before EP semantic review:

```bash
python3 skills/rally-ep-compactness-check.py --content content.txt --out-json ep-compactness.json --out-md EP-COMPACTNESS.md
```

Final integrity should include `--compactness-report ep-compactness.json`.

A long or literary draft can be EP4 even when hook, CTA, and structure are strong. If content is above the soft compactness target, it must justify length with operational value and an easy reply path.

### Required Tool Addition - RQ Prompt-Answer Compliance Check

Run after combined Q&A file is assembled:

```bash
python3 skills/rally-rq-prompt-answer-check.py --content content.txt --combined combined.md --out-json rq-prompt-answer.json --out-md RQ-PROMPT-ANSWER.md
```

Final integrity should include `--rq-report rq-prompt-answer.json`.

Every Q&A pair must answer the actual CTA, add personal story or decision, and advance the conversation. Relevant validation is not enough for RQ5.

### Required Tool Addition - Worst Positive Verdict Check

Before final integrity, run:

```bash
python3 skills/rally-worst-positive-verdict-check.py \
  --content content.txt \
  --combined combined.md \
  --tactical-report tactical-value.json \
  --originality-report originality-saturation.json \
  --compactness-report ep-compactness.json \
  --rq-report rq-prompt-answer.json \
  --cta-report cta.json \
  --out-json worst-positive-verdict.json \
  --out-md WORST-POSITIVE-VERDICT.md
```

Final integrity should include `--worst-verdict-report worst-positive-verdict.json`.

Purpose: detect positive-but-capping judge language such as:
- strong, but slightly long;
- vivid, but more literary than reply-driving;
- authentic, but motif overlaps;
- relevant replies, but they do not answer the prompt.

If a credible EP4/OAA1/RQ3 sentence remains, fix or rebuild.

### Required Tool Addition - Pre-Draft Risk Contract

After cartography and winner build spec, before writing content, run:

```bash
python3 skills/rally-pre-draft-risk-contract.py \
  --submissions submissions_enriched.json \
  --campaign campaign.json \
  --mission mission-id \
  --winner-build-spec winner-build-spec.json \
  --out-json pre-draft-risk-contract.json \
  --out-md PRE-DRAFT-RISK-CONTRACT.md
```

The agent must convert this into the WINNER-DNA BUILD PLAN. No content may be drafted before this contract exists.

Required contract sections:
- banned / crowded phrases;
- saturated semantic motifs;
- top judge deduction classes;
- required winner mechanisms;
- required CTA answer format;
- likely judge deduction sentences to avoid;
- rebuild triggers.

Rule: fresh campaign data must become a pre-draft blocker, not only a post-draft validator.

### Required Tool Addition - RQ Campaign Mechanics Calibration

For product/protocol campaigns, after RQ prompt-answer check, run:

```bash
python3 skills/rally-rq-mechanics-calibration-check.py \
  --content content.txt \
  --combined combined.md \
  --campaign campaign.json \
  --out-json rq-mechanics.json \
  --out-md RQ-MECHANICS.md
```

Final integrity should include `--rq-mechanics-report rq-mechanics.json`.

Purpose: force all Q-COPY to be Tier-A calibrated: explicit decision + campaign mechanic + personal/skeptical angle.
