# RALLY V7.7 ADDENDUM v2.1 — ADAPTIVE UNKNOWN DISCOVERY PROTOCOL

**Date:** 2026-06-25 Asia/Jakarta  
**Status:** ACTIVE  
**Purpose:** Every campaign and mission can have new judge behavior. Skill must not rely only on static keyword lists. It must discover new deduction language from real verdicts and block final output until unknown classes are cleared.

---

## 1. NEW META-RULE #0V: UNKNOWN DEDUCTION = BLOCKER UNTIL CLEARED

If a mission-scoped verdict contains a deduction-like sentence that cannot be classified into an active class, it becomes:

```text
unknown_new_class
```

Final output is invalid until:

1. the unknown is classified into an existing class, or
2. a new class is created and appended to `ADAPTIVE-RATCHET-LESSONS.md`, or
3. it is explicitly marked non-deduction/praise-only with evidence.

No silent unknowns.

---

## 2. DETECTION MUST BE MULTI-LAYER

The deduction miner must use four layers:

### Layer A — Known markers
Known words like however, lacks, could, slightly, generic, dense, CTA.

### Layer B — Contrast / limitation structure
Detect patterns even if vocabulary is new:

```text
X, but Y
X, while Y
X, though Y
X, yet Y
reads more like X than Y
feels more like X than Y
closes the thought instead of opening replies
```

### Layer C — Middle-praise in nonmax verdicts
In EP4/EP3, words like solid/good/effective/clear/competent/decent can imply not-max when compared to exceptional/compelling/powerful.

### Layer D — Discovery candidates
Extract suspicious phrases such as:

```text
too choreographed
less lived-in
campaign-like
not especially memorable
closes the thought
one-way explanation
over-explains
```

If not classified, block final.

---

## 3. ACTIVE TOOL BEHAVIOR

`rally-ep-deduction-map.py` must output:

```json
{
  "decision": "PASS|REVIEW|FAIL",
  "unknownClassCount": 0,
  "discoveryCandidates": [...],
  "contentRisks": {...}
}
```

Final integrity fails if:

```text
unknownClassCount > 0
```

or:

```text
decision != PASS
```

---

## 4. CAMPAIGN-SPECIFICITY RULE

Never assume a class is universal without checking the mission.

Example:
- polished storytelling may be bad in raw/personal campaigns;
- polished explanation may be good in technical explain campaigns;
- explicit CTA may be necessary in utility campaigns;
- explicit CTA may hurt narrative campaigns.

Therefore every deduction class must be interpreted through:

```text
brief + mission type + gate + judge wording + winner DNA
```

---

## 5. RATCHET RULE

When a new deduction phrase appears repeatedly or causes a real miss, append to:

```text
skills/ADAPTIVE-RATCHET-LESSONS.md
```

Format:

```text
TYPE: DEDUCTION
SOURCE: real verdict / mission pool
EVIDENCE: "..."
ACTIVE RULE: ...
CHECK: ...
ACTION: ...
```

---

## ENFORCEMENT SUMMARY

For every future `/rally`:

1. Mine EP<5 verdicts.
2. Detect known and unknown deduction language.
3. Unknown deduction classes block final output.
4. New real classes become active lessons.
5. Interpret every class through the current mission, not as universal law.
