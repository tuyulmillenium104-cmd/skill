#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Real-judge URL + length preflight, V7.8.5."""
import argparse,sys
from pathlib import Path
from rally_common import find_url_issues,sha256_text

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--genre',default='auto',choices=['auto','tactical','confessional']);ap.add_argument('--official-max',type=int,default=None);ap.add_argument('--engine-review-threshold',type=int,default=1050);args=ap.parse_args()
 text=Path(args.content).read_text(encoding='utf-8').strip();errors=[];warnings=[];u=find_url_issues(text)
 if u['markdownLinks']:errors.append(f"Markdown links are invalid X copy: {u['markdownLinks'][:3]}")
 for x in u['attachedPunctuation']:errors.append(f"URL has attached punctuation: {x['url']!r} + {x['punctuation']!r}")
 n=len(text)
 if args.official_max and n>args.official_max:
  errors.append(f'post is {n} chars (> official max {args.official_max})')
 if args.genre=='tactical':
  if n>args.engine_review_threshold:warnings.append(f'tactical post is {n} chars (> engine high-review threshold {args.engine_review_threshold}; not an official violation)')
  elif n>850:warnings.append(f'tactical post is {n} chars (>850 soft target)')
 elif n>args.engine_review_threshold:warnings.append(f'post is {n} chars (> engine review threshold); verify genre and campaign rules')
 print(f"RALLY PREFLIGHT (URL+LENGTH): {'FAIL' if errors else 'PASS'} [{len(errors)} errors, {len(warnings)} warnings, {n} chars, sha256={sha256_text(text)}]")
 for e in errors:print('  ERROR: '+e)
 for w in warnings:print('  WARN:  '+w)
 sys.exit(1 if errors else 0)
if __name__=='__main__':main()
