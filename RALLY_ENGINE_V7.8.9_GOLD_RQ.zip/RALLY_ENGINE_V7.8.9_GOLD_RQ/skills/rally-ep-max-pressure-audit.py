#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Five-subrubric EP Max Pressure Aggregator (V7.8.7).

Aggregates evidence; it never claims an external score guarantee.
"""
import argparse,json,re,sys,time
from pathlib import Path
from rally_common import report_identity,normalized_text,sha256_file

def load(p):return json.load(open(p,encoding='utf-8')) if p else {}
def paras(t):return [x.strip() for x in re.split(r'\n\s*\n+',t.strip()) if x.strip()]
def sents(t):return [x.strip() for x in re.split(r'(?<=[.!?])\s+|\n+',t) if x.strip()]
def status(fails,reviews):return 'FAIL' if fails else ('REVIEW' if reviews else 'PASS')
def warning_severity(w):
 l=str(w).lower()
 if any(x in l for x in ['malformed','required media','starts with mention','url attached','missing required','error']):return 'deterministic'
 if any(x in l for x in ['dense','too long','over target','late/appended','promotional','generic/template','high semantic','readability']):return 'precedented'
 return 'style'
def hash_check(report,ch,bh=None):
 e=[]
 if report and report.get('contentSha256')!=ch:e.append('content hash stale/missing')
 if report and bh and report.get('combinedSha256')!=bh:e.append('combined hash stale/missing')
 return e
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--content',required=True);ap.add_argument('--combined');ap.add_argument('--submissions');ap.add_argument('--cta-report',required=True);ap.add_argument('--tactical-report',required=True);ap.add_argument('--compactness-report',required=True);ap.add_argument('--naturalness-report',required=True);ap.add_argument('--ep-semantic-report',required=True);ap.add_argument('--originality-report',required=True);ap.add_argument('--oaa-report',required=True);ap.add_argument('--tq-report',required=True);ap.add_argument('--worst-verdict-report',required=True);ap.add_argument('--rq-report');ap.add_argument('--rq-mechanics-report');ap.add_argument('--out-json',required=True);ap.add_argument('--out-md',required=True);args=ap.parse_args()
 text=Path(args.content).read_text(encoding='utf-8').strip();combined=Path(args.combined).read_text(encoding='utf-8') if args.combined else None;ident=report_identity(text,combined);ch=ident['contentSha256'];bh=ident.get('combinedSha256');ps=paras(text);ss=sents(text);hook=ps[0] if ps else ''
 cta=load(args.cta_report);tac=load(args.tactical_report);comp=load(args.compactness_report);nat=load(args.naturalness_report);eps=load(args.ep_semantic_report);ori=load(args.originality_report);oaa=load(args.oaa_report);tq=load(args.tq_report);worst=load(args.worst_verdict_report);rq=load(args.rq_report);rqm=load(args.rq_mechanics_report)
 stale=[]
 for name,r,need_comb in [('cta',cta,False),('tactical',tac,False),('compactness',comp,False),('naturalness',nat,bool(combined)),('ep-semantic',eps,False),('originality',ori,False),('oaa',oaa,False),('tq',tq,False),('worst',worst,bool(combined)),('rq',rq,bool(combined)),('rq-mechanics',rqm,bool(combined))]:
  if r:
   for x in hash_check(r,ch,bh if need_comb else None):stale.append(f'{name}: {x}')
 # 1 Hook
 hf=[];hr=[];generic=['what happens when','nobody is talking','in today\'s','game changer','the future of','did you know']
 if len(hook)<25:hf.append('hook too short to establish tension')
 if any(x in hook.lower() for x in generic):hf.append('generic hook family')
 if len(hook)>180:hr.append('hook may be overloaded')
 exact_hits=0
 if args.submissions:
  subs=json.load(open(args.submissions,encoding='utf-8'));hk=normalized_text(hook)
  for s in subs:
   first=paras(s.get('content') or '')
   if first and normalized_text(first[0])==hk:exact_hits+=1
  if exact_hits:hr.append(f'exact hook already appears {exact_hits} time(s) in pool')
 hook_ev={'quote':hook,'chars':len(hook),'exactPoolHits':exact_hits,'fails':hf,'reviews':hr,'decision':status(hf,hr)}
 # 2 CTA
 cf=[];cr=[]
 if cta.get('decision')!='PASS':cf.append('CTA checker not PASS')
 if cta.get('ctaStrengthRank',9)>2:cr.append(f'CTA rank {cta.get("ctaStrengthRank")} below max-pressure target')
 if not (cta.get('semanticParallelism') or {}).get('pass',True):cf.append('CTA options not semantically parallel')
 if not cta.get('lowFrictionReplyPath'):cf.append('reply path not low friction')
 if cta.get('engagementBaitRisk'):cr.append('explicit engagement-command risk')
 cta_ev={'quote':cta.get('prompt') or cta.get('ctaQuote'),'score':cta.get('ctaFormulaScore'),'rank':cta.get('ctaStrengthRank'),'fails':cf,'reviews':cr,'decision':status(cf,cr)}
 # 3 Structure
 sf=[];sr=[];warning_audit=[]
 if comp.get('decision')!='PASS':sf.append('compactness not PASS')
 if tq.get('decision')!='PASS':sf.append('TQ not PASS')
 for source,items in [('TQ',tq.get('warnings',[])),('OAA',oaa.get('warnings',[]))]:
  for w in items:
   sev=warning_severity(w);warning_audit.append({'source':source,'warning':w,'severity':sev})
   if sev=='deterministic':sf.append(f'{source} deterministic warning: {w}')
   elif sev=='precedented':sr.append(f'{source} precedented warning: {w}')
 if nat.get('decision')=='FAIL':sf.append('naturalness FAIL')
 elif nat.get('decision')=='REVIEW':sr.append('naturalness REVIEW')
 longest=max(map(len,ps),default=0)
 if len(text)>850:sr.append(f'tactical soft target exceeded: {len(text)}')
 if longest>360:sf.append(f'dense paragraph: {longest} chars')
 post_peak=0
 if ps and '?' in ps[-1]:post_peak=0
 else:sr.append('ending lacks a clear final interaction peak')
 structure_ev={'chars':len(text),'paragraphs':len(ps),'sentences':len(ss),'longestParagraph':longest,'postPeakDragParagraphs':post_peak,'fails':sf,'reviews':sr,'decision':status(sf,sr)}
 # 4 Conversation
 vf=[];vr=[]
 if not cta.get('lowFrictionReplyPath'):vf.append('no low-friction CTA path')
 if '?' not in (ps[-1] if ps else ''):vf.append('no final question/open loop')
 if rq:
  if rq.get('decision')!='PASS':vf.append('RQ prompt-answer report not PASS')
 else:vr.append('RQ report not provided')
 if rqm:
  if rqm.get('decision')!='PASS':vf.append('RQ mechanics report not PASS')
  if rqm.get('skepticPct',0)<.25:vr.append('skeptic coverage below 25%')
 else:vr.append('RQ mechanics report not provided')
 conversation_ev={'finalPrompt':ps[-1] if ps else '', 'rqDecision':rq.get('decision') if rq else None,'mechanicsDecision':rqm.get('decision') if rqm else None,'skepticPct':rqm.get('skepticPct') if rqm else None,'fails':vf,'reviews':vr,'decision':status(vf,vr)}
 # 5 Value
 valf=[];valr=[]
 if tac.get('decision')!='PASS':valf.append('tactical value not PASS')
 if tac.get('score',0)<5:valf.append(f'tactical score {tac.get("score")}/6')
 if not tac.get('payloadCandidates'):valf.append('no identifiable reusable payload')
 if eps.get('decision')!='PASS':valf.append('EP semantic report not PASS')
 if eps.get('risks'):valf.extend(eps.get('risks'))
 value_ev={'tacticalScore':tac.get('score'),'payloadCandidates':tac.get('payloadCandidates',[])[:6],'epSemanticRisks':eps.get('risks',[]),'fails':valf,'reviews':valr,'decision':status(valf,valr)}
 sub={'Hook Effectiveness':hook_ev,'CTA Quality':cta_ev,'Content Structure':structure_ev,'Conversation Potential':conversation_ev,'Value Delivery':value_ev}
 fail_sub=[k for k,v in sub.items() if v['decision']=='FAIL'];review_sub=[k for k,v in sub.items() if v['decision']=='REVIEW']
 wf=[];wr=[]
 if worst.get('decision')!='PASS':wf.append('worst-positive-verdict report not PASS')
 if worst.get('credibleDeductions'):wf.append(f'{len(worst.get("credibleDeductions"))} credible capping deductions remain')
 if ori.get('decision')!='PASS':wf.append('originality not PASS')
 if oaa.get('decision')!='PASS':wf.append('OAA not PASS')
 if stale:wf.extend(stale)
 overall='FAIL' if fail_sub or wf else ('REVIEW' if review_sub or wr else 'PASS');ep_dec='EP5_PRESSURE' if overall=='PASS' else 'EP4_RISK'
 result={'tool':'rally-ep-max-pressure-audit.py v7.8.7',**ident,'submissionsSha256':sha256_file(args.submissions) if args.submissions else None,'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'subrubrics':sub,'failedSubrubrics':fail_sub,'reviewSubrubrics':review_sub,'worstPositiveVerdict':{'decision':worst.get('decision'),'credibleDeductions':worst.get('credibleDeductions',[]),'fails':wf,'reviews':wr},'warningAudit':warning_audit,'staleReports':stale,'decision':overall,'epDecision':ep_dec,'externalGuarantee':False}
 Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 md=['# EP MAX PRESSURE AUDIT\n\n',f'Candidate decision: **{overall}**  \nEP status: **{ep_dec}**  \nExternal guarantee: **NO**\n\n']
 for k,v in sub.items():
  md.append(f'## {k}\n\n- Decision: **{v["decision"]}**\n')
  for key,val in v.items():
   if key not in ['decision','fails','reviews']:md.append(f'- {key}: {val}\n')
  md.append('- Fails: '+(str(v['fails']) if v['fails'] else 'none')+'\n- Reviews: '+(str(v['reviews']) if v['reviews'] else 'none')+'\n\n')
 md.append('## Worst Positive Verdict\n\n- Fails: '+(str(wf) if wf else 'none')+'\n- Reviews: '+(str(wr) if wr else 'none')+'\n')
 Path(args.out_md).write_text(''.join(md),encoding='utf-8');print(f'EP MAX PRESSURE: {overall} [{ep_dec}, fail={fail_sub}, review={review_sub}]');sys.exit(0 if overall=='PASS' else 1)
if __name__=='__main__':main()
