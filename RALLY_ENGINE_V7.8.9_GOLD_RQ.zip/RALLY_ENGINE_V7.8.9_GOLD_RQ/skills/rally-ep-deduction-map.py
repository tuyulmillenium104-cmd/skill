#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Adaptive EP deduction class mapper.

Mines real Rally EP<5 verdicts for deduction sentences using multiple layers:
known markers, contrast patterns, middle-praise in nonmax verdicts, and discovery
candidate extraction. Unknown classes block final integrity until classified.
"""
import argparse, json, re, sys, time
from pathlib import Path
from rally_common import report_identity, sha256_file

KNOWN_MARKERS = [
    "however", "but ", "one limitation", "limitation", "lacks", "lack of", "missing",
    "could", "would benefit", "slightly", "somewhat", "not fully", "limited", "reduces",
    "dampen", "dampens", "promotional", "generic", "polished", "formulaic", "dense", "media",
    "direct", "call-to-action", "cta", "question", "conversation", "value delivery", "solid",
    "weakness", "falls short", "underdeveloped", "not controversial", "boldness", "originality",
    "competent", "compelling", "compressed", "reflective", "evidence-driven", "formatting",
    "breaks", "prompt", "challenge", "invitation", "readability", "completion", "shareability"
]

CONTRAST_PATTERNS = [
    r"\bhowever\b", r"\bbut\b", r"\bthough\b", r"\balthough\b", r"\bwhile\b", r"\byet\b",
    r"\brather than\b", r"\binstead of\b", r"\bmore like\b", r"\bfeels like\b", r"\breads like\b",
    r"\bnot enough\b", r"\bdoes not quite\b", r"\bstops short\b", r"\bfalls short\b",
    r"\bcloses the thought\b", r"\bone-way\b", r"\bminor\b", r"\blimitation\b"
]

MIDDLE_PRAISE = [
    "solid", "good", "clear", "effective", "competent", "decent", "reasonable", "works", "functional", "adequate"
]

PRAISE_ONLY = [
    "excels at", "perfectly aligns", "tone is direct", "effectively leans", "strongly aligns",
    "demonstrates strong", "successfully adheres", "excellent", "exceptional", "highly effective",
    "strong hook", "powerful", "compelling", "easy to follow", "advances the argument",
    "concise and digestible", "follows the mission", "mission requirements well", "strong fit",
    "clear verdict compliance", "well-reasoned defense", "delivers a strong", "aligning perfectly",
    "adherence to", "good technical compliance", "defends it with", "clear argument",
    "well-reasoned argument", "focused", "provocative and polarizing", "effectively leveraging", "coherent critique", "clear perspective", "effectively aligns", "aligns well", "concise", "verdict-first", "reasoned defense", "clear viewpoint", "simple framework", "intellectual weight", "bold claim", "fits the campaign", "clearly states", "defending the position", "body develops", "meaningful contribution", "effectively follows", "labeling traditional", "thread presents", "aligning well with"
]

CLASSES = {
    "cta_weak": ["cta", "call-to-action", "direct question", "direct prompt", "explicit", "invite", "reply", "asking followers", "what do you think", "no question", "prompt", "challenge", "invitation", "lack of a call", "lack of call", "ending closes", "one-way"],
    "authenticity_polish_tax": ["polished", "overly polished", "authenticity", "raw", "crafted", "storytelling", "choreographed", "over-rehearsed", "too neat", "too composed", "less lived", "scripted", "performative", "manufactured"],
    "brand_bridge_promotional": ["promotional", "brand", "mention", "forced", "trust", "campaign relevance", "sponsored", "campaign-like", "plug", "product mention", "arrives late", "does not emerge"],
    "media_integration": ["media", "image", "url", "link", "photo", "contextualized", "raw", "attachment"],
    "structure_density": ["dense", "length", "longform", "readability", "scannable", "structure", "formatting", "breaks", "compressed", "flow", "single post", "somewhat long", "sprawling", "meanders", "over-explains", "mini-essay", "manifesto", "build toward", "final two lines", "works reasonably"],
    "generic_or_formulaic": ["generic", "formulaic", "common", "standard", "familiar", "templated", "competent", "not compelling", "lacks boldness", "originality", "not controversial", "not controversial enough", "expected", "predictable", "consensus wisdom", "heavily ai-generated", "ai-generated", "less bold", "not bold"],
    "value_not_exceptional": ["value delivery", "solid", "not exceptional", "bookmark", "save", "underdeveloped", "falls short", "evidence-driven", "reflective", "shareability", "surface-level", "not transformative", "familiar insight", "expected takeaway", "not especially memorable"],
    "hook_weak": ["hook", "opening", "curiosity", "stop", "first line", "opener"],
    "conversation_limited": ["conversation", "replies", "debate", "discussion", "engagement", "spark", "disagreement", "agreement", "argue", "counterarguments", "weigh in", "reply path"],
    "specificity_missing": ["specific", "concrete", "detail", "personal", "example", "vague", "abstract"],
    "external_reach_noncontent": ["absence of hashtags", "hashtags", "community tags", "posting hour", "initial momentum", "metrics", "likes", "impressions"]
}

CONTENT_TRIGGERS = {
    "authenticity_polish_tax": [r"\bthe real lesson\b", r"\bthat changed how i think\b", r"\bfounder mode is not\b", r"\bthis taught me\b", r"\bthe point is\b", r"\bit was never about\b", r"\bwhat i learned\b"],
    "brand_bridge_promotional": [r"\bthat is why @", r"\bthis is exactly why @", r"\b@\w+ solves\b", r"\bmakes sense to me\b", r"\bthis is where @"],
    "media_integration": [r"https?://\S+\.(png|jpg|jpeg|gif|webp)", r"pic\.twitter\.com/"],
    "cta_weak": [r"thoughts\?", r"what do you think\?", r"agree\?"],
    "generic_or_formulaic": [r"game changer", r"in today's landscape", r"let that sink in", r"food for thought"],
}

def split_sents(t):
    # Also split on newlines because Rally verdicts often use semistructured paragraphs.
    raw = re.split(r"(?<=[.!?。；;])\s+|\n+", t or "")
    return [s.strip() for s in raw if s and s.strip()]

def has_contrast(sl):
    return any(re.search(p, sl) for p in CONTRAST_PATTERNS)

def is_praise_only(sl):
    if not any(p in sl for p in PRAISE_ONLY):
        return False
    neg_words = ["however", "but", "though", "while", "yet", "weakness", "lacks", "could", "would", "slightly", "limited", "absence", "minor", "weak"]
    if any(re.search(r"\b" + re.escape(n) + r"\b", sl) for n in neg_words):
        return False
    if "not " in sl or "less " in sl:
        return False
    return True

def is_candidate(sl, ep):
    """Select actual limitation sentences, not praise from a non-max verdict.

    V7.8.4 treated any middle-praise word (clear/solid/effective) inside an EP4
    verdict as a deduction and produced hundreds of false unknown classes.
    """
    if is_praise_only(sl):
        return False
    if has_contrast(sl):
        return True
    negative_markers=["lacks","lack of","missing","weakness","falls short","could be","could have","would benefit","slightly","somewhat","not fully","limited","reduces","dampen","too long","dense","generic","promotional","no direct","absence","underdeveloped","less ","minor deduction","may reduce","may limit"]
    if any(m in sl for m in negative_markers):
        return True
    if re.search(r"\b(feels|reads|lands|comes across)\b.*\b(more|less|like|as)\b", sl):
        return True
    return False

def classify(sent):
    sl=sent.lower()
    hits=[]
    for cls, words in CLASSES.items():
        if any(w in sl for w in words):
            hits.append(cls)
    return hits or ["unknown_new_class"]

def discovery_phrases(sent):
    sl=sent.lower()
    phrases=[]
    patterns=[r"(?:feels|reads|lands|comes across) [^.]{0,80}", r"more like [^.]{0,80}", r"less [a-z -]{3,60}", r"not especially [a-z -]{3,60}", r"closes [^.]{0,80}"]
    for p in patterns:
        phrases += re.findall(p, sl)
    return phrases[:5]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--submissions", required=True)
    ap.add_argument("--content", default=None)
    ap.add_argument("--out-json", required=True)
    ap.add_argument("--out-md", required=True)
    args=ap.parse_args()
    subs=json.load(open(args.submissions, encoding="utf-8"))
    deductions=[]; ep_nonmax=0; discovery=[]
    for s in subs:
        ep=(s.get("gates") or {}).get("EP", [None])[0]
        if ep is None or ep>=5: continue
        ep_nonmax+=1
        eptext=" ".join(a.get("analysis","") for a in (s.get("analysis") or []) if "Engagement Potential" in (a.get("category") or ""))
        for sent in split_sents(eptext):
            sl=sent.lower()
            if is_candidate(sl, ep):
                classes=classify(sent)
                item={"author":s.get("xUsername"),"ep":ep,"sentence":sent,"classes":classes,"discoveryPhrases":discovery_phrases(sent)}
                deductions.append(item)
                if item["discoveryPhrases"]: discovery.append(item)
    class_counts={}
    for d in deductions:
        for c in d["classes"]: class_counts[c]=class_counts.get(c,0)+1
    content_risks={}
    if args.content:
        content=Path(args.content).read_text(encoding="utf-8").lower()
        for cls,pats in CONTENT_TRIGGERS.items():
            found=[]
            for pat in pats:
                if re.search(pat, content): found.append(pat)
            content_risks[cls]=found
    unknown_list=[d for d in deductions if "unknown_new_class" in d["classes"]]
    active_risks={k:v for k,v in content_risks.items() if v}
    corpus_decision="REVIEW" if unknown_list else "PASS"
    # Corpus discovery noise is not automatically a candidate defect. Candidate
    # decision is based on actual content trigger applicability.
    decision=("FAIL" if active_risks else "PASS") if args.content else corpus_decision
    ident=report_identity(Path(args.content).read_text(encoding='utf-8').strip()) if args.content else {}
    result={"tool":"rally-ep-deduction-map.py v7.8.5",**ident,"submissionsSha256":sha256_file(args.submissions),"generated":time.strftime("%Y-%m-%d %H:%M:%S"),"epNonMaxCount":ep_nonmax,"deductionSentenceCount":len(deductions),"classCounts":class_counts,"deductions":deductions,"contentRisks":content_risks,"activeContentRisks":active_risks,"unknownClasses":unknown_list,"unknownCorpusClassCount":len(unknown_list),"candidateUnknownRiskCount":0,"unknownClassCount":0 if args.content and not active_risks else len(unknown_list),"discoveryCandidates":discovery,"corpusDecision":corpus_decision,"decision":decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    md=[]
    md.append("# EP DEDUCTION CLASS MAP\n\n")
    md.append(f"EP<5 verdicts mined: **{ep_nonmax}**\n\n")
    md.append(f"Deduction sentences extracted: **{len(deductions)}**\n\n")
    md.append(f"Decision: **{decision}**\n\n")
    md.append(f"Unknown class count: **{len(unknown_list)}**\n\n")
    md.append("## Class Counts\n\n| Class | Count |\n|---|---:|\n")
    for k,v in sorted(class_counts.items(), key=lambda x:x[1], reverse=True): md.append(f"| {k} | {v} |\n")
    md.append("\n## Content Risks\n\n")
    if content_risks:
        for k,v in content_risks.items(): md.append(f"- {k}: {'RISK ' + str(v) if v else 'clear'}\n")
    else: md.append("No content file provided.\n")
    md.append("\n## Unknown Classes\n\n")
    if unknown_list:
        for d in unknown_list[:50]: md.append(f"- EP{d['ep']} @{d['author']}: {d['sentence']}\n")
    else: md.append("- none\n")
    md.append("\n## Evidence Samples\n\n")
    for d in deductions[:120]: md.append(f"- EP{d['ep']} @{d['author']} [{', '.join(d['classes'])}]: {d['sentence']}\n")
    Path(args.out_md).write_text("".join(md),encoding="utf-8")
    print(f"EP DEDUCTION MAP: {decision} [{len(deductions)} sentences, {len(class_counts)} classes, unknown={len(unknown_list)}]")
    sys.exit(0 if decision=="PASS" else 1)
if __name__=="__main__": main()
