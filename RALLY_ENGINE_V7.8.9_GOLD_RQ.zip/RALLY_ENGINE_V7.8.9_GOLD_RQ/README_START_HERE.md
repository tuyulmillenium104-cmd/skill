# START HERE - RALLY ENGINE V7.8.9 GOLD RQ

Single entry point for any new chat or AI agent.

## Mandatory read order

1. `SKILL.md`
2. `PATCH_V7.8.9_GOLD_RQ.md`
3. `GOLD_RQ_STANDARD_CALIBRATED.md`
4. `PATCH_V7.8.8_PORTABLE.md`
5. `PATCH_V7.8.7_EP_MAX.md`
6. `PATCH_V7.8.6_ANTI_RIGIDITY.md`
7. `ANTI_RIGIDITY_PROTOCOL.md`
8. `skills/ACTIVE-PRECEDENCE.md`
9. `HOW_TO_RUN_COMMANDS.md`
10. `skills/RALLY-EXECUTION-CORE.md`

## Verify first

```bash
python3 skills/rally-handoff-self-check.py --root .
```

Do not run a campaign if this fails.

## Trigger

```text
/rally <campaign-address> misi <number>
```

## Required execution

1. Full API pagination and `SNAPSHOT-MANIFEST.json`.
2. Requirement provenance, mission contract, and relation/media plan.
3. Mission-soul decode from the literal mission verb.
4. Mission-scoped Winner/Loser/Judge DNA and conditional winner lanes.
5. Temporal top-1% champion map.
6. Winner Build Spec with hard/soft/flex separation.
7. Pre-Draft Risk Contract and Build Plan.
8. Natural drafting without copying winner surface.
9. Deterministic, semantic, originality, tactical, compactness, and naturalness gates.
10. Build 20-pair mission-calibrated Gold response library.
11. Gold pair audit: Q/A/Feel >=4, correct type distribution, controlled closing variation.
12. RQ prompt, mechanics, decision, skeptic, and open-loop coverage checks.
13. Worst Positive Verdict.
14. EP Max Pressure Audit.
15. Hash-backed final integrity requiring provenance, relation, snapshot, EP Max, and Gold Q&A reports.
16. One combined Markdown deliverable plus honest residual-risk disclosure.

## Gold deployment law

The twenty Q&A pairs are a response library. Select the pair matching a real incoming reply. `SIMULATED_ARCHETYPE` Real Experience Qs are internal examples and must not be seeded as fake organic testimony.

## Honesty

Never guarantee external all-max, RQ5, or leaderboard victory. Use `EP5_PRESSURE`, `Gold RQ5-pressure`, and `top-1%-caliber` with external-risk disclosure.
