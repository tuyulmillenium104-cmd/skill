# Q&A GOLD STANDARD AUDIT

Decision: **PASS**

- Distribution: {'Specific Probe': 4, 'Challenge': 5, 'Technical Deep-Dive': 5, 'Hot Take': 4, 'Real Experience': 2}
- Question endings: 12/20 (60%)

## Pair Scores

|R|Type|Q|A|Feel|A words|Close|
|---:|---|---:|---:|---:|---:|---|
|1|Specific Probe|5|4|5|29|?|
|2|Challenge|5|5|5|32|?|
|3|Challenge|5|4|5|24|statement|
|4|Technical Deep-Dive|5|4|5|27|?|
|5|Technical Deep-Dive|5|5|5|33|?|
|6|Challenge|5|5|5|34|?|
|7|Hot Take|5|4|5|26|statement|
|8|Challenge|5|5|5|37|?|
|9|Specific Probe|5|5|5|31|?|
|10|Specific Probe|4|4|5|24|statement|
|11|Technical Deep-Dive|5|4|5|29|?|
|12|Technical Deep-Dive|4|4|5|28|statement|
|13|Challenge|5|4|5|29|?|
|14|Technical Deep-Dive|5|4|5|29|?|
|15|Real Experience|5|4|5|28|statement|
|16|Real Experience|5|4|5|28|?|
|17|Hot Take|5|4|5|26|statement|
|18|Specific Probe|5|5|5|32|?|
|19|Hot Take|5|4|5|29|statement|
|20|Hot Take|5|4|5|27|statement|

## Fails
- none

## Reviews
- none
