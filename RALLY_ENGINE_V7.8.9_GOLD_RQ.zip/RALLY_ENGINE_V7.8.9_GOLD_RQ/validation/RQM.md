# RQ CAMPAIGN-DERIVED MECHANICS CHECK

Decision: **PASS**

- Protocol: True
- Active categories: ['adjudication', 'intelligent_contract', 'independent_review', 'appeal_accountability', 'semantic_consensus', 'protocol_utility', 'access_mechanics', 'mint_details', 'product_model', 'real_domain_application']
- Mechanics: 20/20 (100%)
- Decision coverage: 20/20 (100%)
- Skeptic: 12/20 (60%)
- Max non-mechanic streak: 0
- Coverage: 8/10

## Reasons
- clear
