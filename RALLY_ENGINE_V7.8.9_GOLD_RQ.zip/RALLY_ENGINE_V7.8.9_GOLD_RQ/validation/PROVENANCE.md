# REQUIREMENT PROVENANCE

Campaign: **The Adjudication Layer**  
Mission: **mission-0 - What is GenLayer?**

- Official max chars: None
- Official one sentence: False
- Required relation: {'required': False, 'allowedTypes': [], 'sourceUrls': []}
- Required media: False

## MISSION_HARD
- Explain what GenLayer is in your own, original words.
- You must mention @GenLayer in your post.
- Your explanation must be accurate based on the knowledge base.
- Original content in any language.
- Em dashes (—) are not allowed.
- Highly generic or AI-generated-looking content is not allowed.
- Do not start the post with a mention or hashtag.

## CAMPAIGN_HARD
- none

## MISSION_CORE
- Explain what GenLayer is in simple words. Describe it as the adjudication layer for the agentic economy: AI agents are about to move trillions in transactions, every one of those transactions can end in a disagreement, and GenLayer is the layer that resolves them. Make it easy for anyone to understand why this needs to exist.

## CAMPAIGN_GOAL
- This campaign has three goals: explain GenLayer in simple terms, amplify the Why & How thread launch, and drive people to pick their role in the GenLayer Portal.
- First, help your audience understand what an adjudication layer for the agentic economy is and why it needs to exist. Then add your voice to the launch by quoting or replying to the main thread. Finally, point people to the Portal so they can join as Community members, Builders, or Validators and start earning GenLayer Points.

## OPTIONAL_ANGLE
- Start from the problem: trillions moved by agents, zero infrastructure for when they disagree. What happens to the first big agent-to-agent dispute?
- Use an analogy: why does asking many independent AIs beat trusting one? Think second opinions, juries, or peer review.
- Contrast Intelligent Contracts with traditional smart contracts: rigid yes-or-no logic versus contracts that read, reason, and judge what is fair.

## ENGINE_SOFT_TARGET
- Tactical length target 600-850 chars; not an official campaign maximum.

## WINNER_DNA_SIGNAL
- Winner length, opener, Portal, voice, and paragraph prevalence are conditional evidence, not hard law.

## JUDGE_RISK_PRIOR
- Real-verdict deductions inform review pressure but do not override the literal mission.

