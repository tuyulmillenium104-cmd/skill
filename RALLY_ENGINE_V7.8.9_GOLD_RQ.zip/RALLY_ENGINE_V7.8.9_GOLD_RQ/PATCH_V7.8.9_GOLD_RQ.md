# V7.8.9 GOLD RQ PATCH

Built on V7.8.8 Portable.

## Added

- Calibrated five-type Gold Q&A audit.
- Mission-adaptive distribution: Specific 4, Challenge 5, Technical 5, Hot Take 4, Real Experience 2 for PREDICT.
- Real Experience `SIMULATED_ARCHETYPE` labeling.
- Per-pair Q Quality, A Insight, and Conversational Feel scoring; minimum 4/5.
- Practical A target 30-45 words while preserving hard <=280-character limit.
- Opening and closing variation.
- Open-loop coverage target 60% instead of every A ending with a question.
- Gold report hash required by final integrity.

## RQ truth

Gold PASS raises RQ5 pressure but does not guarantee RQ5. Real replies, posting account, response speed, and external judge behavior remain outside the generator.
