Fetched campaign data goes here. Run rally-dna-fetcher.py to populate.
