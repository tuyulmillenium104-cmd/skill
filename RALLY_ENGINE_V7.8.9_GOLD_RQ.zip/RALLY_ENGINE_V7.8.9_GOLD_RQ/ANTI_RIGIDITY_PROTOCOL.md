# ANTI-RIGIDITY PROTOCOL - V7.8.6

## Core law

```text
Brief defines purpose.
Winner DNA supplies mechanisms.
Writer owns voice.
Tools remove risk.
```

## Hard constraints

Only these are automatic blockers:

- literal campaign rules;
- factual/KB boundaries;
- malformed URL/platform failures;
- stale hashes or desynced files;
- exact copied surface without clearance;
- severe duplicated/template Q&A;
- unsupported guarantees or absolutes.

## Soft signals

These are evidence, not laws:

- winner median length;
- dominant opener family;
- Portal prevalence;
- personal voice prevalence;
- exact mechanism labels;
- paragraph count;
- explicit versus implicit CTA style.

Do not stack every positive signal into one post.

## Creative flex zones

The writer may vary:

- analogy/scenario domain;
- sentence rhythm;
- degree of humor;
- personal versus analytical register;
- CTA wording;
- which nonessential mechanism to omit for clarity;
- paragraph cadence.

## Q&A controlled variation

For a 20-pair pack:

- mechanics coverage target >=70%;
- decision coverage target >=75%;
- skeptic coverage target >=25%;
- up to 30% may prioritize humor, emotion, lived context, or natural voice;
- no more than two consecutive non-mechanic pairs;
- exact duplicate Q/A is a hard FAIL;
- opener concentration is REVIEW, not automatic rewrite.

## Naturalness audit behavior

`rally-naturalness-variance-check.py` returns:

- PASS: no meaningful template concentration;
- REVIEW: minor formula/opener concentration requiring human judgment;
- FAIL: exact duplication or severe lack of voice variation.

Final integrity accepts REVIEW with explicit disclosure and blocks FAIL.

## Editing rule

Never replace a clear natural sentence with awkward synonyms merely to reduce a heuristic score. Use exact, boundary-safe clearance for mandatory or uniquely correct phrasing.
