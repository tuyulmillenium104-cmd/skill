# START HERE - Rally Engine Handoff

> V7.8.8 PORTABLE: begin with `README_START_HERE.md` and `SKILL.md`. Official-limit extraction, relation compliance, strict snapshot lock, EP warning severity, EP Max, and hash-backed final integrity are active.

This ZIP is a portable Rally content engine handoff. If another chat/agent receives this bundle, read this file first.

## What this package is

A patched Rally Content Engine designed to produce top-1% / all-max-pressure Rally submissions using:

1. Mission-scoped Winner DNA.
2. Mission-scoped Loser DNA.
3. Winner-DNA Build Spec.
4. Pre-Draft Risk Contract.
5. Winner-DNA Build Plan before drafting.
6. Tactical Value Payload Check.
7. Originality Saturation Check.
8. EP Compactness / Reply Conversion Check.
9. RQ Prompt-Answer Compliance Check.
10. Worst Positive Verdict Check.
11. Judge-Variance Hardening.
12. Final Integrity Check.

## Absolute operating law

```text
Winner DNA is the blueprint.
Loser/Judge DNA is the blocker map.
Fresh data must become a pre-draft contract.
Tools are validators, not creative drivers.
```

Do not write content before creating:

```text
WINNER-BUILD-SPEC.md
PRE-DRAFT-RISK-CONTRACT.md
WINNER-DNA BUILD PLAN
```

## The reason this handoff exists

Real verdicts showed that content can be strong and still miss all-max because:

- EP4: more philosophical than tactical.
- OAA1: wording clean but core motif crowded.
- EP4: long/literary content makes users admire rather than reply.
- RQ3: replies validate the post but do not answer the actual CTA.
- Process miss: fresh Winner/Loser/Judge data was sometimes used as reference, not as hard pre-draft constraints.

## Correct order for every /rally run

```text
1. Fetch mission-scoped campaign/submissions/DNA.
2. Generate Winner Build Spec.
3. Generate Pre-Draft Risk Contract.
4. Write Winner-DNA Build Plan from the contract.
5. Draft from the plan, not from vibes.
6. Check tactical value payload.
7. Check originality saturation.
8. Check EP compactness/reply conversion.
9. Check CTA quality.
10. Run loser-DNA scan.
11. Run TQ/OAA/IA audits.
12. Run EP semantic review.
13. Assemble Q&A pack.
14. Run RQ prompt-answer compliance.
15. Run worst positive verdict check.
16. Run judge-variance hardening.
17. Run final integrity.
18. Save output under konten/<Campaign>/<mission-id_MissionName>/.
```

## Most important final rule

```text
Do not submit strong content. Submit hard-to-deduct content.
```

Before final, ask:

```text
What is the nicest EP4/OAA1/RQ3 sentence a judge could write?
```

If that sentence is credible, fix or rebuild.
