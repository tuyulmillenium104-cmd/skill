# V7.8.8 PORTABLE HANDOFF PATCH

Built on V7.8.7 EP Max.

## Fixed

1. Official maximum characters are extracted from literal rules.
2. Mission contract is generated from provenance; engine soft target is not campaign law.
3. Missing corpus hashes fail under snapshot lock.
4. Quote/reply/media requirements are validated through a submission plan.
5. EP Max promotes deterministic and precedented TQ/OAA warnings.
6. `Inside it` antecedent was replaced by explicit `On that layer` in the validated deliverable.
7. Portable root entrypoints added: `README_START_HERE.md`, `SKILL.md`, and `AGENT_HANDOFF_PROMPT.md`.

## Portable contract

Any receiving agent must be able to identify the read order, run order, required artifacts, hard/soft distinction, and honesty boundary without access to the conversation that created this ZIP.
