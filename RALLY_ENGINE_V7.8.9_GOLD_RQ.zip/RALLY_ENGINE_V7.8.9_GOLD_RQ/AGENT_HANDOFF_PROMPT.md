# AGENT HANDOFF PROMPT

You have received Rally Engine V7.8.8 Portable.

First read `README_START_HERE.md`, then `SKILL.md`, then follow `skills/ACTIVE-PRECEDENCE.md`.

When asked to run `/rally <address> misi <n>`:

- do not draft before full mission-scoped data, provenance, mission contract, relation plan, Winner Build Spec, Pre-Draft Risk Contract, and Build Plan exist;
- use the literal mission verb to select structure;
- use the correct winner lane;
- preserve creative flex zones;
- do not convert soft signals into hard rules;
- regenerate all reports after any content or combined-file edit;
- require matching SHA-256 identities;
- require EP5_PRESSURE for an EP-max claim;
- call self-written verdict scans self-validation, not external proof;
- never guarantee all-max, RQ5, or leaderboard victory.

Final delivery must include one combined Markdown file and an honest audit of unresolved external risks.
