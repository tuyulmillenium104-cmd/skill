# V7.8.7 EP MAX PATCH

Built on V7.8.6 anti-rigidity.

## Added

- Five-subrubric `rally-ep-max-pressure-audit.py`.
- Hook, CTA, Structure, Conversation, and Value evidence matrix.
- Worst-positive-verdict integration.
- Report hash consistency checks.
- Requirement provenance artifact.
- Snapshot manifest and corpus hash lock.
- Official hard limit separated from engine soft target.
- Final integrity requires EP5_PRESSURE when EP Max report is supplied.

## Decision semantics

- `PASS / EP5_PRESSURE`: all five subrubrics PASS, no stale report, no credible capping deduction.
- `REVIEW / EP4_RISK`: at least one subrubric has unresolved review.
- `FAIL / EP4_RISK`: a subrubric fails or report identity is stale.

This is a process/content pressure classification, not a guarantee of the external Rally score.
