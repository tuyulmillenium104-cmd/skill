# Konten Rally

Struktur folder:

```text
konten/
  <Nama_Campaign>/
    <mission-id_Nama_Misi>/
      CONTENT-FINAL.txt
      COMBINED-FINAL-WITH-QNA-AUDIT.md
      QNA / audit files
```

Campaign yang tersedia saat ini:

- `The_Trade_Off`
