# WINNER DNA BUILD SPEC

Winner samples: **9**

Median chars: **734**  
Median paragraphs: **6**

## Opener Types

- tension_declarative: 4
- personal_confession: 4
- declarative: 1

## Value Delivery Styles Detected

- identity_or_boundary_trade: 7
- reflective_reasoning: 6
- tactical_proof_or_process: 2
- reflective_question_close: 2
- money_or_work_trade: 2

## Opener Samples

- @when_tge: `There's a version of me that would be further along by now.`
- @maimelee: `The number was good. The work was empty by Wednesday, every week, without fail.`
- @ahonjumaidil: `Refusing a trade isn't always about what you'd lose.`
- @giang51639726: `There's a relationship I truly want to maintain, but it requires me to become a different version of myself. More accurately, to lose a significant part of myself.`
- @mr_rickprime: `Sé que progresaría más rápido si convirtiera cada afición en contenido.`
- @justinanhy: `Be real, be specific, no hype | I have values | One You Won | Original content in any language. | The One You Won | blocking the person immediately without hesitation | s proposed angle of | s technical infrastructure and operational model. 3. Value Proposition: Rally | ve built on their account and`
- @ka13_cel: `1/5 Someone I liked asked for a simpler version of me 🧊`
- @u67943083: `1/5 A fund wanted me to ghostwrite partner posts 🖊️`

## CTA / Tail Samples

- @when_tge: `Most people will say fear stops them. I think that's too clean. What's actually in the way for you?`
- @maimelee: `Name what you'd give up. Name what you'd gain. Tell me why the exchange is yours to make and not someone else's to approve. 
http://rally.fun/r/maimelee`
- @ahonjumaidil: `Name the trade you keep rejecting that you know would work.`
- @giang51639726: `And I'm still here, waiting for something that truly doesn't require me to give up myself. @RallyOnChain`
- @mr_rickprime: `@RallyOnChain`
- @justinanhy: `Be real, be specific, no hype | I have values | One You Won | Original content in any language. | The One You Won | blocking the person immediately without hesitation | s proposed angle of | s technical infrastructure and operational model. 3. Value Proposition: Rally | ve built on their account and`
- @ka13_cel: `I am putting this on @RallyOnChain at http://app.rally.fun because easy love can still erase you 👀`
- @u67943083: `I am making that refusal public on @RallyOnChain at http://app.rally.fun because money can edit you quietly 👀`

## Mandatory Build Spec Before Drafting

- **hook:** Use dominant winner opener family, but with a concrete scene or tension in first 2 lines.
- **trade:** Name the tempting gain and the refused cost explicitly.
- **whyRefuse:** Explain why the winning version would not feel worth owning.
- **valuePayload:** Include a tactical rule/test/method, not only philosophy.
- **brandBridge:** Mention @RallyOnChain as prompt/context, not as product pitch.
- **cta:** Use winner-style reflective question with easy self-disclosure path.

## Hard Rule

Do not draft until this build spec is converted into the actual content plan. Winner DNA is the blueprint; tools are validators only.
