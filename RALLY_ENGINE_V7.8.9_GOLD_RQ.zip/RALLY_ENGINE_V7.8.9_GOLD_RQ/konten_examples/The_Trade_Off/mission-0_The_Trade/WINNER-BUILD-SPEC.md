# WINNER DNA BUILD SPEC

Winner samples: **8**

Median chars: **521.0**  
Median paragraphs: **5.0**

## Opener Types

- personal_confession: 7
- declarative: 1

## Value Delivery Styles Detected

- money_or_work_trade: 4
- reflective_question_close: 3
- reflective_reasoning: 3
- tactical_proof_or_process: 3
- identity_or_boundary_trade: 1

## Opener Samples

- @heischapman: `For years, I gave my attention away for free. I didn't realize it was a transaction at first.`
- @rui_yi76015: `在这个行业里混久了，我越来越看清一个真相，那就是你想要的一切在底层其实都是有代价的。很多人为了追求所谓的链上神话，付出的代价往往并不是金钱，而是现实生活中的稳定、人际关系甚至是长久以来的舒适圈。借着@RallyOnChain 的活动，我想坦诚面对一次我生活中最沉重的权衡取舍。`
- @kbgold77: `Three years ago I took a role because the number was good. The work was fine in the way a lot of things are fine: stable, functional, quietly draining.`
- @dreybaba1234: `The hardest part of staying in Web3 isn't surviving a brutal bear market.
It's refusing to become comfortable.
I joined this space in early 2021. Somewhere along the way, I realized the biggest risk wasn't missing the next 100x token. It was becoming addicted to chasing`
- @youshiitaa: `The hardest trade I have made this year was not money.`
- @kristinagazieva: `1/5 I would give up 45 minutes of X scrolling 👀`
- @a_s_chubarova: `1/5 I would give up quote-tweet fights after dinner 🍽️`
- @dariasvets: `1/5 I would give up a high-paying KOL manager seat 💼`

## CTA / Tail Samples

- @heischapman: `What do you refuse to trade?`
- @rui_yi76015: `兄弟们，为了得到你们想要的结果，你们曾做出过最让你们后悔或者庆幸的“大交易”是什么？在评论区留下你们的权衡故事，我们一起来聊聊选择背后的内心世界。`
- @kbgold77: `The version of me that took that job had bad criteria. I'd like the next move to be made by someone better.`
- @dreybaba1234: `The hardest part of staying in Web3 isn't surviving a brutal bear market.
It's refusing to become comfortable.
I joined this space in early 2021. Somewhere along the way, I realized the biggest risk wasn't missing the next 100x token. It was becoming addicted to chasing`
- @youshiitaa: `If you could trade away one habit today for one thing you truly want a year from now, what would you choose?`
- @kristinagazieva: `I am testing this on @RallyOnChain at http://app.rally.fun 🧵`
- @a_s_chubarova: `What would you create if you stopped arguing? I am testing mine on @RallyOnChain at http://app.rally.fun because replies vanish fast 👀`
- @dariasvets: `I am arguing this on @RallyOnChain at http://app.rally.fun  🔓`

## Mandatory Build Spec Before Drafting

- **hook:** Use dominant winner opener family, but with a concrete scene or tension in first 2 lines.
- **trade:** Name the tempting gain and the refused cost explicitly.
- **whyRefuse:** Explain why the winning version would not feel worth owning.
- **valuePayload:** Include a tactical rule/test/method, not only philosophy.
- **brandBridge:** Mention @RallyOnChain as prompt/context, not as product pitch.
- **cta:** Use winner-style reflective question with easy self-disclosure path.

## Hard Rule

Do not draft until this build spec is converted into the actual content plan. Winner DNA is the blueprint; tools are validators only.
