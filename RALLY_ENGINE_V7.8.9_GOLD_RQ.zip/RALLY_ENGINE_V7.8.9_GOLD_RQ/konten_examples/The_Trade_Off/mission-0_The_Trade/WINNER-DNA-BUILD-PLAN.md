# WINNER-DNA BUILD PLAN - The Trade Off / mission-0 The Trade

> Note: This plan was added after the real verdict miss. It is the required pre-draft artifact for future rebuilds.

- Hook mechanism selected: personal confession with concrete social proof failure, not generic self-improvement.
- Trade/refusal mechanism selected: give up a specific private/safe behavior to gain one visible proof object.
- Value delivery mechanism selected: must include a practical rule/test, not only reflective philosophy.
- Tactical payload selected: reader gets a repeatable public-proof test or decision rule they can apply today.
- Brand bridge style selected: @RallyOnChain as prompt/context only, never product pitch.
- CTA style selected: winner-style reflective question, easy self-disclosure, not mechanical engagement bait.
- Loser-DNA exclusions: avoid crowded hidden/private to public-proof motif unless angle is semantically fresh; avoid comfort/scroling templates; avoid common progression comfort -> trade -> tag -> reflective question.

## Post-verdict required correction

Real verdict found EP4 and OAA1 because:
- value was more philosophical than tactical;
- core motif was semantically crowded: private/hidden -> public proof.

Future rebuild must use this build plan plus:
- tactical value payload check;
- originality saturation check.
