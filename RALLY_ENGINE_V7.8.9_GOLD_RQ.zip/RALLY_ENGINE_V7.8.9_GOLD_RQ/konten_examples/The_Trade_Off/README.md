# Campaign: The Trade Off

Folder ini berisi semua konten final untuk campaign **The Trade Off**.

## Missions

1. `mission-0_The_Trade`
   - Mission: The Trade
   - File utama: `CONTENT-FINAL.txt`
   - File lengkap: `COMBINED-FINAL-WITH-QNA-AUDIT.md`
   - Build plan: `WINNER-DNA-BUILD-PLAN.md`
   - Winner build spec: `WINNER-BUILD-SPEC.md`

2. `mission-1_The_One_You_Wont_Make`
   - Mission: The One You Won't Make
   - File utama: `CONTENT-FINAL.txt`
   - File lengkap: `COMBINED-FINAL-WITH-QNA-AUDIT.md`
   - Build plan: `WINNER-DNA-BUILD-PLAN.md`
   - Winner build spec: `WINNER-BUILD-SPEC.md`
