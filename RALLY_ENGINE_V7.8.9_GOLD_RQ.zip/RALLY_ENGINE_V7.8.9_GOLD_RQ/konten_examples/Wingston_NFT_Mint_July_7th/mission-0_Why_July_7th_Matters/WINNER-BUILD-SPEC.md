# WINNER DNA BUILD SPEC

Winner samples: **8**

Median chars: **1526.0**  
Median paragraphs: **12.5**

## Opener Types

- personal_confession: 6
- declarative: 2

## Value Delivery Styles Detected

- reflective_reasoning: 7
- money_or_work_trade: 5
- reflective_question_close: 5
- tactical_proof_or_process: 3
- identity_or_boundary_trade: 1

## Opener Samples

- @defifundamental: `3,000 Wingstons Exist. Not One Can Be Bought. July 7 Proves a Point.`
- @samiranzm2001: `I have watched three NFT cycles from close enough to know how they end. Someone with money gets in early, flips to someone with less money, and the project dies when there is no one left to sell to. The people who actually used the product were never the ones who owned it.`
- @lami_thefirst: `I stopped caring about NFTs the day I paid 0.3 ETH for a JPEG that did nothing after mint. Wingston feels like the opposite of that.`
- @nothing__web3: `The NFT market did not collapse because people lost interest in digital ownership.`
- @cutiepupuweb3: `I don't think NFTs failed because people lost interest in digital ownership.`
- @arajean0: `I think the biggest mistake NFTs ever made was convincing people they were buying a lottery ticket.`
- @amadarln2: `I finally became eligible to mint the Wingston NFT.`
- @aburo_dreams: `I've been in the NFT space long enough to remember what the last cycle actually felt like. Where getting into the good stuff was mostly about who you knew, how much you had, or how fast you could move when the mint went live. Participation was technically open to everyone. In practice it wasn't.`

## CTA / Tail Samples

- @defifundamental: `What NFT did you own where the rarity meant nothing the moment the hype left?`
- @samiranzm2001: `The uncomfortable question this mint is forcing is simple: if your project cannot survive without selling access to people who have not earned it yet, what are you actually building? July 7th is the answer to that question, not in theory, but in practice.`
- @lami_thefirst: `Would you mint on July 7th if your contribution, not your budget, decided if you got in?`
- @nothing__web3: `What would NFTs look like if contribution was always the entry requirement?`
- @cutiepupuweb3: `If this model succeeds, do you think more NFT projects will move toward rewarding contributors before capital?`
- @arajean0: `And that’s why I think July 7 is bigger than just another mint.`
- @amadarln2: `• Participate in at least 3`
- @aburo_dreams: `Wingston is the clearest version of that argument I've seen put into an actual product.`

## Mandatory Build Spec Before Drafting

- **hook:** Use dominant winner opener family, but with a concrete scene or tension in first 2 lines.
- **trade:** Name the tempting gain and the refused cost explicitly.
- **whyRefuse:** Explain why the winning version would not feel worth owning.
- **valuePayload:** Include a tactical rule/test/method, not only philosophy.
- **brandBridge:** Mention @RallyOnChain as prompt/context, not as product pitch.
- **cta:** Use winner-style reflective question with easy self-disclosure path.

## Hard Rule

Do not draft until this build spec is converted into the actual content plan. Winner DNA is the blueprint; tools are validators only.
