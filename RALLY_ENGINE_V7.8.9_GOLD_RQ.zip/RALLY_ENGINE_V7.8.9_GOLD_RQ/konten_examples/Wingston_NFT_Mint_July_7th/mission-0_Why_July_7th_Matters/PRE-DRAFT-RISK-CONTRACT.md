# PRE-DRAFT RISK CONTRACT

Campaign: **Wingston NFT Mint: July 7th**  
Mission: **mission-0 - Why July 7th Matters**

## Winner-DNA mechanisms to build from

- Winner count: 8
- Median chars: 1526.0
- Median paragraphs: 12.5
- Opener types: {'declarative': 2, 'personal_confession': 6}
- Required CTA answer format: **direct answer to CTA + personal story + decision/consequence**

### Winner CTA tails
- `What NFT did you own where the rarity meant nothing the moment the hype left?`
- `The uncomfortable question this mint is forcing is simple: if your project cannot survive without selling access to people who have not earned it yet, what are you actually building? July 7th is the answer to that question, not in theory, b`
- `Would you mint on July 7th if your contribution, not your budget, decided if you got in?`
- `What would NFTs look like if contribution was always the entry requirement?`
- `If this model succeeds, do you think more NFT projects will move toward rewarding contributors before capital?`
- `And that’s why I think July 7 is bigger than just another mint.`
- `• Participate in at least 3`
- `Wingston is the clearest version of that argument I've seen put into an actual product.`

## Banned / crowded phrases from non-winners
- `free mint 000` (91)
- `000 supply ethereum` (80)
- `mint 000 supply` (77)
- `free mint 000 supply` (77)
- `mint 000 supply ethereum` (68)
- `supply ethereum july` (47)
- `000 supply ethereum july` (46)
- `free mint ethereum` (43)
- `weekly top 425` (33)
- `earn don't buy` (30)
- `ethereum july 7th` (28)
- `mint july 7th` (28)
- `rally score boost` (24)
- `product nft tied` (24)
- `real business model` (23)
- `ethereum supply 000` (21)
- `least rally campaigns` (20)
- `supply ethereum july 7th` (20)
- `last nft cycle` (19)
- `nft nft nft` (19)
- `price free mint` (18)
- `next era nfts` (17)
- `top 425 leaderboard` (16)
- `july 7th matters` (16)
- `000 nfts ethereum` (16)

## Saturated semantic motifs
- **money_career_trade**: 47 submissions (17.7%) evidence=[('access', 42), ('pay', 37), ('money', 17), ('job', 1)]
- **private_to_public_proof**: 31 submissions (11.7%) evidence=[('score', 30), ('private', 25), ('proof', 8), ('public', 3), ('hidden', 2), ('evidence', 1)]
- **creator_public_work**: 20 submissions (7.5%) evidence=[('work', 17), ('creator', 16), ('content', 10), ('post', 3)]

## Top judge deduction classes in pool
- **conversation_limited**: 261
- **specificity_missing**: 255
- **cta_weak**: 255
- **hook_weak**: 244
- **structure_density**: 243
- **generic_or_formulaic**: 230
- **value_not_exceptional**: 218
- **brand_bridge_promotional**: 158
- **authenticity_polish_tax**: 77

## Required mechanisms for draft
- Include operational/tactical payload, not only reflection.
- CTA must be a low-friction self-disclosure prompt matching campaign action format.
- Use concrete receipt details in first 2-3 paragraphs.
- Keep length compact or earned; avoid dense paragraphs and literary fog.
- Use @RallyOnChain as prompt/context, not product pitch.
- Choose semantic angle outside saturated motifs; if using crowded motif, add major twist.

## Likely judge deduction sentences to avoid
- "Good story, but conversation potential is limited without an answerable prompt."
- "Aligned, but needs more concrete personal detail."
- "CTA is present but not direct enough to drive replies."
- "Readable, but slightly long/dense for casual scrollers."
- "Authentic, but the structure/angle feels familiar or templated."

## Rebuild triggers
- draft uses saturated motif without major twist
- draft lacks operational/tactical payload
- CTA cannot be answered with concrete personal story/decision
- brand mention reads like product pitch
- Q&A replies validate post instead of answering actual CTA
- worst positive verdict can still write EP4/OAA1/RQ3 sentence

## Operating rule

Do not draft until this contract is converted into the WINNER-DNA BUILD PLAN. If draft violates this contract, rebuild instead of patching.
