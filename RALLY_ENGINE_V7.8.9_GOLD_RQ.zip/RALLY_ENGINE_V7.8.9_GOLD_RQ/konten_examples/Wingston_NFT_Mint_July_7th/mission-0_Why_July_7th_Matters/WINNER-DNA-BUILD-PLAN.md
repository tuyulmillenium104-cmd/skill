# WINNER-DNA BUILD PLAN - Wingston NFT Mint: July 7th / mission-0 Why July 7th Matters

- Hook mechanism selected: personal NFT regret leading into Wingston as the opposite mechanism.
- Story mechanism selected: Wingston flips the timestamp: work before ownership, not purpose after mint.
- Value delivery mechanism selected: product NFT test that survives after hype cools.
- Tactical payload selected: remove hype for one week and ask what still works.
- Brand bridge style selected: @RallyOnChain as the operating system that makes the utility loop real.
- CTA style selected: decision fork between buyable collectible and earned product.
- Loser-DNA exclusions: avoided crowded exact phrases from the pre-draft contract, including common mandatory-detail ordering and generic next-era NFT language.
- Contract blockers respected: saturated motifs avoided or cleared where similarity came from mandatory facts; loser-DNA scan clean.

## Submit requirement

This mission requires quoting the Wingston announcement tweet:
https://x.com/RallyOnChain/status/2069816560168915167?s=20

Use the final copy as the quote-tweet text.
