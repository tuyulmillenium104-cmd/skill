# Campaign: Wingston NFT Mint: July 7th

## Missions

1. `mission-0_Why_July_7th_Matters`
   - Mission: Why July 7th Matters
   - File utama: `CONTENT-FINAL.txt`
   - File lengkap: `COMBINED-FINAL-WITH-QNA-AUDIT.md`
   - Submit action: quote the Wingston announcement tweet.
