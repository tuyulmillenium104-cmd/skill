# Campaign: The Glass Half

Folder ini berisi semua konten final untuk campaign **The Glass Half**.

## Missions

1. `mission-0_The_One_Drink`
   - Mission: The One Drink
   - File utama: `CONTENT-FINAL.txt`
   - File lengkap: `COMBINED-FINAL-WITH-QNA-AUDIT.md`
   - Build plan: `WINNER-DNA-BUILD-PLAN.md`
   - Winner build spec: `WINNER-BUILD-SPEC.md`

2. `mission-1_Not_What_I_Ordered`
   - Mission: Not What I Ordered
   - File utama: `CONTENT-FINAL.txt`
   - File lengkap: `COMBINED-FINAL-WITH-QNA-AUDIT.md`
   - Build plan: `WINNER-DNA-BUILD-PLAN.md`
   - Winner build spec: `WINNER-BUILD-SPEC.md`
