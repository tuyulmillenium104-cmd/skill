# WINNER-DNA BUILD PLAN - The Glass Half / mission-1 Not What I Ordered

- Hook mechanism selected: personal expectation-vs-reality drink contrast in first line.
- Story mechanism selected: January ordered one calm year, reality served a specific operational mess.
- Value delivery mechanism selected: practical rule for adapting when the year adds surprise ingredients.
- Tactical payload selected: if the year adds three surprise ingredients, stop defending the original recipe and rewrite the menu by Friday.
- Brand bridge style selected: @RallyOnChain as campaign prompt/context, integrated after the story is established.
- CTA style selected: winner-style reflective question asking for the promised drink and the forced decision.
- Loser-DNA exclusions: avoid crowded tap water, black coffee, lime soda, martini, mineral water, flaming sambuca, and generic "thought 2026 would" phrasing.

## Audit status

- Tactical value payload: PASS 6/6.
- Originality saturation: PASS clear.
- Loser-DNA scan: PASS clean.
- Final integrity: PASS.
