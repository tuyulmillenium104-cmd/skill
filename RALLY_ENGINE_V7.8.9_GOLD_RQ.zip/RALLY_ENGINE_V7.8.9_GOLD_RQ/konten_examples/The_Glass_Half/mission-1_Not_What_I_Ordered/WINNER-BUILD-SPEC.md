# WINNER DNA BUILD SPEC

Winner samples: **10**

Median chars: **273.0**  
Median paragraphs: **3.0**

## Opener Types

- personal_confession: 10

## Value Delivery Styles Detected

- reflective_reasoning: 5
- reflective_question_close: 5
- identity_or_boundary_trade: 2
- tactical_proof_or_process: 1

## Opener Samples

- @mister_fat: `I went from plumbing houses to plumbing chains. Then 2026 handed me both.`
- @spacejunnk: `Back in January, I thought 2026 would taste like green tea.`
- @anhtunbi536660: `In January, I thought success would arrive with a toast.`
- @timoxa_master: `1/5 January me ordered a clean lime soda🧃
New start. Fresh wallet .
Reality got cloudy when my bank asked why three exchange transfers had nearly identical memo text🏦
I am putting this pivot on @RallyOnChain at http://app.rally.fun because admin can hijack a bullish year👀`
- @djrxo2knwzh24wy: `1/5 I wanted 2026 to be quiet oolong and small notes 🍵`
- @fourroad1: `1/5 In January I ordered a victory martini for one clean airdrop exit 🍸`
- @ylia1804: `1/5 In January I ordered a quiet year and fewer Telegram alarms 🔕`
- @kblxdznlmwh0ftr: `1/5 I thought 2026 would taste like mineral water💧
Clean risk.
Then a tiny NFT collab became a spicy Bloody Mary of revisions, royalties, metadata fixes, and one artist panic DM 🎨
I am putting it on @RallyOnChain at http://app.rally.fun because clean plans hate real people🧠`

## CTA / Tail Samples

- @mister_fat: `January me would have called that a step`
- @spacejunnk: `What’s one thing this year gave you that you’d never have had if everything had gone according to plan?`
- @anhtunbi536660: `What drink did January promise you, and what are you actually holding today?`
- @timoxa_master: `1/5 January me ordered a clean lime soda🧃
New start. Fresh wallet .
Reality got cloudy when my bank asked why three exchange transfers had nearly identical memo text🏦
I am putting this pivot on @RallyOnChain at http://app.rally.fun because admin can hijack a bullish year👀`
- @djrxo2knwzh24wy: `Did your quiet plan get ambushed? I am writing mine on @RallyOnChain at http://app.rally.fun 👀`
- @fourroad1: `What did your plan become? Mine goes on @RallyOnChain at http://app.rally.fun and still annoys me 👀`
- @ylia1804: `What made your year louder than planned? I am sharing mine on @RallyOnChain at http://app.rally.fun 👀`
- @kblxdznlmwh0ftr: `1/5 I thought 2026 would taste like mineral water💧
Clean risk.
Then a tiny NFT collab became a spicy Bloody Mary of revisions, royalties, metadata fixes, and one artist panic DM 🎨
I am putting it on @RallyOnChain at http://app.rally.fun because clean plans hate real people🧠`

## Mandatory Build Spec Before Drafting

- **hook:** Use dominant winner opener family, but with a concrete scene or tension in first 2 lines.
- **trade:** Name the tempting gain and the refused cost explicitly.
- **whyRefuse:** Explain why the winning version would not feel worth owning.
- **valuePayload:** Include a tactical rule/test/method, not only philosophy.
- **brandBridge:** Mention @RallyOnChain as prompt/context, not as product pitch.
- **cta:** Use winner-style reflective question with easy self-disclosure path.

## Hard Rule

Do not draft until this build spec is converted into the actual content plan. Winner DNA is the blueprint; tools are validators only.
