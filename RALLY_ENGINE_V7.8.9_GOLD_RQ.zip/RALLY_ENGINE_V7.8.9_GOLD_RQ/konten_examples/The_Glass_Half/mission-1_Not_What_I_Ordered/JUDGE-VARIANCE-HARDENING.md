# JUDGE-VARIANCE HARDENING MATRIX (#0R)

Content: The Glass Half / mission-1 - Not What I Ordered

## 5-Persona Judge Matrix

| Persona | Gate at Risk | Exact Criticism Sentence Judge Might Write | Severity Class | Recurrence Key | Fix Decision |
|---|---|---|---|---|---|
| Literal Compliance | CC/CA | "The post contrasts January's expected drink with the actual drink, includes @RallyOnChain, avoids forbidden punctuation, and does not start with a mention or hashtag." | hallucinated if negative | compliance-clear | ignore |
| IA Skeptic | IA | "Client and launch-rescue details are personal anecdotes without unverifiable public claims, and no platform capability is overstated." | hallucinated if negative | personal-claim-bounded | ignore |
| OAA Similarity | OAA | "Chamomile tea versus vending-machine mushroom soup is a fresh drink contrast, and originality saturation is clear." | hallucinated if negative | motif-clear | ignore |
| EP Harsh | EP | "The launch-rescue details are a bit niche, but the post gives a usable rule about rewriting the menu and an easy CTA about January's promised drink." | style preference | niche-specificity | monitor |
| TQ Native | TQ | "The post is polished but still X-readable, with short paragraphs, a concrete scene, and clean punctuation." | style preference | crafted-polish | monitor |

Worst credible verdict: EP5 / OAA2 / TQ5 / IA2 / CA2 / CC2.

Repeated criticisms: none.

Required fixes: none.

Residual after fixes:
- EP: low
- OAA: low
- TQ: low
- IA: low
- CA/CC: low

## Deduction Surface Map

### EP
- Possible attack: "The client rescue details may be niche."
- Defense: Niche details make the story concrete; the tactical rule generalizes the value for readers.
- Residual: low.

### OAA
- Possible attack: "Another expectation-versus-reality drink post."
- Defense: The core motif and drink pair are not saturated; originality saturation PASS clear.
- Residual: low.

### TQ
- Possible attack: "Slightly crafted phrasing."
- Defense: The phrasing is still direct, clean, and platform-native; TQ audit PASS.
- Residual: low.

### IA
- Possible attack: "Client details are unverifiable."
- Defense: They are framed as personal lived experience, not factual claims about a public entity.
- Residual: low.

Decision: PASS.
