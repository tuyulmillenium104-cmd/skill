# WINNER-DNA BUILD PLAN - The Glass Half / mission-0 The One Drink

- Hook mechanism selected: personal confession through a single concrete drink, with a slightly embarrassing truth in the first two lines.
- Story mechanism selected: drink reveals the real state of the year, not just a mood or aesthetic.
- Value delivery mechanism selected: practical difference between momentum and depletion.
- Tactical payload selected: if a week needs recovery math to survive, remove one commitment before adding more discipline.
- Brand bridge style selected: @RallyOnChain as campaign prompt/context, integrated after the year story is established.
- CTA style selected: winner-style reflective question asking for drink plus the hidden decision behind it.
- Loser-DNA exclusions: avoid crowded glass water, triple espresso, black coffee, beer, champagne, sparkling water, generic "felt like", and tacked-on app link phrasing.

## Rebuild audit status

- Tactical value payload: PASS 6/6.
- Originality saturation: PASS clear.
- Loser-DNA scan: PASS clean.
- Final integrity: PASS.
