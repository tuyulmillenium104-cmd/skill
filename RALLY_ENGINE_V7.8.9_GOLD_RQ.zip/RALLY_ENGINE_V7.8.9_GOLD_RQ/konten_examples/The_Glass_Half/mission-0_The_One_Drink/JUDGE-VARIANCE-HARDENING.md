# JUDGE-VARIANCE HARDENING MATRIX (#0R)

Content: The Glass Half / mission-0 - The One Drink

## 5-Persona Judge Matrix

| Persona | Gate at Risk | Exact Criticism Sentence Judge Might Write | Severity Class | Recurrence Key | Fix Decision |
|---|---|---|---|---|---|
| Literal Compliance | CC/CA | "The post mentions @RallyOnChain, does not start with a mention or hashtag, names a drink, and connects it to a personal 2026 story." | hallucinated if negative | compliance-clear | ignore |
| IA Skeptic | IA | "The health details are personal anecdotes, not medical claims, and the process rule is framed as personal behavior rather than universal medical advice." | hallucinated if negative | personal-claim-bounded | ignore |
| OAA Similarity | OAA | "The oral rehydration salts in a chipped mug is not a crowded drink trope in this mission pool, and the originality saturation scan is clear." | hallucinated if negative | motif-clear | ignore |
| EP Harsh | EP | "This could be slightly introspective, but it gives a practical process rule and a clear reply prompt, so the value is not merely philosophical." | style preference | ep-introspection | monitor |
| TQ Native | TQ | "The long third paragraph is dense but readable, and the overall X rhythm remains clean with short follow-up paragraphs." | style preference | paragraph-density | monitor |

Worst credible verdict: EP5 / OAA2 / TQ5 / IA2 / CA2 / CC2.

Repeated criticisms: none.

Required fixes: none.

Residual after fixes:
- EP: low
- OAA: low
- TQ: low-medium due one dense paragraph, not enough to force fix
- IA: low
- CA/CC: low

## Deduction Surface Map

### EP
- Possible attack: "More introspective than broadly viral."
- Defense: Drink is unusual, details are concrete, CTA is direct, and tactical rule is usable today.
- Residual: low.

### OAA
- Possible attack: "Another burnout drink story."
- Defense: Oral rehydration salts + chipped mug + recovery math is semantically distinct from coffee/water/beer/champagne clusters; originality saturation PASS clear.
- Residual: low.

### TQ
- Possible attack: "One paragraph is long."
- Defense: Paragraph is story payload; surrounding paragraphs are short and scannable; TQ audit PASS.
- Residual: low-medium.

### IA
- Possible attack: "Health symptoms are medical."
- Defense: Symptoms are personal story details, no diagnosis or medical advice.
- Residual: low.

Decision: PASS.
