# WINNER DNA BUILD SPEC

Winner samples: **15**

Median chars: **278**  
Median paragraphs: **4**

## Opener Types

- personal_confession: 14
- declarative: 1

## Value Delivery Styles Detected

- reflective_reasoning: 10
- reflective_question_close: 9
- identity_or_boundary_trade: 3
- money_or_work_trade: 3
- tactical_proof_or_process: 1

## Opener Samples

- @jermey255: `Nobody noticed when I stopped. I almost didn't either.`
- @changzhcrypto: `Everyone on this app is posting pictures of champagne or triple espressos to make 2026 look exciting.`
- @spacejunnk: `If my 2026 had one drink, it would be melted ice cream.`
- @gasparjayena: `My 2026 year tastes like a double serving of protein after two hours in the gym. A slightly bitter and thick shake that gives pure energy when you feel running on empty.`
- @yaayeuhh85021: `My 2026 drink would be a cup of instant noodles broth.`
- @timoxa_master: `1/5 My 2026 is a glass of water 💧`
- @dariasvets: `1/5 My 2026 is airport lounge sparkling wine 🥂`
- @lwzgh4rvwhpbhyg: `1/5 My 2026 is a warm stout I forgot during a governance vote 🍺`

## CTA / Tail Samples

- @jermey255: `What's yours? Drop your drink and the one sentence you haven't said out loud about your year yet.`
- @changzhcrypto: `What is the one drink that sums up your 2026, and what story put it in your hand?`
- @spacejunnk: `Every idea I`
- @gasparjayena: `Inner balance helps to keep growing. That is why I support great initiatives and share this with you together with @RallyOnChain, because growth only happens through daily hard work.`
- @yaayeuhh85021: `@RallyOnChain`
- @timoxa_master: `I am posting this reset on @RallyOnChain at http://app.rally.fun because basics kept me alive 🧠✅`
- @dariasvets: `I am sharing it on @RallyOnChain at http://app.rally.fun because wins feel different when they arrive tired 👀`
- @lwzgh4rvwhpbhyg: `What got stuck for you? Mine goes on @RallyOnChain at http://app.rally.fun 👀`

## Mandatory Build Spec Before Drafting

- **hook:** Use dominant winner opener family, but with a concrete scene or tension in first 2 lines.
- **trade:** Name the tempting gain and the refused cost explicitly.
- **whyRefuse:** Explain why the winning version would not feel worth owning.
- **valuePayload:** Include a tactical rule/test/method, not only philosophy.
- **brandBridge:** Mention @RallyOnChain as prompt/context, not as product pitch.
- **cta:** Use winner-style reflective question with easy self-disclosure path.

## Hard Rule

Do not draft until this build spec is converted into the actual content plan. Winner DNA is the blueprint; tools are validators only.
