# GOLD RQ STANDARD - CALIBRATED

## Five types

Use all five as an internal response library, but do not force equal distribution.

For PREDICT missions:

- Specific Probe: 4
- Challenge: 5
- Technical Deep-Dive: 5
- Hot Take: 4
- Real Experience: 2

## Real Experience

AI may generate realistic incoming-reply archetypes, but they must be labeled:

`SIMULATED_ARCHETYPE - DO NOT DEPLOY AS A FAKE ORGANIC REPLY`

Use the A-COPY only when a similar organic reply actually appears.

## Q requirements

- Persona-driven.
- Specific reference to the post, mechanism, timing, number, or thesis.
- Opinion, decision, stake, or reasoning.
- Not FAQ or journalist wording.
- Challenge requires a mechanism or counter-scenario.
- Hot Take requires an alternative thesis.

## A requirements

- Hard maximum: 280 characters.
- Practical target: 30-45 words when possible.
- Insight-dense, not KB recitation.
- Zero fabricated facts.
- Writer presence consistent with main content.
- Openings varied.
- Closings varied: question, statement, implication, reframe, or admission.

## Pack-level targets

- Q Quality >=4/5 for every pair.
- A Insight >=4/5 for every pair.
- Conversational Feel >=4/5 for every pair.
- Mechanics coverage >=70%.
- Decision coverage >=75%.
- Skeptic coverage >=25%.
- Open-loop question endings 50-75%.
- Exact duplicates: 0.
- No more than three consecutive identical opening or closing patterns.

## Deployment law

The 20 pairs are a response library, not twenty replies that must all be posted. Select the pair that matches the real incoming reply. Do not seed fabricated personal stories.
