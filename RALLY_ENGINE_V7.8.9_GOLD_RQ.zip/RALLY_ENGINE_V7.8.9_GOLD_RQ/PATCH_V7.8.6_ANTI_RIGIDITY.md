# V7.8.6 ANTI-RIGIDITY PATCH

Built on V7.8.5 deep-audit fixes.

## Added

- `ANTI_RIGIDITY_PROTOCOL.md`
- `rally-naturalness-variance-check.py`
- Hard constraints versus soft signals versus creative flex zones.
- Q&A mechanics coverage threshold instead of every-pair formula enforcement.
- Decision coverage target 75% and mechanics target 70%.
- Controlled 30% allowance for human/humor/emotional pairs.
- Naturalness REVIEW can pass final integrity with disclosure; severe duplication FAILs.
- Winner Build Spec now declares creative flex zones and anti-copy rule.
- Pre-Draft Risk Contract no longer promotes every winner feature into a hard blocker.

## Intended effect

The engine remains strict on facts, compliance, copying, URLs, and freshness while no longer forcing every content piece or Q&A pair into the same surface template.
