# Prompt to give another chat/agent

Read first:

1. `README_START_HERE.md`
2. `SKILL.md`
3. `PATCH_V7.8.9_GOLD_RQ.md`
4. `GOLD_RQ_STANDARD_CALIBRATED.md`
5. `skills/ACTIVE-PRECEDENCE.md`
6. `HOW_TO_RUN_COMMANDS.md`

For `/rally <address> misi <n>`:

1. Run handoff self-check.
2. Fetch full mission snapshot and lock hashes.
3. Generate provenance, mission contract, and relation plan.
4. Decode mission type from title/core ask before supporting verbs.
5. Generate lane-aware Winner/Loser/Judge DNA.
6. Create Winner Build Spec, Pre-Draft Risk Contract, and Build Plan.
7. Draft naturally and run all content gates.
8. Build the mission-calibrated 20-pair Gold response library.
9. Require every pair Q/A/Feel score >=4.
10. Require controlled type distribution and 50-75% question endings.
11. Label AI-generated Real Experience Qs `SIMULATED_ARCHETYPE` and never seed them as fake testimony.
12. Run RQ, naturalness, Worst Verdict, EP Max, and Gold audit.
13. Final integrity requires Gold, EP Max, snapshot, provenance, relation, and matching hashes.

Never guarantee external RQ5, all-max, or leaderboard victory.
