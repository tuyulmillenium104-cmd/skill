#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mine all currently active Rally campaigns and update active skill ratchet.

Focus: judge verdict patterns across active campaigns/missions (not full tweet text).
Outputs a global active map and appends concise lessons to ADAPTIVE-RATCHET-LESSONS.md.
"""
import argparse, json, re, sys, time, urllib.request, urllib.parse
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter, defaultdict

UA="Mozilla/5.0"
CAMPAIGNS_URL="https://app.rally.fun/api/campaigns?page={page}&limit={limit}"
CAMPAIGN_URL="https://app.rally.fun/api/campaigns/{addr}"
SUBS_URL="https://app.rally.fun/api/submissions?campaignAddress={addr}&limit={limit}&offset={offset}"

GATE_CAT={
 'EP':'Engagement Potential','OAA':'Originality','TQ':'Technical Quality','IA':'Information Accuracy','CA':'Content Alignment','CC':'Campaign Compliance','RQ':'Reply Quality'
}
MAX={'EP':5,'OAA':2,'TQ':5,'IA':2,'CA':2,'CC':2,'RQ':5}

CLASS_PATTERNS={
 'cta_weak':['cta','call-to-action','direct question','direct prompt','explicit','prompt','reply','question','invitation'],
 'conversation_limited':['conversation','replies','discussion','debate','engagement','spark','reply path'],
 'value_not_exceptional':['value delivery','solid','underdeveloped','not exceptional','bookmark','save','surface-level','expected'],
 'hook_weak':['hook','opening','opener','first line','stop-scroll'],
 'structure_density':['dense','too long','length','readability','formatting','structure','compressed','wall of text','over-explains'],
 'generic_formulaic':['generic','formulaic','template','templated','common','standard','familiar','predictable','ai-generated','vague'],
 'brand_promotional':['promotional','brand','mention','plug','forced','campaign-like','sponsored'],
 'authenticity_polish':['polished','authenticity','raw','scripted','manufactured','performative','choreographed'],
 'media_issue':['media','image','url','link','photo','attachment','broken'],
 'claim_accuracy':['unsupported','unverified','misleading','overstate','inaccurate','incorrect','not supported','speculative'],
 'specificity_missing':['specific','concrete','detail','vague','personal example','lacks detail'],
 'compliance_issue':['requirement','compliance','does not','missing','violates','em dash','hashtag','mention'],
 'rq_generic':['generic praise','vague','platitudes','templated','no replies','low-effort','spam','one-word'],
}
MARKERS=['however','but ','lacks','lack of','missing','could','would benefit','slightly','somewhat','not fully','limited','generic','solid','moderate','minor','weak','issue','fails','does not','notably','acceptable','competent','though','while','yet']

def http_json(url):
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'application/json'})
    return json.loads(urllib.request.urlopen(req,timeout=40).read().decode('utf-8','ignore'))

def parse_dt(s):
    if not s: return None
    return datetime.fromisoformat(s.replace('Z','+00:00'))

def fetch_campaigns(limit=50):
    out=[]; page=1
    while True:
        d=http_json(CAMPAIGNS_URL.format(page=page,limit=limit))
        out.extend(d.get('campaigns',[]))
        pag=d.get('pagination',{})
        if not pag.get('hasNext'): break
        page+=1; time.sleep(0.1)
    return out

def fetch_subs(addr, limit=300, max_total=1200):
    subs=[]; off=0
    while off<max_total:
        batch=http_json(SUBS_URL.format(addr=addr,limit=limit,offset=off))
        if not isinstance(batch,list) or not batch: break
        subs.extend(batch)
        if len(batch)<limit: break
        off+=limit; time.sleep(0.15)
    return subs

def atto(v):
    try: return int(v)/1e18
    except: return 0

def gates(sub):
    g={}
    for a in sub.get('analysis') or []:
        cat=(a.get('category') or '')
        for code,name in GATE_CAT.items():
            if name in cat:
                g[code]=(atto(a.get('atto_score')), atto(a.get('atto_max_score')))
    return g

def cat_text(sub, gate):
    name=GATE_CAT[gate]
    return ' '.join(a.get('analysis','') for a in sub.get('analysis') or [] if name in (a.get('category') or ''))

def sents(t):
    return [x.strip() for x in re.split(r'(?<=[.!?。；;])\s+|\n+', t or '') if x.strip()]

def classify(sent, gate):
    sl=sent.lower(); hits=[]
    for cls,pats in CLASS_PATTERNS.items():
        if any(p in sl for p in pats): hits.append(cls)
    if gate=='RQ' and any(p in sl for p in CLASS_PATTERNS['rq_generic']): hits.append('rq_generic')
    return hits or ['unknown_candidate']

def mine_gate(subs, gate):
    cls=Counter(); unknown=[]; evidence=defaultdict(list); nonmax=0
    for sub in subs:
        g=gates(sub); score=g.get(gate,(None,None))[0]
        if score is None or score>=MAX[gate]: continue
        nonmax+=1
        text=cat_text(sub,gate)
        for sent in sents(text):
            sl=sent.lower()
            if any(m in sl for m in MARKERS) or gate=='RQ':
                cs=classify(sent, gate)
                for c in cs:
                    cls[c]+=1
                    if len(evidence[c])<5: evidence[c].append(sent)
                if 'unknown_candidate' in cs and len(unknown)<30: unknown.append(sent)
    return {'gate':gate,'nonmax':nonmax,'classCounts':dict(cls),'unknownSamples':unknown,'evidence':dict(evidence)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out-dir', default='rally-data/global-active')
    ap.add_argument('--sub-limit', type=int, default=500)
    ap.add_argument('--include-ended-hours', type=int, default=0, help='include campaigns ended within N hours')
    ap.add_argument('--max-campaigns', type=int, default=0)
    args=ap.parse_args()
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    now=datetime.now(timezone.utc)
    campaigns=fetch_campaigns()
    active=[]
    for c in campaigns:
        end=parse_dt(c.get('endDate'))
        if not end: continue
        if end >= now or (args.include_ended_hours and (now-end).total_seconds() <= args.include_ended_hours*3600):
            if not c.get('deletedAt'): active.append(c)
    active=sorted(active,key=lambda c:c.get('endDate') or '')
    if args.max_campaigns: active=active[:args.max_campaigns]
    summary=[]; global_gate={g:Counter() for g in GATE_CAT}; global_unknown=defaultdict(list)
    mission_maps=[]
    for idx,c in enumerate(active,1):
        addr=c.get('intelligentContractAddress'); title=c.get('title')
        print(f'[{idx}/{len(active)}] {title} {addr}')
        try:
            detail=http_json(CAMPAIGN_URL.format(addr=addr))
            subs=fetch_subs(addr, max_total=args.sub_limit)
        except Exception as e:
            print('  fetch fail',e); continue
        # group by mission
        by=defaultdict(list)
        for s in subs:
            by[s.get('missionId') or 'mission-0'].append(s)
        for mid,msubs in by.items():
            mm={'campaign':title,'address':addr,'mission':mid,'submissions':len(msubs),'gates':{}}
            for gate in GATE_CAT:
                gm=mine_gate(msubs,gate)
                mm['gates'][gate]=gm
                global_gate[gate].update(gm['classCounts'])
                for u in gm['unknownSamples'][:5]: global_unknown[gate].append({'campaign':title,'mission':mid,'sentence':u})
            mission_maps.append(mm)
        summary.append({'title':title,'address':addr,'endDate':c.get('endDate'),'missions':list(by.keys()),'submissions':len(subs)})
        time.sleep(0.2)
    result={'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'activeCampaigns':len(active),'campaigns':summary,'globalGateClassCounts':{g:dict(c) for g,c in global_gate.items()},'unknownSamples':{g:v[:30] for g,v in global_unknown.items()},'missionMaps':mission_maps}
    (out/'global-active-map.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append('# GLOBAL ACTIVE RALLY MAP\n\n')
    md.append(f'Generated: {result["generated"]}\n\n')
    md.append(f'Active campaigns mined: **{len(active)}**\n\n')
    md.append('## Campaigns\n')
    for c in summary: md.append(f"- {c['title']} `{c['address']}` end={c['endDate']} missions={c['missions']} submissions={c['submissions']}\n")
    md.append('\n## Global Gate Class Counts\n')
    for gate,cnt in result['globalGateClassCounts'].items():
        md.append(f'\n### {gate}\n')
        for k,v in sorted(cnt.items(), key=lambda x:x[1], reverse=True)[:20]: md.append(f'- {k}: {v}\n')
    md.append('\n## Unknown Candidate Samples\n')
    for gate,samps in result['unknownSamples'].items():
        if not samps: continue
        md.append(f'\n### {gate}\n')
        for u in samps[:10]: md.append(f"- {u['campaign']} / {u['mission']}: {u['sentence'][:300]}\n")
    # Active lessons summary
    md.append('\n## Active Skill Update Recommendations\n')
    ep=result['globalGateClassCounts'].get('EP',{})
    top=sorted(ep.items(), key=lambda x:x[1], reverse=True)[:8]
    md.append('Top active EP deduction pressure points:\n')
    for k,v in top: md.append(f'- {k}: {v}\n')
    md.append('\nRecommended enforcement: keep CTA, conversation, value ceiling, hook, structure/media, specificity, and generic/formulaic gates mandatory.\n')
    (out/'GLOBAL-ACTIVE-RALLY-MAP.md').write_text(''.join(md),encoding='utf-8')
    # append concise ratchet entry
    ratchet=Path('skills/ADAPTIVE-RATCHET-LESSONS.md')
    entry='\n---\n\n## '+time.strftime('%Y-%m-%d')+' — Global active campaign mining — active gate pressure map\n\nTYPE: GLOBAL-ACTIVE-MINING\nSOURCE: all currently active Rally campaigns available via public campaigns API\nEVIDENCE:\n'
    for k,v in top[:6]: entry += f'- EP active pressure: {k} = {v}\n'
    entry += 'ACTIVE RULE:\n- Before writing in any active campaign, run campaign cartography and treat current active EP pressure points as priors, subordinate to mission-specific data.\nCHECK:\n- GLOBAL-ACTIVE-RALLY-MAP.md exists and mission-specific map exists.\nACTION:\n- If mission data is sparse, use global active pressure map to harden CTA, conversation, value, hook, structure/TQ, specificity, and generic-risk checks.\n'
    ratchet.write_text(ratchet.read_text(encoding='utf-8')+entry, encoding='utf-8')
    print('GLOBAL ACTIVE MINING COMPLETE')
    print(out/'GLOBAL-ACTIVE-RALLY-MAP.md')

if __name__=='__main__': main()
