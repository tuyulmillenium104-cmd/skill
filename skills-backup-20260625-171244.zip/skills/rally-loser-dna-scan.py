#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mission-scoped loser DNA sterilization scanner.

Checks exact n-gram overlap between a candidate content file and non-winner corpus,
core motif hits, and common fatal loser patterns. Designed to enforce Addendum v1.6 (#0S2).
"""
import argparse, json, re, sys, time
from pathlib import Path

DEFAULT_WHITELIST = [
    "@rallyonchain", "app rally fun", "rally fun", "wingston", "wingston vip",
    "wingston nft", "vip community", "token gated", "token gated community",
    "private campaigns", "higher reward campaigns", "early updates", "early rally",
    "whitelist", "whitelist opportunities", "whitelist access", "rlp", "rlp benefits",
    "official announcement", "quote tweet", "creator", "creators"
]

FATAL_PATTERNS = {
    "missing_clear_cta": lambda t: "?" not in t and not any(v in t for v in ["reply", "comment", "tell me", "choose", "visit", "check", "learn", "join", "mint", "app.rally.fun"]),
    "generic_hype": lambda t: any(x in t for x in ["game changer", "huge advantage!!!", "must join now!!!", "exclusive club", "alpha group", "don't miss out!!!"]),
    "unsupported_guarantee": lambda t: any(x in t for x in ["guaranteed", "guarantees", "will make you", "profit", "income", "roi", "full time", "100x"]),
    "format_violation": lambda t: any(ch in t for ch in ["—", "–", "“", "”", "‘", "’"]) or (t[:1] in ["@", "#"]),
    "mention_tacked_on_end": lambda t: ("@rallyonchain" in t and t.rfind("@rallyonchain") / max(1, len(t)) > 0.80),
}

def toks(text):
    return re.findall(r"[a-z0-9@.']+", text.lower())

def ngrams(tokens, n):
    return [" ".join(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

def is_whitelisted(phrase, whitelist):
    return any(w in phrase for w in whitelist)

def load_submissions(path):
    data = json.load(open(path, encoding="utf-8"))
    if not isinstance(data, list):
        raise SystemExit("submissions file must be submissions_enriched.json list")
    return data

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--submissions", required=True)
    ap.add_argument("--out-json", required=True)
    ap.add_argument("--out-md", default=None)
    ap.add_argument("--motif", action="append", default=[])
    ap.add_argument("--whitelist", action="append", default=[])
    ap.add_argument("--allow-5gram-whitelisted", action="store_true", default=True)
    args = ap.parse_args()

    content_path = Path(args.content)
    content = content_path.read_text(encoding="utf-8").strip()
    subs = load_submissions(args.submissions)
    nonwinners = [s for s in subs if not s.get("winner")]
    whitelist = [w.lower() for w in DEFAULT_WHITELIST + args.whitelist]

    ct = toks(content)
    all_hits = []
    summary = {}
    for n in [4,5,6,7,8]:
        cng = set(ngrams(ct, n))
        hits = []
        for s in nonwinners:
            st = s.get("content") or ""
            inter = cng & set(ngrams(toks(st), n))
            for phrase in sorted(inter):
                wl = is_whitelisted(phrase, whitelist)
                hit = {
                    "n": n,
                    "author": s.get("xUsername"),
                    "phrase": phrase,
                    "whitelisted": wl,
                    "gates": {k:v[0] for k,v in (s.get("gates") or {}).items() if isinstance(v, list) and v},
                }
                hits.append(hit)
                all_hits.append(hit)
        summary[str(n)] = {
            "total": len(hits),
            "unwhitelisted": sum(1 for h in hits if not h["whitelisted"]),
            "sample": hits[:20],
        }

    lower = content.lower()
    motif_hits = {}
    for motif in args.motif:
        ml = motif.lower()
        motif_hits[motif] = [s.get("xUsername") for s in nonwinners if ml in ((s.get("content") or "").lower())]

    fatal = {name: bool(fn(lower)) for name, fn in FATAL_PATTERNS.items()}

    unwhitelisted_5plus = sum(1 for h in all_hits if h["n"] >= 5 and not h["whitelisted"])
    unwhitelisted_6plus = sum(1 for h in all_hits if h["n"] >= 6 and not h["whitelisted"])
    fatal_count = sum(1 for v in fatal.values() if v)
    motif_contamination = {m:h for m,h in motif_hits.items() if h}

    decision = "PASS"
    reasons = []
    if unwhitelisted_5plus:
        decision = "FAIL"; reasons.append(f"unwhitelisted_5gram_plus={unwhitelisted_5plus}")
    if fatal_count:
        decision = "FAIL"; reasons.append(f"fatal_patterns={fatal_count}")

    result = {
        "tool": "rally-loser-dna-scan.py",
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "content": str(content_path),
        "contentChars": len(content),
        "nonWinnerCorpus": len(nonwinners),
        "ngramSummary": summary,
        "unwhitelisted5gramPlus": unwhitelisted_5plus,
        "unwhitelisted6gramPlus": unwhitelisted_6plus,
        "motifHits": motif_hits,
        "fatalLoserPatterns": fatal,
        "decision": decision,
        "reasons": reasons,
    }
    Path(args.out_json).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    md = []
    md.append("# LOSER-DNA STERILIZATION REPORT\n\n")
    md.append(f"Content: `{content_path}`\n\n")
    md.append(f"Non-winner corpus: **{len(nonwinners)}**\n\n")
    md.append("## Exact Overlap\n\n")
    md.append("| n-gram | total hits | unwhitelisted hits |\n|---|---:|---:|\n")
    for n in [8,7,6,5,4]:
        s = summary[str(n)]
        md.append(f"| {n} | {s['total']} | {s['unwhitelisted']} |\n")
    md.append("\n## Motif Hits\n\n")
    if motif_hits:
        for m,h in motif_hits.items(): md.append(f"- `{m}`: {len(h)} hits {h[:10]}\n")
    else:
        md.append("No motifs provided.\n")
    md.append("\n## Fatal Loser Patterns\n\n")
    for k,v in fatal.items(): md.append(f"- {k}: {'RISK' if v else 'CLEAR'}\n")
    md.append(f"\n## Decision: {decision}\n")
    if reasons: md.append("Reasons: " + ", ".join(reasons) + "\n")
    if args.out_md:
        Path(args.out_md).write_text("".join(md), encoding="utf-8")
    else:
        print("".join(md))

    print(f"LOSER-DNA SCAN: {decision} [{', '.join(reasons) if reasons else 'clean'}]")
    sys.exit(0 if decision == "PASS" else 1)

if __name__ == "__main__":
    main()
