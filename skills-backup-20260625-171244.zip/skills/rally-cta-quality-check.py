#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CTA Quality Max Formula checker (#0T+)."""
import argparse, json, re, sys
from pathlib import Path

VERBS = ["reply", "comment", "tell me", "choose", "name", "check", "visit", "learn", "join", "mint", "compare", "pick", "show me", "share", "test", "spend", "route"]
GENERIC = ["thoughts?", "what do you think?", "agree?", "drop yours", "let me know"]
CHOICE_MARKERS = [" or ", ":", "which", "choose", "pick", "rather", "first"]

def extract_last_cta(text):
    paras=[p.strip() for p in re.split(r"\n\s*\n", text.strip()) if p.strip()]
    tail="\n\n".join(paras[-2:]) if paras else text.strip()
    return tail

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--out-json", default=None)
    ap.add_argument("--out-md", default=None)
    ap.add_argument("--require-url", default=None)
    args=ap.parse_args()
    text=Path(args.content).read_text(encoding="utf-8").strip()
    tl=text.lower()
    cta=extract_last_cta(text)
    cl=cta.lower()
    verbs=[v for v in VERBS if v in cl]
    has_verb=bool(verbs)
    has_url=(args.require_url.lower() in tl) if args.require_url else True
    generic=[g for g in GENERIC if g in cl]
    has_choice=any(m in cl for m in CHOICE_MARKERS) or "?" in cta
    # concrete object heuristic: numbers, protocol nouns, or specific campaign nouns
    object_terms=["rlp","gas","campaign","usdc","whitelist","genlayer","llm","consensus","reviewer","judge","app.rally.fun","wingston","creator","access","reward","founder","founder-mode","draft","take","process","permission","decision","problem","work","brief","quality","owner","ownership","verdict","genius","mid","cooked","restaking","yield","risk","risks","floor","trend","product","company","protocol","dashboard","apr"]
    objects=[o for o in object_terms if o in cl]
    has_object=bool(objects)
    low_friction=has_choice and has_object and ("?" in cta or any(v in cl for v in ["choose","pick","tell me","name","what would","which"]))
    thesis_integrated=has_object and not generic
    score=sum([has_verb, has_object, has_choice, low_friction, thesis_integrated])
    # rank heuristic
    if has_verb and has_choice and has_object and (args.require_url is None or has_url): rank=1
    elif has_verb and has_object and "?" in cta: rank=2
    elif args.require_url and has_url and has_verb: rank=3
    elif has_choice and has_object: rank=4
    elif "?" in cta: rank=5
    elif generic: rank=6
    else: rank=7
    decision="PASS" if score>=4 and rank<=4 and has_url and not generic else "FAIL"
    result={"tool":"rally-cta-quality-check.py","content":args.content,"ctaQuote":cta,"behavioralVerb":has_verb,"verbs":verbs,"concreteObject":has_object,"objects":objects,"campaignNativeChoice":has_choice,"lowFrictionReplyPath":low_friction,"thesisIntegrated":thesis_integrated,"genericCTA":generic,"requiredUrlPresent":has_url,"ctaStrengthRank":rank,"ctaFormulaScore":score,"decision":decision}
    if args.out_json: Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    md=f"""# CTA QUALITY CHECK (#0T+)

CTA quote:
```text
{cta}
```

- Behavioral verb: {has_verb} {verbs}
- Concrete object: {has_object} {objects}
- Campaign-native choice/options: {has_choice}
- Low-friction reply path: {low_friction}
- Thesis-integrated: {thesis_integrated}
- Required URL present: {has_url}
- Generic CTA: {generic or 'NONE'}
- CTA Strength Rank: {rank}
- CTA Formula Score: {score}/5
- Decision: **{decision}**
"""
    if args.out_md: Path(args.out_md).write_text(md,encoding="utf-8")
    print(f"CTA QUALITY CHECK: {decision} [score={score}/5 rank={rank}]")
    sys.exit(0 if decision=="PASS" else 1)
if __name__=="__main__": main()
