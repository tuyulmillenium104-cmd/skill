#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EP semantic deduction review gate (#0W).

This is a structured heuristic red-team. It checks whether obvious semantic EP4 risks
remain after EP deduction map, CTA, OAA, and TQ reports. It cannot replace human judgment,
but it prevents final output without a documented semantic clearance.
"""
import argparse, json, re, sys, time
from pathlib import Path

GENERIC_PHRASES = [
    "future of", "game changer", "this is why", "not just", "more than", "unlock", "revolutionary",
    "strong opinion", "hot take"  # only risky if unsupported by specifics
]
MEMORABLE_MARKERS = [
    "cosplay", "painted", "laundering", "access budget", "single throat", "upstream", "receipt",
    "flywheel", "keycard", "queue position", "working fuel"
]

def load_json(path):
    return json.load(open(path, encoding="utf-8")) if path else {}

def sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if s.strip()]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--ep-map", required=True)
    ap.add_argument("--cta-report", default=None)
    ap.add_argument("--oaa-report", default=None)
    ap.add_argument("--tq-report", default=None)
    ap.add_argument("--out-json", required=True)
    ap.add_argument("--out-md", required=True)
    args = ap.parse_args()

    text = Path(args.content).read_text(encoding="utf-8").strip()
    tl = text.lower()
    ep = load_json(args.ep_map)
    cta = load_json(args.cta_report)
    oaa = load_json(args.oaa_report)
    tq = load_json(args.tq_report)

    risks=[]; passes=[]

    # Hard dependencies
    if ep.get("decision") != "PASS" or ep.get("unknownClassCount", 0):
        risks.append("EP deduction map not fully clear")
    else:
        passes.append("EP deduction map clear")

    if cta:
        if cta.get("decision") != "PASS" or cta.get("ctaFormulaScore",0) < 4:
            risks.append("CTA not strong enough for EP5")
        elif not cta.get("lowFrictionReplyPath", False):
            risks.append("CTA lacks low-friction reply path")
        else:
            passes.append("CTA reply engine clear")

    if tq and tq.get("decision") != "PASS":
        risks.append("TQ/format issue may reduce EP read-through")
    else:
        passes.append("TQ format clear")

    if oaa and oaa.get("decision") != "PASS":
        risks.append("OAA structure issue may reduce originality/engagement")
    else:
        passes.append("OAA structure clear")

    # Semantic heuristics
    sents=sentences(text)
    first=sents[0].lower() if sents else ""
    has_clear_stance = any(x in tl for x in ["verdict:", "cooked", "genius", "mid", "my take", "hot take", "opinion:", "founder-mode opinion"])
    has_question = "?" in text
    has_memorable = any(m in tl for m in MEMORABLE_MARKERS) or any(len(w)>10 for w in re.findall(r"\b[a-z]+\b", tl))
    generic_hits=[g for g in GENERIC_PHRASES if g in tl]

    if not has_clear_stance and any(x in tl for x in ["verdict", "take", "opinion", "founder mode"]):
        risks.append("stance may not be explicit enough")
    else:
        passes.append("stance explicit or mission-compatible")

    if not has_memorable:
        risks.append("no obviously memorable/quotable phrase detected")
    else:
        passes.append("memorable phrase present")

    if generic_hits and not any(m in tl for m in MEMORABLE_MARKERS):
        risks.append(f"generic phrase risk without strong distinctive frame: {generic_hits}")

    # Check abstract-to-concrete balance
    concrete_terms = re.findall(r"\b(?:dashboard|validator|liquidity|telegram|google docs|screenshots|gas|campaign|whitelist|reviewer|llm|consensus|brief|wallet|apr|restaking|yield|process|draft)\b", tl)
    if len(concrete_terms) < 3 and len(text) > 500:
        risks.append("low concrete-detail density for long post")
    else:
        passes.append("concrete detail density acceptable")

    # Brand bridge trust heuristic
    if "@rallyonchain" in tl:
        if re.search(r"that is why @|this is exactly why @|@rallyonchain (solves|is the answer)", tl):
            risks.append("brand bridge may read promotional")
        else:
            passes.append("brand bridge not obviously promotional")
    else:
        passes.append("brand bridge N/A or no mention required")

    # Credible EP4 sentence synthesis for unresolved risks
    credible = []
    for r in risks:
        credible.append(f"A judge could write: {r}.")

    decision = "PASS" if not risks else "FAIL"
    result = {
        "tool":"rally-ep-semantic-review.py",
        "generated":time.strftime("%Y-%m-%d %H:%M:%S"),
        "contentChars":len(text),
        "passes":passes,
        "risks":risks,
        "credibleEP4Sentences":credible,
        "decision":decision
    }
    Path(args.out_json).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    md=[]
    md.append("# EP SEMANTIC DEDUCTION REVIEW (#0W)\n\n")
    md.append(f"Decision: **{decision}**\n\n")
    md.append("## Passes\n")
    md += [f"- {p}\n" for p in passes] or ["- none\n"]
    md.append("\n## Risks\n")
    md += [f"- {r}\n" for r in risks] or ["- none\n"]
    md.append("\n## Credible EP4 Sentences Remaining\n")
    md += [f"- {c}\n" for c in credible] or ["- none\n"]
    Path(args.out_md).write_text("".join(md), encoding="utf-8")
    print(f"EP SEMANTIC REVIEW: {decision} [{len(risks)} risks]")
    sys.exit(0 if decision=="PASS" else 1)

if __name__ == "__main__":
    main()
