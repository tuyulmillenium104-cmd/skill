# ADAPTIVE RATCHET LESSONS — ACTIVE

**Status:** ACTIVE SKILL FILE. Load this in Step 0.

This file stores concise active lessons discovered from real Rally verdicts, mission pools, and live misses. It is not an archive. Future runs must enforce these lessons.

---

## 2026-06-25 — Founder Mode mission-0 — polished story / brand bridge / media drag

TYPE: DEDUCTION
SOURCE: Real Rally verdict, EP4/TQ4 on Founder Mode mission-0
EVIDENCE:
- "reads a bit polished and polished storytelling can sometimes reduce raw authenticity"
- "brand mention is integrated but slightly promotional"
- "media link appears to be a direct image URL rather than a more contextualized media integration"
ACTIVE RULE:
- For personal-experience campaigns, check for polished aphorism lines that sound like a keynote quote rather than lived speech.
- Brand bridge must emerge from the exact story pain, not read like campaign copy.
- If media is not required, text-only is safest. If media is used, it must be native and referenced by the text.
CHECK:
- Flag lines like "Founder mode is not X, it is Y" / "That is why @Brand makes sense" / raw http image links.
ACTION:
- Rewrite polished summary into concrete action/result.
- Rewrite brand bridge as story pain -> brand mechanism.
- Remove media or upload native with explicit textual reference.

---

## 2026-06-25 — Multi-campaign EP verdict mining — CTA max formula

TYPE: CTA
SOURCE: Mining 1,474 real EP verdicts across local datasets
EVIDENCE:
- EP5 CTAs often use concrete resource routing or binary choice: "What would you spend your first 200 RLPs on..."
- EP4 deductions often say "lacks a direct, explicit CTA" even when conversation potential is praised.
ACTIVE RULE:
- CTA max candidate = behavioral verb + concrete object + campaign-native choice + low-friction reply path.
CHECK:
- Run `rally-cta-quality-check.py` before final.
ACTION:
- If CTA score <4/5 or rank >4, revise CTA and rerun #0S2 + final integrity.

---

## 2026-06-25 — Global active campaign mining — active gate pressure map

TYPE: GLOBAL-ACTIVE-MINING
SOURCE: all currently active Rally campaigns available via public campaigns API
EVIDENCE:
- EP active pressure: conversation_limited = 15070
- EP active pressure: cta_weak = 11681
- EP active pressure: compliance_issue = 5484
- EP active pressure: value_not_exceptional = 5258
- EP active pressure: hook_weak = 4488
- EP active pressure: structure_density = 4278
ACTIVE RULE:
- Before writing in any active campaign, run campaign cartography and treat current active EP pressure points as priors, subordinate to mission-specific data.
CHECK:
- GLOBAL-ACTIVE-RALLY-MAP.md exists and mission-specific map exists.
ACTION:
- If mission data is sparse, use global active pressure map to harden CTA, conversation, value, hook, structure/TQ, specificity, and generic-risk checks.

---

## 2026-06-25 — Global EP4 subtype playbook — active campaigns

TYPE: GLOBAL-EP-DEDUCTION
SOURCE: Active campaign EP<5 verdict mining
EVIDENCE:
- cta.other: 9508
- hook.not_sharp: 8273
- media.raw_or_unintegrated: 6760
- conversation.other: 6424
- value.other: 4049
- structure.formatting: 4011
- specificity.missing: 3186
- generic.formulaic: 2835
- structure.dense_or_long: 2789
- cta.no_direct_prompt: 2353
ACTIVE RULE:
- Use GLOBAL-EP4-PLAYBOOK.md as global prior after mission-specific EP map. Top recurring subtypes harden CTA, conversation, value, hook, structure/media, generic, brand, argument boldness, and specificity gates.
CHECK:
- Mission-specific EP map PASS unknown=0, then semantic review checks against global top subtypes.
ACTION:
- If content matches any top global subtype risk, revise before final.
