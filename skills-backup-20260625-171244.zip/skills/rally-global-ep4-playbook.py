#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Global EP4/EP<5 active-campaign playbook miner.

Fetches all active campaigns, mines Engagement Potential non-max verdicts,
classifies deduction sentences into operational subtypes, and writes a global
playbook + active ratchet entry.
"""
import argparse, json, re, time, urllib.request, sys
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone

UA='Mozilla/5.0'
CAMPAIGNS_URL='https://app.rally.fun/api/campaigns?page={page}&limit={limit}'
SUBS_URL='https://app.rally.fun/api/submissions?campaignAddress={addr}&limit={limit}&offset={offset}'

def http_json(url):
    req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'application/json'})
    return json.loads(urllib.request.urlopen(req,timeout=45).read().decode('utf-8','ignore'))

def parse_dt(s):
    return datetime.fromisoformat(s.replace('Z','+00:00')) if s else None

def fetch_active(max_campaigns=0):
    rows=[]; page=1
    while True:
        d=http_json(CAMPAIGNS_URL.format(page=page,limit=50)); rows+=d.get('campaigns',[])
        if not d.get('pagination',{}).get('hasNext'): break
        page+=1
    now=datetime.now(timezone.utc)
    active=[c for c in rows if c.get('endDate') and parse_dt(c['endDate'])>=now and not c.get('deletedAt')]
    active=sorted(active,key=lambda c:c['endDate'])
    return active[:max_campaigns] if max_campaigns else active

def fetch_subs(addr, limit=300, max_total=1200):
    subs=[]; off=0
    while off<max_total:
        batch=http_json(SUBS_URL.format(addr=addr,limit=limit,offset=off))
        if not isinstance(batch,list) or not batch: break
        subs+=batch
        if len(batch)<limit: break
        off+=limit; time.sleep(0.1)
    return subs

def atto(v):
    try: return int(v)/1e18
    except: return 0

def ep_score(sub):
    for a in sub.get('analysis') or []:
        if 'Engagement Potential' in (a.get('category') or ''):
            return atto(a.get('atto_score')), atto(a.get('atto_max_score')), a.get('analysis','')
    return None,None,''

def sents(t):
    return [x.strip() for x in re.split(r'(?<=[.!?。；;])\s+|\n+', t or '') if x.strip()]

NEG_MARKERS=[
 'however',' but ','though','although','while','yet','one limitation','limitation','weakness','lacks','lack of','missing','could','would benefit','slightly','somewhat','not fully','limited','reduces','dampens','falls short','stops short','not enough','does not quite','less ','minor','issue','concern','risk','may reduce','may limit','notably','moderate','competent','acceptable','solid but','good but','effective but','underdeveloped','generic','formulaic','templated','dense','too long','media','url','image','cta','call-to-action','question','conversation','value delivery','not exceptional','promotional','brand','specificity','vague','unclear','overlap','similar','common','familiar','predictable','ai-generated','platitudes','no replies','low-effort'
]
PRAISE_ONLY=[
 'excellent','exceptional','strong','highly effective','compelling','powerful','clear and compelling','perfectly aligns','fully complies','well-structured','easy to follow','logical flow','successfully','demonstrates','effective hook','strong hook','solid hook' # solid hook can be praise, but if but/limited exists caught by neg
]

def is_candidate(sent):
    sl=' '+sent.lower()+' '
    if any(m in sl for m in NEG_MARKERS): return True
    # contrast forms with comma/semicolon
    if re.search(r'\b(reads|feels|lands|comes across)\b.{0,80}\b(more|less|like|as)\b', sl): return True
    # middle praise in EP nonmax
    if any(re.search(r'\b'+re.escape(w)+r'\b', sl) for w in ['solid','good','effective','competent','decent','adequate','reasonable','functional']): return True
    return False

def praise_only(sent):
    sl=' '+sent.lower()+' '
    has=any(p in sl for p in PRAISE_ONLY)
    neg=any(m in sl for m in NEG_MARKERS)
    # avoid substring trap, if only positive compliance language skip
    compliance_positive=any(p in sl for p in ['fully complies','perfectly aligns','successfully adheres','clear verdict','well-reasoned argument','logical flow'])
    return (has or compliance_positive) and not neg

SUBTYPES={
 'cta.no_direct_prompt':['no direct','lacks a direct','no explicit','lack of a clear call','does not include a clear cta','no cta','absence of a call'],
 'cta.generic_or_soft':['generic cta','soft','implicit cta','mildly generic','thoughts','what do you think','curious how','could be stronger'],
 'cta.no_reply_path':['does not pose','no question','lacks a question','no prompt','one-way','declarative ending','does not explicitly invite'],
 'conversation.limited':['conversation potential is limited','moderate conversation','limited conversation','may limit replies','less interactive','not likely to spark','does not spark'],
 'conversation.niche_or_narrow':['niche audience','limited audience','narrow','too niche'],
 'value.solid_not_exceptional':['solid value','value delivery is solid','not exceptional','not especially','good but not','competent','adequate'],
 'value.underdeveloped':['underdeveloped','could go deeper','more depth','surface-level','not fully developed','briefly mentioned'],
 'hook.not_sharp':['hook','opening','opener','could be stronger','not punchy','lacks immediacy','curiosity-driven rather than'],
 'structure.dense_or_long':['dense','too long','length','longform','readability','completion','wall of text','over-explains'],
 'structure.formatting':['formatting','line breaks','paragraph','visual','scannable','bullet'],
 'media.raw_or_unintegrated':['media','image','url','link','raw','not referenced','contextualized','broken'],
 'generic.formulaic':['generic','formulaic','templated','standard','common','familiar','predictable','expected'],
 'generic.ai_or_polished':['ai-generated','polished','overly polished','scripted','platitudes','corporate-speak'],
 'specificity.missing':['vague','specific','concrete','detail','personal example','lacks detail','not enough examples'],
 'brand.promotional_bridge':['promotional','brand mention','forced','plug','campaign-like','sponsored','trust'],
 'argument.not_bold_enough':['not controversial','lacks boldness','not bold','safe','consensus wisdom','not polarizing'],
 'argument.evidence_gap':['evidence','well-reasoned','reasoned','proof','support','substantiation','not enough support'],
 'external.reach_metrics':['hashtags','posting hour','initial momentum','likes','impressions','metrics','discoverability'],
 'rq.no_or_generic_replies':['no replies','generic praise','low-effort','platitudes','vague replies','templated replies'],
}

def classify(sent):
    sl=sent.lower(); hits=[]
    for k,pats in SUBTYPES.items():
        if any(p in sl for p in pats): hits.append(k)
    if hits: return hits
    # Broad fallbacks for no unknown silence
    if any(x in sl for x in ['cta','call-to-action','question','prompt','reply','invite']): return ['cta.other']
    if any(x in sl for x in ['conversation','debate','discussion','engagement']): return ['conversation.other']
    if any(x in sl for x in ['value','solid','competent','underdeveloped','depth','insight']): return ['value.other']
    if any(x in sl for x in ['hook','opening','opener']): return ['hook.other']
    if any(x in sl for x in ['structure','format','dense','length','readability']): return ['structure.other']
    if any(x in sl for x in ['generic','common','standard','familiar','ai-generated','polished']): return ['generic.other']
    if any(x in sl for x in ['specific','concrete','vague','detail']): return ['specificity.other']
    if any(x in sl for x in ['media','url','image','link']): return ['media.other']
    if any(x in sl for x in ['brand','promotional','mention']): return ['brand.other']
    if any(x in sl for x in ['however','but','though','while','yet','could','would','slightly','limited','weakness','falls short','not fully']): return ['semantic.other_deduction']
    return ['semantic.reviewed_misc']

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out-dir',default='rally-data/global-active-ep4')
    ap.add_argument('--max-campaigns',type=int,default=0)
    ap.add_argument('--sub-limit',type=int,default=1200)
    args=ap.parse_args()
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    active=fetch_active(args.max_campaigns)
    counts=Counter(); evidence=defaultdict(list); total_sents=0; ep_nonmax=0; campaigns=[]
    for i,c in enumerate(active,1):
        addr=c['intelligentContractAddress']; title=c['title']
        print(f'[{i}/{len(active)}] {title}')
        try: subs=fetch_subs(addr,max_total=args.sub_limit)
        except Exception as e: print(' fail',e); continue
        campaigns.append({'title':title,'address':addr,'submissions':len(subs),'endDate':c.get('endDate')})
        for sub in subs:
            score,mx,txt=ep_score(sub)
            if score is None or score>=5: continue
            ep_nonmax+=1
            for sent in sents(txt):
                if praise_only(sent): continue
                if is_candidate(sent):
                    total_sents+=1
                    for cls in classify(sent):
                        counts[cls]+=1
                        if len(evidence[cls])<12: evidence[cls].append({'campaign':title,'author':sub.get('xUsername'),'ep':score,'sentence':sent})
        time.sleep(0.1)
    result={'generated':time.strftime('%Y-%m-%d %H:%M:%S'),'activeCampaigns':len(active),'epNonMaxVerdicts':ep_nonmax,'deductionSentences':total_sents,'subtypeCounts':dict(counts),'evidence':dict(evidence),'campaigns':campaigns}
    (out/'global-ep4-playbook.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=[]
    md.append('# GLOBAL EP4 / EP<5 PLAYBOOK\n\n')
    md.append(f"Generated: {result['generated']}\n\n")
    md.append(f"Active campaigns mined: **{len(active)}**  \nEP nonmax verdicts: **{ep_nonmax}**  \nDeduction sentences: **{total_sents}**\n\n")
    md.append('## Subtype Counts\n\n| Subtype | Count |\n|---|---:|\n')
    for k,v in counts.most_common(): md.append(f'| {k} | {v} |\n')
    md.append('\n## Operational Rules by Top Subtype\n')
    rules={
      'cta.no_direct_prompt':'Always include a direct behavioral CTA unless format forbids it.',
      'cta.generic_or_soft':'Avoid generic/soft prompts. Use campaign-native choice or personal experience CTA.',
      'conversation.limited':'Add a reply path that asks for a specific memory, choice, or disagreement.',
      'value.solid_not_exceptional':'Add a named lens, surprising mechanism, or memorable phrase.',
      'hook.not_sharp':'Open with verdict, contradiction, concrete pain, or specific scene.',
      'structure.dense_or_long':'Use short paragraphs and remove non-essential explanatory drag.',
      'media.raw_or_unintegrated':'No raw media URL. If media used, native and referenced.',
      'generic.formulaic':'Name a fresh category or use a concrete lived mechanism.',
      'brand.promotional_bridge':'Brand bridge must emerge from exact story/argument pain.',
      'argument.not_bold_enough':'For hot take/verdict campaigns, make a costly stance, not consensus wisdom.',
      'specificity.missing':'Add who/what/when/tool/action/result details.',
    }
    for k,v in counts.most_common(20):
        md.append(f'\n### {k} ({v})\n')
        md.append(f"Rule: {rules.get(k,'Review evidence and create mission-specific avoidance rule.')}\n\n")
        for e in evidence[k][:5]: md.append(f"- {e['campaign']} @{e['author']} EP{e['ep']}: {e['sentence'][:360]}\n")
    (out/'GLOBAL-EP4-PLAYBOOK.md').write_text(''.join(md),encoding='utf-8')
    # append ratchet
    ratchet=Path('skills/ADAPTIVE-RATCHET-LESSONS.md')
    entry='\n---\n\n## '+time.strftime('%Y-%m-%d')+' — Global EP4 subtype playbook — active campaigns\n\nTYPE: GLOBAL-EP-DEDUCTION\nSOURCE: Active campaign EP<5 verdict mining\nEVIDENCE:\n'
    for k,v in counts.most_common(10): entry += f'- {k}: {v}\n'
    entry+='ACTIVE RULE:\n- Use GLOBAL-EP4-PLAYBOOK.md as global prior after mission-specific EP map. Top recurring subtypes harden CTA, conversation, value, hook, structure/media, generic, brand, argument boldness, and specificity gates.\nCHECK:\n- Mission-specific EP map PASS unknown=0, then semantic review checks against global top subtypes.\nACTION:\n- If content matches any top global subtype risk, revise before final.\n'
    ratchet.write_text(ratchet.read_text(encoding='utf-8')+entry,encoding='utf-8')
    print('GLOBAL EP4 PLAYBOOK COMPLETE')
    print(out/'GLOBAL-EP4-PLAYBOOK.md')

if __name__=='__main__': main()
