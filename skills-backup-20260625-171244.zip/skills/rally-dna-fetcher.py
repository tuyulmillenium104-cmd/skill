#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RALLY DNA FETCHER v1.0 — PERBAIKAN MASALAH INTI
================================================
MASALAH (akar yang diperbaiki tool ini):
  Skill rally-content-engine V7.7 butuh "Winner DNA" dan "Non-Winner DNA"
  (konten ASLI tweet pemenang & yang kalah) untuk: angle-fit, structure-gap-scan,
  motif-overlap, winner-DNA markers, kompetitor-failure-audit.

  NAMUN Rally submissions API (https://app.rally.fun/api/submissions) HANYA
  mengembalikan: tweetId, xUsername, skor, dan judge-analysis (vonis juri yang
  hanya mengutip FRAGMEN konten). Field tweetText/content TIDAK ADA.

  => Skill selama ini TIDAK BISA mengambil data konten asli. DNA dibangun dari
     ingatan/asumsi, bukan data nyata = pelanggaran berat Meta-Rule #0B
     (Winner DNA = CAMPAIGN-SCOPED, ground truth > self-score).

SOLUSI (tool ini):
  1. Ambil SEMUA submission dari Rally API (skor + vonis juri).
  2. Untuk SETIAP submission, ambil KONTEN TWEET ASLI via multi-source fallback:
       a) cdn.syndication.twimg.com/tweet-result  (PRIMER — teks lengkap + media)
       b) api.fxtwitter.com                        (fallback #1)
       c) publish.x.com/oembed                     (fallback #2, jika masih hidup)
       d) ekstraksi kutipan dari judge-analysis     (TERAKHIR — tweet dihapus/tidak akses)
  3. Hitung skor per-gate (EP/OAA/TQ/CA/IA/CC/RQ) ternormalisasi.
  4. Klasifikasikan WINNER (ALL-MAX / top) vs NON-WINNER.
  5. Output: dna.json (mesin) + DNA-WINNER.md + DNA-NONWINNER.md (dibaca skill)
     + submissions_enriched.json (cache lengkap).

PAKAI:
  python3 skills/rally-dna-fetcher.py --address 0x...
  python3 skills/rally-dna-fetcher.py --address 0x... --limit 200 --top-pct 20
  python3 skills/rally-dna-fetcher.py --address 0x... --out rally-data/learn/0xABC
  python3 skills/rally-dna-fetcher.py --address 0x... --mission mission-0   # [v1.2] filter per-misi

CATATAN: Tool ini TIDAK butuh auth/api-key (semua endpoint publik).
         Rate-limit aman: jeda antar request tweet, retry dengan backoff.

v1.2 (2026-06-24): + --mission filter. KAMUS: campaign multi-misi punya perintah
    BERBEDA per misi (mis. mission-0=WHAT/WHY, mission-1=WHO needs it). DNA yang
    dicampur lintas misi = TERKONTAMINASI (Meta-Rule #0B violation). Filter wajib.
"""
import sys, os, re, json, time, argparse, urllib.request, urllib.error, urllib.parse

# ===========================================================================
# KONFIGURASI
# ===========================================================================
RALLY_CAMPAIGN_URL = "https://app.rally.fun/api/campaigns/{addr}"
RALLY_SUBMISSIONS_URL = "https://app.rally.fun/api/submissions?campaignAddress={addr}&limit={limit}&offset={offset}"
SYNDICATION_URL = "https://cdn.syndication.twimg.com/tweet-result?id={tid}&token=a"
FXITTER_URL = "https://api.fxtwitter.com/i/status/{tid}"
FXITTER_USER_URL = "https://api.fxtwitter.com/{user}/status/{tid}"
OEMBED_URL = "https://publish.x.com/oembed?url={url}&omit_script=true"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
TIMEOUT = 25               # untuk API Rally
TIMEOUT_TWEET = 10         # lebih singkat utk fetch tweet per-sumber
SLEEP_BETWEEN = 0.15       # jeda antar request tweet (sopan ke Twitter CDN)
SLEEP_BACKOFF = 1.0        # jeda saat retry

# Pemetaan kategori vonis juri -> kode gate skill
CATEGORY_MAP = {
    "engagement potential": "EP",
    "originality": "OAA",
    "technical quality": "TQ",
    "content alignment": "CA",
    "information accuracy": "IA",
    "campaign compliance": "CC",
    "reply quality": "RQ",
}
GATE_ORDER = ["CA", "IA", "CC", "OAA", "EP", "TQ", "RQ"]

# ===========================================================================
# HTTP HELPERS
# ===========================================================================
def http_get(url, accept="application/json"):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
    return urllib.request.urlopen(req, timeout=TIMEOUT).read().decode("utf-8", "ignore")

def http_get_safe(url, accept="application/json", timeout=None):
    """GET yang tidak raise; return (text, status). Ikuti redirect."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
        resp = urllib.request.urlopen(req, timeout=timeout or TIMEOUT)
        return resp.read().decode("utf-8", "ignore"), resp.getcode()
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", "ignore")
        except Exception:
            body = ""
        return body, e.code
    except Exception:
        return "", 0

# ===========================================================================
# SUMBER KONTEN TWEET (multi-fallback)
# ===========================================================================
def strip_html(html):
    """Bersihkan tag HTML -> teks bersih."""
    # ganti <br> dan <p> jadi newline dulu
    h = re.sub(r"(?i)<br\s*/?>", "\n", html)
    h = re.sub(r"(?i)</p>", "\n", h)
    txt = re.sub(r"<[^>]+>", "", h)
    # decode entitas umum
    txt = (txt.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
              .replace("&#39;", "'").replace("&quot;", '"').replace("&nbsp;", " "))
    return re.sub(r"\n{3,}", "\n\n", txt).strip()

def fetch_syndication(tweet_id):
    """Sumber PRIMER: cdn.syndication.twimg.com. Return (text, source) atau None."""
    body, code = http_get_safe(SYNDICATION_URL.format(tid=tweet_id), timeout=TIMEOUT_TWEET)
    if code != 200 or not body:
        return None
    try:
        d = json.loads(body)
    except Exception:
        return None
    tn = d.get("__typename", "")
    if tn == "TweetTombstone":
        return ("__DELETED__", "syndication-tombstone")
    txt = d.get("text") or d.get("full_text")
    if txt:
        return (txt, "syndication")
    return None

def fetch_fxtwitter(tweet_id, username=None):
    """Fallback #1: api.fxtwitter.com."""
    urls = []
    if username:
        urls.append(FXITTER_USER_URL.format(user=username, tid=tweet_id))
    urls.append(FXITTER_URL.format(tid=tweet_id))
    for u in urls:
        body, code = http_get_safe(u, timeout=TIMEOUT_TWEET)
        if code == 200 and body:
            try:
                d = json.loads(body)
                t = d.get("tweet") or {}
                txt = t.get("text") or t.get("full_text")
                if txt:
                    return (txt, "fxtwitter")
            except Exception:
                continue
    return None

def fetch_oembed(tweet_id, username):
    """Fallback #2: oEmbed (sering hanya HTML error sekarang, tapi dicoba)."""
    url = OEMBED_URL.format(url=urllib.parse.quote(
        f"https://x.com/{username}/status/{tweet_id}", safe=""))
    body, code = http_get_safe(url, timeout=TIMEOUT_TWEET)
    if code == 200 and body and body.lstrip().startswith("{"):
        try:
            d = json.loads(body)
            html = d.get("html", "")
            txt = strip_html(html)
            # buang baris akhir yang biasanya "MM DD, YYYY · ..." (timestamp oEmbed)
            txt = re.sub(r"\s*\d{1,2}:\d{2}.*$", "", txt).strip()
            if txt and len(txt) > 8:
                return (txt, "oembed")
        except Exception:
            pass
    return None

def extract_quotes_from_analysis(analysis_list, username):
    """TERAKHIR: tweet dihapus/tidak terakses. Ambil fragmen konten yang juri KUTIP
    dari vonis. Bukan teks lengkap, tapi menangkap DNA (frasa khas) lebih baik daripada kosong."""
    quotes = set()
    if not analysis_list:
        return ("", "no-data")
    for a in analysis_list:
        text = (a.get("analysis") or "")
        for m in re.findall(r'[\'\u2018\u2019"]([^\'\u2018\u2019"]{4,120})[\'\u2018\u2019"]', text):
            q = m.strip()
            # skip nama gate/juri/generic
            if q.lower() not in {"rallyonchain", "em-dash", "em dash"} and not q.startswith("@"):
                quotes.add(q)
        # kutipan dengan tanda petik ganda
        for m in re.findall(r'"([^"]{4,120})"', text):
            quotes.add(m.strip())
    frag = " | ".join(sorted(quotes)[:15]) if quotes else ""
    return (frag, "judge-quote-fragments" if frag else "no-data")

def is_truncated(text):
    """syndication memotong tweet panjang (note-tweet/thread) di t.co link ~<320 chars.
    Deteksi: ada t.co link DAN teks pendek = kemungkinan terpotong."""
    if not text:
        return False
    return ("https://t.co/" in text or "http://t.co/" in text) and len(text) < 340

def fetch_tweet_content(tweet_id, username):
    """Coba semua sumber berurutan. Return (text_or_marker, source).
    FIX 2026-06-24: fxtwitter dipakai PERTAMA (beri konten lengkap note-tweet),
    syndication sebagai fallback. Sebelumnya syndication dipakai duluan dan
    menerima teks terpotong tanpa fallback -> DNA cacat."""
    # 1. fxtwitter PERTAMA (konten lengkap, menangani note-tweet/thread)
    r = fetch_fxtwitter(tweet_id, username)
    if r and not is_truncated(r[0]):
        return r
    time.sleep(SLEEP_BETWEEN * 0.4)
    # 2. syndication (fallback; deteksi tombstone)
    r2 = fetch_syndication(tweet_id)
    if r2:
        if r2[0] == "__DELETED__":
            return r2
        # syndication bisa lebih lengkap di kasus tertentu
        if r and len(r[0]) >= len(r2[0]):
            return r
        return r2
    # 3. oembed
    if username:
        r3 = fetch_oembed(tweet_id, username)
        if r3:
            return r3
    # 4. fallback terakhir: fragmen vonis juri
    return None

# ===========================================================================
# SKOR & KLASIFIKASI
# ===========================================================================
def atto_to_human(v):
    try:
        return int(v) / 1e18
    except Exception:
        return 0.0

def gate_scores(analysis_list):
    """Hitung skor per-gate dari array analysis. Return dict {gate: (score, max)}."""
    out = {}
    for a in analysis_list or []:
        cat = (a.get("category") or "").lower()
        gate = None
        for key, g in CATEGORY_MAP.items():
            if key in cat:
                gate = g; break
        if not gate:
            continue
        sc = atto_to_human(a.get("atto_score"))
        mx = atto_to_human(a.get("atto_max_score"))
        if mx <= 0:
            continue
        out[gate] = (sc, mx)
    return out

def normalized_total(gates):
    """Rata-rata skor ternormalisasi (0..1) lintas gate yang ada (tanpa RQ, yang hidup pasca-posting)."""
    vals = [s / m for g, (s, m) in gates.items() if g != "RQ" and m > 0]
    return sum(vals) / len(vals) if vals else 0.0

def all_max(gates):
    """True jika semua gate konten (kecuali RQ) mencapai max."""
    vals = [(s, m) for g, (s, m) in gates.items() if g != "RQ"]
    if not vals:
        return False
    return all(abs(s - m) < 1e-9 for s, m in vals)

def classify(submissions_with_scores, top_pct):
    """Bagi jadi winner vs non-winner.
       WINNER = ALL-MAX atau top top_pct% (jika ALL-MAX kosong).
       NON-WINNER = sisanya."""
    items = [s for s in submissions_with_scores if s["_norm"] is not None]
    items.sort(key=lambda s: s["_norm"], reverse=True)
    allmax = [s for s in items if s["_allmax"]]
    if allmax:
        winners = allmax
    else:
        cut = max(1, int(round(len(items) * top_pct / 100.0)))
        winners = items[:cut]
    winner_ids = set(id(s) for s in winners)
    nonwinners = [s for s in items if id(s) not in winner_ids]
    return winners, nonwinners

# ===========================================================================
# FETCH CAMPAIGN + SUBMISSIONS
# ===========================================================================
def fetch_campaign(address):
    return json.loads(http_get(RALLY_CAMPAIGN_URL.format(addr=address)))

def fetch_all_submissions(address, limit=200):
    all_subs = []
    offset = 0
    page = limit
    while True:
        url = RALLY_SUBMISSIONS_URL.format(addr=address, limit=page, offset=offset)
        batch = json.loads(http_get(url))
        if not isinstance(batch, list) or not batch:
            break
        all_subs.extend(batch)
        if len(batch) < page:
            break
        offset += page
        time.sleep(0.3)
        # pengaman: berhenti jika sudah sangat banyak (default 200 cukup utk mayoritas)
        if offset >= 1000:
            break
    return all_subs

# ===========================================================================
# OUTPUT
# ===========================================================================
def compact_gate_str(gates):
    # gates sudah menyimpan nilai human (score, max) dari gate_scores()
    return " ".join(f"{g}={gates[g][0]:.0f}/{gates[g][1]:.0f}"
                    for g in GATE_ORDER if g in gates)

def md_escape(t):
    return (t or "").replace("|", "\\|")

def write_dna_md(path, header, submissions):
    lines = [f"# {header}", "",
             f"> Jumlah: **{len(submissions)}** submission. Konten asli tweet + vonis juri.",
             "> Sumber konten: syndication.twimg.com / fxtwitter / oembed / judge-quote-fragments.",
             "", "| # | Author | Skor gate | Total% | Konten asli tweet | Sumber konten |", "|---|---|---|---|---|---|"]
    for i, s in enumerate(submissions, 1):
        gates = s["_gates"]
        uname = s.get("xUsername") or "?"
        norm = s["_norm"]
        txt = md_escape((s["_content"] or "").replace("\n", " ⏎ "))
        if len(txt) > 280:
            txt = txt[:277] + "..."
        src = s["_content_source"]
        lines.append(f"| {i} | @{md_escape(uname)} | {compact_gate_str(gates)} | {norm*100:.0f}% | {txt} | {src} |")
    # blok vonis juri (DNA failure patterns)
    lines += ["", "## VONIS JURI (failure/praise DNA per gate)", ""]
    for i, s in enumerate(submissions, 1):
        uname = s.get("xUsername") or "?"
        lines.append(f"### {i}. @{md_escape(uname)}  ({compact_gate_str(s['_gates'])})")
        for a in (s.get("analysis") or []):
            cat = a.get("category", "?")
            sc = atto_to_human(a.get("atto_score")); mx = atto_to_human(a.get("atto_max_score"))
            lines.append(f"- **{cat}** [{sc:.0f}/{mx:.0f}]: {a.get('analysis','')}")
        lines.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

def main():
    ap = argparse.ArgumentParser(description="Rally DNA Fetcher — ambil konten asli winner & non-winner DNA")
    ap.add_argument("--address", required=True, help="Campaign intelligentContractAddress (0x...)")
    ap.add_argument("--limit", type=int, default=200, help="Maks submission diambil (default 200)")
    ap.add_argument("--top-pct", type=float, default=20, help="%% top sebagai winner jika tak ada ALL-MAX (default 20)")
    ap.add_argument("--out", default=None, help="Output dir (default: rally-data/learn/<short-addr>)")
    ap.add_argument("--mission", default=None, help="[v1.2] Filter submission by missionId, mis. 'mission-0'. DNA WAJIB scoped per-misi.")
    ap.add_argument("--no-fetch-content", action="store_true", help="Lewati ambil konten tweet (hanya skor)")
    args = ap.parse_args()

    addr = args.address
    short = addr[:10] if len(addr) > 12 else addr
    mission_tag = f"-{args.mission}" if args.mission else ""
    out_dir = args.out or os.path.join("rally-data", "learn", short + mission_tag)
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 72)
    print(f"RALLY DNA FETCHER v1.0 — {addr}")
    print("=" * 72)

    # 1. Campaign
    print("[1/4] Mengambil campaign...", end=" ")
    try:
        campaign = fetch_campaign(addr)
    except Exception as e:
        print(f"GAGAL: {e}")
        sys.exit(1)
    title = campaign.get("title", "?")
    print(f"OK — {title}")
    campaign_path = os.path.join(out_dir, "campaign.json")
    with open(campaign_path, "w", encoding="utf-8") as f:
        json.dump(campaign, f, ensure_ascii=False, indent=2)

    # 2. Submissions
    print(f"[2/4] Mengambil submissions (limit {args.limit})...", end=" ")
    subs = fetch_all_submissions(addr, args.limit)
    print(f"OK — {len(subs)} submission")
    if not subs:
        print("TIDAK ADA submission. Selesai.")
        sys.exit(0)

    # [v1.2] FILTER MISSION — DNA WAJIB scoped per-misi (perintah beda antar misi)
    if args.mission:
        before = len(subs)
        subs = [s for s in subs if s.get("missionId") == args.mission]
        print(f"      [MISSION FILTER] {args.mission}: {len(subs)}/{before} submission (sisanya misi lain, DIBUANG)")
        if not subs:
            print(f"TIDAK ADA submission untuk mission {args.mission}. Selesai.")
            sys.exit(0)

    # 3. Skor + klasifikasi
    print("[3/4] Menghitung skor per-gate & klasifikasi winner/non-winner...", end=" ")
    enriched = []
    for s in subs:
        g = gate_scores(s.get("analysis"))
        s["_gates"] = g
        s["_norm"] = normalized_total(g)
        s["_allmax"] = all_max(g)
        s["_content"] = None
        s["_content_source"] = "pending"
        enriched.append(s)
    winners, nonwinners = classify(enriched, args.top_pct)
    print(f"OK — {len(winners)} winner, {len(nonwinners)} non-winner")

    # 4. Konten tweet asli (multi-fallback)
    n_ok = n_del = n_quote = n_fail = 0
    if args.no_fetch_content:
        print("[4/4] Ambil konten tweet: SKIP (--no-fetch-content)")
    else:
        print(f"[4/4] Mengambil KONTEN TWEET ASLI untuk {len(enriched)} submission (multi-source)...")
        for idx, s in enumerate(enriched, 1):
            tid = s.get("tweetId"); uname = s.get("xUsername")
            if not tid:
                s["_content_source"] = "no-tweetId"; continue
            r = fetch_tweet_content(str(tid), uname)
            if r:
                txt, src = r
                if txt == "__DELETED__":
                    # tweet dihapus -> ambil fragmen dari vonis juri
                    frag, fsrc = extract_quotes_from_analysis(s.get("analysis"), uname)
                    s["_content"] = frag; s["_content_source"] = fsrc
                    n_del += 1
                else:
                    s["_content"] = txt; s["_content_source"] = src
                    n_ok += 1
            else:
                frag, fsrc = extract_quotes_from_analysis(s.get("analysis"), uname)
                s["_content"] = frag; s["_content_source"] = fsrc
                if frag:
                    n_quote += 1
                else:
                    n_fail += 1
            if idx % 10 == 0:
                print(f"      ...{idx}/{len(enriched)} diproses (OK={n_ok} del={n_del} quote={n_quote} fail={n_fail})")
            time.sleep(SLEEP_BETWEEN)
        print(f"      Selesai: konten-penuh={n_ok} | tweet-dihapus(fragmen-juri)={n_del} | fragmen-juri={n_quote} | gagal={n_fail}")

    # pisahkan ulang winner/nonwinner dgn konten sudah terisi
    winners, nonwinners = classify(enriched, args.top_pct)

    # --- TULIS OUTPUT ---
    # submissions_enriched.json (cache lengkap: skor + konten + vonis)
    enrich_path = os.path.join(out_dir, "submissions_enriched.json")
    serializable = []
    for s in enriched:
        serializable.append({
            "id": s.get("id"), "xUsername": s.get("xUsername"), "tweetId": s.get("tweetId"),
            "periodIndex": s.get("periodIndex"), "missionId": s.get("missionId"),
            "atemporalPoints": s.get("atemporalPoints"), "temporalPoints": s.get("temporalPoints"),
            "gates": {g: list(v) for g, v in s["_gates"].items()},
            "normTotal": s["_norm"], "allMax": s["_allmax"],
            "winner": id(s) in {id(w) for w in winners},
            "content": s["_content"], "contentSource": s["_content_source"],
            "analysis": s.get("analysis"),
        })
    with open(enrich_path, "w", encoding="utf-8") as f:
        json.dump(serializable, f, ensure_ascii=False, indent=2)

    # dna.json (mesin: ringkas untuk konsumsi skill)
    def slim(group):
        return [{
            "author": s.get("xUsername"), "tweetId": s.get("tweetId"), "missionId": s.get("missionId"),
            # _gates sudah human-valued (score, max) dari gate_scores(); JANGAN re-convert
            "gates": {g: v[0] for g, v in s["_gates"].items()},
            "gatesMax": {g: v[1] for g, v in s["_gates"].items()},
            "normTotal": round(s["_norm"], 4), "allMax": s["_allmax"],
            "content": s["_content"], "contentSource": s["_content_source"],
            "judgeAnalysis": [{"category": a.get("category"), "score": atto_to_human(a.get("atto_score")),
                               "max": atto_to_human(a.get("atto_max_score")), "text": a.get("analysis")}
                              for a in (s.get("analysis") or [])],
        } for s in group]
    dna = {
        "tool": "rally-dna-fetcher v1.2", "campaign": title, "address": addr, "mission": args.mission or "ALL",
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"), "totalSubmissions": len(enriched),
        "winners": len(winners), "nonWinners": len(nonwinners),
        "contentRetrieval": {"fullContent": n_ok, "deletedTweetFragments": n_del,
                             "judgeQuoteFragments": n_quote, "failed": n_fail},
        "winnerDNA": slim(winners), "nonWinnerDNA": slim(nonwinners),
    }
    dna_path = os.path.join(out_dir, "dna.json")
    with open(dna_path, "w", encoding="utf-8") as f:
        json.dump(dna, f, ensure_ascii=False, indent=2)

    # DNA-WINNER.md & DNA-NONWINNER.md (dibaca skill langsung)
    write_dna_md(os.path.join(out_dir, "DNA-WINNER.md"),
                 f"WINNER DNA — {title}", winners)
    write_dna_md(os.path.join(out_dir, "DNA-NONWINNER.md"),
                 f"NON-WINNER DNA — {title}", nonwinners)

    print("")
    print("=" * 72)
    print("SELESAI — file output:")
    print(f"  {campaign_path}")
    print(f"  {enrich_path}        (cache lengkap: skor + konten + vonis)")
    print(f"  {dna_path}                       (mesin: ringkas untuk skill)")
    print(f"  {os.path.join(out_dir, 'DNA-WINNER.md')}     ({len(winners)} winner)")
    print(f"  {os.path.join(out_dir, 'DNA-NONWINNER.md')} ({len(nonwinners)} non-winner)")
    print("=" * 72)
    print("PERBAIKAN MASALAH DNA: konten asli tweet kini diambil via syndication/fxtwitter/")
    print("oembed + fallback fragmen-vonis-juri untuk tweet yang dihapus. Skill bisa load")
    print("DNA-WINNER.md / DNA-NONWINNER.md / dna.json untuk Step 2 Winner/Loser DNA.")
    print("Per Meta-Rule #0B: Winner DNA kini CAMPAIGN-SCOPED dari data nyata, bukan asumsi.")

if __name__ == "__main__":
    main()
