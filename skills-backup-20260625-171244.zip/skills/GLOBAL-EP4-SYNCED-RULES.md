# GLOBAL EP4 SYNCED RULES — ACTIVE BASELINE

**Status:** ACTIVE BASELINE SKILL DATA  
**Source:** One-time global mining of active Rally campaigns, 2026-06-25 Asia/Jakarta  
**Source files:**
- `rally-data/global-active-ep4/GLOBAL-EP4-PLAYBOOK.md`
- `rally-data/global-active-ep4/global-ep4-playbook.json`

**Purpose:** This is not a separate gate. This file synchronizes global EP4 learning into the skill baseline. Mission-specific maps remain primary.

---

## PRIORITY ORDER

```text
1. Brief / mission rules
2. Mission-specific winner + deduction maps
3. Campaign-specific data
4. GLOBAL EP4 synced baseline rules in this file
5. Historical memory
```

Global rules are defaults and priors. They do not override mission context.

---

## GLOBAL BASELINE RULES FROM ACTIVE EP4 MINING

### 1. CTA must be behavioral and low-friction

**Global evidence:** CTA weakness is one of the largest active EP4 pressure points.

**Active rule:**
- If campaign format allows CTA, use a behavioral CTA.
- Target formula: behavioral verb + concrete object + campaign-native choice + low-friction reply path.

**Detect:**
- no direct prompt;
- generic or soft CTA;
- no reply path;
- action CTA without conversation path.

**Fix:**
- Use `choose`, `tell me`, `name`, `reply`, `visit/check/test + specific question`.
- Avoid `thoughts?`, `what do you think?`, `let me know`.

---

### 2. Conversation potential must create a specific reply path

**Global evidence:** conversation-limited appears repeatedly in EP4 verdicts.

**Active rule:**
- Do not merely end with a statement.
- Ask for a specific memory, choice, disagreement, verdict, or use case.

**Fix examples:**
- `Which would you choose: X or Y?`
- `What is the smallest X you fixed?`
- `What would you do with your first 200 RLP?`
- `Which verdict would you defend: Genius, Mid, or Cooked?`

---

### 3. Hook must be sharp in the first line

**Global evidence:** hook-not-sharp is a recurring EP4 reason.

**Active rule:**
- Open with verdict, contradiction, concrete pain, personal scene, or a named frame.

**Weak:**
- slow context;
- generic intro;
- broad explanation.

**Strong:**
- `Verdict: Cooked.`
- `Founder-mode opinion: employee mode is judgment laundering.`
- `Most crypto points are receipts.`

---

### 4. Value must be exceptional, not merely solid

**Global evidence:** `solid value` / `value delivery not exceptional` recurs in EP4.

**Active rule:**
- Content needs a memorable lens, mechanism, or category the judge can quote.

**Fix:**
- Name a fresh category.
- Add a mechanism, not just an opinion.
- Convert feature list into a usable frame.

Examples:
- `correlation cosplay`
- `creator access budget`
- `queue position`
- `judgment laundering`

---

### 5. Structure must protect readability

**Global evidence:** dense/long/formatting issues recur in EP4 and TQ.

**Active rule:**
- Use short paragraphs.
- Avoid dense mini-essays unless campaign requires longform.
- Remove non-essential explanatory drag.

**Fix:**
- One idea per paragraph.
- Keep sentence rhythm varied.
- Avoid wall-of-text blocks.

---

### 6. Media must not create TQ drag

**Global evidence:** media/raw URL/uncontextualized media repeatedly appears in deductions.

**Active rule:**
- Default to text-only if media is not required.
- If media is used: native upload only, no raw image URL, and text must reference/explain it.

**Fix:**
- Remove media link from body.
- If image is necessary, upload as native attachment and explain why it matters.

---

### 7. Avoid generic/formulaic framing

**Global evidence:** generic/formulaic/template wording is a frequent EP/OAA pressure.

**Active rule:**
- Do not use generic marketing language as the main frame.
- Build from a concrete mechanism, lived action, or named lens.

**Avoid:**
- `game changer`
- `future of`
- `unlock full potential`
- `not just X, but Y` unless earned by specifics.

---

### 8. Specificity beats broad claims

**Global evidence:** lack of specific/concrete detail appears in EP4 verdicts.

**Active rule:**
- Include who/what/tool/action/result details where campaign permits.

**Fix:**
- Add a tool, platform, time, behavior, metric, concrete object, or exact action.

---

### 9. Brand bridge must be earned

**Global evidence:** promotional brand bridge appears across active EP4/OAA/TQ verdicts.

**Active rule:**
- Brand/platform mention must emerge from the exact story pain or argument mechanism.
- Avoid campaign-copy bridges.

**Risk phrases:**
- `That is why @...`
- `This is exactly why @...`
- `@Brand solves this...`
- `makes sense to me` when used as a generic bridge.

**Fix:**
- Story pain -> brand mechanism.
- Argument problem -> protocol mechanism.

---

### 10. Argument must be bold enough for hot take/verdict campaigns

**Global evidence:** not-bold/not-controversial/consensus-wisdom deductions recur.

**Active rule:**
- In verdict/hot-take missions, take a costly stance.
- Do not restate consensus as if it is a verdict.

**Fix:**
- Pick a specific target.
- Name the mechanism of failure/success.
- Use required verdict labels clearly if campaign asks.

---

## TOOL SYNC STATUS

The following tools have been updated or should be interpreted through this baseline:

- `rally-cta-quality-check.py`
- `rally-ep-deduction-map.py`
- `rally-ep-semantic-review.py`
- `rally-tq-format-audit.py`
- `rally-oaa-structure-audit.py`
- `rally-ia-claim-boundary.py`

`rally-global-prior-check.py` is optional diagnostic only. It is not part of the mandatory final gate.
