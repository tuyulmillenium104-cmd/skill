#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TQ format and media audit for Rally content."""
import argparse, json, re, sys, time
from pathlib import Path
BAD_CHARS=["—","–","“","”","‘","’"]
IMG_RE=re.compile(r"https?://\S+\.(?:png|jpg|jpeg|gif|webp)(?:\?\S*)?", re.I)
URL_RE=re.compile(r"https?://\S+", re.I)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--content',required=True)
    ap.add_argument('--out-json',required=True)
    ap.add_argument('--out-md',required=True)
    ap.add_argument('--media-used',action='store_true')
    ap.add_argument('--media-referenced',action='store_true')
    args=ap.parse_args()
    text=Path(args.content).read_text(encoding='utf-8').strip()
    lower=text.lower()
    paras=[p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    words=re.findall(r"\b\w+\b", text)
    errors=[]; warnings=[]
    bad=[ch for ch in BAD_CHARS if ch in text]
    if bad: errors.append(f"bad unicode punctuation: {bad}")
    img=IMG_RE.findall(text)
    if img: errors.append(f"raw image/media URL in body: {img[:3]}")
    urls=URL_RE.findall(text)
    punct_bad=[u for u in urls if u[-1:] in [',','.',')',']']]
    if punct_bad: warnings.append(f"URL may include trailing punctuation: {punct_bad[:3]}")
    if text[:1] in ['@','#']: errors.append('starts with mention/hashtag')
    long_paras=[len(re.findall(r"\b\w+\b", p)) for p in paras if len(re.findall(r"\b\w+\b", p))>70]
    if long_paras: warnings.append(f"dense paragraph(s) >70 words: {long_paras}")
    if len(text)>1600: warnings.append(f"longform >1600 chars: {len(text)}")
    if '@RallyOnChain' in text:
        pos=text.find('@RallyOnChain')/max(1,len(text))*100
        if pos>80: warnings.append(f"mention late/appended risk: {pos:.1f}%")
        if pos<3: errors.append(f"mention too early/start risk: {pos:.1f}%")
    if args.media_used and not args.media_referenced:
        errors.append('media_used=true but media not referenced/explained in text')
    decision='PASS' if not errors else 'FAIL'
    result={'tool':'rally-tq-format-audit.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'contentChars':len(text),'wordCount':len(words),'paragraphs':len(paras),'rawImageUrls':img,'urls':urls,'errors':errors,'warnings':warnings,'decision':decision}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# TQ FORMAT AUDIT\n\n',f'- Content chars: {len(text)}\n',f'- Words: {len(words)}\n',f'- Paragraphs: {len(paras)}\n',f'- Decision: **{decision}**\n\n','## Errors\n']
    md += [f'- {e}\n' for e in errors] or ['- none\n']
    md += ['\n## Warnings\n'] + ([f'- {w}\n' for w in warnings] or ['- none\n'])
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'TQ FORMAT AUDIT: {decision} [{len(errors)} errors, {len(warnings)} warnings]')
    sys.exit(0 if decision=='PASS' else 1)
if __name__=='__main__': main()
