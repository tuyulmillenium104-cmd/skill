#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OPTIONAL DIAGNOSTIC: Global EP4 prior checker.

Uses GLOBAL-EP4-PLAYBOOK as active skill data. Mission-specific data remains higher
priority, but this catches common EP4 risks that may be absent from small mission pools.
"""
import argparse, json, re, sys, time
from pathlib import Path

BAD_MEDIA=re.compile(r"https?://\S+\.(?:png|jpg|jpeg|gif|webp)(?:\?\S*)?", re.I)
GENERIC=['game changer','future of','in today','not just','more than','unlock the full potential','revolutionary','alpha','secret weapon','no brainer','thoughts?','what do you think?']
CTA_VERBS=['choose','tell me','name','reply','comment','visit','check','test','pick','share','compare','show me','route','spend']
CONCRETE=['rlp','gas','campaign','whitelist','verdict','genius','mid','cooked','founder','process','permission','draft','take','judge','consensus','dashboard','apr','yield','risk','restaking','wallet','telegram','docs','screenshots','brief','usdc','app.rally.fun']
MEMORABLE=['cosplay','painted','laundering','access budget','single throat','upstream','receipt','flywheel','keycard','queue position','working fuel','black box','permission slip','leak']

def paras(t): return [p.strip() for p in re.split(r"\n\s*\n", t.strip()) if p.strip()]
def words(t): return re.findall(r"\b\w+\b", t)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--content', required=True)
    ap.add_argument('--global-playbook', default='rally-data/global-active-ep4/global-ep4-playbook.json')
    ap.add_argument('--mission-ep-map', default=None)
    ap.add_argument('--out-json', required=True)
    ap.add_argument('--out-md', required=True)
    args=ap.parse_args()
    text=Path(args.content).read_text(encoding='utf-8').strip()
    tl=text.lower(); ps=paras(text); tail='\n\n'.join(ps[-2:]).lower() if ps else tl
    gp=json.load(open(args.global_playbook, encoding='utf-8')) if Path(args.global_playbook).exists() else {}
    mission=json.load(open(args.mission_ep_map, encoding='utf-8')) if args.mission_ep_map and Path(args.mission_ep_map).exists() else {}
    errors=[]; warnings=[]; passes=[]

    # Global top pressure: CTA/conversation
    has_question='?' in text
    cta_verbs=[v for v in CTA_VERBS if v in tail]
    concrete=[c for c in CONCRETE if c in tail]
    if not cta_verbs:
        errors.append('GLOBAL CTA risk: no behavioral CTA verb detected in ending')
    elif not has_question and not any(v in tail for v in ['visit','check','test']):
        warnings.append('GLOBAL conversation risk: CTA has action but no question/reply path')
    elif not concrete:
        warnings.append('GLOBAL CTA risk: CTA lacks concrete campaign-native object')
    else:
        passes.append('CTA/conversation global prior clear')

    # Hook sharpness
    first=ps[0].lower() if ps else ''
    if not any(x in first for x in ['verdict','cooked','genius','mid','hot take','opinion','most ','the first','by the time','founder','my ']) and '?' not in first:
        warnings.append('GLOBAL hook risk: opener may not contain verdict, contradiction, personal scene, or question')
    else:
        passes.append('Hook global prior clear')

    # Media/TQ
    if BAD_MEDIA.findall(text): errors.append('GLOBAL media risk: raw image/media URL in text')
    else: passes.append('Media global prior clear')

    # Structure/density
    long_paras=[len(words(p)) for p in ps if len(words(p))>75]
    if long_paras: warnings.append(f'GLOBAL structure risk: dense paragraph(s) {long_paras}')
    elif len(text)>1700: warnings.append(f'GLOBAL structure risk: longform length {len(text)} may reduce completion')
    else: passes.append('Structure density global prior clear')

    # Generic/formulaic
    gen=[g for g in GENERIC if g in tl]
    if gen: warnings.append(f'GLOBAL generic/formulaic risk: {gen}')
    else: passes.append('Generic/formulaic global prior clear')

    # Specificity
    conc_all=[c for c in CONCRETE if c in tl]
    if len(conc_all)<3 and len(text)>500: warnings.append('GLOBAL specificity risk: low concrete-detail density')
    else: passes.append('Specificity global prior clear')

    # Value ceiling / memorability
    mem=[m for m in MEMORABLE if m in tl]
    if not mem and len(text)>500:
        warnings.append('GLOBAL value ceiling risk: no named/memorable phrase detected')
    else: passes.append(f'Memorability global prior clear: {mem}')

    # Brand bridge
    if re.search(r"that is why @|this is exactly why @|@\w+ solves|makes sense to me", tl):
        warnings.append('GLOBAL brand bridge risk: possible promotional bridge wording')
    else: passes.append('Brand bridge global prior clear')

    # Argument boldness for verdict/hot take content
    if any(x in tl for x in ['verdict','hot take','opinion','cooked','genius','mid']):
        if not any(x in tl for x in ['cooked','genius','mid','judgment laundering','correlation cosplay','single throat','accountability','overrated','doomed']):
            warnings.append('GLOBAL argument risk: verdict/hot take may not be bold enough')
        else:
            passes.append('Argument boldness global prior clear')

    # Mission map decision can contextualize but not override hard global failures
    mission_unknown=mission.get('unknownClassCount') if mission else None
    if mission and mission.get('decision') != 'PASS':
        errors.append(f'Mission EP map not PASS: {mission.get("decision")}')
    if mission_unknown:
        errors.append(f'Mission EP map has unknown classes: {mission_unknown}')

    decision='FAIL' if errors else ('WARN' if warnings else 'PASS')
    result={'tool':'rally-global-prior-check.py','generated':time.strftime('%Y-%m-%d %H:%M:%S'),'contentChars':len(text),'globalPlaybook':args.global_playbook,'passes':passes,'warnings':warnings,'errors':errors,'decision':decision,'globalTopSubtypes':list((gp.get('subtypeCounts') or {}).items())[:20] if isinstance(gp.get('subtypeCounts'),dict) else []}
    Path(args.out_json).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# GLOBAL PRIOR CHECK\n\n',f'Decision: **{decision}**\n\n','## Errors\n']
    md += [f'- {e}\n' for e in errors] or ['- none\n']
    md += ['\n## Warnings\n'] + ([f'- {w}\n' for w in warnings] or ['- none\n'])
    md += ['\n## Passes\n'] + ([f'- {p}\n' for p in passes] or ['- none\n'])
    Path(args.out_md).write_text(''.join(md),encoding='utf-8')
    print(f'GLOBAL PRIOR CHECK: {decision} [{len(errors)} errors, {len(warnings)} warnings]')
    sys.exit(0 if decision in ['PASS','WARN'] else 1)
if __name__=='__main__': main()
