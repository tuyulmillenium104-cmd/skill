#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Final deliverable integrity checker for Rally workflow.

Prevents stale combined files after content revisions. Enforces Addenda v1.1, v1.6, v1.7.
"""
import argparse, json, re, sys
from pathlib import Path

BAD_CHARS = ["—", "–", "“", "”", "‘", "’"]

def fail(msgs):
    print("FINAL INTEGRITY CHECK: FAIL")
    for m in msgs: print("  FAIL:", m)
    sys.exit(1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--content", required=True)
    ap.add_argument("--combined", required=True)
    ap.add_argument("--compliance-output", default=None)
    ap.add_argument("--rules-output", default=None)
    ap.add_argument("--loser-report", default=None)
    ap.add_argument("--min-qna", type=int, default=0)
    ap.add_argument("--require-url", default=None)
    ap.add_argument("--require-cta-verb", action="store_true")
    ap.add_argument("--cta-report", default=None)
    ap.add_argument("--ep-map", default=None)
    ap.add_argument("--winner-map", default=None)
    ap.add_argument("--tq-report", default=None)
    ap.add_argument("--oaa-report", default=None)
    ap.add_argument("--ia-report", default=None)
    ap.add_argument("--ep-semantic-report", default=None)
    ap.add_argument("--global-prior-report", default=None)
    args = ap.parse_args()

    errs = []
    content = Path(args.content).read_text(encoding="utf-8").strip()
    combined = Path(args.combined).read_text(encoding="utf-8")

    if content not in combined:
        errs.append("combined file does not contain exact current content.txt")

    for ch in BAD_CHARS:
        if ch in combined:
            errs.append(f"bad unicode punctuation found in combined: {repr(ch)}")

    if args.require_url and args.require_url not in content:
        errs.append(f"required URL missing from content: {args.require_url}")

    if args.require_cta_verb:
        verbs = ["reply", "comment", "tell me", "choose", "name", "check", "visit", "learn", "join", "mint", "compare", "pick", "show me", "share"]
        if not any(v in content.lower() for v in verbs):
            errs.append("no direct behavioral CTA verb found")

    if args.compliance_output:
        co = Path(args.compliance_output).read_text(encoding="utf-8", errors="ignore")
        if "COMPLIANCE GATE: ALL BINARY PASS" not in co:
            errs.append("compliance output is not PASS")
        m = re.search(r"ALL BINARY PASS \((\d+) chars\)", co)
        if m and int(m.group(1)) != len(content):
            errs.append(f"compliance char count stale: output={m.group(1)} actual={len(content)}")

    if args.rules_output:
        ro = Path(args.rules_output).read_text(encoding="utf-8", errors="ignore")
        if "SEMUA PASS" not in ro:
            errs.append("rally-rules output is not all-pass")

    if args.loser_report:
        lr = json.load(open(args.loser_report, encoding="utf-8"))
        if lr.get("decision") != "PASS":
            errs.append("loser DNA report decision is not PASS")
        if lr.get("contentChars") is not None and int(lr.get("contentChars")) != len(content):
            errs.append(f"loser DNA report stale: report chars={lr.get('contentChars')} actual={len(content)}")

    q_blocks = len(re.findall(r"\*\*Q-COPY\*\*\s*```text", combined))
    a_blocks = len(re.findall(r"\*\*A-COPY\*\*\s*```text", combined))
    if args.min_qna and (q_blocks < args.min_qna or a_blocks < args.min_qna):
        errs.append(f"QnA blocks below minimum: Q={q_blocks}, A={a_blocks}, min={args.min_qna}")

    # Q/A text blocks length check, excluding main content block by label context is hard; check all Q/A captures.
    pairs = re.findall(r"\*\*Q-COPY\*\*\s*```text\n(.*?)\n```\s*\*\*A-COPY\*\*\s*```text\n(.*?)\n```", combined, flags=re.S)
    for idx, (q,a) in enumerate(pairs, 1):
        if len(q) > 280: errs.append(f"Q{idx} exceeds 280 chars ({len(q)})")
        if len(a) > 280: errs.append(f"A{idx} exceeds 280 chars ({len(a)})")

    required_sections = ["DETAIL KANONIK", "FINAL AUDIT", "LOSER-DNA", "JUDGE-VARIANCE"]
    for sec in required_sections:
        if sec.lower() not in combined.lower():
            errs.append(f"required section missing: {sec}")


    # Optional adaptive reports must exist, be PASS where applicable, and match current content chars if available.
    for label, path, requires_pass in [
        ("cta", args.cta_report, True), ("tq", args.tq_report, True),
        ("oaa", args.oaa_report, True), ("ia", args.ia_report, True), ("ep_semantic", args.ep_semantic_report, True)]:
        if path:
            data = json.load(open(path, encoding="utf-8"))
            if requires_pass and data.get("decision") != "PASS":
                errs.append(f"{label} report decision is not PASS")
            if data.get("contentChars") is not None and int(data.get("contentChars")) != len(content):
                errs.append(f"{label} report stale: report chars={data.get('contentChars')} actual={len(content)}")
    for label, path in [("ep_map", args.ep_map), ("winner_map", args.winner_map)]:
        if path and not Path(path).exists():
            errs.append(f"required adaptive report missing: {label} {path}")
        elif path and label == "ep_map":
            data = json.load(open(path, encoding="utf-8"))
            if data.get("decision") and data.get("decision") != "PASS":
                errs.append(f"EP deduction map decision is not PASS: {data.get('decision')}")
            if data.get("unknownClassCount", 0):
                errs.append(f"EP deduction map has unresolved unknown classes: {data.get('unknownClassCount')}")


    if args.global_prior_report:
        data = json.load(open(args.global_prior_report, encoding="utf-8"))
        if data.get("decision") == "FAIL":
            errs.append("global prior report decision is FAIL")
        if data.get("contentChars") is not None and int(data.get("contentChars")) != len(content):
            errs.append(f"global prior report stale: report chars={data.get('contentChars')} actual={len(content)}")

    if errs: fail(errs)
    print(f"FINAL INTEGRITY CHECK: PASS (content {len(content)} chars, Q={q_blocks}, A={a_blocks})")
    sys.exit(0)

if __name__ == "__main__":
    main()
