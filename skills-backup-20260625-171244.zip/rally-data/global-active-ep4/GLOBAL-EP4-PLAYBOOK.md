# GLOBAL EP4 / EP<5 PLAYBOOK

Generated: 2026-06-25 16:19:12

Active campaigns mined: **24**  
EP nonmax verdicts: **7466**  
Deduction sentences: **51527**

## Subtype Counts

| Subtype | Count |
|---|---:|
| cta.other | 9508 |
| hook.not_sharp | 8273 |
| media.raw_or_unintegrated | 6760 |
| conversation.other | 6424 |
| value.other | 4049 |
| structure.formatting | 4011 |
| specificity.missing | 3186 |
| generic.formulaic | 2835 |
| structure.dense_or_long | 2789 |
| cta.no_direct_prompt | 2353 |
| brand.promotional_bridge | 2037 |
| external.reach_metrics | 1992 |
| semantic.other_deduction | 1901 |
| value.solid_not_exceptional | 1606 |
| cta.no_reply_path | 1093 |
| cta.generic_or_soft | 1051 |
| conversation.limited | 753 |
| semantic.reviewed_misc | 752 |
| structure.other | 674 |
| argument.evidence_gap | 414 |
| generic.ai_or_polished | 371 |
| brand.other | 363 |
| conversation.niche_or_narrow | 293 |
| value.underdeveloped | 169 |
| argument.not_bold_enough | 34 |
| rq.no_or_generic_replies | 30 |

## Operational Rules by Top Subtype

### cta.other (9508)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @jemmie1155431 EP4.0: the strong opinion on empty NFT projects and the personal campaign result naturally invite discussion and debate, though incorporating a direct question could further amplify reply rates.
- Wingston NFT Utility @ahonjumaidil EP4.0: Conversation potential is strong due to the merit-versus-follower-count comparison, which naturally invites debate, quotes, and shares from creators frustrated by traditional platforms.
- Wingston NFT Utility @ahonjumaidil EP4.0: The primary area for improvement is the call-to-action quality;
- Wingston NFT Utility @marilynnhopkin5 EP4.0: Conversation potential is above average because the final question invites opinions and frames a comparison rather than a yes/no response.
- Wingston NFT Utility @elliederler2 EP4.0: The call-to-action is implicit but compelling through the final rhetorical question that invites personal reflection.

### hook.not_sharp (8273)
Rule: Open with verdict, contradiction, concrete pain, or specific scene.

- Wingston NFT Utility @jemmie1155431 EP4.0: The hook is highly effective, leveraging personal experience and a contrarian take on typical free mints to immediately capture attention and establish credibility.
- Wingston NFT Utility @ahonjumaidil EP4.0: The tweet excels in hook effectiveness by opening with a highly relatable creator pain point regarding algorithmic opacity, immediately establishing relevance and curiosity.
- Wingston NFT Utility @__allend__ EP4.0: The tweet demonstrates high engagement potential by utilizing a strong contrast hook that differentiates 'Wingston' from generic NFT projects.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: Content structure is good overall: short opening line, spaced paragraphs, and a concluding question make it readable despite the longform length.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: Overall, this is a thoughtful, on-brief tweet with a strong hook and useful explanation, but its niche subject matter and moderately dense structure keep it from top-tier viral engagement potential.

### media.raw_or_unintegrated (6760)
Rule: No raw media URL. If media used, native and referenced.

- Wingston NFT Utility @jemmie1155431 EP4.0: The hook is highly effective, leveraging personal experience and a contrarian take on typical free mints to immediately capture attention and establish credibility.
- Wingston NFT Utility @ahonjumaidil EP4.0: The tweet excels in hook effectiveness by opening with a highly relatable creator pain point regarding algorithmic opacity, immediately establishing relevance and curiosity.
- Wingston NFT Utility @ahonjumaidil EP4.0: while it successfully directs users to app.rally.fun and meets the mission requirements, the phrasing ('this is worth looking at') is slightly passive rather than a direct imperative, which may reduce immediate click-through urgency.
- Wingston NFT Utility @__allend__ EP4.0: One minor area for improvement is the lack of visual media to accompany the text, but the strong quote-tweet integration compensates for this by providing context.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: It immediately frames the NFT as functional rather than speculative, which is a compelling angle.

### conversation.other (6424)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @jemmie1155431 EP4.0: Conversation potential is solid;
- Wingston NFT Utility @ahonjumaidil EP4.0: Value delivery is excellent, clearly explaining Rally's transparent scoring mechanics and the Wingston NFT's utility boost while maintaining an authentic, conversational tone that aligns perfectly with the campaign style.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: This tweet has solid engagement potential and aligns well with the campaign brief.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: That said, the topic is somewhat niche, so discussion may stay limited to users already interested in Web3, NFTs, or Rally.
- Wingston NFT Utility @xiaoming_web3 EP4.0: Conversation Potential: Moderate;

### value.other (4049)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @jemmie1155431 EP4.0: Value delivery is high, as it clearly articulates tangible, non-speculative benefits for creators, making it highly bookmarkable for the target audience.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: Value delivery is strong because the tweet clearly explains why Wingston matters, highlights its free mint and practical utility, and gives readers a reason to remember or save the post if they are considering joining Rally.
- Wingston NFT Utility @_dripxel EP4.0: The value delivery is clear: a free mint opportunity and a path to earn from existing X content.
- Wingston NFT Utility @xiaoming_web3 EP4.0: Value Delivery: High;
- Wingston NFT Utility @xiaoming_web3 EP4.0: clearly explains multiple tangible utilities (free mint, VIP community access, Rally Score boost, daily RLP staking) while strictly avoiding ROI promises, providing strong, bookmark-worthy educational value.

### structure.formatting (4011)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @__allend__ EP4.0: One minor area for improvement is the lack of visual media to accompany the text, but the strong quote-tweet integration compensates for this by providing context.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: Content structure is good overall: short opening line, spaced paragraphs, and a concluding question make it readable despite the longform length.
- Wingston NFT Utility @shinyviq EP4.0: The structure is digestible, using line breaks to separate the problem, the solution, and the call-to-action.
- Wingston NFT Utility @jimmyshequ EP4.0: The content is long-form without formatting breaks (no bullet points or emojis), making it less scannable.
- Wingston NFT Utility @jimmyshequ EP4.0: Overall, it's an authentic, informative post with good engagement potential, though it could benefit from stronger opening and better formatting.

### specificity.missing (3186)
Rule: Add who/what/when/tool/action/result details.

- Wingston NFT Utility @__allend__ EP4.0: The Call-to-Action is direct and open-ended, inviting specific feedback on utility preferences, which is a proven driver for reply-count growth.
- Wingston NFT Utility @elliederler2 EP4.0: Value delivery is strong by explaining concrete utilities tied to platform success, making it informational for creators.
- Wingston NFT Utility @_dripxel EP4.0: However, the tweet slightly oversells by framing it as 'where that effort starts to compound' without a concrete, personal example, which could feel promotional.
- Wingston NFT Utility @0x_4444 EP4.0: The value delivery is high for creators looking for exposure, but the conversation potential could be improved by asking a more specific question to the audience rather than a general invitation to talk.
- Wingston NFT Utility @luke102579 EP4.0: It invites action but does not strongly prompt replies, reposts, or specific engagement behaviors beyond clicking/joining.

### generic.formulaic (2835)
Rule: Name a fresh category or use a concrete lived mechanism.

- Wingston NFT Utility @__allend__ EP4.0: The tweet demonstrates high engagement potential by utilizing a strong contrast hook that differentiates 'Wingston' from generic NFT projects.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: However, the earlier instruction to "join 3 campaigns, aim for the whitelist" may feel slightly directive and less natural for broader audiences unfamiliar with Rally.
- Wingston NFT Utility @elliederler2 EP4.0: The hook effectively grabs attention by contrasting common NFT disappointment with a 'different' drop, creating curiosity.
- Wingston NFT Utility @elliederler2 EP4.0: The absence of generic phrasing and avoidance of promised ROI aligns with campaign style.
- Wingston NFT Utility @shinyviq EP4.0: While the CTA is clear, the 'GM CT' opening is slightly generic, and the conversation potential could be enhanced by asking a direct question to the audience.

### structure.dense_or_long (2789)
Rule: Use short paragraphs and remove non-essential explanatory drag.

- Wingston NFT Utility @marilynnhopkin5 EP4.0: Content structure is good overall: short opening line, spaced paragraphs, and a concluding question make it readable despite the longform length.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: Still, at 111 words and 593 characters, it is somewhat dense for a tweet, which may reduce completion rate.
- Wingston NFT Utility @marilynnhopkin5 EP4.0: Overall, this is a thoughtful, on-brief tweet with a strong hook and useful explanation, but its niche subject matter and moderately dense structure keep it from top-tier viral engagement potential.
- Wingston NFT Utility @elliederler2 EP4.0: Minor deduction for not explicitly stating the 'free mint' aspect in the text (though it's implied by 'free mints'), and the longform nature may slightly limit quick engagement.
- Wingston NFT Utility @luke102579 EP4.0: Overall: Strong alignment and decent readability/value, but limited discussion prompts and a somewhat soft CTA reduce its maximum engagement potential.

### cta.no_direct_prompt (2353)
Rule: Always include a direct behavioral CTA unless format forbids it.

- Wingston NFT Utility @xiaoming_web3 EP4.0: the tweet lacks a direct, actionable CTA or explicit invitation to click, reply, or mint, relying instead on implied value and a concluding statement.
- Wingston NFT Utility @huangyu31085955 EP4.0: while it encourages creators not to miss out and suggests getting a WL, it lacks a direct instruction or link for the audience to take the next step.
- Wingston NFT Utility @lamide_nova EP4.0: While the tweet lacks a direct, link-based CTA, the closing rhetorical question ('So what exactly is the excuse?') successfully drives conversation potential by prompting replies and challenging reader skepticism.
- Wingston NFT Utility @toimurb97512 EP4.0: The closing question successfully prompts discussion but lacks a direct, actionable invitation for creators to join Rally or participate in the free mint, which limits alignment with the campaign's conversion goal.
- Wingston NFT Utility @dreybaba1234 EP4.0: while the premise invites creator interest, it lacks a direct question or explicit prompt to spark replies and shares.

### brand.promotional_bridge (2037)
Rule: Brand bridge must emerge from exact story/argument pain.

- Wingston NFT Utility @shinyviq EP4.0: However, the high reply-to-impression ratio (57 replies to 326 impressions) indicates very strong engagement and community trust.
- Wingston NFT Utility @_dripxel EP4.0: However, the tweet slightly oversells by framing it as 'where that effort starts to compound' without a concrete, personal example, which could feel promotional.
- Wingston NFT Utility @luke102579 EP4.0: This tweet has moderate-to-strong engagement potential, but it is more persuasive/promotional than conversation-driven.
- Wingston NFT Utility @luke102579 EP4.0: One limitation is that it reads partly like campaign content, so some readers may discount its value as promotional.
- Wingston NFT Utility @meo_testnet EP4.0: It is more educational than promotional, which helps credibility.

### external.reach_metrics (1992)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @shinyviq EP4.0: However, the high reply-to-impression ratio (57 replies to 326 impressions) indicates very strong engagement and community trust.
- Wingston NFT Utility @voice_zuba91656 EP4.0: The metrics (14 replies, 13 likes) indicate good engagement relative to impressions.
- Wingston NFT Utility @yeyoucao EP4.0: However, engagement potential is slightly limited by the lack of visual media or hashtags, which could improve discoverability, and the niche crypto/NFT focus may not resonate with a broader audience.
- Wingston NFT Utility @dreybaba1234 EP4.0: Overall, it is a well-crafted, mission-aligned post with solid engagement potential, particularly for awareness and referral clicks, but would benefit from a more urgent CTA and an interactive question to drive higher discussion metrics.
- Wingston NFT Utility @0xric9 EP4.0: Performance metrics show 4 bookmarks from 2,215 impressions, indicating strong save-worthy content, though reply and quote counts suggest room for improvement in driving conversation.

### semantic.other_deduction (1901)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @meo_testnet EP4.0: However, it does not directly push readers to join Rally as strongly as it could.
- Wingston NFT Utility @srinigoes EP4.0: The content aligns perfectly with the campaign goal of explaining utility while maintaining an authentic, enthusiast voice.
- Wingston NFT Utility @amir1339216rkt EP4.0: it could be more compelling by framing the invitation around community collaboration rather than just securing a whitelist spot.
- Wingston NFT Utility @ros1_crypto EP4.0: However, it is more thoughtful than punchy, so it may not stop fast scrollers as strongly as a sharper or more surprising first line would.
- Wingston NFT Utility @manchoice1 EP4.0: The personal story occasionally risks overshadowing the product message, but the transition back to Wingston is handled well.

### value.solid_not_exceptional (1606)
Rule: Add a named lens, surprising mechanism, or memorable phrase.

- Wingston NFT Utility @jimmyshequ EP4.0: The tweet delivers solid value by clearly explaining Wingston's utility (Rally Score boost, daily RLP staking, VIP access) and differentiating it from typical NFTs.
- Wingston NFT Utility @amir1339216rkt EP4.0: Value delivery is solid, clearly outlining concrete benefits like the Rally Score boost and daily RLP staking while adhering to campaign guidelines by avoiding ROI promises.
- Wingston NFT Utility @amage17463 EP4.0: Hook effectiveness is moderate: the opening, "I’ve been digging into Wingston a bit more," is personal and credible, but it is not especially punchy or curiosity-driven, so it may not stop scrolling as strongly as a sharper lead.
- Wingston NFT Utility @0xqzivo EP4.0: There is only a light call-to-action at the end ('Join @RallyOnChain, participate in campaigns...'), and it is functional but not especially inviting or interactive.
- Wingston NFT Utility @renkkkt EP4.0: The CTA is decent but not especially strong.

### cta.no_reply_path (1093)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @amir1339216rkt EP4.0: The primary weakness lies in conversation potential, as the thread functions as a one-way broadcast without open-ended questions or explicit prompts to encourage replies and discussion.
- Wingston NFT Utility @ros1_crypto EP4.0: 'If you're already creating content on Rally, it's worth understanding how Wingston fits into the ecosystem' encourages interest, but it does not explicitly invite replies, shares, or signups in a highly actionable way.
- Wingston NFT Utility @cayairdropx EP4.0: Conversation potential is limited as the post is primarily informational and does not pose a question or explicitly invite opinions, though the targeted mention of 'consumer crypto' and 'creator economy' may naturally prompt niche discussions from qualified users.
- Wingston NFT Utility @anhtunbi536660 EP4.0: The post informs and persuades, but it does not explicitly invite replies, reposts, clicks, or creator signups.
- Wingston NFT Utility @xavage_prince EP3.0: Still, the tweet does not pose a question or a controversial take that would naturally spark replies.

### cta.generic_or_soft (1051)
Rule: Avoid generic/soft prompts. Use campaign-native choice or personal experience CTA.

- Wingston NFT Utility @jemmie1155431 EP4.0: The CTA is authentic and perfectly aligned with the campaign's requested conversational tone, though it leans slightly soft ('worth checking out') rather than explicitly directive.
- Wingston NFT Utility @0x_4444 EP4.0: However, the Call-to-Action is soft ('welcome everyone to discuss'), which limits the sense of urgency.
- Wingston NFT Utility @luke102579 EP4.0: However, the CTA is somewhat soft.
- Wingston NFT Utility @luke102579 EP4.0: Overall: Strong alignment and decent readability/value, but limited discussion prompts and a somewhat soft CTA reduce its maximum engagement potential.
- Wingston NFT Utility @ros1_crypto EP4.0: The call to action is present but soft.

### conversation.limited (753)
Rule: Add a reply path that asks for a specific memory, choice, or disagreement.

- Wingston NFT Utility @ros1_crypto EP4.0: Conversation potential is limited.
- Wingston NFT Utility @cayairdropx EP4.0: Conversation potential is limited as the post is primarily informational and does not pose a question or explicitly invite opinions, though the targeted mention of 'consumer crypto' and 'creator economy' may naturally prompt niche discussions from qualified users.
- Wingston NFT Utility @xamiguo EP4.0: Overall, this is a credible, well-structured quote tweet with good informational value and moderate conversation potential, but it could be stronger with a sharper hook or a more direct engagement prompt.
- Wingston NFT Utility @stsweet007 EP3.0: Conversation potential is limited as there's no direct question or controversial take to spark debate;
- Wingston NFT Utility @shin_ptc EP3.0: Conversation potential is limited without questions or prompts.

### semantic.reviewed_misc (752)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @__allend__ EP4.0: The content feels authentic and avoids the 'hype-beast' tropes often found in Web3, making it more relatable to serious creators.
- Wingston NFT Utility @luke102579 EP4.0: It is also likely somewhat bookmarkable for those exploring Rally later.
- Wingston NFT Utility @ros1_crypto EP4.0: Wingston feels like the opposite.' That framing creates curiosity and gives readers a reason to continue.
- Wingston NFT Utility @olorunfemi12344 EP4.0: Its biggest limitation is that it does not actively drive interaction beyond reading and clicking.
- Wingston NFT Utility @ola3803 EP4.0: Despite this minor conversion gap, the authentic tone and clear utility focus make it highly likely to drive meaningful community interaction.

### structure.other (674)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @membervic1506 EP4.0: Overall, it effectively fulfills the mission requirements while maintaining an authentic, informative tone.
- Wingston NFT Utility @32manb EP4.0: The structure is clean with good use of spacing, making it digestible.
- Wingston NFT Utility @anhtunbi536660 EP4.0: Content structure is good.
- Wingston NFT Utility @furkaggn EP3.0: As a quote tweet, it builds on existing content but feels more informative than interactive.
- Wingston NFT Utility @web3chidex EP3.0: The tweet also lacks bookmark-worthy elements like lists, steps, or exclusive information.

### argument.evidence_gap (414)
Rule: Review evidence and create mission-specific avoidance rule.

- Wingston NFT Utility @shinyviq EP4.0: High conversation potential through personal proof and ecosystem explanation, though the quoted post format slightly reduces originality.
- Wingston NFT Utility @yaayeuhh85021 EP4.0: Formatting with line breaks and a quoted image supports readability.
- Wingston NFT Utility @0xmists EP4.0: By quoting the official announcement and mentioning @RallyOnChain, it leverages social proof while directing attention to the larger conversation.
- Wingston NFT Utility @0xqzivo EP4.0: It also feels more specific than generic AI-style copy, which supports authenticity.
- Wingston NFT Utility @anhtunbi536660 EP4.0: It reads more like a thoughtful personal take than an ad, which supports authenticity.
